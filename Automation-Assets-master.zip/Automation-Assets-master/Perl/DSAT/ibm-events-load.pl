#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Events File Load (Import)
### Date:		June 23, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("EVENTS LOAD/UPDATE");

die "You must provide an EVENTS Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkEV	 				= ();	# hash table to lookup EVENT already in the database

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $IndexDelimit = '^';

my $iSqlErr	= 0;
my $iSqlEVInsert = 0;
my $iSqlEVUpdate = 0;
my $iDataErrors = 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		print "******* LKU LOC: " . $cd . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
	}
}

if ((grep { /event/ } @dbTables) == 0) {
	print "Table: event not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT name, location_id, id FROM `" . $main::IDB_NAME . "`.`event`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $name = $refr[0];
		my $loc = $refr[1];
		my $lkey = $loc . $name;
		$lkEV{$lkey}{id} = $refr[2]; # the id table index is the data
		print "******* LKU EV: " . $name . " key: " . $lkEV{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet = "";
my $keycount = 0;
my $TotalHeaders	= 2;
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min=0;
my $row_max=0;
my $col_min=0;
my $col_max=0;

### MAIN WSIB_Servers worksheet
my $worksheet = $workbook->worksheet(0);

if (!defined($worksheet)) {
	$dbh->disconnect();
	die "ERROR -- Events Worksheet not found.\n";
}

## remove all of the old MASTER errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='events';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

$current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
( $row_min, $row_max ) = $worksheet->row_range();
( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

$keycount = 0;
$TotalHeaders	= 10;	# total number of column headers we need to find in this worksheet to proceed with processing
%xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 2;

for my $row ( $row_min .. $row_max ) {
	$iExcelRows++; # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if ( $fld =~ m/wavesequence/i ) {
				$xlsCol{wavesequence} = $col;
				$keycount++;
			} elsif ( $fld =~ m/eventname/i ) {
				$xlsCol{eventname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/sourcedc/i ) {
				$xlsCol{srcloccode} = $col;
				$keycount++;
			} elsif ( $fld =~ m/targetdc/i ) {
				$xlsCol{tgtloccode} = $col;
				$keycount++;
			} elsif ( $fld =~ m/eventdesc/i ) {
				$xlsCol{eventdesc} = $col;
				$keycount++;
			} elsif ( $fld =~ m/nonprdcut/i ) {
				$xlsCol{nonprodcutover} = $col;
				$keycount++;
			} elsif ( $fld =~ m/prodcut/i ) {
				$xlsCol{prodcutover} = $col;
				$keycount++;
			} elsif ( $fld =~ m/contingencycut/i ) {
				$xlsCol{contingencycutover} = $col;
				$keycount++;
			} elsif ( $fld =~ m/notes/i ) {
				$xlsCol{notes} = $col;
				$keycount++;
			} elsif ( $fld =~ m/riskfactor/i ) {
				$xlsCol{riskfactor} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		# NEW CODE TO LOCALIZE ROW VALUES
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if $cell;
		}
		my $XLRow = $row + 1; # the Excel row for error reporting

		# clean up the values to assure clean db queries
		$xlsRowVal{wavesequence} = trim(substr($xlsRowVal{wavesequence},0,10));
		$xlsRowVal{eventname} = trim(substr($xlsRowVal{eventname},0,255));
		$xlsRowVal{srcloccode} = trim(substr($xlsRowVal{srcloccode},0,255));
		$xlsRowVal{tgtloccode} = trim(substr($xlsRowVal{tgtloccode},0,255));
		$xlsRowVal{eventdesc} = trim(substr($xlsRowVal{eventdesc},0,255));
		$xlsRowVal{nonprodcutover} = trim(substr($xlsRowVal{nonprodcutover},0,30));
		$xlsRowVal{prodcutover} = trim(substr($xlsRowVal{prodcutover},0,30));
		$xlsRowVal{contingencycutover} = trim(substr($xlsRowVal{contingencycutover},0,30));
		$xlsRowVal{notes} = trim(substr($xlsRowVal{notes},0,1024));
		$xlsRowVal{riskfactor} = trim(substr($xlsRowVal{riskfactor},0,10));

		# SET UP THE SQL CODE FOR INSERT OR UPDATE
		my $assetSrcID = (exists($lkLOC{$xlsRowVal{srcloccode}})) ? $lkLOC{$xlsRowVal{srcloccode}}{id} : "";
		my $assetTgtID = (exists($lkLOC{$xlsRowVal{tgtloccode}})) ? $lkLOC{$xlsRowVal{tgtloccode}}{id} : "";

		if ($assetSrcID eq "" || $assetTgtID eq "") {
			$iDataErrors++;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'events\',\n";
			$sql .= "   errorlog = \'EVENTS row (". $XLRow .") has an INVALID source or target location.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
			next; # skip the rest of processing on this record
		}

		my $assetWaveSeq = ($xlsRowVal{wavesequence} ne "" && looks_like_number($xlsRowVal{wavesequence}) ) ? $xlsRowVal{wavesequence} : "";
		if ($assetWaveSeq eq "") {
			$iDataErrors++;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'events\',\n";
			$sql .= "   errorlog = \'EVENTS row (". $XLRow .") has an INVALID wave sequence number.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
			next; # skip the rest of processing on this record
		}

		my $assetEventName = $xlsRowVal{eventname};
		if ($assetEventName eq "") {
			$iDataErrors++;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'events\',\n";
			$sql .= "   errorlog = \'EVENTS row (". $XLRow .") Event Name is BLANK.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
			next; # skip the rest of processing on this record
		}

		## Data is good for SQL insert/update
		my $sqlcoldata = "   location_id = ". $assetSrcID . ",\n";
		$sqlcoldata .= "   tgtlocation_id = ". $assetTgtID . ",\n";
		$sqlcoldata .= "   name = \'". $assetEventName . "\',\n";
		$sqlcoldata .= "   wavesequence = ". $assetWaveSeq . ",\n";
		$sqlcoldata .= "   description = " . (($xlsRowVal{eventdesc} ne "") ? "\'". $xlsRowVal{eventdesc} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   nonprod_cutover = " . (($xlsRowVal{nonprodcutover} ne "") ? "\'". $xlsRowVal{nonprodcutover} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   cutover = " . (($xlsRowVal{prodcutover} ne "") ? "\'". $xlsRowVal{prodcutover} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   contingency_cutover = " . (($xlsRowVal{contingencycutover} ne "") ? "\'". $xlsRowVal{contingencycutover} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   notes = " . (($xlsRowVal{notes} ne "") ? "\'". $xlsRowVal{notes} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   riskfactor = ". (($xlsRowVal{riskfactor} ne "" && looks_like_number($xlsRowVal{riskfactor})) ? $xlsRowVal{riskfactor} : "NULL") . ",\n";

		my $lkey = $assetSrcID . $assetEventName;
		if (exists($lkEV{$lkey})) {
			$sql = "UPDATE `" . $main::IDB_NAME . "`.`event` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
			$sql .= "   WHERE id = " . $lkEV{$lkey}{id} . ";\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
			} else {
				$iSqlEVUpdate++;
			}
		} else { # insert
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`event` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlEVInsert++;
				## create a new hash element
				$lkEV{$lkey}{id} = $dbh->{mysql_insertid};
			}
		}
	} # end if headers have all been found
} # end for row

## update rows
$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-events-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "EV Inserts\t:" . $iSqlEVInsert . "\n";
print "EV Updates\t:" . $iSqlEVUpdate . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
