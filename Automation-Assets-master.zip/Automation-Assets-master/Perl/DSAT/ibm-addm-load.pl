#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	ADDM File Load (Import)
### Date:		June 18, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 6/17/2020 - Revamp the code to gain some efficiency and handle serial number missing bug
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("OPS INVENTORY LOAD/UPDATE");

die "You must provide an ADDM Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkGIP	 				= ();	# hash table to lookup Global IP addresses already in the database
my %lkOS	 				= ();	# hash table to lookup OS already in the database
my %lkADSW				= ();	# hash table to link ADDM SW records from ADDM
my %lkADIP				= ();	# hash table to link ADDM IP records from ADDM
my %lkADDM 				= ();	# hash table to lookup ADDM records already in the database
my %lkADDMSW			= ();	# hash table to lookup ADDM sw records already in the database
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my @FSUBS					= (); # array for fast IP to subnet validation

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr	= 0;
my $iSqlADDMInsert = 0;
my $iSqlADDMUpdate = 0;
my $iSqlADDMSWInsert = 0;
my $iSqlADIPInsert = 0;
my $iSqlADSWInsert = 0;
my $iSqlIPInsert 	= 0;
my $iSqlIPNotFound = 0;
my $iSqlIPUpdate = 0;
my $iSqlNotifyInsert = 0;
#my $iDataErrors = 0;

my $IndexDelimit = '^';

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		print "******* LKU LOC: " . $cd . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
	}
}

if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), location_id, id, inuse, inaddm FROM `" . $main::IDB_NAME . "`.`ipadd`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $fip = $refr[0];
		if (!exists($lkGIP{$fip})) {
			$lkGIP{$fip}{location_id} = (defined($refr[1]) ? $refr[1] : "");
			$lkGIP{$fip}{id} = $refr[2];
			$lkGIP{$fip}{inuse} = (defined($refr[3]) ? $refr[3] : 0);
			$lkGIP{$fip}{inaddm} = (defined($refr[4]) ? $refr[4] : 0);
		}
		print "******* LKU GIP: fip=" . $fip . " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## New code 2/19/20 - Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

if ((grep { /addm/ } @dbTables) == 0) {
	print "Table: addm not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, name, type, product, manufacturer, serialnum, admos_id, cpu, createdate, modifydate FROM `" . $main::IDB_NAME . "`.`addm`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ciname = $refr[1]; ## ciname
		$lkADDM{$ciname}{id} = $refr[0]; ## add the id here indicating it's on file
		$lkADDM{$ciname}{type} = (defined($refr[2]) ? $refr[2] : "");
		$lkADDM{$ciname}{productname} = (defined($refr[3]) ? $refr[3] : "");
		$lkADDM{$ciname}{manufacturer} = (defined($refr[4]) ? $refr[4] : "");
		$lkADDM{$ciname}{serialnum} = (defined($refr[5]) ? $refr[5] : "");
		$lkADDM{$ciname}{admos_id} = (defined($refr[6]) ? $refr[6] : "");
		$lkADDM{$ciname}{cpu} = (defined($refr[7]) ? $refr[7] : "");
		$lkADDM{$ciname}{createdate} = (defined($refr[8]) ? $refr[8] : "");
		$lkADDM{$ciname}{modifydate} = (defined($refr[9]) ? $refr[9] : "");
		@{$lkADDM{$ciname}{ip_keys}} = (); # array
		%{$lkADDM{$ciname}{sw}} = (); # hash
		print "******* LKU ADDM: (" . $lkADDM{$ciname}{id} . ") lkey: " . $ciname . "\n" if ($DEBUGSQL); # debug sql
	}
}

## Load the software table
if ((grep { /addmsw/ } @dbTables) == 0) {
	print "Table: addmsw not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, product, type, modelver FROM `" . $main::IDB_NAME . "`.`addmsw`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $swkey = (defined($refr[2]) ? $refr[2] : "") . $IndexDelimit . (defined($refr[1]) ? $refr[1] : "") . $IndexDelimit . (defined($refr[3]) ? $refr[3] : "");
		$lkADDMSW{$swkey}{id} = $refr[0]; ## add the id here indicating it's on file
		print "******* LKU ADDMSW: (" . $lkADDMSW{$swkey}{id} . ") lkey: " . $swkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## remove all of the old ADDM errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='addm';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

## rebuild these relationship tables on each run
$result = $dbh->do("TRUNCATE `" . $main::IDB_NAME . "`.`adiprel`;");
$result = $dbh->do("TRUNCATE `" . $main::IDB_NAME . "`.`adswrel`;");

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet = "";
my $keycount = 0;
my $TotalHeaders	= 2;
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min=0;
my $row_max=0;
my $col_min=0;
my $col_max=0;

### MAIN WSIB_Servers worksheet
my $worksheet = $workbook->worksheet(0);

if (!defined($worksheet)) {
	$dbh->disconnect();
	die "ERROR -- Worksheet 0 not found.\n";
}

$current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
( $row_min, $row_max ) = $worksheet->row_range();
( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

$keycount = 0;
$TotalHeaders	= 11;	# total number of column headers we need to find in this worksheet to proceed with processing
%xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 2;

for my $row ( $row_min .. $row_max ) { # loop through the Excel rows
	$iExcelRows++ if ($row <= $row_max); # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if ( $fld =~ m/ci name/i && !($fld =~ m/system/i) ) {
				$xlsCol{ciname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/tier 1/i ) {
				$xlsCol{tier1} = $col;
				$keycount++;
			} elsif ( $fld =~ m/tier 2/i ) {
				$xlsCol{tier2} = $col;
				$keycount++;
			} elsif ( $fld =~ m/tier 3/i ) {
				$xlsCol{tier3} = $col;
				$keycount++;
			} elsif ( $fld =~ m/product name/i ) {
				$xlsCol{productname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/model/i && $fld =~ m/version/i  ) {
				$xlsCol{modelver} = $col;
				$keycount++;
			} elsif ( $fld =~ m/manufacturer/i ) {
				$xlsCol{manufacturer} = $col;
				$keycount++;
			} elsif ( $fld =~ m/serial number/i ) {
				$xlsCol{serialnum} = $col;
				$keycount++;
			} elsif ( $fld =~ m/create/i && $fld =~ m/date/i  ) {
				$xlsCol{createdate} = $col;
				$keycount++;
			} elsif ( $fld =~ m/modified/i && $fld =~ m/date/i  ) {
				$xlsCol{modifydate} = $col;
				$keycount++;
			} elsif ( $fld =~ m/system/i && $fld =~ m/ci name/i  ) {
				$xlsCol{sysciname} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {

		# NEW CODE TO LOCALIZE ROW VALUES
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if ($row <= $row_max && $cell); # leave as blank if we are on the row beyond row_max
		}

		## Fix the data so it's normalized and ready to insert:
		$xlsRowVal{ciname} = substr($xlsRowVal{ciname},0,255);
		$xlsRowVal{tier1} = substr($xlsRowVal{tier1},0,255);
		$xlsRowVal{tier2} = substr($xlsRowVal{tier2},0,255);
		$xlsRowVal{tier3} = substr($xlsRowVal{tier3},0,255);
		$xlsRowVal{productname} = substr($xlsRowVal{productname},0,255);
		$xlsRowVal{manufacturer} = substr($xlsRowVal{manufacturer},0,255);
		$xlsRowVal{modelver} = substr($xlsRowVal{modelver},0,255);
		$xlsRowVal{serialnum} = substr($xlsRowVal{serialnum},0,255);
		$xlsRowVal{createdate} = substr($xlsRowVal{createdate},0,255);
		$xlsRowVal{modifydate} = substr($xlsRowVal{modifydate},0,255);
		$xlsRowVal{sysciname} = substr($xlsRowVal{sysciname},0,255);

		my $XLRow = $row + 1; # the Excel row for error reporting

		if ($xlsRowVal{sysciname} ne "" && !exists($lkADDM{$xlsRowVal{sysciname}})) {
			my $ciname = $xlsRowVal{sysciname};
			## set up a new blank object -- will be used later for SQL
			$lkADDM{$ciname}{id} = "";
			$lkADDM{$ciname}{type} = "";
			$lkADDM{$ciname}{productname} = "";
			$lkADDM{$ciname}{manufacturer} = "";
			$lkADDM{$ciname}{serialnum} = "";
			$lkADDM{$ciname}{admos_id} = "";
			$lkADDM{$ciname}{cpu} = 0;
			$lkADDM{$ciname}{createdate} = "";
			$lkADDM{$ciname}{modifydate} = "";
			@{$lkADDM{$ciname}{ip_keys}} = (); # array
			%{$lkADDM{$ciname}{sw}} = (); # hash
		}
		if ($xlsRowVal{sysciname} ne "" && exists($lkADDM{$xlsRowVal{sysciname}})) { ## we have created a base object for this sysciname
			if ($xlsRowVal{tier1} =~ m/it hardware/i && ($xlsRowVal{tier2} =~ m/server/i || $xlsRowVal{tier2} =~ m/network/i)) { ## this is a new server or network record
				$lkADDM{$xlsRowVal{sysciname}}{cpu} = 0;
				$lkADDM{$xlsRowVal{sysciname}}{productname} = $xlsRowVal{productname};
				$lkADDM{$xlsRowVal{sysciname}}{manufacturer} = $xlsRowVal{manufacturer};
				$lkADDM{$xlsRowVal{sysciname}}{createdate} = $xlsRowVal{createdate};
				$lkADDM{$xlsRowVal{sysciname}}{modifydate} = $xlsRowVal{modifydate};
				$lkADDM{$xlsRowVal{sysciname}}{serialnum} = ""; # default
				$lkADDM{$xlsRowVal{sysciname}}{serialnum} = $xlsRowVal{serialnum} if ($xlsRowVal{serialnum} ne "" && !($xlsRowVal{tier3} =~ m/virtual/i && $xlsRowVal{manufacturer} =~ m/vmware/i));

				# figure out the type based on the data
				if ($xlsRowVal{tier2} =~ m/server/i) {
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{ucs} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/mid-range/i && $xlsRowVal{productname} =~ m/cisco ucs/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{sunfire} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/mid-range/i && $xlsRowVal{productname} =~ m/sun fire/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{dell} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/mid-range/i && $xlsRowVal{productname} =~ m/poweredge/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{xseries} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/mid-range/i && $xlsRowVal{productname} =~ m/system x/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{vm} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/virtual/i && $xlsRowVal{productname} =~ m/vmware server/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{ucsvm} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/virtual/i && $xlsRowVal{productname} =~ m/cisco uc/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{partition} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/virtual/i && $xlsRowVal{productname} =~ m/ibm partition/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{container} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/virtual/i && $xlsRowVal{productname} =~ m/solaris container/i);
				} elsif ($xlsRowVal{tier2} =~ m/network/i) {
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{controller} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/controller/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{router} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/router/i);
					$lkADDM{$xlsRowVal{sysciname}}{type} = $main::hashADDMtype{switch} if ($lkADDM{$xlsRowVal{sysciname}}{type} eq "" && $xlsRowVal{tier3} =~ m/switch/i);
				}
			} #if ($xlsRowVal{tier1} =~ m/it hardware/i && ($xlsRowVal{tier2} =~ m/server/i || $xlsRowVal{tier2} =~ m/network/i))

			## IP Addresses associated to the server
			if ($xlsRowVal{tier1} =~ m/logical entity/i && $xlsRowVal{tier2} =~ m/addresses/i && $xlsRowVal{tier3} =~ m/ip address/i) { # evaluate IP address
				if (is_ipv4($xlsRowVal{ciname})) { # we found a valid IP address
					# is the IP in our range of subnets?
					my $ipv4 = $xlsRowVal{ciname};
					my $ip_id = "";
					my $sn = $SubClassifier->($ipv4); # find the subnet in range quickly
					my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
					my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

					if (exists($lkGIP{$ipv4})) { # find it if it already exists
						$ip_id = $lkGIP{$ipv4}{id};
						$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
						$sql .= "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
						$sql .= "   ipv4 = INET_ATON(\'" . $ipv4 . "\'),\n";
						$sql .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
						$sql .= "   inuse = 1,\n";
						$sql .= "   inaddm = 1,\n";
						$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
						$sql .= "   WHERE id = " . $ip_id . ";\n";
						print $sql . "\n" if ($DEBUGSQL); # debug sql
						$dbh->do($sql);
						if (!defined($dbh) ) {
							print "Error while executing SQL:\n";
							print $sql . "\n";
							print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
							$iSqlErr++;
						} else {
							$iSqlIPUpdate++;
							$lkGIP{$ipv4}{inuse} = 1;
							$lkGIP{$ipv4}{inaddm} = 1;
						} # we inserted a record
					} else { # we don't have it in the hash yet
						#if (defined($sn)) { # we found a subnet in range
							$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
							$sql .= "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
							$sql .= "   ipv4 = INET_ATON(\'" . $ipv4 . "\'),\n";
							$sql .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
							$sql .= "   inuse = 1,\n";
							$sql .= "   inaddm = 1,\n";
							$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
							$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
							print $sql . "\n" if ($DEBUGSQL); # debug sql
							$dbh->do($sql);
							if (!defined($dbh) ) {
								print "Error while executing SQL:\n";
								print $sql . "\n";
								print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
								$iSqlErr++;
							} else {
								$iSqlIPInsert++;
								$lkGIP{$ipv4}{id} = $dbh->{mysql_insertid}; # add to hash
								$lkGIP{$ipv4}{inuse} = 1;
								$lkGIP{$ipv4}{inaddm} = 1;
								$ip_id = $lkGIP{$ipv4}{id};
							} # we inserted a record
						#} # defined(sn)
					} # we don't have it in the hash yet
					push (@{$lkADDM{$xlsRowVal{sysciname}}{ip_keys}},$ip_id) if ($ip_id ne "" && (grep { /$ip_id/ } @{$lkADDM{$xlsRowVal{sysciname}}{ip_keys}}) == 0); # if we found an IP address id, push it if it's not already there
				} #if (is_ipv4($xlsRowVal{ciname})) { # we found a valid IP address
			} #if ($xlsRowVal{tier1} =~ m/logical entity/i && $xlsRowVal{tier2} =~ m/addresses/i && $xlsRowVal{tier3} =~ m/ip address/i) {

			## CPU counts
			if ($xlsRowVal{tier1} =~ m/it hardware/i && $xlsRowVal{tier2} =~ m/component/i && $xlsRowVal{tier3} =~ m/cpu/i) {
				$lkADDM{$xlsRowVal{sysciname}}{cpu} += 1;
			} ## CPU counts

			## SOFTWARE
			my $assetSWtype = 0;
			my $assetOSflag = 0;
			if ($xlsRowVal{tier1} =~ m/software/i) { ## Software
				if (!$assetSWtype && $xlsRowVal{tier2} =~ m/operating system/i) {
					$assetSWtype = $main::hashADDMswtype{networkos} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/network operating/i);
					$assetSWtype = $main::hashADDMswtype{linux} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/linux/i);
					$assetSWtype = $main::hashADDMswtype{unix} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/unix/i);
					$assetSWtype = $main::hashADDMswtype{windows} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/windows/i);
					$assetSWtype = $main::hashADDMswtype{os} if (!$assetSWtype && lc($xlsRowVal{tier3}) eq 'operating system');
					$assetOSflag = 1 if ($assetSWtype ne "");
				} # operating system
				my $apptype = lc($xlsRowVal{tier2});
				if (!$assetSWtype && ($apptype eq 'application' || $apptype eq 'business' || $apptype eq 'infrastructure') ) {
					$assetSWtype = $main::hashADDMswtype{appdeploy} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/deployment/i);
					$assetSWtype = $main::hashADDMswtype{appserver} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/application server/i);
					$assetSWtype = $main::hashADDMswtype{assetmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/asset management/i);
					$assetSWtype = $main::hashADDMswtype{backup} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/backup/i);
					$assetSWtype = $main::hashADDMswtype{busintel} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/business intelligence/i);
					$assetSWtype = $main::hashADDMswtype{cluster} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/clustering/i);
					$assetSWtype = $main::hashADDMswtype{contentmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/content/i && $xlsRowVal{tier3} =~ m/management/i);
					$assetSWtype = $main::hashADDMswtype{dataaccess} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/data access/i);
					$assetSWtype = $main::hashADDMswtype{dataintegration} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/data integration/i);
					$assetSWtype = $main::hashADDMswtype{dataprotection} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/data protection/i);
					$assetSWtype = $main::hashADDMswtype{dbmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/database/i && $xlsRowVal{tier3} =~ m/management/i);
					$assetSWtype = $main::hashADDMswtype{devlanguage} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/development language/i);
					$assetSWtype = $main::hashADDMswtype{email} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/e-mail/i);
					$assetSWtype = $main::hashADDMswtype{enduserquery} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/end-user query/i);
					$assetSWtype = $main::hashADDMswtype{entresplan} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/enterprise resource/i && $xlsRowVal{tier3} =~ m/planning/i);
					$assetSWtype = $main::hashADDMswtype{entportal} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/enterprise portal/i);
					$assetSWtype = $main::hashADDMswtype{entresmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/enterprise resource/i && $xlsRowVal{tier3} =~ m/management/i);
					$assetSWtype = $main::hashADDMswtype{evtmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/event management/i);
					$assetSWtype = $main::hashADDMswtype{evtdrvmw} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/event\-driven middleware/i);
					$assetSWtype = $main::hashADDMswtype{extract} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/extract/i && $xlsRowVal{tier3} =~ m/transform/i);
					$assetSWtype = $main::hashADDMswtype{filesys} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/file system/i);
					$assetSWtype = $main::hashADDMswtype{idmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/identity/i && $xlsRowVal{tier3} =~ m/access/i);
					$assetSWtype = $main::hashADDMswtype{instantcom} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/instant comm/i);
					$assetSWtype = $main::hashADDMswtype{integrationserver} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/integration server/i);
					$assetSWtype = $main::hashADDMswtype{middleware} if (!$assetSWtype && lc($xlsRowVal{tier3}) eq 'middleware');
					$assetSWtype = $main::hashADDMswtype{monitoring} if (!$assetSWtype && lc($xlsRowVal{tier3}) eq 'monitoring');
					$assetSWtype = $main::hashADDMswtype{network} if (!$assetSWtype && lc($xlsRowVal{tier3}) eq 'network');
					$assetSWtype = $main::hashADDMswtype{networkmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/network management/i);
					$assetSWtype = $main::hashADDMswtype{nonreldb} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/nonrelational database/i);
					$assetSWtype = $main::hashADDMswtype{otherappmw} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/other application server mid/i);
					$assetSWtype = $main::hashADDMswtype{otherdeploy} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/other/i && $xlsRowVal{tier3} =~ m/deployment/i && $xlsRowVal{tier3} =~ m/software/i);
					$assetSWtype = $main::hashADDMswtype{performmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/performance management/i);
					$assetSWtype = $main::hashADDMswtype{processauto} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/process automation mid/i);
					$assetSWtype = $main::hashADDMswtype{projectmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/project/i && $xlsRowVal{tier3} =~ m/management/i);
					$assetSWtype = $main::hashADDMswtype{qualtools} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/software quality tools/i);
					$assetSWtype = $main::hashADDMswtype{reporting} if (!$assetSWtype && lc($xlsRowVal{tier3}) eq 'reporting');
					$assetSWtype = $main::hashADDMswtype{scheduling} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/scheduling/i);
					$assetSWtype = $main::hashADDMswtype{searchdiscover} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/search/i && $xlsRowVal{tier3} =~ m/discover/i);
					$assetSWtype = $main::hashADDMswtype{securecontent} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/secure/i && $xlsRowVal{tier3} =~ m/content/i && $xlsRowVal{tier3} =~ m/threat/i);
					$assetSWtype = $main::hashADDMswtype{security} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/security/i);
					$assetSWtype = $main::hashADDMswtype{storagemgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/storage/i && $xlsRowVal{tier3} =~ m/device management/i);
					$assetSWtype = $main::hashADDMswtype{sysmgt} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/system/i && $xlsRowVal{tier3} =~ m/management/i);
					$assetSWtype = $main::hashADDMswtype{teamcollab} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/team/i && $xlsRowVal{tier3} =~ m/collaborative/i);
					$assetSWtype = $main::hashADDMswtype{transactionproc} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/transaction/i && $xlsRowVal{tier3} =~ m/processing/i);
					$assetSWtype = $main::hashADDMswtype{vmsoftware} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/software/i && $xlsRowVal{tier3} =~ m/virtual machine/i);
					$assetSWtype = $main::hashADDMswtype{webserver} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/web server/i);
					$assetSWtype = $main::hashADDMswtype{workloadsched} if (!$assetSWtype && $xlsRowVal{tier3} =~ m/software/i && $xlsRowVal{tier3} =~ m/workload schedul/i);
				} # application

				## Do we have the software on the addmsw table?
				my $assetSWid = 0;
				if ($assetSWtype) {
					my $swkey = $assetSWtype . $IndexDelimit . $xlsRowVal{productname} . $IndexDelimit . $xlsRowVal{modelver};
					if (exists($lkADDMSW{$swkey})) {
						$assetSWid = $lkADDMSW{$swkey}{id}; # assign the ID if this is the os key
					} else { ## insert a new ADDMSW row
						## 6/10/20 -- Fix the product name on OS software
						if ($xlsRowVal{productname} =~ m/red hat/i) {
							$xlsRowVal{productname} =~ s/red hat//ig; # remove multiple red hat
							$xlsRowVal{productname} = trim($xlsRowVal{productname});
							$xlsRowVal{productname} = "Red Hat " . $xlsRowVal{productname};
							if ($xlsRowVal{productname} =~ m/7\.\d/) {
								$xlsRowVal{productname} =~ s/7\.\d//ig;
								$xlsRowVal{productname} = trim($xlsRowVal{productname});
								$xlsRowVal{productname} .= " " . $xlsRowVal{modelver}; ## modelver
							}
						}
						if ($xlsRowVal{productname} =~ m/cisco systems/i) {
							$xlsRowVal{productname} =~ s/cisco systems//ig; # remove multiple cisco systems
							$xlsRowVal{productname} = trim($xlsRowVal{productname});
							$xlsRowVal{productname} = "Cisco Systems " . $xlsRowVal{productname};
							if ($xlsRowVal{productname} =~ m/nx\-os/i) {
								$xlsRowVal{productname} =~ s/nx\-os.+$//i; # remove everything after NX-OS
								$xlsRowVal{productname} = trim($xlsRowVal{productname});
								$xlsRowVal{productname} .= " " . $xlsRowVal{modelver}; ## modelver
							}
						}
						$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`addmsw` SET \n";
						$sql .= "   product = \'". $xlsRowVal{productname} . "\',\n";
						$sql .= "   type = " . $assetSWtype . ",\n";
						$sql .= "   modelver = " . (($xlsRowVal{modelver} ne "") ? "\'" . $xlsRowVal{modelver} . "\'" : "NULL") . ",\n";
						$sql .= "   manufacturer = " . (($xlsRowVal{manufacturer} ne "") ? "\'" . $xlsRowVal{manufacturer} . "\'" : "NULL") . ",\n";
						$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
						$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
						print $sql . "\n" if ($DEBUGSQL); # debug sql
						$dbh->do($sql);
						if (!defined($dbh) ) {
							print "Error while executing SQL:\n";
							print $sql . "\n";
							print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
							$iSqlErr++;
						} else {
							$iSqlADDMSWInsert++;
							$lkADDMSW{$swkey}{id} = $dbh->{mysql_insertid};
							$assetSWid = $lkADDMSW{$swkey}{id}; # assign the ID if this is the os key
						}
					} # insert a new ADDMSW row
					if ($assetOSflag && $assetSWid) { # we need to relate this to the main record because the OS will be related on the main column admos_id when the ADDM row is inserted/updated
						$lkADDM{$xlsRowVal{sysciname}}{admos_id} = $assetSWid;
					} elsif ($assetSWid) {
						my $instancename = $xlsRowVal{ciname};
						${$lkADDM{$xlsRowVal{sysciname}}{sw}}{$instancename} = $assetSWid; # hash
					}
				} # if SWtype ne ""
			} ## SOFTWARE

		} else { ## error! sysciname eq ""

		}
	} # end if headers have all been found
} # end for row

## Loop through the keys in the ADDM file
foreach my $ciname (keys %lkADDM) {
	## sqlcoldata code to simplify NULLs

	next if ($lkADDM{$ciname}{type} eq ""); # if we don't know the type, skip it
	my $sqlcoldata = "   name = \'". $ciname . "\',\n";
	$sqlcoldata .= "   type = " . $lkADDM{$ciname}{type} . ",\n";
	$sqlcoldata .= "   product = " . (($lkADDM{$ciname}{productname} ne "") ? "\'" . $lkADDM{$ciname}{productname} . "\'" : "NULL") . ",\n";
	$sqlcoldata .= "   manufacturer = " . (($lkADDM{$ciname}{manufacturer} ne "") ? "\'" . $lkADDM{$ciname}{manufacturer} . "\'" : "NULL") . ",\n";
	$sqlcoldata .= "   serialnum = " . (($lkADDM{$ciname}{serialnum} ne "") ? "\'" . $lkADDM{$ciname}{serialnum} . "\'" : "NULL") . ",\n";
	$sqlcoldata .= "   admos_id = " . (($lkADDM{$ciname}{admos_id} ne "") ? $lkADDM{$ciname}{admos_id} : "NULL") . ",\n";
	$sqlcoldata .= "   cpu = " . (($lkADDM{$ciname}{cpu} ne "") ? $lkADDM{$ciname}{cpu} : "NULL") . ",\n";
	$sqlcoldata .= "   ipsinrange = " . scalar(@{$lkADDM{$ciname}{ip_keys}})  . ",\n";
	$sqlcoldata .= "   createdate = " . (($lkADDM{$ciname}{createdate} ne "") ? "\'" . $lkADDM{$ciname}{createdate} . "\'" : "NULL") . ",\n";
	$sqlcoldata .= "   modifydate = " . (($lkADDM{$ciname}{modifydate} ne "") ? "\'" . $lkADDM{$ciname}{modifydate} . "\'" : "NULL") . ",\n";

	my $dbupdated = 0;

	if ($lkADDM{$ciname}{id} eq "") { # new record
		$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`addm` SET \n";
		$sql .= $sqlcoldata;
		$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
		$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
		print $sql . "\n" if ($DEBUGSQL); # debug sql
		$dbh->do($sql);
		if (!defined($dbh) ) {
			print "Error while executing SQL:\n";
			print $sql . "\n";
			print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
			$iSqlErr++;
		} else {
			$iSqlADDMInsert++;
			$lkADDM{$ciname}{id} = $dbh->{mysql_insertid};
			$dbupdated = 1;
		}
	} else {
		$sql = "UPDATE `" . $main::IDB_NAME . "`.`addm` SET \n";
		$sql .= $sqlcoldata;
		$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
		$sql .= "   WHERE id = " . $lkADDM{$ciname}{id} . ";\n";
		$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
		print $sql . "\n" if ($DEBUGSQL); # debug sql
		$dbh->do($sql);
		if (!defined($dbh) ) {
			print "Error while executing SQL:\n";
			print $sql . "\n";
			print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
			$iSqlErr++;
		} else {
			$iSqlADDMUpdate++;
			$dbupdated = 1;
		}
	} # done with ADDM SQL

	if ($dbupdated) { ## insert all of the associated relationships
		my $ADDMid = $lkADDM{$ciname}{id};

		# addm to ip ID relationships
		foreach my $ipkey (@{$lkADDM{$ciname}{ip_keys}}) {
			## insert a adip relationship record
			if ($ADDMid ne "") {
				my $lku = $ADDMid . $IndexDelimit . $ipkey;
				if (!exists($lkADIP{$lku})) {
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`adiprel` SET \n";
					$sql .= "   addm_id = ". $ADDMid . ",\n";
					$sql .= "   ipadd_id = ". $ipkey . ",\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlADIPInsert++;
						$lkADIP{$lku}{id} = $dbh->{mysql_insertid}; # add to hash
					} # we inserted a record
				} #if (!exists($lkADIP{$lku}))
			} #if ($ip_id ne "" && $ADDMid ne "")
		} #foreach my $ipkey (@assetIPkeys)

		## addm to sw relationships
		foreach my $swinst (keys %{$lkADDM{$ciname}{sw}}) {
			my $swkey = ${$lkADDM{$ciname}{sw}}{$swinst}; # hash value
			my $lku = $ADDMid . $IndexDelimit . $swkey . $IndexDelimit . $swinst;
			if (!exists($lkADSW{$lku})) {
				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`adswrel` SET \n";
				$sql .= "   addm_id = ". $ADDMid . ",\n";
				$sql .= "   addmsw_id = ". $swkey . ",\n";
				$sql .= "   instname = " . ($swinst ? "\'" . $swinst . "\'" : "NULL") . ",\n";
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlADSWInsert++;
					$lkADSW{$lku}{id} = $dbh->{mysql_insertid}; # add to hash
				} # we inserted a record
			} # if (!exists($lkADSW{$lku}))
		} # foreach my $swkey (@{$lkADDM{$ciname}{sw_keys}})
	} # if ($dbupdated)
} # foreach loop ciname

## update tracking table
$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-addm-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "ADDM Inserts\t:" . $iSqlADDMInsert . "\n";
print "ADDM Updates\t:" . $iSqlADDMUpdate . "\n";
print "ADDMSW Inserts\t:" . $iSqlADDMSWInsert . "\n";
print "ADIP Inserts\t:" . $iSqlADIPInsert . "\n";
print "ADSW Inserts\t:" . $iSqlADSWInsert . "\n";
print "IP Not Found\t:" . $iSqlIPNotFound . "\n";
print "IP Inserts\t:" . $iSqlIPInsert . "\n";
print "IP Updates\t:" . $iSqlIPUpdate . "\n";
print "Notifications\t:" . $iSqlNotifyInsert . "\n";
#print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
