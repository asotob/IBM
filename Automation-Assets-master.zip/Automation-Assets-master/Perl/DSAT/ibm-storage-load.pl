#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Storage File RE-Load (Import)
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Data::Validate::IP qw(is_ipv4);
use Scalar::Util qw(looks_like_number);
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("STORAGE LOAD/UPDATE");

die "You must provide a Storage Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
#my %lkNAS	 				= ();	# hash table to lookup NAS data already in the database
my %lkNASmap			= ();	# hash table to lookup NASMAP data already in the database
my %lkSAN	 				= ();	# hash table to lookup SAN data already in the database
my %lkINV	 				= ();	# hash table to lookup INVENTORY already in the database by rscdname
my %lkINVw	 			= ();	# hash table to lookup INVENTORY already in the database by wsibname
my %lkSAMI 				= ();	# hash table to lookup SAMI records already in the database (for legacy lookups by wsib hostname)

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr	= 0;
my $iSqlNASInsert = 0;
my $iSqlNASmapInsert = 0;
my $iSqlSANInsert = 0;
my $iDataErrors 	= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		print "******* LKU LOC: " . $cd . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
	}
}

if ((grep { /inventory/ } @dbTables) == 0) {
	print "Table: inventory not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	print "\n**** Loading INVENTORY lookup table...\n" if ($DEBUGSQL); # debug sql
	## 12/18/19 - Changing the logic to just look up the Excel Row as the hash index
	$sql = "SELECT inv.rscdname, inv.id, op.wsibname, os.name  \n";
	$sql .= "   FROM `" . $main::IDB_NAME . "`.`inventory` inv\n";
	$sql .= "   LEFT JOIN `" . $main::IDB_NAME . "`.`opsinv` op ON inv.opsinv_id = op.id\n";
	$sql .= "   LEFT JOIN `" . $main::IDB_NAME . "`.`opsys` os ON inv.os_id = os.id\n";
	$sql .= "   WHERE inv.rscdname IS NOT NULL;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0]; # the lookup key is rscdname
		$lkINV{$lkey}{id} = $refr[1];
		$lkINV{$lkey}{wsibname} = "";
		$lkINV{$lkey}{wsibname} = $refr[2] if (defined($refr[2]));
		$lkINV{$lkey}{osname} = "";
		$lkINV{$lkey}{osname} = $refr[3] if (defined($refr[3]));
		if ($lkINV{$lkey}{wsibname} ne "") {
			my $lkey2 = $lkINV{$lkey}{wsibname};
			$lkINVw{$lkey2}{id} = $lkINV{$lkey}{id};
			$lkINVw{$lkey2}{rscdname} = $lkey;
			$lkINVw{$lkey2}{osname} = $lkINV{$lkey}{osname};
		}
		print "******* LKU INVENTORY: name:" . $lkey . " key: " . $lkINV{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /sami/ } @dbTables) == 0) { # SAMI table not found
	print "Table: sami not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT id, wsibname, rscdname, env, component \n";
	$sql .= "FROM `" . $main::IDB_NAME . "`.`sami`; \n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[1];
		$lkSAMI{$lkey}{id} = $refr[0]; # SAMI table index
		$lkSAMI{$lkey}{rscdname} = "";
		$lkSAMI{$lkey}{rscdname} =  $refr[2] if (defined($refr[2]));
		$lkSAMI{$lkey}{env} = "";
		$lkSAMI{$lkey}{env} =  $refr[3] if (defined($refr[3]));
		$lkSAMI{$lkey}{component} = "";
		$lkSAMI{$lkey}{component} =  $refr[4] if (defined($refr[4]));
		print "******* LKU SAMI: lkey=" . $lkey . " db key: " . $lkSAMI{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /sanspecs/ } @dbTables) == 0) { # table not found
	print "Table: sanspecs not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	# truncate table and rebuild it
	$sql = "TRUNCATE `" . $main::IDB_NAME . "`.`sanspecs`;";
	$result = $dbh->do($sql);
}

if ((grep { /nasspecs/ } @dbTables) == 0) { # table not found
	print "Table: nasspecs not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	# truncate table and rebuild it
	$sql = "TRUNCATE `" . $main::IDB_NAME . "`.`nasspecs`;";
	$result = $dbh->do($sql);
}

if ((grep { /nasmap/ } @dbTables) == 0) { # table not found
	print "Table: nasmap not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	# truncate table and rebuild it
	$sql = "TRUNCATE `" . $main::IDB_NAME . "`.`nasmap`;";
	$result = $dbh->do($sql);
}
# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet;
my $keycount;
my $TotalHeaders;
my %xlsCol;	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min;
my $row_max;
my $col_min;
my $col_max;

################################################################################
################################################################################
### SAN WORKSHEET
################################################################################
################################################################################
my $san_ws = $workbook->worksheet('SAN');

if (defined($san_ws)) {
	$current_sheet = trim($san_ws->get_name());

	# Find out the worksheet ranges
	( $row_min, $row_max ) = $san_ws->row_range();
	( $col_min, $col_max ) = $san_ws->col_range();

	print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";
	$keycount = 0;
	$TotalHeaders	= 12;	# total number of column headers we need to find in this worksheet to proceed with processing
	$FIRST_DATA_ROW = 2;
	%xlsCol = ();

	for my $row ( $row_min .. $row_max ) {
		$iExcelRows++; # increment total Excel row counter
		if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
			for my $col ( $col_min .. $col_max ) {
				my $cell = $san_ws->get_cell( $row, $col ); # Return the cell object at $row and $col
				next unless $cell;
				my $fld = lc(trim($cell->value()));
				if 	( $fld eq 'dc' ||  $fld eq 'datacenter' ) {
					$xlsCol{loccode} = $col;
					$keycount++;
				} elsif ( $fld =~ m/host_name/i ) {
					$xlsCol{hostnames} = $col;
					$keycount++;
				} elsif ( $fld eq 'sn' ) {
					$xlsCol{serialnum} = $col;
					$keycount++;
				} elsif ( $fld eq 'class' ) {
					$xlsCol{class} = $col;
					$keycount++;
				} elsif ( $fld =~ m/host_alias/i ) { #5
					$xlsCol{hostaliases} = $col;
					$keycount++;
				} elsif ( $fld =~ m/servername/i ) {
					$xlsCol{wsibname} = $col;
					$keycount++;
				} elsif ( $fld =~ m/environment/i ) {
					$xlsCol{wsibenv} = $col;
					$keycount++;
				} elsif ( $fld =~ m/lun id/i ) {
					$xlsCol{lunid} = $col;
					$keycount++;
				} elsif ( $fld =~ m/vg_name/i ) {
					$xlsCol{vgname} = $col;
					$keycount++;
				} elsif ( $fld =~ m/disk name/i ) { #10
					$xlsCol{diskname} = $col;
					$keycount++;
				} elsif ( $fld =~ m/disk size/i ) {
					$xlsCol{disksizegb} = $col;
					$keycount++;
				} elsif ( $fld eq 'os' ) {
					$xlsCol{serveros} = $col;
					$keycount++;
				} # end if
			} # end for col
		} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
			print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
			print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
			print "****        KEYS FOUND:\n";
			foreach my $key (sort keys %xlsCol) {
				print "****           $key\n";
			}
			$dbh->disconnect(); # disconnect gracefully
			die;
		} elsif ($keycount == $TotalHeaders) {
			# new code for localized values
			my %xlsRowVal	= ();	# hash table to contain excel row values
			foreach my $key (keys %xlsCol) {
				my $cell = $san_ws->get_cell( $row, $xlsCol{$key} );
				$xlsRowVal{$key} = "";
				$xlsRowVal{$key} = trim($cell->value()) if $cell;
			}

			## reformat the manual data entered
			$xlsRowVal{loccode} = substr($xlsRowVal{loccode},0,255);
			$xlsRowVal{hostnames} = substr($xlsRowVal{hostnames},0,255);
			$xlsRowVal{serialnum} = substr($xlsRowVal{serialnum},0,255);
			$xlsRowVal{class} = substr($xlsRowVal{class},0,255);
			$xlsRowVal{hostaliases} = substr($xlsRowVal{hostaliases},0,512);
			$xlsRowVal{wsibname} = lc(trim(substr($xlsRowVal{wsibname},0,255)));
			$xlsRowVal{wsibenv} = substr($xlsRowVal{wsibenv},0,255);
			$xlsRowVal{lunid} = substr($xlsRowVal{lunid},0,255);
			$xlsRowVal{vgname} = substr($xlsRowVal{vgname},0,255);
			$xlsRowVal{diskname} = substr($xlsRowVal{diskname},0,255);
			$xlsRowVal{disksizegb} = substr($xlsRowVal{disksizegb},0,255);
			$xlsRowVal{serveros} = substr($xlsRowVal{serveros},0,255);

			# pull together some key fields for insert/update later
			my $assetXLRow = ($row + 1); # row is actually behind by 1
			my %assetHN = (); # hash

			my $assetLOCkey = "";
			my $assetLOCcode = uc($xlsRowVal{loccode});
			my $assetLUNid = $xlsRowVal{lunid};
			my $assetDiskSizeGB = "";
			$assetDiskSizeGB = $xlsRowVal{disksizegb} if (looks_like_number($xlsRowVal{disksizegb}));

			if ($assetLOCcode ne "" && exists($lkLOC{$assetLOCcode})) {
				$assetLOCkey = $lkLOC{$assetLOCcode}{id};
			}

			# make sure we have a valid location key
			if ($assetLOCkey eq "") {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'storage\',\n";
				 $sql .= "   errorlog = \'Storage worksheet ". $current_sheet . " row (". $assetXLRow .") LOCATION \"". $assetLOCcode  ."\" NOT FOUND.\',\n";
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
				 next; # skip this record
			}

			my $assetSerialNum = "";
			$assetSerialNum = $xlsRowVal{serialnum} if ($xlsRowVal{serialnum} ne "");
			# make sure we have a valid serialnum for insert/update
			if ($assetSerialNum eq "") {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'storage\',\n";
				 $sql .= "   errorlog = \'Storage worksheet ". $current_sheet . " row (". $assetXLRow .") SERIAL NUMBER IS BLANK.\',\n";
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
				 next; # skip this record
			}

			# make sure we have a valid LunID for insert/update
			if ($assetLUNid eq "") {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'storage\',\n";
				 $sql .= "   errorlog = \'Storage worksheet ". $current_sheet . " row (". $assetXLRow .") LUNID IS BLANK.\',\n";
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
				 next; # skip this record
			}

			# format the column data
			## asset ID map
			my $assetID = "";
			my $assetOSname = "";
			my $assetWSIBname = "";

			my @rscdlist = split(/\,/,$xlsRowVal{hostnames}); # split by comma
			my @aliaslist = split(/\,/,$xlsRowVal{hostaliases}); # split by comma
			for (my $i=0;$i < scalar(@rscdlist);$i++) {
				$assetHN{$i}{rscdname} = "";
				if ($rscdlist[$i] ne "") {
					$assetHN{$i}{rscdname} = lc(trim($rscdlist[$i]));
					if ($assetHN{$i}{rscdname} ne "" && exists($lkINV{$assetHN{$i}{rscdname}})) {
						$assetID = $lkINV{$assetHN{$i}{rscdname}}{id} if ($assetID eq "");
						$assetOSname = $lkINV{$assetHN{$i}{rscdname}}{osname} if ($assetOSname eq "");
						$assetWSIBname = $lkINV{$assetHN{$i}{rscdname}}{wsibname} if ($assetWSIBname eq "");
					}
				}
				$assetHN{$i}{alias} = "";
				$assetHN{$i}{alias} = $aliaslist[$i] if ($aliaslist[$i] ne "");
			}

			## search by wsibname
			if ($xlsRowVal{wsibname} ne "" && exists($lkINVw{$xlsRowVal{wsibname}})) {
				$assetID = $lkINVw{$xlsRowVal{wsibname}}{id} if ($assetID eq "");
				$assetOSname = $lkINVw{$xlsRowVal{wsibname}}{osname} if ($assetOSname eq "");
				$assetWSIBname = $xlsRowVal{wsibname} if ($assetWSIBname eq "");
			}

			## if we didn't find the asset, but we do have a wsibhostname, keep what was entered
			$assetWSIBname = $xlsRowVal{wsibname} if ($assetID eq "" && $assetWSIBname eq "" && $xlsRowVal{wsibname} ne "");

			## WSIB Environment Code - Consistent across worksheets
			my $assetWSIBenv = "";
			my $wsib_name = $assetWSIBname;
			if ($wsib_name ne "") {
				if (length($wsib_name) == 8) { ## follows WSIB naming convention
					my $c_env = lc(substr($wsib_name,0,1)); # environment
					$assetWSIBenv = $main::hashWSIBEnv{$c_env} if (exists($main::hashWSIBEnv{$c_env}));
				}

				## if we haven't found the environment yet, try using the legacy WSIB naming convention
				if ($assetWSIBenv eq "" && length($wsib_name) == 9 && lc(substr($wsib_name,0,2)) eq "sr") { ## follows LEGACY WSIB naming convention
					my $c_env = lc(substr($wsib_name,6,1));
					if ($c_env eq "p") {
						$assetWSIBenv = "PRD";
					} elsif ($c_env eq "d") {
						$assetWSIBenv = "DEV";
					} elsif ($c_env eq "u") {
						$assetWSIBenv = "UAT";
					} elsif ($c_env eq "t") {
						$assetWSIBenv = "TEST";
					}
				}
				## if we still haven't found the environment, use the SAMI
				if ($assetWSIBenv eq "" && exists($lkSAMI{$wsib_name})) { # do we have a legacy SAMI record?
					$assetWSIBenv = $lkSAMI{$wsib_name}{env}; # get the env from the SAMI instead
				}
			}

			if ($assetWSIBenv eq "") {  # worst case scenario, keep what was entered
				$assetWSIBenv = $xlsRowVal{wsibenv};
				$assetWSIBenv = "PRD" if ($assetWSIBenv =~ m/pro/i || $assetWSIBenv =~ m/prd/i);
				$assetWSIBenv = "PPD" if ($assetWSIBenv =~ m/pre/i || $assetWSIBenv =~ m/ppd/i);
				$assetWSIBenv = "QA" if ($assetWSIBenv =~ m/qa/i);
				$assetWSIBenv = "SIT" if ($assetWSIBenv =~ m/sit/i);
				$assetWSIBenv = "UAT" if ($assetWSIBenv =~ m/uat/i);
				$assetWSIBenv = "BAT" if ($assetWSIBenv =~ m/bat/i);
				$assetWSIBenv = "CONV" if ($assetWSIBenv =~ m/con/i ||$assetWSIBenv =~ m/cnv/i);
				$assetWSIBenv = "DIT" if ($assetWSIBenv =~ m/dit/i || $assetWSIBenv =~ m/integ/i);
				$assetWSIBenv = "TEST" if ($assetWSIBenv =~ m/test/i);
				$assetWSIBenv = "TRN" if ($assetWSIBenv =~ m/tra/i || $assetWSIBenv =~ m/trn/i);
				$assetWSIBenv = "DEV" if ($assetWSIBenv =~ m/dev/i);
			}

			## can we find a better OS name?
			$xlsRowVal{serveros} = $assetOSname if ($assetOSname ne "");
			$assetWSIBname = $xlsRowVal{wsibname} if ($assetWSIBname eq ""); # use what was entered if not found

			## now insert or update
			## new sqlcoldata code to simplify NULLs
			my $sqlcoldata = "   location_id = ". $assetLOCkey . ",\n";
			$sqlcoldata .= "   lunid = \'". $assetLUNid . "\',\n";
			$sqlcoldata .= "   rscdname1 = " . ((exists($assetHN{0}) && $assetHN{0}{rscdname} ne "") ? "\'". $assetHN{0}{rscdname} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   rscdname2 = " . ((exists($assetHN{1}) && $assetHN{1}{rscdname} ne "") ? "\'". $assetHN{1}{rscdname} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   serialnum = \'". $assetSerialNum . "\',\n";
			$sqlcoldata .= "   class = " . (($xlsRowVal{class} ne "") ? "\'". $xlsRowVal{class} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   alias1 = " . ((exists($assetHN{0}) && $assetHN{0}{alias} ne "") ? "\'". $assetHN{0}{alias} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   alias2 = " . ((exists($assetHN{1}) && $assetHN{1}{alias} ne "") ? "\'". $assetHN{1}{alias} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   servername = " . (($assetWSIBname ne "") ? "\'". $assetWSIBname . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   inv_id = " . (($assetID ne "") ? $assetID : "NULL") . ",\n";
			$sqlcoldata .= "   environment = " . (($assetWSIBenv ne "") ? "\'". $assetWSIBenv . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   vgname = " . (($xlsRowVal{vgname} ne "") ? "\'". $xlsRowVal{vgname} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   diskname = " . (($xlsRowVal{diskname} ne "") ? "\'". $xlsRowVal{diskname} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   disksizegb = " . (($assetDiskSizeGB ne "") ? $assetDiskSizeGB : "NULL") . ",\n";
			$sqlcoldata .= "   serveros = " . (($xlsRowVal{serveros} ne "") ? "\'". $xlsRowVal{serveros} . "\'" : "NULL") . ",\n";

			my $llkey = $assetLOCkey . $assetSerialNum . $assetLUNid;
			if (!exists($lkSAN{$llkey})) { # update an existing record
				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`sanspecs` SET \n";
				$sql .= $sqlcoldata;
				$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$result = $dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlSANInsert++;
					$lkSAN{$llkey}{id} = $dbh->{mysql_insertid};
				}
			} # insert or update
		} # found headers
	} # for my row loop
} # if SAN worksheet defined

################################################################################
################################################################################
### NAS WORKSHEET
################################################################################
################################################################################
my $nas_ws = $workbook->worksheet('NAS');

if (defined($nas_ws)) {
	$current_sheet = trim($nas_ws->get_name());

	# Find out the worksheet ranges
	( $row_min, $row_max ) = $nas_ws->row_range();
	( $col_min, $col_max ) = $nas_ws->col_range();

	print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";
	$keycount = 0;
	$TotalHeaders	= 14;	# total number of column headers we need to find in this worksheet to proceed with processing
	$FIRST_DATA_ROW = 2;
	%xlsCol = ();

	for my $row ( $row_min .. $row_max ) {
		$iExcelRows++; # increment total Excel row counter
		if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
			for my $col ( $col_min .. $col_max ) {
				my $cell = $nas_ws->get_cell( $row, $col ); # Return the cell object at $row and $col
				next unless $cell;
				my $fld = lc(trim($cell->value()));
				if 	( $fld eq 'dc' ||  $fld eq 'datacenter' ) {
					$xlsCol{loccode} = $col;
					$keycount++;
				} elsif ( $fld =~ m/evs/i && $fld =~ m/id/i ) {
					$xlsCol{evsid} = $col;
					$keycount++;
				} elsif ( $fld =~ m/evs/i && $fld =~ m/ip/i) {
					$xlsCol{evsip} = $col;
					$keycount++;
				} elsif ( $fld =~ m/evs/i && $fld =~ m/label/i) {
					$xlsCol{evslabel} = $col;
					$keycount++;
				} elsif ( $fld =~ m/share/i && $fld =~ m/name/i ) { #5
					$xlsCol{sharename} = $col;
					$keycount++;
				} elsif ( $fld =~ m/allocated/i && $fld =~ m/capacity/i ) {
					$xlsCol{alloccapacitygb} = $col;
					$keycount++;
				} elsif ( $fld =~ m/used/i && $fld =~ m/capacity/i ) {
					$xlsCol{usedcapacitygb} = $col;
					$keycount++;
				} elsif ( $fld =~ m/protocol/i ) {
					$xlsCol{protocol} = $col;
					$keycount++;
				} elsif ( $fld =~ m/filesystem/i ) {
					$xlsCol{filesystem} = $col;
					$keycount++;
				} elsif ( $fld eq 'path' ) {
					$xlsCol{path} = $col;
					$keycount++;
				} elsif ( $fld =~ m/replication/i ) { #10
					$xlsCol{replication} = $col;
					$keycount++;
				} elsif ( $fld =~ m/mount point/i ) {
					$xlsCol{mountpoint} = $col;
					$keycount++;
				} elsif ( $fld =~ m/servers/i && $fld =~ m/mapped/i) {
					$xlsCol{serversmapped} = $col;
					$keycount++;
				} elsif ( $fld eq 'security' ) {
					$xlsCol{security} = $col;
					$keycount++;
				} # end if
			} # end for col
		} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
			print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
			print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
			print "****        KEYS FOUND:\n";
			foreach my $key (sort keys %xlsCol) {
				print "****           $key\n";
			}
			$dbh->disconnect(); # disconnect gracefully
			die;
		} elsif ($keycount == $TotalHeaders) {
			# new code for localized values
			my %xlsRowVal	= ();	# hash table to contain excel row values
			foreach my $key (keys %xlsCol) {
				my $cell = $nas_ws->get_cell( $row, $xlsCol{$key} );
				$xlsRowVal{$key} = "";
				$xlsRowVal{$key} = trim($cell->value()) if $cell;
			}

			## reformat the manual data entered
			$xlsRowVal{loccode} = substr($xlsRowVal{loccode},0,255);
			$xlsRowVal{evsid} = substr($xlsRowVal{evsid},0,255);
			$xlsRowVal{evslabel} = substr($xlsRowVal{evslabel},0,255);
			$xlsRowVal{evsip} = substr($xlsRowVal{evsip},0,255);
			$xlsRowVal{sharename} = substr($xlsRowVal{sharename},0,255);
			$xlsRowVal{path} = substr($xlsRowVal{path},0,255);
			$xlsRowVal{alloccapacitygb} = substr($xlsRowVal{alloccapacitygb},0,255);
			$xlsRowVal{usedcapacitygb} = substr($xlsRowVal{usedcapacitygb},0,255);
			$xlsRowVal{protocol} = substr($xlsRowVal{protocol},0,30);
			$xlsRowVal{filesystem} = substr($xlsRowVal{filesystem},0,255);
			$xlsRowVal{replication} = substr($xlsRowVal{replication},0,255);
			$xlsRowVal{mountpoint} = substr($xlsRowVal{mountpoint},0,255);

			# pull together some key fields for insert/update later
			my $assetXLRow = ($row + 1); # row is actually behind by 1
			my %assetHN = (); # hash

			my $assetLOCkey = "";
			my $assetLOCcode = uc($xlsRowVal{loccode});

			if ($assetLOCcode ne "" && exists($lkLOC{$assetLOCcode})) {
				$assetLOCkey = $lkLOC{$assetLOCcode}{id};
			}

			# make sure we have a valid location key
			if ($assetLOCkey eq "") {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'storage\',\n";
				 $sql .= "   errorlog = \'Storage worksheet ". $current_sheet . " row (". $assetXLRow .") LOCATION \"". $assetLOCcode  ."\" NOT FOUND.\',\n";
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
				 next; # skip this record
			}

			my $assetUsedCapGB = "";
			$assetUsedCapGB = $xlsRowVal{usedcapacitygb} if (looks_like_number($xlsRowVal{usedcapacitygb}));

			my $assetAllocCapGB = "";
			$assetAllocCapGB = $xlsRowVal{alloccapacitygb} if (looks_like_number($xlsRowVal{alloccapacitygb}));

			my $assetEvsID = "";
			$assetEvsID = $xlsRowVal{evsid} if (looks_like_number($xlsRowVal{evsid}));

			my $assetEvsIP = "";
			$assetEvsIP = $xlsRowVal{evsip} if (is_ipv4($xlsRowVal{evsip}));

			my $assetReplication = 0;
			$assetReplication = 1 if ($xlsRowVal{replication} =~ m/yes/i);

			## get rid of trailing commas at the end of the security string
			$xlsRowVal{serversmapped} =~ s/\, +/\, /; # replace 1 or more spaces after a comma with just one
			$xlsRowVal{serversmapped} =~ s/\,+$//; # replace 1 or more commas at the end with nothing
			$xlsRowVal{serversmapped} =~ s/\,\s*/, /g;
			$xlsRowVal{serversmapped} = substr($xlsRowVal{serversmapped},0,255);

			$xlsRowVal{security} =~ s/\, +/\, /; # replace 1 or more spaces after a comma with just one
			$xlsRowVal{security} =~ s/\,+$//; # replace 1 or more commas at the end with nothing
			$xlsRowVal{security} =~ s/\,\s*/, /g;
			$xlsRowVal{security} = substr($xlsRowVal{security},0,1024);

			## now insert or update
			## 2/27/20 new sqlcoldata code to simplify NULLs
			my $sqlcoldata = "   location_id = ". $assetLOCkey . ",\n";
			$sqlcoldata .= "   evsid  = \'". $assetEvsID . "\',\n";
			$sqlcoldata .= "   evsip = " . (($assetEvsIP ne "") ? "INET_ATON(\'". $assetEvsIP . "\')" : "NULL") . ",\n"; # new EVS IP on 3/24/20
			$sqlcoldata .= "   evslabel = " . (($xlsRowVal{evslabel} ne "") ? "\'". $xlsRowVal{evslabel} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   sharename = " . (($xlsRowVal{sharename} ne "") ? "\'". $xlsRowVal{sharename} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   alloccapgb = " . (($assetAllocCapGB ne "") ? $assetAllocCapGB : "NULL") . ",\n";
			$sqlcoldata .= "   usedcapgb = " . (($assetUsedCapGB ne "") ? $assetUsedCapGB : "NULL") . ",\n";
			$sqlcoldata .= "   protocol = " . (($xlsRowVal{protocol} ne "") ? "\'". $xlsRowVal{protocol} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   filesystem = " . (($xlsRowVal{filesystem} ne "") ? "\'". $xlsRowVal{filesystem} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   path = " . (($xlsRowVal{path} ne "") ? "\'". $xlsRowVal{path} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   replication = ". $assetReplication . ",\n";
			$sqlcoldata .= "   mountpoint = " . (($xlsRowVal{mountpoint} ne "") ? "\'". $xlsRowVal{mountpoint} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   serversmapped = " . (($xlsRowVal{serversmapped} ne "") ? "\'". $xlsRowVal{serversmapped} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   security = " . (($xlsRowVal{security} ne "") ? "\'". $xlsRowVal{security} . "\'" : "NULL") . ",\n";

			my $assetNAS_ID = 0;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`nasspecs` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$result = $dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else { # we inserted a row
				$iSqlNASInsert++;
				$assetNAS_ID = $dbh->{mysql_insertid};
				## Map the NAS
				my $mappedstr = $xlsRowVal{serversmapped};
				$mappedstr =~ s/\s*\,\s*/,/g;
				my @mapped = split(',',$mappedstr);

				my $securitystr = $xlsRowVal{security};
				## get rid of the security junk at the end of the string
				$securitystr =~ s/\s+\(.*$//; # replace from the open paren to the end of the string with nothing
				$securitystr =~ s/\s*\,\s*/,/g;
				my @ipmap = split(',',$securitystr);
				if (scalar @mapped == scalar @ipmap) { # exactly the same number of entries in both
					for (my $i=0;$i < scalar @mapped; $i++) {
						my $hostnm = trim(lc($mapped[$i]));
						my $assetID = "";
						$assetID = $lkINVw{$hostnm}{id} if ($hostnm ne "" && exists($lkINVw{$hostnm}));
						my $ipv4 = $ipmap[$i];
						if ($assetID ne "" && $assetNAS_ID && is_ipv4($ipv4)) {
							my $lkey = $assetID . "^" . $assetNAS_ID . "^" . $ipmap[$i];
							if (!exists($lkNASmap{$lkey})) {
								$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`nasmap` SET \n";
								$sql .= "   inv_id = ". $assetID . ",\n";
								$sql .= "   nas_id = ". $assetNAS_ID . ",\n";
								$sql .= "   nas_ip = INET_ATON(\'". $ipmap[$i] . "\'),\n";
								$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
								$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
								print $sql . "\n" if ($DEBUGSQL); # debug sql
								$result = $dbh->do($sql);
								if (!defined($dbh) ) {
									print "Error while executing SQL:\n";
									print $sql . "\n";
									print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
									$iSqlErr++;
								} else {
									$iSqlNASmapInsert++;
									$lkNASmap{$lkey}{id} = $dbh->{mysql_insertid};
								}
							} # insert the record?
						} #if ($assetID ne "" && $assetNAS_ID && is_ipv4($ipmap[$i])) {
					} # for (my $i=0;$i < scalar @mapped; $i++) {
				} #if (scalar @mapped == scalar @ipmap) { # exactly the same number of entries in both
			} # we inserted a row
		} # found headers
	} # for my row loop
} # if NAS worksheet defined

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-storage-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "SAN Inserts\t:" . $iSqlSANInsert . "\n";
print "NAS Inserts\t:" . $iSqlNASInsert . "\n";
print "NASmap Inserts\t:" . $iSqlNASmapInsert . "\n";
print "Errors\t\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
