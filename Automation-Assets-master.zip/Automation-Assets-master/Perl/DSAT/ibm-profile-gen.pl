#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Migration Profile Generator (Ad Hoc Report)
### No database inserts or updates occur in this script.
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Excel::Writer::XLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
no warnings 'once';

require './ibm-globals.pl';

# accumulators and switch variables --------------------------------------
my $iRows;
my $href;

my %lkWAVE 				= ();	# hash table to lookup WAVE sequences already in the database
my %lkINV					= ();	# hash table to lookup INVENTORY record details by wsib hostname

my %qHOST 				= ();	# hash table to query host details -- the core of this script
my %qIP 					= ();	# hash table to query IP address details
my %qVLAN					= ();	# hash table to query VLAN details


my $outExcelRows	= 0;  # total number of excel rows written
my $DEBUGSQL 			= 1; 	# set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 		# this is the row to stop checking for headers and fail if all headers haven't been found
my %KEY_DATA_ERRORS	= (); # hash to contain data errors by Excel row (key information not found)

my $FONT_SIZE_HDR = 10;
my $FONT_CELL = 'IBM Plex Sans';
my $FONT_SIZE_CELL = 10;
my $FONT_SIZE_NOTES = 12;
my $ROW_HEIGHT_HDR = 24;
my $MAX_COLS = 18;

my $iSqlErr				= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

# -----------------------------------------------------------------------
# LOAD PRIOR DATA FOR LOOKUPS
# -----------------------------------------------------------------------
# Wave Sequence EVENT table lookups
if ((grep { /event/ } @dbTables) == 0) {
	print "Table: event not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
$sql = "SELECT wavesequence, name  FROM `" . $main::IDB_NAME . "`.`event`;\n";
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $waveseq = (defined($refr[0])) ? $refr[0] : "";
	my $wavenm = (defined($refr[1])) ? $refr[1] : "";
	if (!exists($lkWAVE{$waveseq})) {
		$lkWAVE{$waveseq}{name} = $wavenm;
	}
}

## INV lookups
$sql = "SELECT inv.wsibname, inv.rscdname, inv.category, inv.location_id, inv.tgtlocation_id, inv.ipadd_id, inv.addm_id, inv.opsinv_id, \n";
$sql .= "   inv.rvt_id, inv.os_id, inv.event_id, inv.pattern_id, inv.csasset_id, inv.premigration, inv.serialnum, inv.primaryfunction,\n";
$sql .= "   inv.baselinedelta, inv.notes, inv.verifiedscope, inv.discoverystatus, inv.dispositioncode, inv.ipdipositioncode, inv.disasterrecovery, \n";
$sql .= "   inv.ipcell, vl.number, ev.wavesequence\n";
$sql .= "  FROM `i_wsib`.`inventory` inv \n";
$sql .= "  LEFT JOIN `i_wsib`.`ipadd` ip ON inv.ipadd_id = ip.id\n";
$sql .= "  LEFT JOIN `i_wsib`.`vlan` vl ON ip.vlan_id = vl.id\n";
$sql .= "  LEFT JOIN `i_wsib`.`event` ev ON inv.event_id = ev.id\n";
$sql .= "    WHERE wsibname IS NOT NULL;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	#$lkINV
	my $wsibname = $refr[0];
	$lkINV{$wsibname}{rscdname} = (defined($refr[1]) ? $refr[1] : "");
	$lkINV{$wsibname}{category} = (defined($refr[2]) ? $refr[2] : "");
	$lkINV{$wsibname}{location_id} = (defined($refr[3]) ? $refr[3] : "");
	$lkINV{$wsibname}{tgtlocation_id} = (defined($refr[4]) ? $refr[4] : "");
	$lkINV{$wsibname}{ipadd_id} = (defined($refr[5]) ? $refr[5] : "");
	$lkINV{$wsibname}{addm_id} = (defined($refr[6]) ? $refr[6] : "");
	$lkINV{$wsibname}{opsinv_id} = (defined($refr[7]) ? $refr[7] : "");
	$lkINV{$wsibname}{rvt_id} = (defined($refr[8]) ? $refr[8] : "");
	$lkINV{$wsibname}{os_id} = (defined($refr[9]) ? $refr[9] : "");
	$lkINV{$wsibname}{event_id} = (defined($refr[10]) ? $refr[10] : "");
	$lkINV{$wsibname}{pattern_id} = (defined($refr[11]) ? $refr[11] : "");
	$lkINV{$wsibname}{csasset_id} = (defined($refr[12]) ? $refr[12] : "");
	$lkINV{$wsibname}{premigration} = (defined($refr[13]) ? $refr[13] : "");
	$lkINV{$wsibname}{serialnum} = (defined($refr[14]) ? $refr[14] : "");
	$lkINV{$wsibname}{primaryfunction} = (defined($refr[15]) ? $refr[15] : "");
	$lkINV{$wsibname}{baselinedelta} = (defined($refr[16]) ? $refr[16] : "");
	$lkINV{$wsibname}{notes} = (defined($refr[17]) ? $refr[17] : "");
	$lkINV{$wsibname}{verifiedscope} = (defined($refr[18]) ? $refr[18] : "");
	$lkINV{$wsibname}{discoverystatus} = (defined($refr[19]) ? $refr[19] : "");
	$lkINV{$wsibname}{dispositioncode} = (defined($refr[20]) ? $refr[20] : "");
	$lkINV{$wsibname}{ipdispositioncode} = (defined($refr[21]) ? $refr[21] : "");
	$lkINV{$wsibname}{disasterrecovery} = (defined($refr[22]) ? $refr[22] : "");
	$lkINV{$wsibname}{ipcell} = (defined($refr[23]) ? $refr[23] : "");
	$lkINV{$wsibname}{vlannum} = (defined($refr[24]) ? $refr[24] : "");
	$lkINV{$wsibname}{wavesequence} = (defined($refr[25]) ? $refr[25] : "");
	print "******* LKU INV: wsibname: " . $wsibname . " vlannum: " . $lkINV{$wsibname}{vlannum} . "\n" if ($DEBUGSQL); # debug sql
}

## wave:# or w:# -- collect all of the details for all HOSTNAMES for a specific wave sequence number
## hostname -- collect all of the details for specific HOSTNAMES, regardless of wave

my @WAVES = ();
my @HOSTS = ();

foreach my $arg (@ARGV) {
	my @qrylist = split(/\,/,$arg); # split by comma
	foreach my $qry (@qrylist) {
		if ($qry =~ m/\:/) { # contains a colon separator
			my ($ctl1, $num1) = split(/\:/,$qry); # split into 2 args
			if (lc($ctl1) eq "w" || $ctl1 =~ m/wav/i) { # wave sequence queried
				if ($num1 =~ m/\-/) { # contains a dash separator meaning waves m-n
					my ($wslo, $wshi) = split(/\-/,$num1); # split into 2 args
					if (looks_like_number($wslo) && $wslo > 0 && looks_like_number($wshi) && $wshi > $wslo) {
						for (my $i = $wslo; $i <= $wshi; $i++) {
							push(@WAVES,$i);
						}
					}
				} elsif (looks_like_number($num1) && $num1 > 0) {
					push(@WAVES,$num1);
				}
			}
		} elsif (length($qry) > 4 && exists($lkHOST{lc($qry)})) {
			push(@HOSTS,lc($qry));
		}
	}
}

## figure out the file content
my $file_content = "";
my $valid_queries = 0;

if (scalar @WAVES) {
	my $elecount = scalar @WAVES;
	$valid_queries += $elecount;
	$file_content .= "." if ($file_content ne "");
	$file_content .= $elecount . "xWave";
	$file_content .= "s" if ($elecount != 1);
}
if (scalar @HOSTS) {
	my $elecount = scalar @HOSTS;
	$valid_queries += $elecount;
	$file_content .= "." if ($file_content ne "");
	$file_content .= $elecount . "xHost";
	$file_content .= "s" if ($elecount != 1);
}

if ($valid_queries == 0) { # no valid queries supplied
	$dbh->disconnect(); # Disconnect from the database.
	die "\n*** ERROR: No valid query parameters were supplied as a command line parameters, so cannot proceed.\n\n";
}

# Output a banner to show what we're doing
Display_Pgm_Banner("GENERATING MIGRATION PROFILE REPORT");

# other variables --------------------------------------------------------
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
my $today = (1900 + $year) . sprintf("%02d",$mon + 1) . sprintf("%02d",$mday);
my $xlsxfilenm =  $main::SCRIPT_TAG . " " . $main::CUST_NAME . " " . $file_content . " Migration Profile Report-v" . $main::SCRIPT_VER . "_" . $today . ".xlsx";

# Create a new workbook --------------------------------------------------
my $workbookout = Excel::Writer::XLSX->new($xlsxfilenm);
die "Problems creating new Excel file: $!" unless defined $workbookout;

$workbookout->set_properties(
	title    	=> 'IBM Migration Profile Report'),
	subject  	=> 'IBM '. $file_content .' Migration Profile Report',
	author   	=> 'Joseph Blaty',
	company   	=> 'IBM Corporation',
	comments 	=> 'Complete discovery details by host.',
);

# custom formats and colors ----------------------------------------------
# set_custom_color($index, $red, $green, $blue) --------------------------
my $greenbar = $workbookout->set_custom_color(54, 228, 255, 223); # Green bar color

my $brightblue = $workbookout->set_custom_color(40, 0, 112, 192); # Bright Blue Header Color

my $wavepurple = $workbookout->set_custom_color(41, 204, 192, 218); # Purple Wave Color

my $osorange = $workbookout->set_custom_color(42, 252, 213, 180); # Orange OS Color

my $appskyblue = $workbookout->set_custom_color(43, 183, 222, 232); # Sky Blue App Color

my $purplerain = $workbookout->set_custom_color(44, 112, 48, 160); # Purple Cell color

my $title_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'center',
	valign => 'bottom' );

my $title_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'left',
	valign => 'bottom' );

my $title_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'right',
	valign => 'bottom' );

my $wave_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $wavepurple,
		align => 'center',
		valign => 'bottom' );

my $wave_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $wavepurple,
		align => 'left',
		valign => 'bottom' );

my $os_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $osorange,
		align => 'center',
		valign => 'bottom' );

my $os_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $osorange,
		align => 'left',
		valign => 'bottom' );

my $app_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $appskyblue,
		align => 'center',
		valign => 'bottom' );

my $app_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $appskyblue,
		align => 'left',
		valign => 'bottom' );

my $notes_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_NOTES,
	bold => 1,
	border=> 1,
		color => 'red',
	align => 'left',
	text_wrap=> 1,
	valign => 'bottom' );

my $row_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	bold => 1,
	border=> 1,
	align => 'center',
	valign => 'bottom' );

my $cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	align => 'right',
	valign => 'bottom' );

my $cell_fmt_lbl	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	bold => 1,
	border=> 1,
	align => 'right',
	valign => 'bottom' );

my $cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $cell_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'right',
	valign => 'bottom' );

my $gn_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	align => 'right',
	valign => 'bottom' );

my $gn_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $gn_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $totals_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	bold => 1,
	border=> 1,
	color => 'white',
	bg_color => 'grey',
	align => 'right',
	valign => 'bottom' );

my $totals_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	border=> 1,
	bold => 1,
	color => 'white',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $totals_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	bold => 1,
	border=> 1,
	color => 'white',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $ye_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	align => 'right',
	valign => 'bottom' );

my $ye_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $ye_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $re_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	align => 'right',
	valign => 'bottom' );

my $re_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $re_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $grey_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'yellow',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $grey_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'yellow',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $purple_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $purplerain,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $purple_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $purplerain,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

### END OF EXCEL formats

## Set up the columns of the VLAN worksheet
my %xlsTrfOrd=();	# hash table to define spreadsheet column order
my %xlsTrfCol=();	# hash table to define spreadsheet columns from which to obtain data

for my $col ( 0 .. ($MAX_COLS - 1)) {
	if 	( $col == 0 ) { #A
		$xlsTrfOrd{$col}{label} = "direction";
		$xlsTrfOrd{$col}{title} = "Direction";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 1 ) { #B
		$xlsTrfOrd{$col}{label} = "srcaddr";
		$xlsTrfOrd{$col}{title} = "Source IP";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 2 ) { #C
		$xlsTrfOrd{$col}{label} = "srcvlan";
		$xlsTrfOrd{$col}{title} = "Source VLAN";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 3 ) { #D
		$xlsTrfOrd{$col}{label} = "srcdc";
		$xlsTrfOrd{$col}{title} = "Source Location";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 4 ) { #E
		$xlsTrfOrd{$col}{label} = "srcvname";
		$xlsTrfOrd{$col}{title} = "Source VLAN Name";
		$xlsTrfOrd{$col}{width} = 38;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 5 ) { #F
		$xlsTrfOrd{$col}{label} = "srcsubnet";
		$xlsTrfOrd{$col}{title} = "Source Subnet";
		$xlsTrfOrd{$col}{width} = 24;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 6 ) { #G
		$xlsTrfOrd{$col}{label} = "srchostname";
		$xlsTrfOrd{$col}{title} = "Source Hostname";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 7 ) { #H
		$xlsTrfOrd{$col}{label} = "srcgroup";
		$xlsTrfOrd{$col}{title} = "Source Group";
		$xlsTrfOrd{$col}{width} = 38;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 8 ) { #I
		$xlsTrfOrd{$col}{label} = "destaddr";
		$xlsTrfOrd{$col}{title} = "Dest. IP";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 9 ) { #J
		$xlsTrfOrd{$col}{label} = "destvlan";
		$xlsTrfOrd{$col}{title} = "Dest. VLAN";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 10 ) { #K
		$xlsTrfOrd{$col}{label} = "destdc";
		$xlsTrfOrd{$col}{title} = "Dest. DC";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 11 ) { #L
		$xlsTrfOrd{$col}{label} = "destvname";
		$xlsTrfOrd{$col}{title} = "Dest. VLAN Name";
		$xlsTrfOrd{$col}{width} = 38;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 12 ) { #M
		$xlsTrfOrd{$col}{label} = "destsubnet";
		$xlsTrfOrd{$col}{title} = "Dest. Subnet";
		$xlsTrfOrd{$col}{width} = 24;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 13 ) { #N
		$xlsTrfOrd{$col}{label} = "desthostname";
		$xlsTrfOrd{$col}{title} = "Dest. Hostname";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 14 ) { #O
		$xlsTrfOrd{$col}{label} = "destgroup";
		$xlsTrfOrd{$col}{title} = "Dest. Group";
		$xlsTrfOrd{$col}{width} = 38;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 15 ) { #P
		$xlsTrfOrd{$col}{label} = "destport";
		$xlsTrfOrd{$col}{title} = "Dest. Port";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 16 ) { #Q
		$xlsTrfOrd{$col}{label} = "protocol";
		$xlsTrfOrd{$col}{title} = "Protocol";
		$xlsTrfOrd{$col}{width} = 24;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 17 ) { #R
		$xlsTrfOrd{$col}{label} = "hitcount";
		$xlsTrfOrd{$col}{title} = "Hit Count";
		$xlsTrfOrd{$col}{width} = 18;
		$xlsTrfOrd{$col}{hformat} = $title_fmt;
	} # end if
	$xlsTrfCol{$xlsTrfOrd{$col}{label}}{col} = $col;
} # end for col


## WAVES PARAMETERS WERE PASSED
if (scalar @WAVES) {
	## for each WAVE in scope, loop here
	foreach my $waveseq (@WAVES) {
		next if (!looks_like_number($waveseq));
		# Find the hostnames in scope for that wave
		$sql = "SELECT inv.wsibname\n";
		$sql .= "  FROM `" . $main::IDB_NAME . "`.`inventory` inv \n";
		$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`event` ev  ON inv.event_id = ev.id\n";
		$sql .= "  WHERE ev.wavesequence = ". $waveseq ."\n";
		$sql .= "    AND inv.wsibname IS NOT NULL;\n";
		print $sql . "\n" if ($DEBUGSQL); # debug sql
		$sth = $dbh->prepare($sql);
		if (!$sth) {
			die "Error:" . $dbh->errstr . "\n";
		}
		if (!$sth->execute) {
			die "Error:" . $sth->errstr . "\n";
		}
		while (my @refr = $sth->fetchrow_array) {
			push(@HOSTS,$refr[0]); # HOST in scope
		}
	} # foreach my $waveseq (@WAVES) {
} #if (scalar @WAVES) {

@WAVES = (); # we don't need the input waves any longer - clean up
my %resWS = (); # hash table for ALL worksheets

## if we have hosts in the host list
if (scalar @HOSTS) {
	foreach my $hn (@HOSTS) {
		if (exists($lkINV{$hn})) {
			my $wsname = "";
			if (exists($lkINV{$hn}) && $lkINV{$hn}{vlannum} ne "") {
				$wsname = "v" . sprintf('%04d',$lkINV{$hn}{vlannum}) . "_" . $hn;
			} else {
				$wsname = "Other_" . $hn;
			}
			if (!exists($resWS{$wsname})) {
				## Create the worksheet
				$resWS{$wsname}{wks}	= $workbookout->add_worksheet($wsname);
				$resWS{$wsname}{row} = 0;
				$resWS{$wsname}{vlan} = $lkINV{$hn}{vlannum};
				$resWS{$wsname}{wsibname} = $hn;
			}
		} #if (!exists($lkHOST{$hn})) {
	} #foreach my $hn (@HOSTS) {
} # if (scalar @HOSTS) {


#	$lkHOST{$hn}{wsibname} =



		if ($detail_view) { # detail view
			## for each HOST in scope, loop here
			foreach my $hostnm (@inscopeHOSTS) {
				my $wsname = "w" . $waveseq . "_" . $hostnm;
				$resWS{$wsname}{wks}	= $workbookout->add_worksheet($wsname);
				$resWS{$wsname}{row} = 0;

				## column headers
				foreach my $col (sort keys %xlsOrd) {
					$resWS{$wsname}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
					$resWS{$wsname}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
				}
				$resWS{$wsname}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
				$resWS{$wsname}{row} += 1; # increment the row counter

				## now loop twice for outbound and inbound traffic
				for (my $i=0;$i < 2;$i++) {
					$sql = "SELECT ";
					if ($i == 0) {
						$sql .= "'OUTBOUND' as value,";
					} else {
						$sql .= "'INBOUND' as value,";
					}
					$sql .= "INET_NTOA(csp.srcaddr) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
					$sql .= "INET_NTOA(csp.destaddr) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
					$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` inscopeIPs ON csp.src_ipadd_id = inscopeIPs.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON inscopeIPs.vlan_id = vls.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";
					if ($i == 0) {
						$sql .= "where csp.srcname = \'";
					} else {
						$sql .= "where csp.destname = \'";
					}
					$sql .= $hostnm . "\'\n";
					if ($i == 0) {
						$sql .= "ORDER BY vls.number, csp.srcaddr, csp.destaddr;\n";
					} else {
						$sql .= "ORDER BY vld.number, csp.destaddr, csp.srcaddr;\n";
					}
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$sth = $dbh->prepare($sql);
					if (!$sth) {
						die "Error:" . $dbh->errstr . "\n";
					}
					if (!$sth->execute) {
						die "Error:" . $sth->errstr . "\n";
					}

					while (my @refr = $sth->fetchrow_array) {
						foreach my $col (sort keys %xlsOrd) {
							my $this_cell_format = $cell_fmt_ct;
							my $this_cell_value = "";
							$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
							$resWS{$wsname}{wks} -> write($resWS{$wsname}{row}, $col, $this_cell_value , $this_cell_format);
							$resWS{$wsname}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
						}
						$resWS{$wsname}{row} += 1; # increment the row counter
					} # sql results loop
				} ## for loop inbound/outbound traffic
				$resWS{$wsname}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
				$resWS{$wsname}{wks} -> freeze_panes(1,0); # freeze panes on the first row
			} ## foreach hostnm
		} else { # rollup view
			my $wsname = "Wave " . $waveseq;
			$resWS{$wsname}{wks}	= $workbookout->add_worksheet($wsname);
			$resWS{$wsname}{row} = 0;

			## column headers
			foreach my $col (sort keys %xlsOrd) {
				$resWS{$wsname}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
				$resWS{$wsname}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
			}
			$resWS{$wsname}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
			$resWS{$wsname}{row} += 1; # increment the row counter

			## now loop twice for outbound and inbound traffic
			for (my $i=0;$i < 2;$i++) {
				$sql = "SELECT ";
				if ($i == 0) {
					$sql .= "'OUTBOUND' as value,";
				} else {
					$sql .= "'INBOUND' as value,";
				}
				$sql .= "INET_NTOA(csp.srcaddr) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
				$sql .= "INET_NTOA(csp.destaddr) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
				$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` inscopeIPs ON csp.src_ipadd_id = inscopeIPs.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON inscopeIPs.vlan_id = vls.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";
				if ($i == 0) {
					$sql .= "where csp.srcname IN (";
				} else {
					$sql .= "where csp.destname IN (";
				}
				$sql .= $inscopeHOSTstr . ")\n";
				if ($i == 0) {
					$sql .= "ORDER BY vls.number, csp.srcname, csp.srcaddr, csp.destaddr;\n";
				} else {
					$sql .= "ORDER BY vld.number, csp.destname, csp.destaddr, csp.srcaddr;\n";
				}
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$sth = $dbh->prepare($sql);
				if (!$sth) {
					die "Error:" . $dbh->errstr . "\n";
				}
				if (!$sth->execute) {
					die "Error:" . $sth->errstr . "\n";
				}

				while (my @refr = $sth->fetchrow_array) {
					foreach my $col (sort keys %xlsOrd) {
						my $this_cell_format = $cell_fmt_ct;
						my $this_cell_value = "";
						$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
						$resWS{$wsname}{wks} -> write($resWS{$wsname}{row}, $col, $this_cell_value , $this_cell_format);
						$resWS{$wsname}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
					}
					$resWS{$wsname}{row} += 1; # increment the row counter
				} # sql results loop
			} ## for loop inbound/outbound traffic
			$resWS{$wsname}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
			$resWS{$wsname}{wks} -> freeze_panes(1,0); # freeze panes on the first row
		} # detail or rollup view
	} # foreach @WAVES
} # if scalar @WAVES

## HOSTNAME PARAMETERS WERE PASSED
if (scalar @HOSTS) {
	## for each HOST in scope, loop here
	foreach my $hostnm (@HOSTS) {
		$resWS{$hostnm}{wks}	= $workbookout->add_worksheet($hostnm);
		$resWS{$hostnm}{row} = 0;

		## column headers
		foreach my $col (sort keys %xlsOrd) {
			$resWS{$hostnm}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
			$resWS{$hostnm}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
		}
		$resWS{$hostnm}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
		$resWS{$hostnm}{row} += 1; # increment the row counter

		## now loop twice for outbound and inbound traffic
		for (my $i=0;$i < 2;$i++) {
			$sql = "SELECT ";
			if ($i == 0) {
				$sql .= "'OUTBOUND' as value,";
			} else {
				$sql .= "'INBOUND' as value,";
			}
			$sql .= "INET_NTOA(csp.srcaddr) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
			$sql .= "INET_NTOA(csp.destaddr) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
			$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` inscopeIPs ON csp.src_ipadd_id = inscopeIPs.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON inscopeIPs.vlan_id = vls.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";
			if ($i == 0) {
				$sql .= "where csp.srcname = \'";
			} else {
				$sql .= "where csp.destname = \'";
			}
			$sql .= $hostnm . "\'\n";
			if ($i == 0) {
				$sql .= "ORDER BY vls.number, csp.srcaddr, csp.destaddr;\n";
			} else {
				$sql .= "ORDER BY vld.number, csp.destaddr, csp.srcaddr;\n";
			}
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$sth = $dbh->prepare($sql);
			if (!$sth) {
				die "Error:" . $dbh->errstr . "\n";
			}
			if (!$sth->execute) {
				die "Error:" . $sth->errstr . "\n";
			}
			my $inscopeIPstr = "";
			while (my @refr = $sth->fetchrow_array) {
				foreach my $col (sort keys %xlsOrd) {
					my $this_cell_format = $cell_fmt_ct;
					my $this_cell_value = "";
					$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
					$resWS{$hostnm}{wks} -> write($resWS{$hostnm}{row}, $col, $this_cell_value , $this_cell_format);
					$resWS{$hostnm}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
				}
				$resWS{$hostnm}{row} += 1; # increment the row counter
			} # sql results loop
		} ## for loop inbound/outbound traffic
		$resWS{$hostnm}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
		$resWS{$hostnm}{wks} -> freeze_panes(1,0); # freeze panes on the first row
	} ## foreach hostnm
} # if scalar @HOSTS

# Disconnect from the database.
$dbh->disconnect();
$workbookout->close(); # close and write the workbook
exit;
