#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	LoadBalancer File Load (Import)
### Date:		May 11, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 2/19/20 - Major revamp of IP Address handling
### 4/12/20 - Handle all IP addresses, regardless of VLAN
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::CIDR qw(cidrvalidate);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("LOAD BALANCER POOL DATA LOAD/UPDATE");

die "You must provide an Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkGIP	 				= ();	# hash table to lookup Global IP addresses already in the database
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my @FSUBS					= (); # array for fast IP to subnet validation

my %lkLBDEV				= ();	# hash table to lookup load balancer devices already in the database
my %lkLBPOOL			= ();	# hash table to lookup load balancer pool rows already in the database

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $IndexDelimit = '^';

my $iSqlErr				= 0;
my $iSqlIPInsert 	= 0;
my $iSqlIPUpdate 	= 0;
my $iSqlLBDInsert = 0;
my $iSqlLBPInsert = 0;
my $iSqlLBPUpdate = 0;
my $iDataErrors 	= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
		push @dbTables, lc($refr[0]);
}
## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

# -----------------------------------------------------------------------
# LOAD PRIOR DATA FOR LOOKUPS
# -----------------------------------------------------------------------
# LOCATION table lookups
# Check for the location table as it's key to proceed
if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		$lkLOC{$cd}{id} = $refr[1];
		print "******* LKU LOC: " . $cd . " key: " . $lkLOC{$cd}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# LBDEV table lookups
if ((grep { /lbdev/ } @dbTables) == 0) {
	print "Table: lbdev not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT name, id, location_id FROM `" . $main::IDB_NAME . "`.`lbdev`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $devnm = $refr[0];
		$lkLBDEV{$devnm}{id} = $refr[1];
		$lkLBDEV{$devnm}{location_id} = defined($refr[2]) ? $refr[2] : "";
		print "******* LKU LBDEV: " . $devnm . " key: " . $lkLBDEV{$devnm}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# LBDEV table lookups
if ((grep { /lbpool/ } @dbTables) == 0) {
	print "Table: lbpool not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, lbdev_id, vs_name, pool_name, INET_NTOA(pool_ipv4) FROM `" . $main::IDB_NAME . "`.`lbpool`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		## Lookup key for LBPOOL
		my $lbdev_id = $refr[1];
		my $vs_name = $refr[2];
		my $pool_name = $refr[3];
		my $pool_ipv4 = $refr[4];
		my $lku = $lbdev_id . $IndexDelimit . $vs_name . $IndexDelimit . $pool_name . $IndexDelimit . $pool_ipv4;
		$lkLBPOOL{$lku}{id} = $refr[0];
		$lkLBPOOL{$lku}{this_run} = 0; ## tracking
		print "******* LKU LBPOOL: " . $lku . " key: " . $lkLBPOOL{$lku}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}


# VLAN table subnet lookups
# create and/or truncate the VLAN table
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

# IP table lookups
$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), location_id, id, loadbal, vs_ipadd_id FROM `" . $main::IDB_NAME . "`.`ipadd`");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $fip = $refr[0];
	$lkGIP{$fip}{location_id} = (defined($refr[1]) ? $refr[1] : "");
	$lkGIP{$fip}{id} = $refr[2]; # the id table index is the data
	$lkGIP{$fip}{loadbal} = (defined($refr[3]) ? $refr[3] : 0);
	$lkGIP{$fip}{vs_ipadd_id} = (defined($refr[4]) ? $refr[4] : 0);
	$lkGIP{$fip}{this_run} = 0; # tracking - touched this run
	print "******* LKU GIP: fip=" . $fip . " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
}

## remove all of the old VLAN errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='loadbal';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}
# -----------------------------------------------------------------------
# SET UP TO PARSE THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
if ( !defined $workbook ) {
	$dbh->disconnect(); # disconnect gracefully
	die $parser->error() . ".\n";
}

# For this workbook, we need to parse several worksheets, so we need to loop through the workbook
for my $worksheet ( $workbook->worksheets() ) {
	my $current_sheet = trim($worksheet->get_name());

	if ($current_sheet =~ m/all_pools/i) {
		# Find out the worksheet ranges
		my ( $row_min, $row_max ) = $worksheet->row_range();
		my ( $col_min, $col_max ) = $worksheet->col_range();

		my $datactr_code = $current_sheet;
		$datactr_code =~ s/all_pools//i;
		$datactr_code =~ s/_virtualserver//i;
		$datactr_code = uc(trim($datactr_code));

		my $assetLOCkey = "";
		if (exists($lkLOC{$datactr_code})) {
			$assetLOCkey = $lkLOC{$datactr_code}{id};
		} else {
			$iDataErrors++; # this is a data error
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type = \'loadbal\',\n";
			$sql .= "   errorlog = \'Load Balancer file (". $file .") does not contain a valid location " . $datactr_code . ".\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
			next;
		}

		print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

		my $keycount = 0;
		my $TotalHeaders	= 6;	# total number of column headers we need to find in this worksheet to proceed with processing
		my %xlsCol = (); # Empty the column hash table
		$FIRST_DATA_ROW = 2;

		for my $row ( $row_min .. $row_max ) {
			$iExcelRows++; # increment total Excel row counter
			if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
				for my $col ( $col_min .. $col_max ) {
			  	my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			  	next unless $cell;
					my $fld = trim($cell->value());
					if 	( $fld =~ m/device/i  ) {
						$xlsCol{device_name} = $col;
						$keycount++;
					} elsif ( $fld =~ m/pool name/i) {
						$xlsCol{pool_name} = $col;
						$keycount++;
					} elsif ($fld =~ m/^pool member/i && !($fld =~ m/ip$/i)) {
						$xlsCol{pool_membername} = $col;
						$keycount++;
					} elsif ( $fld =~ m/member ip/i) {
						$xlsCol{pool_ipv4} = $col;
						$keycount++;
					} elsif ( $fld =~ m/virtual/i && $fld =~ m/server/i) {
						$xlsCol{vs_name} = $col;
						$keycount++;
					} elsif ( $fld =~ m/vs ip/i) {
						$xlsCol{vs_ipv4} = $col;
						$keycount++;
					} # end if
				} # end for col
			} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1) ) {
				print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
				print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
				print "****        KEYS FOUND:\n";
				foreach my $key (sort keys %xlsCol) {
					print "****           $key\n";
				}
				$dbh->disconnect(); # disconnect gracefully
				die;
			} elsif ($keycount == $TotalHeaders) {
				# new code for localized values
				my %xlsRowVal	= ();	# hash table to contain excel row values
				foreach my $key (keys %xlsCol) {
					my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
					$xlsRowVal{$key} = "";
					$xlsRowVal{$key} = trim($cell->value()) if $cell;
				}

				$xlsRowVal{device_name} = substr($xlsRowVal{device_name},0,255);
				$xlsRowVal{pool_name} = substr($xlsRowVal{pool_name},0,255);
				$xlsRowVal{pool_membername} = substr($xlsRowVal{pool_membername},0,255);
				$xlsRowVal{pool_ipv4} = ipfmt($xlsRowVal{pool_ipv4});
				$xlsRowVal{vs_name} = substr($xlsRowVal{vs_name},0,255);
				$xlsRowVal{vs_ipv4} = ipfmt($xlsRowVal{vs_ipv4});

				## skip this row if the virtualservername is "None"
				next if ($xlsRowVal{vs_name} eq "" || lc($xlsRowVal{vs_name}) eq "none");
				my $assetVSname = $xlsRowVal{vs_name};

				next if ($xlsRowVal{pool_name} eq "" || lc($xlsRowVal{pool_name}) eq "none");
				my $assetPoolname = $xlsRowVal{pool_name};

				## Device name exists already?
				my $assetLBDEVkey = "";
				## Check to see if the VCENTER record exists
				if (!exists($lkLBDEV{$xlsRowVal{device_name}})) {
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`lbdev` SET \n";
					$sql .= "   location_id = ". $assetLOCkey . ",\n";
					$sql .= "   name = \'". $xlsRowVal{device_name} . "\',\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
								print "Error while executing SQL:\n";
								print $sql . "\n";
								print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlLBDInsert++;
						$lkLBDEV{$xlsRowVal{device_name}}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
						$lkLBDEV{$xlsRowVal{device_name}}{location_id} = $assetLOCkey;
					}
				}

				$assetLBDEVkey = $lkLBDEV{$xlsRowVal{device_name}}{id} if (exists($lkLBDEV{$xlsRowVal{device_name}}));

				next if ($assetLBDEVkey eq ""); # can't insert without a device key

				## Now let's check the IP addresses
				## The VIP should always be on one of our local subnets -- if not, there's an error
				my $assetVSIPkey = "";
				my $assetVSIPv4 = "";
				$assetVSIPv4 = $xlsRowVal{vs_ipv4} if (is_ipv4($xlsRowVal{vs_ipv4}));
				if ($assetVSIPv4 ne "") { # we found a valid IP address
					my $sn = $SubClassifier->($assetVSIPv4); # find the subnet in range quickly
					if (defined($sn)) { # on one of our known subnets
						my $vlan_id =  $lkSUBNT{$sn}{vlan_id};
						my $sqlcoldata = "   location_id = ". (($assetLOCkey ne "") ? $assetLOCkey : "NULL")  . ",\n";
						$sqlcoldata .= "   ipv4 = INET_ATON(\'" . $assetVSIPv4 . "\'),\n";
						$sqlcoldata .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
						$sqlcoldata .= "   loadbal = " . $main::hashLBScope{vip} .  ",\n";
						$sqlcoldata .= "   inuse = 1,\n";

						if (exists($lkGIP{$assetVSIPv4})) {
							$assetVSIPkey = $lkGIP{$assetVSIPv4}{id};
							if (!$lkGIP{$assetVSIPv4}{this_run}) {
								$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
								$sql .= $sqlcoldata;
								$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
								$sql .= "   WHERE id = " . $lkGIP{$assetVSIPv4}{id} . ";\n";
								print $sql . "\n" if ($DEBUGSQL); # debug sql
								$dbh->do($sql);
								if (!defined($dbh) ) {
									print "Error while executing SQL:\n";
									print $sql . "\n";
									print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
									$iSqlErr++;
								} else {
									$iSqlIPUpdate++;
									$lkGIP{$assetVSIPv4}{loadbal} = $main::hashLBScope{vip};
									$lkGIP{$assetVSIPv4}{vs_ipadd_id} = ""; # there is no parent vip to the vip
									$lkGIP{$assetVSIPv4}{this_run} = 1; # tracking - touched this run
								} # we inserted a record
							}
						} else {
							$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
							$sql .= $sqlcoldata;
							$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
							$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
							print $sql . "\n" if ($DEBUGSQL); # debug sql
							$dbh->do($sql);
							if (!defined($dbh) ) {
								print "Error while executing SQL:\n";
								print $sql . "\n";
								print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
								$iSqlErr++;
							} else {
								$iSqlIPInsert++;
								$lkGIP{$assetVSIPv4}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
								$assetVSIPkey = $lkGIP{$assetVSIPv4}{id};
								$lkGIP{$assetVSIPv4}{loadbal} = $main::hashLBScope{vip};
								$lkGIP{$assetVSIPv4}{vs_ipadd_id} = ""; # there is no parent vip to the vip
								$lkGIP{$assetVSIPv4}{this_run} = 1; # tracking - touched this run
							} # we updated a record
						}
					} else { # not on one of our known subnets -- ERROR
						$iDataErrors++; # this is a data error
						$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
						$sql .= "   type = \'loadbal\',\n";
						$sql .= "   errorlog = \'LB row (". ($row+1) .") VIRTUAL SERVER VIP (". $assetVSIPv4 .") IS NOT ON A VALID SUBNET RANGE.\',\n";
						$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
						print $sql . "\n" if ($DEBUGSQL); # debug sql
						$dbh->do($sql);
						if (!defined($dbh) ) {
							print "Error while executing SQL:\n";
							print $sql . "\n";
							print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
							$iSqlErr++;
						}
						next;
					}
				} # if (is_ipv4($xlsRowVal{vsip})) { # we found a valid IP address

				## now check the pool member IP to see if we already have it or add it
				my $assetPoolIPkey = "";
				my $assetPoolIPv4 = "";
				$assetPoolIPv4 = $xlsRowVal{pool_ipv4} if (is_ipv4($xlsRowVal{pool_ipv4}));
				if ($assetPoolIPv4 ne "") { # we found a valid IP address
					my $sn = $SubClassifier->($assetPoolIPv4); # find the subnet in range quickly
					if (defined($sn)) { # on one of our known subnets
						my $vlan_id =  $lkSUBNT{$sn}{vlan_id};
						my $sqlcoldata = "   location_id = ". (($assetLOCkey ne "") ? $assetLOCkey : "NULL")  . ",\n";
						$sqlcoldata .= "   ipv4 = INET_ATON(\'" . $assetPoolIPv4  . "\'),\n";
						$sqlcoldata .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
						$sqlcoldata .= "   vs_ipadd_id = ". (($assetVSIPkey ne "") ? $assetVSIPkey : "NULL")  . ",\n";
						$sqlcoldata .= "   loadbal = " . $main::hashLBScope{pool} .  ",\n";
						$sqlcoldata .= "   inuse = 1,\n";

						if (exists($lkGIP{$assetPoolIPv4 })) {
							$assetPoolIPkey = $lkGIP{$assetPoolIPv4}{id};
							if (!$lkGIP{$assetPoolIPv4}{this_run}) {
								$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
								$sql .= $sqlcoldata;
								$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
								$sql .= "   WHERE id = " . $lkGIP{$assetPoolIPv4}{id} . ";\n";
								print $sql . "\n" if ($DEBUGSQL); # debug sql
								$dbh->do($sql);
								if (!defined($dbh) ) {
									print "Error while executing SQL:\n";
									print $sql . "\n";
									print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
									$iSqlErr++;
								} else {
									$iSqlIPUpdate++;
									$lkGIP{$assetPoolIPv4}{loadbal} = $main::hashLBScope{pool};
									$lkGIP{$assetPoolIPv4}{vs_ipadd_id} = ($assetVSIPkey ne "") ? $assetVSIPkey : ""; # parent vip to the pool member
									$lkGIP{$assetPoolIPv4}{this_run} = 1; # tracking - touched this run
								} # we updated a record
							}
						} else { # !exists($lkGIP{$ipv4})
							$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
							$sql .= $sqlcoldata;
							$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
							$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
							print $sql . "\n" if ($DEBUGSQL); # debug sql
							$dbh->do($sql);
							if (!defined($dbh) ) {
								print "Error while executing SQL:\n";
								print $sql . "\n";
								print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
								$iSqlErr++;
							} else {
								$iSqlIPInsert++;
								$lkGIP{$assetPoolIPv4}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
								$assetPoolIPkey = $lkGIP{$assetPoolIPv4}{id};
								$lkGIP{$assetPoolIPv4}{loadbal} = $main::hashLBScope{pool};
								$lkGIP{$assetPoolIPv4}{vs_ipadd_id} = ($assetVSIPkey ne "") ? $assetVSIPkey : ""; # parent vip to the pool member
								$lkGIP{$assetPoolIPv4}{this_run} = 1; # tracking - touched this run
							} # we inserted a record
						}
					} # on a known subnet
				} # if (is_ipv4($xlsRowVal{poolip})) { # we found a valid IP address

				## now insert or update the lbpool table
				if ($assetLBDEVkey ne "" && $assetVSname ne "" && $assetPoolname ne "" && $assetPoolIPv4 ne "" && $assetVSIPv4 ne "") {
					my $sqlcoldata = "   lbdev_id = ". $assetLBDEVkey  . ",\n";
					$sqlcoldata .= "   vs_name = \'" . $assetVSname . "\',\n";
					$sqlcoldata .= "   pool_name = \'" . $assetPoolname . "\',\n";
					$sqlcoldata .= "   vs_ipv4 = INET_ATON(\'" . $assetVSIPv4  . "\'),\n";
					$sqlcoldata .= "   pool_ipv4 = INET_ATON(\'" . $assetPoolIPv4  . "\'),\n";
					$sqlcoldata .= "   pool_membername = " . ( $xlsRowVal{pool_membername} ne "" ? "\'" . $xlsRowVal{pool_membername} . "\'" : "NULL" ) . ",\n";
					$sqlcoldata .= "   vs_ipadd_id = ". (($assetVSIPkey ne "") ? $assetVSIPkey : "NULL")  . ",\n";
					$sqlcoldata .= "   pool_ipadd_id = ". (($assetPoolIPkey ne "") ? $assetPoolIPkey : "NULL")  . ",\n";

					## Lookup key for LBPOOL
					my $lku = $assetLBDEVkey . $IndexDelimit . $assetVSname . $IndexDelimit . $assetPoolname . $IndexDelimit . $xlsRowVal{pool_ipv4};
					if (exists($lkLBPOOL{$lku})) {
						if (!$lkLBPOOL{$lku}{this_run}) {
							$sql = "UPDATE `" . $main::IDB_NAME . "`.`lbpool` SET \n";
							$sql .= $sqlcoldata;
							$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
							$sql .= "   WHERE id = " . $lkLBPOOL{$lku}{id} . ";\n";
							print $sql . "\n" if ($DEBUGSQL); # debug sql
							$dbh->do($sql);
							if (!defined($dbh) ) {
								print "Error while executing SQL:\n";
								print $sql . "\n";
								print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
								$iSqlErr++;
							} else {
								$iSqlLBPUpdate++;
								$lkLBPOOL{$lku}{this_run} = 1; # tracking - touched this run
							} # we updated a record
						}
					} else {
						$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`lbpool` SET \n";
						$sql .= $sqlcoldata;
						$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
						$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
						print $sql . "\n" if ($DEBUGSQL); # debug sql
						$dbh->do($sql);
						if (!defined($dbh) ) {
							print "Error while executing SQL:\n";
							print $sql . "\n";
							print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
							$iSqlErr++;
						} else {
							$iSqlLBPInsert++;
							$lkLBPOOL{$lku}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
							$lkLBPOOL{$lku}{this_run} = 1; # tracking - touched this run
						} # we inserted a record
					}
				}
			} #end if headers identification
		} # end for row
	} ## if ($current_sheet =~ m/all_pools/i) {
} # end for worksheet

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-lb-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "IP Inserts\t:" . $iSqlIPInsert . "\n";
print "IP Updates\t:" . $iSqlIPUpdate . "\n";
print "LBDev Inserts\t:" . $iSqlLBDInsert . "\n";
print "LBPool Inserts\t:" . $iSqlLBPInsert . "\n";
print "LBPool Updates\t:" . $iSqlLBPUpdate . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
