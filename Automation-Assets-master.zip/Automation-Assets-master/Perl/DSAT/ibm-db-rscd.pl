#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	RSCD shortname injection to database file
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("RSCD Injector");

die "You must provide an input Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));


my %lkIP	 				= ();	# hash table to lookup IP addresses already in the database

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 0; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr	= 0;
my $iSqlIPNotFound = 0;
my $iDataErrors = 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	#$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), location_id, id, inuse, inops FROM `" . $main::IDB_NAME . "`.`ipadd`");
	$sql = "SELECT INET_NTOA(ip.ipv4), op.rscdname \n";
	$sql .= " FROM `" . $main::IDB_NAME . "`.`ipadd` ip\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`opsinv` op ON op.ipadd_id = ip.id; \n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0];
		$lkIP{$lkey}{shortname} = "";
		$lkIP{$lkey}{shortname} = $refr[1] if (defined($refr[1]));
	}
}

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet = "";
my $keycount = 0;
my $TotalHeaders	= 2;
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min=0;
my $row_max=0;
my $col_min=0;
my $col_max=0;

### MAIN WSIB_Servers worksheet
my $worksheet = $workbook->worksheet(0);

if (!defined($worksheet)) {
	$dbh->disconnect();
	die "ERROR -- WSIB_Servers worksheet not found.\n";
}

## remove all of the old MASTER errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='opsinv';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

$current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
( $row_min, $row_max ) = $worksheet->row_range();
( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

$keycount = 0;
$TotalHeaders	= 1;	# total number of column headers we need to find in this worksheet to proceed with processing
%xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 2;

for my $row ( $row_min .. $row_max ) {
	$iExcelRows++; # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if ( $fld =~ m/ip address/i ) {
				$xlsCol{primaryip} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		# NEW CODE TO LOCALIZE ROW VALUES
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if $cell;
		}

		my $XLRow = $row + 1; # the Excel row for error reporting

		my $assetIPv4 = "";

		$xlsRowVal{primaryip} = ipfmt($xlsRowVal{primaryip});
		$assetIPv4 = $xlsRowVal{primaryip} if ($xlsRowVal{primaryip} ne "");
		if (exists($lkIP{$assetIPv4})) {
			print $lkIP{$assetIPv4}{shortname} . "\n";
		} else {
			print "\n";
			$iSqlIPNotFound++;
		}
	} # end if headers have all been found
} # end for row

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "IP Not Found\t:" . $iSqlIPNotFound . "\n";
print "SQL Errors\t\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
