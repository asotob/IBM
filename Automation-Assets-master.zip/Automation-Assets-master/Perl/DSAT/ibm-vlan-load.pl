#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	VLAN File Load (Import)
### Date:		August 7, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 2/19/20 - Major revamp of IP Address handling
### 4/12/20 - Handle all IP addresses, regardless of VLAN
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::CIDR qw(cidrvalidate);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("VLAN & LB IP LOAD/UPDATE");

die "You must provide an Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkLOC	 			= ();	# hash table to lookup LOCATION already in the database
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my %thisSN				= ();	# hash table to lookup SUBNETS already processed on this run to search for duplicates
my @FSUBS				= (); # array for fast IP to subnet validation

my $iExcelRows 			= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr				= 0;
my $iSqlVLANInsert 		= 0;
my $iSqlVLANUpdate 		= 0;
my $iDataErrors 		= 0;

my $IndexDelimit 		= '^';

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
		push @dbTables, lc($refr[0]);
}
## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

# -----------------------------------------------------------------------
# LOAD PRIOR DATA FOR LOOKUPS
# -----------------------------------------------------------------------
# LOCATION table lookups
# Check for the location table as it's key to proceed
if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		$lkLOC{$cd}{id} = $refr[1];
		print "******* LKU LOC: " . $cd . " key: " . $lkLOC{$cd}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# VLAN table subnet lookups
# create and/or truncate the VLAN table
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0] . $IndexDelimit . $refr[2]; # location-subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## remove all of the old VLAN errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='vlan';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}
# -----------------------------------------------------------------------
# SET UP TO PARSE THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
if ( !defined $workbook ) {
	$dbh->disconnect(); # disconnect gracefully
	die $parser->error() . ".\n";
}

# For this workbook, we need to parse several worksheets, so we need to loop through the workbook
for my $worksheet ( $workbook->worksheets() ) {
	my $current_sheet = trim($worksheet->get_name());

	if ($current_sheet =~ m/subnet allocation/i) {
		# Find out the worksheet ranges
		my ( $row_min, $row_max ) = $worksheet->row_range();
		my ( $col_min, $col_max ) = $worksheet->col_range();

		print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

		my $keycount = 0;
		my $TotalHeaders	= 7;	# total number of column headers we need to find in this worksheet to proceed with processing
		my %xlsCol = (); # Empty the column hash table
		$FIRST_DATA_ROW = 2;

		for my $row ( $row_min .. $row_max ) {
			$iExcelRows++; # increment total Excel row counter
			if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
				for my $col ( $col_min .. $col_max ) {
			  	my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			  	next unless $cell;
					my $fld = trim($cell->value());
					if 	( $fld =~ m/vlan id/i  ) {
						$xlsCol{number} = $col;
						$keycount++;
					} elsif ( $fld =~ m/vlan name/i ) {
						$xlsCol{vlanname} = $col;
						$keycount++;
					} elsif ( $fld =~ m/subnet/i ) {
						$xlsCol{subnet} = $col;
						$keycount++;
					} elsif ( $fld =~ m/zone/i ) {
						$xlsCol{zone} = $col;
						$keycount++;
					} elsif ( $fld =~ m/environment/i && $fld =~ m/1/ ) {
						$xlsCol{env1} = $col;
						$keycount++;
					} elsif ( $fld =~ m/environment/i && $fld =~ m/2/ ) {
						$xlsCol{env2} = $col;
						$keycount++;
					} elsif ( $fld =~ m/location/i ) {
						$xlsCol{loc} = $col;
						$keycount++;
					} # end if
				} # end for col
			} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1) ) {
				print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
				print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
				print "****        KEYS FOUND:\n";
				foreach my $key (sort keys %xlsCol) {
					print "****           $key\n";
				}
				$dbh->disconnect(); # disconnect gracefully
				die;
			} elsif ($keycount == $TotalHeaders) {
				# new code for localized values
				my %xlsRowVal	= ();	# hash table to contain excel row values
				foreach my $key (keys %xlsCol) {
					my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
					$xlsRowVal{$key} = "";
					$xlsRowVal{$key} = trim($cell->value()) if $cell;
				}

				# FIRST, CHECK TO SEE IF WE HAVE THE LOCATION ON THE TABLE
				next if ($xlsRowVal{loc} ne "" && !exists($lkLOC{$xlsRowVal{loc}}));

				## 4/20/20 figure out the target location based on the source
				## Find the target location
				my $assetTGTLOCkey = "";
				my $assetLOCcode = uc($xlsRowVal{loc});
				if ($assetLOCcode eq "MDC") {  # Mississauga
					$assetTGTLOCkey =  $lkLOC{"4AN"}{id}; # Markham
				} elsif ($assetLOCcode eq "DDC") { # Dickson-Montreal
					$assetTGTLOCkey =  $lkLOC{"5AW"}{id}; # Viger
				}

				next if ($xlsRowVal{number} eq "" || !looks_like_number($xlsRowVal{number})); # skip this row if any of these are true = filter bad data

				$xlsRowVal{subnet} = substr($xlsRowVal{subnet},0,255); # subnet must be unique
				next if ($xlsRowVal{subnet} eq ""); # must have the subnet to proceed

				## validate CIDR for subnet
				my $validSn = Net::CIDR::cidrvalidate($xlsRowVal{subnet}); # validate CIDR notation
				if (!defined($validSn) || $validSn ne $xlsRowVal{subnet}) {
					print "*ERROR: " . uc($current_sheet) . " row: " . ($row+1) . " Location " . $xlsRowVal{loc} . " VLAN " . $xlsRowVal{number} . " subnet ". $xlsRowVal{subnet} ."\n";
					print "\t Subnet is INVALID as it is not a valid CIDR.\n\tPlease correct the error as this record will NOT be inserted.\n\n";

					$iDataErrors++; # this is a data error
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
					$sql .= "   type = \'vlan\',\n";
					$sql .= "   errorlog = \'VLAN row (". ($row+1) .") SUBNET ". $xlsRowVal{subnet} ." IS NOT A VALID CIDR NOTATION.\',\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					}
					next;
				}

				# get rid of any questionable characters in the excel data
				$xlsRowVal{zone} =~ s/\?+//g;
				$xlsRowVal{env2} =~ s/\?+//g;
				if ($xlsRowVal{env1} =~ m/no\-/i || $xlsRowVal{env1} =~ m/not\-/i) {
					$xlsRowVal{env1} .= " (Legacy)" if ($xlsRowVal{env1} =~ m/no\-/i || $xlsRowVal{env1} =~ m/not\-/i); # append Legacy to the end
				} elsif ($xlsRowVal{env1} =~ m/g3/i) {
					$xlsRowVal{env1} .= " (Private Cloud)"; # append Private Cloud Legacy to the end
				}

				$xlsRowVal{vlanname} = substr($xlsRowVal{vlanname},0,255);
				$xlsRowVal{zone} = substr($xlsRowVal{zone},0,255);
				$xlsRowVal{env1} = substr($xlsRowVal{env1},0,255);
				$xlsRowVal{env2} = substr($xlsRowVal{env2},0,255);

				## 2/27/20 new sqlcoldata code to simplify NULLs
				my $sqlcoldata = "   location_id = ". $lkLOC{$xlsRowVal{loc}}{id} . ",\n";
				$sqlcoldata .= "   tgt_location_id = " . (($assetTGTLOCkey ne "") ? $assetTGTLOCkey : "NULL") . ",\n";
				$sqlcoldata .= "   subnet = \'". $xlsRowVal{subnet} . "\',\n";
				$sqlcoldata .= "   number = ". $xlsRowVal{number} . ",\n";
				$sqlcoldata .= "   name = " . (($xlsRowVal{vlanname} ne "") ? "\'". $xlsRowVal{vlanname} . "\'" : "NULL") . ",\n";
				$sqlcoldata .= "   zone = " . (($xlsRowVal{zone} ne "") ? "\'". $xlsRowVal{zone} . "\'" : "NULL") . ",\n";
				$sqlcoldata .= "   env1 = " . (($xlsRowVal{env1} ne "") ? "\'". $xlsRowVal{env1} . "\'" : "NULL") . ",\n";
				$sqlcoldata .= "   env2 = " . (($xlsRowVal{env2} ne "") ? "\'". $xlsRowVal{env2} . "\'" : "NULL") . ",\n";

				if (exists($lkSUBNT{$xlsRowVal{subnet}}) && $lkLOC{$xlsRowVal{loc}}{id} == $lkSUBNT{$xlsRowVal{subnet}}{loc_id}) { # already in the database, so we need to update
					if (exists($thisSN{$xlsRowVal{subnet}})) {
						print "*ERROR: " . uc($current_sheet) . " row: " . ($row+1) . " Location " . $xlsRowVal{loc} . " VLAN " . $xlsRowVal{number} . " subnet ". $xlsRowVal{subnet} ."\n";
						print "\t Subnet is already on the vlan table from row: ". $thisSN{$xlsRowVal{subnet}} .".\n\tThis indicates a duplicate record on the input file.\n\tPlease correct the error as this record will NOT be updated.\n\n";

						$iDataErrors++; # this is a data error
						$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
						$sql .= "   type = \'vlan\',\n";
						$sql .= "   errorlog = \'VLAN row (". ($row+1) .") SUBNET ". $xlsRowVal{subnet} ." DUPLICATED FROM ROW (". $thisSN{$xlsRowVal{subnet}} .") AND WILL NOT BE UPDATED.\',\n";
						$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
						print $sql . "\n" if ($DEBUGSQL); # debug sql
						$dbh->do($sql);
						if (!defined($dbh) ) {
							print "Error while executing SQL:\n";
							print $sql . "\n";
							print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
							$iSqlErr++;
						}
					} else {
						$sql = "UPDATE `" . $main::IDB_NAME . "`.`vlan` SET \n";
						$sql .= $sqlcoldata;
						$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
						$sql .= "   WHERE id = " . $lkSUBNT{$xlsRowVal{subnet}}{loc_id} . ";\n";
						$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
						print $sql . "\n" if ($DEBUGSQL); # debug sql
						$dbh->do($sql);
						if (!defined($dbh) ) {
							print "Error while executing SQL:\n";
							print $sql . "\n";
							print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
							$iSqlErr++;
						} else {
							$iSqlVLANUpdate++;
							$thisSN{$xlsRowVal{subnet}} = $row+1; # flag we processed this subnet on this run
						}
					}
				} else { # there isn't a row in the database, so we need to insert
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`vlan` SET \n";
					$sql .= $sqlcoldata;
					$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlVLANInsert++;
						my $vlanid = $dbh->{mysql_insertid};
						my $lkey2 = $lkLOC{$xlsRowVal{loc}}{id} . $IndexDelimit . $vlanid; # location-subnet
						$lkSUBNT{$lkey2}{vlan_id} = $vlanid;
						$lkSUBNT{$lkey2}{loc_id} = $lkLOC{$xlsRowVal{loc}}{id};
						push @FSUBS, $lkey2; # load FSUBS array for fast lookups
						$thisSN{$xlsRowVal{subnet}} = $row+1; # flag we processed this subnet on this run
					} # insert VLAN
				} # end if exists $lkVLAN
			} #end if headers identification
		} # end for row
	} ## 4/15/20 removed load balancer IPs as this is stale data - just load subnet allocation
} # end for worksheet

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-vlan-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "VLAN Inserts\t:" . $iSqlVLANInsert . "\n";
print "VLAN Updates\t:" . $iSqlVLANUpdate . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
