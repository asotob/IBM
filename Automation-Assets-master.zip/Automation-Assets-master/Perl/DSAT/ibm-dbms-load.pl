#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	DBMS (Database) Excel Workbook RE-Load (Import)
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("DBMS LOAD/UPDATE");

die "You must provide a Database Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my %lkGIP	 				= ();	# hash table to lookup Global IP addresses already in the database
my %lkDBMS 				= ();	# hash table to lookup DBMS data already in the database
my %lkINV	 				= ();	# hash table to lookup ASSET already in the database by rscd name
my %lkSAMI 				= ();	# hash table to lookup SAMI records already in the database (for legacy lookups by wsib hostname)
my @FSUBS					= (); # array for fast IP to subnet validation

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr	= 0;
my $iSqlDBMSInsert = 0;
my $iSqlDBIInsert = 0;
my $iSqlIPInsert = 0;
my $iDataErrors 	= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}
## New code 2/19/20 - Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

# IP table lookups
$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), id FROM `" . $main::IDB_NAME . "`.`ipadd`");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $fip = $refr[0];
	$lkGIP{$fip}{id} = $refr[1]; # the id table index is the data
	print "******* LKU GIP: fip=" . $fip . " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
}

if ((grep { /inventory/ } @dbTables) == 0) {
	print "Table: inventory not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	print "\n**** Loading INVENTORY lookup table...\n" if ($DEBUGSQL); # debug sql
	$sql = "SELECT inv.rscdname, inv.id, op.wsibname  \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`inventory` inv \n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`opsinv` op ON inv.opsinv_id = op.id \n";
	$sql .= "  WHERE inv.rscdname IS NOT NULL;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0]; # the lookup key is rscd shortname
		$lkINV{$lkey}{id} = $refr[1];
		$lkINV{$lkey}{wsibname} = (defined($refr[2]) ? $refr[2] : "");
		print "******* LKU INVENTORY: name:" . $lkey . " key: " . $lkINV{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /sami/ } @dbTables) == 0) { # SAMI table not found
	print "Table: sami not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT id, wsibname, rscdname, env, component \n";
	$sql .= "FROM `" . $main::IDB_NAME . "`.`sami`; \n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[1];
		$lkSAMI{$lkey}{id} = $refr[0]; # SAMI table index
		$lkSAMI{$lkey}{rscdname} = "";
		$lkSAMI{$lkey}{rscdname} =  $refr[2] if (defined($refr[2]));
		$lkSAMI{$lkey}{env} = "";
		$lkSAMI{$lkey}{env} =  $refr[3] if (defined($refr[3]));
		$lkSAMI{$lkey}{component} = "";
		$lkSAMI{$lkey}{component} =  $refr[4] if (defined($refr[4]));
		print "******* LKU SAMI: lkey=" . $lkey . " db key: " . $lkSAMI{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /dbms/ } @dbTables) == 0) { # table not found
	print "Table: dbms not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else { # we are rebuilding the table, so just truncate it
	$sql = "TRUNCATE `" . $main::IDB_NAME . "`.`dbms`;";
	$result = $dbh->do($sql);
}

if ((grep { /dbinst/ } @dbTables) == 0) { # table not found
	print "Table: dbinst not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else { # we are rebuilding the table, so just truncate it
	$sql = "TRUNCATE `" . $main::IDB_NAME . "`.`dbinst`;";
	$result = $dbh->do($sql);
}

## remove all of the old VLAN errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='dbms';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet;
my $keycount;
my $TotalHeaders;
my %xlsCol;	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min;
my $row_max;
my $col_min;
my $col_max;

################################################################################
################################################################################
### DBMS WORKSHEET
################################################################################
################################################################################
my $dbms_ws = $workbook->worksheet('DBMS');

if (defined($dbms_ws)) {
	$current_sheet = trim($dbms_ws->get_name());

	# Find out the worksheet ranges
	( $row_min, $row_max ) = $dbms_ws->row_range();
	( $col_min, $col_max ) = $dbms_ws->col_range();

	print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";
	$keycount = 0;
	$TotalHeaders	= 11;	# total number of column headers we need to find in this worksheet to proceed with processing
	$FIRST_DATA_ROW = 2;
	%xlsCol = ();

	for my $row ( $row_min .. $row_max ) {
		$iExcelRows++; # increment total Excel row counter
		if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
			for my $col ( $col_min .. $col_max ) {
				my $cell = $dbms_ws->get_cell( $row, $col ); # Return the cell object at $row and $col
				next unless $cell;
				my $fld = lc(trim($cell->value()));
				if 	( $fld =~ m/dbms/i && $fld =~ m/shortname/i ) {
					$xlsCol{shortname} = $col;
					$keycount++;
				} elsif ( $fld =~ m/manufacturer/i ) {
					$xlsCol{manufacturer} = $col;
					$keycount++;
				} elsif ( $fld =~ m/dbms type/i ) {
					$xlsCol{dbtype} = $col;
					$keycount++;
				} elsif ( $fld =~ m/edition/i  ) {
					$xlsCol{edition} = $col;
					$keycount++;
				} elsif (  $fld =~ m/version/i  ) { #5
					$xlsCol{version} = $col;
					$keycount++;
				} elsif (  $fld =~ m/latest/i  ) {
					$xlsCol{latestrel} = $col;
					$keycount++;
				} elsif ( $fld eq 'eol' ) {
					$xlsCol{eol} = $col;
					$keycount++;
				} elsif ( $fld =~ m/eoxs/i ) {
					$xlsCol{eoxs} = $col;
					$keycount++;
				} elsif ( $fld =~ m/speol/i ) {
					$xlsCol{speol} = $col;
					$keycount++;
				} elsif ( $fld =~ m/supported/i ) { #10
					$xlsCol{supported} = $col;
					$keycount++;
				} elsif ( $fld =~ m/notes/i ) {
					$xlsCol{notes} = $col;
					$keycount++;
				} # end if
			} # end for col
		} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
			print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
			print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
			print "****        KEYS FOUND:\n";
			foreach my $key (sort keys %xlsCol) {
				print "****           $key\n";
			}
			$dbh->disconnect(); # disconnect gracefully
			die;
		} elsif ($keycount == $TotalHeaders) {
			# new code for localized values
			my %xlsRowVal	= ();	# hash table to contain excel row values
			foreach my $key (keys %xlsCol) {
				my $cell = $dbms_ws->get_cell( $row, $xlsCol{$key} );
				$xlsRowVal{$key} = "";
				$xlsRowVal{$key} = trim($cell->value()) if $cell;
			}

			## reformat the manual data entered
			$xlsRowVal{shortname} = lc(substr($xlsRowVal{shortname},0,255));
			$xlsRowVal{manufacturer} = substr($xlsRowVal{manufacturer},0,255);
			$xlsRowVal{dbtype} = substr($xlsRowVal{dbtype},0,255);
			$xlsRowVal{edition} = substr($xlsRowVal{edition},0,255);
			$xlsRowVal{version} = substr($xlsRowVal{version},0,255);
			$xlsRowVal{latestrel} = uc(substr($xlsRowVal{latestrel},0,255));
			$xlsRowVal{eol} = substr($xlsRowVal{eol},0,255);
			$xlsRowVal{eoxs} = substr($xlsRowVal{eoxs},0,255);
			$xlsRowVal{speol} = substr($xlsRowVal{speol},0,255);
			$xlsRowVal{supported} = substr($xlsRowVal{supported},0,255);
			$xlsRowVal{notes} =~ s/\'/\\\'/g; # escape any single quotes
			$xlsRowVal{notes} = substr($xlsRowVal{notes},0,512);

			my $assetSupported = ($xlsRowVal{supported} =~ m/y/i) ? 1 : 0;

			# pull together some key fields for insert/update later
			my $assetXLRow = ($row + 1); # row is actually behind by 1
			my $assetShortname = lc($xlsRowVal{shortname});

			# make sure we have a valid location key
			if ($assetShortname eq "") {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'dbms\',\n";
				 $sql .= "   errorlog = \'Database worksheet ". $current_sheet . " row (". $assetXLRow .") DBMS SHORTNAME IS BLANK.\',\n";
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
				 next; # skip this record
			}

			## now insert (no updates since this is a reload)
			## sqlcoldata code to simplify NULLs
			my $sqlcoldata = "   shortname = \'". $assetShortname . "\',\n";
			$sqlcoldata .= "   manufacturer = " . (($xlsRowVal{manufacturer} ne "") ? "\'". $xlsRowVal{manufacturer} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   dbtype = " . (($xlsRowVal{dbtype} ne "") ? "\'". $xlsRowVal{dbtype} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   edition = " . (($xlsRowVal{edition} ne "") ? "\'". $xlsRowVal{edition} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   version = " . (($xlsRowVal{version} ne "") ? "\'". $xlsRowVal{version} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   latestrel = " . (($xlsRowVal{latestrel} ne "") ? "\'". $xlsRowVal{latestrel} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   eol = " . (($xlsRowVal{eol} ne "") ? "\'". $xlsRowVal{eol} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   eoxs = " . (($xlsRowVal{eoxs} ne "") ? "\'". $xlsRowVal{eoxs} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   speol = " . (($xlsRowVal{speol} ne "") ? "\'". $xlsRowVal{speol} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   supported = " . $assetSupported . ",\n";
			$sqlcoldata .= "   notes = " . (($xlsRowVal{notes} ne "") ? "\'". $xlsRowVal{notes} . "\'" : "NULL") . ",\n";

			if (!exists($lkDBMS{$assetShortname})) { # only do inserts
				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`dbms` SET \n";
				$sql .= $sqlcoldata;
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$result = $dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlDBMSInsert++;
					$lkDBMS{$assetShortname}{id} = $dbh->{mysql_insertid};
				}
			} # insert or update
		} # found headers
	} # for my row loop
} # if DBMS worksheet defined

################################################################################
################################################################################
### DB INSTANCES WORKSHEET
################################################################################
################################################################################
my $dbinst_ws = $workbook->worksheet('Instances');

if (defined($dbinst_ws)) {
	$current_sheet = trim($dbinst_ws->get_name());

	# Find out the worksheet ranges
	( $row_min, $row_max ) = $dbinst_ws->row_range();
	( $col_min, $col_max ) = $dbinst_ws->col_range();

	print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";
	$keycount = 0;
	$TotalHeaders	= 12;	# total number of column headers we need to find in this worksheet to proceed with processing
	$FIRST_DATA_ROW = 2;
	%xlsCol = ();

	for my $row ( $row_min .. $row_max ) {
		$iExcelRows++; # increment total Excel row counter
		if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
			for my $col ( $col_min .. $col_max ) {
				my $cell = $dbinst_ws->get_cell( $row, $col ); # Return the cell object at $row and $col
				next unless $cell;
				my $fld = lc(trim($cell->value()));
				if 	( $fld =~ m/rscd/i ) {
					$xlsCol{rscdname} = $col;
					$keycount++;
				} elsif ( $fld =~ m/ip address/i ) {
					$xlsCol{primaryip} = $col;
					$keycount++;
				} elsif ( $fld =~ m/vip/i ) {
					$xlsCol{vip} = $col;
					$keycount++;
				} elsif ( $fld =~ m/dbms/i && $fld =~ m/shortname/i  ) {
					$xlsCol{shortname} = $col;
					$keycount++;
				} elsif (  $fld =~ m/db name/i  ) { #5
					$xlsCol{dbname} = $col;
					$keycount++;
				} elsif (  $fld =~ m/instance/i && $fld =~ m/name/i  ) {
					$xlsCol{instancename} = $col;
					$keycount++;
				} elsif ( $fld =~ m/associated/i ) {
					$xlsCol{appassociated} = $col;
					$keycount++;
				} elsif ( $fld =~ m/environment/i ) {
					$xlsCol{wsibenv} = $col;
					$keycount++;
				} elsif ( $fld =~ m/cluster/i ) {
					$xlsCol{cluster} = $col;
					$keycount++;
				} elsif ( $fld =~ m/dbms/i && $fld =~ m/patch/i && $fld =~ m/level/i ) { #10
					$xlsCol{patchlevel} = $col;
					$keycount++;
				} elsif ( $fld =~ m/supported/i && $fld =~ m/patch/i && $fld =~ m/level/i ) {
					$xlsCol{supported} = $col;
					$keycount++;
				} elsif ( $fld =~ m/notes/i ) {
					$xlsCol{notes} = $col;
					$keycount++;
				} # end if
			} # end for col
		} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
			print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
			print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
			print "****        KEYS FOUND:\n";
			foreach my $key (sort keys %xlsCol) {
				print "****           $key\n";
			}
			$dbh->disconnect(); # disconnect gracefully
			die;
		} elsif ($keycount == $TotalHeaders) {
			# new code for localized values
			my %xlsRowVal	= ();	# hash table to contain excel row values
			foreach my $key (keys %xlsCol) {
				my $cell = $dbinst_ws->get_cell( $row, $xlsCol{$key} );
				$xlsRowVal{$key} = "";
				$xlsRowVal{$key} = trim($cell->value()) if $cell;
			}

			## reformat the manual data entered
			$xlsRowVal{shortname} = lc(substr($xlsRowVal{shortname},0,255));
			$xlsRowVal{rscdname} = lc(substr($xlsRowVal{rscdname},0,255));
			$xlsRowVal{primaryip} = ipfmt(substr($xlsRowVal{primaryip},0,255));
			$xlsRowVal{vip} = ipfmt(substr($xlsRowVal{vip},0,255));
			$xlsRowVal{dbname} =~ s/\'//g; # remove any single quotes
			$xlsRowVal{dbname} = substr($xlsRowVal{dbname},0,255);
			$xlsRowVal{instancename} =~ s/\'//g; # remove any single quotes
			$xlsRowVal{instancename} = substr($xlsRowVal{instancename},0,255);
			$xlsRowVal{appassociated} =~ s/\'/\\\'/g; # escape any single quotes
			$xlsRowVal{appassociated} = substr($xlsRowVal{appassociated},0,255);
			$xlsRowVal{wsibenv} = substr($xlsRowVal{wsibenv},0,255);
			$xlsRowVal{cluster} = substr($xlsRowVal{cluster},0,255);
			$xlsRowVal{patchlevel} = uc(substr($xlsRowVal{patchlevel},0,255));
			$xlsRowVal{supported} = substr($xlsRowVal{supported},0,255);
			$xlsRowVal{notes} =~ s/\'/\\\'/g; # escape any single quotes
			$xlsRowVal{notes} = substr($xlsRowVal{notes},0,512);

			my $assetSupported = ($xlsRowVal{supported} =~ m/y/i) ? 1 : 0;
			my $assetCluster = ($xlsRowVal{cluster} =~ m/y/i) ? 1 : 0;

			# pull together some key fields for insert/update later
			my $assetXLRow = ($row + 1); # row is actually behind by 1
			my $assetShortname = lc($xlsRowVal{shortname});

			if ($assetShortname eq "" || !exists($lkDBMS{$assetShortname})) {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'dbms\',\n";
				 if ($assetShortname ne "" && !exists($lkDBMS{$assetShortname})) {
					 $sql .= "   errorlog = \'Database worksheet ". $current_sheet . " row (". $assetXLRow .") DBMS SHORTNAME (". $assetShortname . ") NOT FOUND.\',\n";
				 } else {
					 $sql .= "   errorlog = \'Database worksheet ". $current_sheet . " row (". $assetXLRow .") DBMS SHORTNAME IS BLANK.\',\n";
				 }
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
				 next; # skip this record
			}

			my $assetRSCDname = lc($xlsRowVal{rscdname}); # rscd shortname

			my $assetPrimaryKey = "";
			my $assetPrimaryIP = $xlsRowVal{primaryip};

			if ($assetPrimaryIP ne "" && is_ipv4($assetPrimaryIP)) { # we still have a valid IPv4 format
				my $sn = $SubClassifier->($assetPrimaryIP); # find the subnet in range quickly
				my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
				my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

				if (exists($lkGIP{$assetPrimaryIP})) {
					$assetPrimaryKey = $lkGIP{$assetPrimaryIP}{id};
				} else { # IP doesn't exist already
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
					$sql .=  "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
					$sql .= "   ipv4 = INET_ATON(\'" . $assetPrimaryIP  . "\'),\n";
					$sql .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
					$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlIPInsert++;
						$lkGIP{$assetPrimaryIP}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
						$assetPrimaryKey = $lkGIP{$assetPrimaryIP}{id};
					} # we inserted a record
				} # lkGIP found
			}

			my $assetVIPKey = "";
			my $assetVIP = $xlsRowVal{vip};
			if ($assetVIP ne "" && is_ipv4($assetVIP)) { # we still have a valid IPv4 format
				my $sn = $SubClassifier->($assetVIP); # find the subnet in range quickly
				my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
				my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

				if (exists($lkGIP{$assetVIP})) {
					$assetVIPKey = $lkGIP{$assetVIP}{id};
				} else { # IP doesn't exist already
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
					$sql .= "   location_id = ". $lkSUBNT{$sn}{loc_id} . ",\n";
					$sql .= "   ipv4 = INET_ATON(\'" . $assetVIP  . "\'),\n";
					$sql .= "   vlan_id = ". $lkSUBNT{$sn}{vlan_id} . ",\n";
					$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlIPInsert++;
						$lkGIP{$assetVIP}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
						$assetVIPKey = $lkGIP{$assetVIP}{id};
					} # we inserted a record
				} # lkGIP found
			}

			## Connect to the asset table
			my $assetID = "";
			my $assetWSIBname = "";

			# handle the dbrel inserts here
			if ($assetRSCDname eq "" || !exists($lkINV{$assetRSCDname})) {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'dbms\',\n";
				 if ($assetRSCDname ne "" && !exists($lkINV{$assetRSCDname})) {
					 $sql .= "   errorlog = \'Database worksheet ". $current_sheet . " row (". $assetXLRow .") ASSET WITH RSCD NAME (". $assetRSCDname . ") NOT FOUND.\',\n";
				 } else {
					 $sql .= "   errorlog = \'Database worksheet ". $current_sheet . " row (". $assetXLRow .") RSCD NAME IS BLANK.\',\n";
				 }
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
			} elsif ($assetRSCDname ne "" && exists($lkINV{$assetRSCDname})) {
				$assetID = $lkINV{$assetRSCDname}{id};
				$assetWSIBname = $lkINV{$assetRSCDname}{wsibname};
			}

			## WSIB Environment Code - Consistent across worksheets
			my $assetWSIBenv = "";
			my $wsib_name = $assetWSIBname;
			if ($wsib_name ne "") {
				if (length($wsib_name) == 8) { ## follows WSIB naming convention
					my $c_env = lc(substr($wsib_name,0,1)); # environment
					$assetWSIBenv = $main::hashWSIBEnv{$c_env} if (exists($main::hashWSIBEnv{$c_env}));
				}

				## if we haven't found the environment yet, try using the legacy WSIB naming convention
				if ($assetWSIBenv eq "" && length($wsib_name) == 9 && lc(substr($wsib_name,0,2)) eq "sr") { ## follows LEGACY WSIB naming convention
					my $c_env = lc(substr($wsib_name,6,1));
					if ($c_env eq "p") {
						$assetWSIBenv = "PRD";
					} elsif ($c_env eq "d") {
						$assetWSIBenv = "DEV";
					} elsif ($c_env eq "u") {
						$assetWSIBenv = "UAT";
					} elsif ($c_env eq "t") {
						$assetWSIBenv = "TEST";
					}
				}
				## if we still haven't found the environment, use the SAMI
				if ($assetWSIBenv eq "" && exists($lkSAMI{$wsib_name})) { # do we have a legacy SAMI record?
					$assetWSIBenv = $lkSAMI{$wsib_name}{env}; # get the env from the SAMI instead
				}
			}

			if ($assetWSIBenv eq "") {  # worst case scenario, use what was entered
				$assetWSIBenv = $xlsRowVal{wsibenv};
				$assetWSIBenv = "PRD" if ($assetWSIBenv =~ m/pro/i || $assetWSIBenv =~ m/prd/i);
				$assetWSIBenv = "PPD" if ($assetWSIBenv =~ m/pre/i || $assetWSIBenv =~ m/ppd/i);
				$assetWSIBenv = "QA" if ($assetWSIBenv =~ m/qa/i);
				$assetWSIBenv = "SIT" if ($assetWSIBenv =~ m/sit/i);
				$assetWSIBenv = "UAT" if ($assetWSIBenv =~ m/uat/i);
				$assetWSIBenv = "BAT" if ($assetWSIBenv =~ m/bat/i);
				$assetWSIBenv = "CONV" if ($assetWSIBenv =~ m/con/i ||$assetWSIBenv =~ m/cnv/i);
				$assetWSIBenv = "DIT" if ($assetWSIBenv =~ m/dit/i || $assetWSIBenv =~ m/integ/i);
				$assetWSIBenv = "TEST" if ($assetWSIBenv =~ m/test/i);
				$assetWSIBenv = "TRN" if ($assetWSIBenv =~ m/tra/i || $assetWSIBenv =~ m/trn/i);
				$assetWSIBenv = "DEV" if ($assetWSIBenv =~ m/dev/i);
			}

			## now insert (no updates since this is a reload)
			## sqlcoldata code to simplify NULLs
			my $sqlcoldata = "   dbms_id = ". $lkDBMS{$assetShortname}{id}. ",\n";
			$sqlcoldata .= "   ipadd_id = ". (($assetPrimaryKey ne "") ? $assetPrimaryKey : "NULL") . ",\n";
			$sqlcoldata .= "   vipadd_id = ". (($assetVIPKey ne "") ? $assetVIPKey : "NULL") . ",\n";
			$sqlcoldata .= "   inv_id = ". (($assetID ne "") ? $assetID : "NULL") . ",\n";
			$sqlcoldata .= "   dbname = " . (($xlsRowVal{dbname} ne "") ? "\'". $xlsRowVal{dbname} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   instancename = " . (($xlsRowVal{instancename} ne "") ? "\'". $xlsRowVal{instancename} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   appassociated = " . (($xlsRowVal{appassociated} ne "") ? "\'". $xlsRowVal{appassociated} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   wsibenv = " . (($assetWSIBenv ne "") ? "\'". $assetWSIBenv . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   cluster = " . $assetCluster  . ",\n";
			$sqlcoldata .= "   patchlevel = " . (($xlsRowVal{patchlevel} ne "") ? "\'". $xlsRowVal{patchlevel} . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   supported = " . $assetSupported . ",\n";
			$sqlcoldata .= "   notes = " . (($xlsRowVal{notes} ne "") ? "\'". $xlsRowVal{notes} . "\'" : "NULL") . ",\n";

			my $assetDBInstanceID = "";
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`dbinst` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$result = $dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlDBIInsert++;
				$assetDBInstanceID = $dbh->{mysql_insertid};
			}
		} # found headers
	} # for my row loop
} # if DB INSTANCES worksheet defined

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-dbms-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "DBMS Inserts\t:" . $iSqlDBMSInsert . "\n";
print "DBI Inserts\t:" . $iSqlDBIInsert . "\n";
print "IP Inserts\t:" . $iSqlIPInsert . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
