#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	OPS Inventory File Load (Import)
### Date:		June 18, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("OPS INVENTORY LOAD/UPDATE");

die "You must provide an OPS Inventory Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkGIP	 				= ();	# hash table to lookup Global IP addresses already in the database
my %lkOS	 				= ();	# hash table to lookup OS already in the database
my %lkLINKOS			= ();	# hash table to link OS records from OPSYS to OS tables
my %lkOPS	 				= ();	# hash table to lookup OPS records already in the database by rscd shortname
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my @FSUBS					= (); # array for fast IP to subnet validation

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $IndexDelimit = '^';

my $iSqlErr	= 0;
my $iSqlOPSInsert = 0;
my $iSqlOPSUpdate = 0;
my $iSqlOPSDelete = 0;
my $iSqlIPInsert 	= 0;
my $iSqlIPUpdate = 0;
my $iSqlNotifyInsert = 0;
my $iDataErrors = 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my $opsinv_rows = 0; ## number of rows in opsinv when we started
if ((grep { /opsinv/ } @dbTables) == 0) {
	print "Table: opsinv not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`opsinv`;");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		$opsinv_rows = $refr[0];
	}
	$sql = "SELECT op.id, INET_NTOA(ip.ipv4), op.ipadd_id, op.rscdname\n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`opsinv` op\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON op.ipadd_id = ip.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[3]; # rscdname
		$lkOPS{$lkey}{id} = $refr[0];
		$lkOPS{$lkey}{primaryip} = $refr[1];
		$lkOPS{$lkey}{ipadd_id} = "";
		$lkOPS{$lkey}{ipadd_id} = $refr[2] if (defined($refr[2]));
		$lkOPS{$lkey}{inops} = 1;
		$lkOPS{$lkey}{this_inops} = 0; # tracking
		print "******* LKU OPS: lkey=" .  $lkey . " db key: " . $lkOPS{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		print "******* LKU LOC: " . $cd . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
	}
}

if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), location_id, id, inuse FROM `" . $main::IDB_NAME . "`.`ipadd`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $fip = $refr[0];
		$lkGIP{$fip}{id} = $refr[2];
		$lkGIP{$fip}{ipv4} = $refr[0];
		$lkGIP{$fip}{location_id} = (defined($refr[2]) ? $refr[2] : "");
		$lkGIP{$fip}{inuse} = (defined($refr[3]) ? $refr[3] : 0);
		$lkGIP{$fip}{this_inops} = 0; # haven't determined this yet for tracking -- assume not operational
		print "******* LKU GIP: lkey=" . $fip. " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /opsys/ } @dbTables) == 0) {
	print "Table: opsys not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT name, id, platform FROM `" . $main::IDB_NAME . "`.`opsys`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0];
		# set up all of the lookup values and later for update comparison
		$lkOS{$lkey}{name} = $refr[0];
		$lkOS{$lkey}{id} = $refr[1];
		$lkOS{$lkey}{platform} = $refr[2];
		print "******* LKU OS: lkey=" . $lkey . " id: " . $lkOS{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## New code 2/19/20 - Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

## grab the old value of the tracking TIMESTAMP
my $lastRunTimestamp = ""; # save this for tracking purposes
my $lastRunRowsIn = 0;
$sql = "SELECT lastrun, rows_in FROM `" . $main::IDB_NAME . "`.`dsattrack` \n";
$sql .= "   WHERE datasrcscript='ibm-ops-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	$lastRunTimestamp = $refr[0] if (defined($refr[0]));
	$lastRunRowsIn = $refr[1] if (defined($refr[1]));
}

## update the TIMESTAMP
$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP\n";
$sql .= "   WHERE datasrcscript='ibm-ops-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet = "";
my $keycount = 0;
my $TotalHeaders	= 2;
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min=0;
my $row_max=0;
my $col_min=0;
my $col_max=0;

### MAIN WSIB_Servers worksheet
my $worksheet = $workbook->worksheet(0);

if (!defined($worksheet)) {
	$dbh->disconnect();
	die "ERROR -- WSIB_Servers worksheet not found.\n";
}

## remove all of the old MASTER errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='opsinv';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

$current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
( $row_min, $row_max ) = $worksheet->row_range();
( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

$keycount = 0;
$TotalHeaders	= 7;	# total number of column headers we need to find in this worksheet to proceed with processing
%xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 2;

for my $row ( $row_min .. $row_max ) {
	$iExcelRows++; # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if ( $fld =~ m/shortname/i ) {
				$xlsCol{rscdname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/real hostname/i ) {
				$xlsCol{wsibname} = $col;
				$keycount++;
			} elsif ( $fld eq 'ip' ) {
				$xlsCol{primaryip} = $col;
				$keycount++;
			} elsif ( lc($fld) eq 'os' ) {
				$xlsCol{ostype} = $col;
				$keycount++;
			} elsif ( $fld =~ m/platform/i ) {
				$xlsCol{osplatform} = $col;
				$keycount++;
			} elsif ( $fld =~ m/version/i ) {
				$xlsCol{osversion} = $col;
				$keycount++;
			} elsif ( $fld =~ m/qualified/i || $fld =~ m/fqdn/i ) {
				$xlsCol{fqdn} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		# NEW CODE TO LOCALIZE ROW VALUES
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if $cell;
		}

		my $XLRow = $row + 1; # the Excel row for error reporting

		## 1/9/20 - RSCDNAME is a unique key
		$xlsRowVal{rscdname} = lc(trim(substr($xlsRowVal{rscdname},0,255)));
		my $assetRSCDname = $xlsRowVal{rscdname};
		$assetRSCDname =~ s/\..*$//; # remove everything after the first period

		$xlsRowVal{wsibname} = lc(trim(substr($xlsRowVal{wsibname},0,255)));
		my $assetWSIBname = $xlsRowVal{wsibname};

		if ($assetRSCDname eq "") {
			$iDataErrors++;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'opsinv\',\n";
			$sql .= "   errorlog = \'OPSINV row (". $XLRow .") RSCD shortname is BLANK.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
			next; # skip the rest of processing on this record
		}

		my $assetIPkey = "";
		my $assetIPv4 = "";

		$xlsRowVal{primaryip} = ipfmt($xlsRowVal{primaryip});
		$assetIPv4 = $xlsRowVal{primaryip} if ($xlsRowVal{primaryip} ne "" && is_ipv4($xlsRowVal{primaryip}));
		if ($assetIPv4 eq "") {
			$iDataErrors++;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'opsinv\',\n";
			$sql .= "   errorlog = \'OPSINV ROW (". $XLRow .") IP ADDRESS IS INVALID OR BLANK.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
			next; # skip the rest of processing on this record
		}

		if (exists($lkGIP{$assetIPv4})) {
			$assetIPkey = $lkGIP{$assetIPv4}{id};
			if (!$lkGIP{$assetIPv4}{this_inops}) { # havent already updated
				$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
				$sql .= "   inuse = 1,\n";
				$sql .= "   inopsinv = 1,\n"; ## 6/18/20 added for master load optimization
				$sql .= "   lastseen = CURRENT_TIMESTAMP,\n";
				$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
				$sql .= "   WHERE id = " . $assetIPkey . ";\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
							print "Error while executing SQL:\n";
							print $sql . "\n";
							print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlIPUpdate++;
					$lkGIP{$assetIPv4}{this_inops} = 1;
				}
			}
		} else {
			## didn't find the IP address in our database
			# is the IP in our range of subnets?
			my $sn = $SubClassifier->($assetIPv4); # find the subnet in range quickly
			my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
			my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
			$sql .= "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
			$sql .= "   ipv4 = INET_ATON(\'" . $assetIPv4 . "\'),\n";
			$sql .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
			$sql .= "   inuse = 1,\n";
			$sql .= "   inopsinv = 1,\n"; ## 6/18/20 added for master load optimization
			$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlIPInsert++;
				$assetIPkey = $dbh->{mysql_insertid}; # add to the lookup hash table
				$lkGIP{$assetIPv4}{id} = $assetIPkey;
				$lkGIP{$assetIPv4}{inuse} = 1;
				$lkGIP{$assetIPv4}{this_inops} = 1; # tracking
			} # we inserted a record
		}

		# continue on with the OPSINV specific fields
		# clean up the values to assure clean db queries
		$xlsRowVal{ostype} = trim(substr($xlsRowVal{ostype},0,255));
		$xlsRowVal{osplatform} = trim(substr($xlsRowVal{osplatform},0,255));
		$xlsRowVal{osversion} = trim(substr($xlsRowVal{osversion},0,255));
		$xlsRowVal{fqdn} = lc(trim(substr($xlsRowVal{fqdn},0,255)));

		# SET UP THE SQL CODE FOR INSERT OR UPDATE
		## Link the OS to a record in the OPSYS table
		my $assetOSkey = "";
		if ($xlsRowVal{ostype} ne "" && $xlsRowVal{osversion} ne "") {
			my $ostype = lc($xlsRowVal{ostype});
			my $osver = lc($xlsRowVal{osversion});
			my $lkey = $ostype . $IndexDelimit . $osver;
			if (exists($lkLINKOS{$lkey})) { # we already found this so use it
				$assetOSkey = $lkLINKOS{$lkey}{id};
			} else { # figure out the link
				my $oslookupname = $xlsRowVal{osversion}; # start with the infrastructure string
				$oslookupname =~ s/red hat es/Red Hat Enterprise Linux/i;
				$oslookupname = "Solaris " . $oslookupname if ($ostype =~ m/solaris/i);
				$oslookupname = "IBM AIX " . $oslookupname if ($ostype =~ m/aix/i);
				if ($oslookupname ne "" && $ostype =~ m/windows/i) {
					if ($osver =~ m/2008/ || $osver =~ m/2012/ || $osver =~ m/2016/ || $osver =~ m/2019/) {
						$oslookupname = "Microsoft Windows Server " . $oslookupname;
					}
				}
				if (exists($lkOS{$oslookupname})) {
					$assetOSkey = $lkOS{$oslookupname}{id};
					$lkLINKOS{$lkey}{id} = $assetOSkey; # make it easier for later
				}
			}
		}

		if ($assetOSkey eq "") { # we didn't find the OS, so we may have a new one that's not on file
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'opsinv\',\n";
			$sql .= "   errorlog = \'UNKNOWN OS ROW (". $XLRow .") TYPE \"". $xlsRowVal{ostype} .  "\" OS NAME \"" . $xlsRowVal{osversion} . "\".\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlNotifyInsert++;
			}
		}

		## Normalize the platform
		$xlsRowVal{osplatform} = uc($xlsRowVal{osplatform}) if ($xlsRowVal{osplatform} =~/sparc/i);

		## 2/27/20 new sqlcoldata code to simplify NULLs
		my $sqlcoldata = "   wsibname = \'". $assetWSIBname . "\',\n";
		$sqlcoldata .= "   ipadd_id = " . (($assetIPkey ne "") ? $assetIPkey : "NULL") . ",\n";
		$sqlcoldata .= "   os_id = " . (($assetOSkey ne "") ? $assetOSkey : "NULL") . ",\n";
		$sqlcoldata .= "   rscdname = \'". $assetRSCDname . "\',\n";
		$sqlcoldata .= "   ostype = " . (($xlsRowVal{ostype} ne "") ? "\'". $xlsRowVal{ostype} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   osplatform = " . (($xlsRowVal{osplatform} ne "") ? "\'". $xlsRowVal{osplatform} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   osversion = " . (($xlsRowVal{osversion} ne "") ? "\'". $xlsRowVal{osversion} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   fqdn = " . (($xlsRowVal{fqdn} ne "") ? "\'". $xlsRowVal{fqdn} . "\'" : "NULL") . ",\n";

		if (exists($lkOPS{$assetRSCDname})) { # already in the database, so we need to update and we haven't already processed on this run
			# tracking updates check to see if an ip address has changed since the last time on a record we aren't excluding
			if ($opsinv_rows > 0 && $assetIPkey ne "" && exists($lkOPS{$assetRSCDname}) && $lkOPS{$assetRSCDname}{ipadd_id} ne "" && $assetIPkey != $lkOPS{$assetRSCDname}{ipadd_id}) { # we started with rows in the opsinv table
				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`notify` SET \n";
				$sql .= "   type=\'opsinv\',\n";
				$sql .= "   message = \'IP ADDRESS CHANGED ROW (". $XLRow .") RSCD shortname \"". $assetRSCDname .  "\" FROM (". $lkOPS{$assetRSCDname}{primaryip} . ") TO (". $assetIPv4 . ").\',\n";
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlNotifyInsert++;
				}
			}
			$sql = "UPDATE `" . $main::IDB_NAME . "`.`opsinv` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastseen = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
			$sql .= "   WHERE id = " . $lkOPS{$assetRSCDname}{id} . ";\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
			} else {
				$iSqlOPSUpdate++;
				$lkOPS{$assetRSCDname}{primaryip} = $assetIPv4;
				$lkOPS{$assetRSCDname}{ipadd_id} = $assetIPkey;
				$lkOPS{$assetRSCDname}{this_inops} = 1; # tracking
			}
		} elsif (!exists($lkOPS{$assetWSIBname})) { # there isn't a row in the database, so we need to insert
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`opsinv` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastseen = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlOPSInsert++;
				# tracking updates
				if ($opsinv_rows > 0) { # we started with rows in the opsinv table
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`notify` SET \n";
					$sql .= "   type=\'opsinv\',\n";
					$sql .= "   message = \'New system ADDED at row (". $XLRow .") WSIB hostname \"". $assetWSIBname . "\" with primary IP address (". $assetIPv4 . ").\',\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlNotifyInsert++;
					}
				}
				## create a new hash element
				$lkOPS{$assetRSCDname}{id} = $dbh->{mysql_insertid};
				$lkOPS{$assetRSCDname}{primaryip} = $assetIPv4;
				$lkOPS{$assetRSCDname}{ipadd_id} = $assetIPkey;
				$lkOPS{$assetRSCDname}{this_inops} = 1; # tracking
			}
		} # end insert or update to database
	} # end if headers have all been found
} # end for row

## tracking - systems no longer operational - remove from OPSINV
if ($opsinv_rows > 0) { # we started with rows in the opsinv table
	foreach my $lkey (keys %lkOPS) {
		if ($lkOPS{$lkey}{inops} && $lkOPS{$lkey}{this_inops} == 0) { ## was operational last month, but not now
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`notify` SET \n";
			$sql .= "   type=\'opsinv\',\n";
			$sql .= "   message = \'NO LONGER OPERATIONAL RSCD shortname \"". $lkey . "\" with primary IP address (". $lkOPS{$lkey}{primaryip} . ").\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlNotifyInsert++;
			}
			## last, delete the record from opsinv
			if (exists($lkOPS{$lkey})) {
				$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`opsinv` \n";
				$sql .= "   WHERE id = " . $lkOPS{$lkey}{id} . ";\n";
				$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlOPSDelete++;
					#delete($lkOPS{$lkey});  # delete the hash element
				}
			}
		}
	}
}

## update rows
$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-ops-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "OPS Inserts\t:" . $iSqlOPSInsert . "\n";
print "OPS Updates\t:" . $iSqlOPSUpdate . "\n";
print "OPS Deletes\t:" . $iSqlOPSDelete . "\n";
print "IP Inserts\t:" . $iSqlIPInsert . "\n";
print "IP Updates\t:" . $iSqlIPUpdate . "\n";
print "Notifications\t:" . $iSqlNotifyInsert . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
