#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Appstack File Load (Import data generated in Cloudscape)
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("CS APPSTACK LOAD/UPDATE");

die "You must provide an OPS Inventory Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkAPS	 				= ();	# hash table to lookup AppStack records already in the database by stackname

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr	= 0;
my $iSqlAPSInsert = 0;
my $iSqlAPSUpdate = 0;
my $iDataErrors 	= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

if ((grep { /appstack/ } @dbTables) == 0) {
	print "Table: appstack not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT id, stackname, disposition \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`appstack`;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[1]; # stackname
		$lkAPS{$lkey}{id} = $refr[0];
		$lkAPS{$lkey}{disposition} = $main::hashAppDisposition{retain}; ## global disposition default = retain
		$lkAPS{$lkey}{disposition} = $refr[2] if (defined($refr[2]));
		print "******* LKU OPS: lkey=" .  $lkey . " db key: " . $lkAPS{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet = "";
my $keycount = 0;
my $TotalHeaders	= 16;
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min=0;
my $row_max=0;
my $col_min=0;
my $col_max=0;
$FIRST_DATA_ROW = 2;

my $worksheet = $workbook->worksheet(0); # first and only worksheet

## remove all of the old APPSTACK errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='appstack';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

$current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
( $row_min, $row_max ) = $worksheet->row_range();
( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

for my $row ( $row_min .. $row_max ) {
	$iExcelRows++; # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if ( $fld =~ m/stack name/i || $fld =~ m/stackname/i ) {
				$xlsCol{stackname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/description/i ) {
				$xlsCol{stackdesc} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner name1/i ) {
				$xlsCol{ownname1} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner phone1/i ) {
				$xlsCol{ownphone1} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner email1/i ) {
				$xlsCol{ownemail1} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner name2/i ) {
				$xlsCol{ownname2} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner phone2/i ) {
				$xlsCol{ownphone2} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner email2/i ) {
				$xlsCol{ownemail2} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner name3/i ) {
				$xlsCol{ownname3} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner phone3/i ) {
				$xlsCol{ownphone3} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner email3/i ) {
				$xlsCol{ownemail3} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner name4/i ) {
				$xlsCol{ownname4} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner phone4/i ) {
				$xlsCol{ownphone4} = $col;
				$keycount++;
			} elsif ( $fld =~ m/owner email4/i ) {
				$xlsCol{ownemail4} = $col;
				$keycount++;
			} elsif ( $fld =~ m/criticality/i ) {
				$xlsCol{criticality} = $col;
				$keycount++;
			} elsif ( $fld =~ m/notes/i ) {
				$xlsCol{notes} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		# NEW CODE TO LOCALIZE ROW VALUES
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if $cell;
		}

		my $XLRow = $row + 1; # the Excel row for error reporting

		## stackname is a unique key
		$xlsRowVal{stackname} = trim(substr($xlsRowVal{stackname},0,255));
		$xlsRowVal{stackname} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		my $assetStackname = $xlsRowVal{stackname};

		if ($assetStackname eq "") {
			$iDataErrors++;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'appstack\',\n";
			$sql .= "   errorlog = \'APPSTACK row (". $XLRow .") Stack Name is BLANK.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
			next; # skip the rest of processing on this record
		}

		# clean up the values to assure clean db queries
		$xlsRowVal{stackdesc} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{stackdesc} = trim(substr($xlsRowVal{stackdesc},0,1024));
		$xlsRowVal{ownname1} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{ownname1} = trim(substr($xlsRowVal{ownname1},0,255));
		$xlsRowVal{ownphone1} = trim(substr($xlsRowVal{ownphone1},0,255));
		$xlsRowVal{ownemail1} = trim(substr($xlsRowVal{ownemail1},0,255));
		$xlsRowVal{ownname2} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{ownname2} = trim(substr($xlsRowVal{ownname2},0,255));
		$xlsRowVal{ownphone2} = trim(substr($xlsRowVal{ownphone2},0,255));
		$xlsRowVal{ownemail2} = trim(substr($xlsRowVal{ownemail2},0,255));
		$xlsRowVal{ownname3} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{ownname3} = trim(substr($xlsRowVal{ownname3},0,255));
		$xlsRowVal{ownphone3} = trim(substr($xlsRowVal{ownphone3},0,255));
		$xlsRowVal{ownemail3} = trim(substr($xlsRowVal{ownemail3},0,255));
		$xlsRowVal{ownname4} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{ownname4} = trim(substr($xlsRowVal{ownname4},0,255));
		$xlsRowVal{ownphone4} = trim(substr($xlsRowVal{ownphone4},0,255));
		$xlsRowVal{ownemail4} = trim(substr($xlsRowVal{ownemail4},0,255));
		$xlsRowVal{criticality} = trim(substr($xlsRowVal{criticality},0,25));
		$xlsRowVal{notes} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{notes} = trim(substr($xlsRowVal{notes},0,1024));

		my $assetAppDisposition = $main::hashAppDisposition{retain}; ## global disposition default = retain
		my $assetCriticality = $main::hashAppCriticality{low}; ## global criticality default = low
		$assetCriticality = $main::hashAppCriticality{high} if ($xlsRowVal{criticality} ne "" && $xlsRowVal{criticality} =~ m/high/i);

		# SET UP THE SQL CODE FOR INSERT OR UPDATE
		## 2/27/20 new sqlcoldata code to simplify NULLs
		my $sqlcoldata = "   stackname = \'". $assetStackname . "\',\n";
		$sqlcoldata .= "   description = " . (($xlsRowVal{stackdesc} ne "") ? "\'". $xlsRowVal{stackdesc} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownname1 = " . (($xlsRowVal{ownname1} ne "") ? "\'". $xlsRowVal{ownname1} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownphone1 = " . (($xlsRowVal{ownphone1} ne "") ? "\'". $xlsRowVal{ownphone1} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownemail1 = " . (($xlsRowVal{ownemail1} ne "") ? "\'". $xlsRowVal{ownemail1} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownname2 = " . (($xlsRowVal{ownname2} ne "") ? "\'". $xlsRowVal{ownname2} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownphone2 = " . (($xlsRowVal{ownphone2} ne "") ? "\'". $xlsRowVal{ownphone2} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownemail2 = " . (($xlsRowVal{ownemail2} ne "") ? "\'". $xlsRowVal{ownemail2} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownname3 = " . (($xlsRowVal{ownname3} ne "") ? "\'". $xlsRowVal{ownname3} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownphone3 = " . (($xlsRowVal{ownphone3} ne "") ? "\'". $xlsRowVal{ownphone3} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownemail3 = " . (($xlsRowVal{ownemail3} ne "") ? "\'". $xlsRowVal{ownemail3} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownname4 = " . (($xlsRowVal{ownname4} ne "") ? "\'". $xlsRowVal{ownname4} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownphone4 = " . (($xlsRowVal{ownphone4} ne "") ? "\'". $xlsRowVal{ownphone4} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ownemail4 = " . (($xlsRowVal{ownemail4} ne "") ? "\'". $xlsRowVal{ownemail4} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   criticality = " . (($assetCriticality ne "") ? $assetCriticality : "NULL") . ",\n";
		$sqlcoldata .= "   notes = " . (($xlsRowVal{notes} ne "") ? "\'". $xlsRowVal{notes} . "\'" : "NULL") . ",\n";

		if (exists($lkAPS{$assetStackname})) {
			$assetAppDisposition = $lkAPS{$assetStackname}{disposition}; # use the value we originally read from the database
			$sqlcoldata .= "   disposition = ". $assetAppDisposition . ",\n" if ($assetAppDisposition ne "");
			$sql = "UPDATE `" . $main::IDB_NAME . "`.`appstack` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
			$sql .= "   WHERE id = " . $lkAPS{$assetStackname}{id} . ";\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlAPSUpdate++;
			}
		} else { ## insert
			$sqlcoldata .= "   disposition = ". $assetAppDisposition . ",\n" if ($assetAppDisposition ne "");
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`appstack` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlAPSInsert++;
				$lkAPS{$assetStackname}{id} = $dbh->{mysql_insertid};
				$lkAPS{$assetStackname}{disposition} = $assetAppDisposition;
			}
		}
	} # end if headers have all been found
} # end for row

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-appstack-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "APS Inserts\t:" . $iSqlAPSInsert . "\n";
print "APS Updates\t:" . $iSqlAPSUpdate . "\n";
print "Data Errors\t\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
