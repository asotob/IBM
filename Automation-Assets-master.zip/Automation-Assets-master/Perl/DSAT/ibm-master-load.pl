#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Master Inventory File RE-Load (Import)
### Note this is a read-only load and validation.
### No Excel writes are performed in this script.
### Date:		June 19, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 2/19/20 - Major revamp of IP Address handling
### 3/26/20 - Additional logic to validate against ADDM to fill in blanks
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("MASTER LOAD/UPDATE");

die "You must provide an Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkINV	 				= ();	# hash table to lookup INVENTORY already in the database
my %lkINVIP				= ();	# hash table to lookup INVIPREL records already in the database
my %lkEV	 				= ();	# hash table to lookup EVENT already in the database
my %lkGIP	 				= ();	### hash table to lookup Global IP addresses already in the database
my %lkADDMi				= ();	### hash table to lookup ADDM records already in the database by IP address
my %lkADDM				= ();	### hash table to lookup ADDM records already in the database by hostname
my %lkOPSi 				= ();	### hash table to lookup OPS records already in the database by IP address
my %lkRVTi				= ();	### hash table to lookup RVT records already in the database by IP address
my %lkRVTr				= ();	### hash table to lookup RVT records already in the database by RSCDname
my %lkPA	 				= ();	# hash table to lookup PATTERN already in the database
my %lkOS	 				= ();	# hash table to lookup OS already in the database
my %lkCSAi	 			= ();	### hash table to lookup CS ASSET rows already in the database by IP address
my %lkCSA	 				= ();	### hash table to lookup CS ASSET rows already in the database by WSIBname
my %lkSAMI 				= ();	### hash table to lookup SAMI records already in the database
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my %IPASSIGN			= ();	### hash table to lookup IP Assignments by WSIBName
my %IPKEYS				= ();	### hash table to lookup IP addresses already assigned by ipkey - prevent multiple tallies of the same IP address (i.e. load balancing/clustering)
my @FSUBS					= (); # array for fast IP to subnet validation

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr				= 0;
my $iSqlIPUpdate 	= 0;
my $iSqlINVInsert = 0;
my $iSqlINVIPInsert = 0;
my $iSqlEVInsert 	= 0;
my $iSqlEVUpdate 	= 0;
my $iDataErrors 	= 0;

my $IndexDelimit = '^';

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
		push @dbTables, lc($refr[0]);
}

# -----------------------------------------------------------------------
# CHECK EXISTENCE AND LOAD LOOKUPS
# -----------------------------------------------------------------------
## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
		print "******* LKU LOC: " . $cd . " key: " . $lkLOC{$cd}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT ip.id, INET_NTOA(ip.ipv4), ip.location_id, lo.code, ip.cloudscapescan, ip.cloudscapeasset, ip.inaddm, ip.inrvt, ip.inopsinv \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`ipadd` ip\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON ip.location_id = lo.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $fip = $refr[1];
		if (!exists($lkGIP{$fip})) {
			$lkGIP{$fip}{id} = $refr[0];
			$lkGIP{$fip}{loc_id} = (defined($refr[2]) ? $refr[2] : "");
			$lkGIP{$fip}{loc_code} = (defined($refr[3]) ? $refr[3] : "");
			$lkGIP{$fip}{cloudscapescan} = (defined($refr[4]) ? $refr[4] : 0);

			## 6/18/20 -- add flags to optimize lookups
			$lkGIP{$fip}{cloudscapeasset} = (defined($refr[5]) ? $refr[5] : 0);
			$lkGIP{$fip}{inaddm} = (defined($refr[6]) ? $refr[6] : 0);
			$lkGIP{$fip}{inrvt} = (defined($refr[7]) ? $refr[7] : 0);
			$lkGIP{$fip}{inopsinv} = (defined($refr[8]) ? $refr[8] : 0);
		}
		print "******* LKU GIP: fip=" . $fip . " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet, tgt_location_id FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		$lkSUBNT{$lkey}{tgt_loc_id} = defined($refr[3]) ? $refr[3] : "";
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## New code 2/19/20 - Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

## 3/26/20 v3.1 - ADDM lookups
if ((grep { /addm/ } @dbTables) == 0) {
	print "Table: addm not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT a.id, a.name, a.type, a.serialnum, INET_NTOA(ip.ipv4), ip.id\n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`adiprel` ix\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`addm` a ON a.id = ix.addm_id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON ix.ipadd_id = ip.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ciname = $refr[1]; ## ciname
		my $ipv4 = (defined($refr[4]) ? $refr[4] : "");
		my $ip_id = (defined($refr[5]) ? $refr[5] : "");
		if (is_ipv4($ipv4)) {
			if (!exists($lkADDMi{$ipv4})) {
				$lkADDMi{$ipv4}{id} = $refr[0];
				$lkADDMi{$ipv4}{type} = (defined($refr[2]) ? $refr[2] : "");
				$lkADDMi{$ipv4}{hostname} = $ciname;
				$lkADDMi{$ipv4}{serialnum} = (defined($refr[3]) ? $refr[3] : "");
			}
			if ($ciname ne "" && $ip_id ne "") {
				if (exists($IPASSIGN{$ciname})) {
					if (!exists($IPKEYS{$ip_id})) {
						push(@ { $IPASSIGN{$ciname}{ipadd_ids} },$ip_id); # add this IP to the same ciname
						$IPKEYS{$ip_id}{wsibname} = $ciname;
					}
				} else { # doesn't exist - start a new one
					@ { $IPASSIGN{$ciname}{ipadd_ids} } = (); # initialize
					if (!exists($IPKEYS{$ip_id})) {
						push(@ { $IPASSIGN{$ciname}{ipadd_ids} },$ip_id); # add this IP to the same ciname
						$IPKEYS{$ip_id}{wsibname} = $ciname;
					}
				}
			}
			print "******* LKU ADDMi: (" . $ipv4 . ") belongs to: " . $ciname . "\n" if ($DEBUGSQL); # debug sql
		}
	}
	$sql = "SELECT a.id, a.name, a.type, a.serialnum\n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`addm` a\n";
	$sql .= "  WHERE a.name IS NOT NULL;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ciname = $refr[1]; ## ciname
		my $lku = lc($ciname);
		if ($ciname ne "" && !exists($lkADDM{$lku})) {
			$lkADDM{$lku}{id} = $refr[0];
			$lkADDM{$lku}{type} = (defined($refr[2]) ? $refr[2] : "");
			$lkADDM{$lku}{hostname} = $ciname;
			$lkADDM{$lku}{serialnum} = (defined($refr[3]) ? $refr[3] : "");
			print "******* LKU ADDM: (" . $lku . ") loaded\n" if ($DEBUGSQL); # debug sql
		}
	}
}

## 1/10/20 - New OPSINV table
if ((grep { /opsinv/ } @dbTables) == 0) {
	print "Table: opsinv not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT op.id, INET_NTOA(ip.ipv4), op.rscdname, op.wsibname, ip.id \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`opsinv` op \n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON op.ipadd_id = ip.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		if (defined($refr[1])) {
			my $lkey = $refr[1]; # IPv4
			$lkOPSi{$lkey}{id} = $refr[0];
			$lkOPSi{$lkey}{ipv4} = (defined($refr[1]) ? $refr[1] : "");
			$lkOPSi{$lkey}{rscdname} = (defined($refr[2]) ? $refr[2] : "");
			$lkOPSi{$lkey}{wsibname} = (defined($refr[3]) ? $refr[3] : "");
			my $wsibname = $lkOPSi{$lkey}{wsibname};
			my $ip_id = (defined($refr[4]) ? $refr[4] : "");
			if ($wsibname ne "" && $ip_id ne "") {
				if (exists($IPASSIGN{$wsibname})) {
					if (!exists($IPKEYS{$ip_id})) {
						push(@ { $IPASSIGN{$wsibname}{ipadd_ids} },$ip_id); # add this IP to the same ciname
						$IPKEYS{$ip_id}{wsibname} = $wsibname;
					}
				} else { # doesn't exist - start a new one
					@ { $IPASSIGN{$wsibname}{ipadd_ids} } = (); # initialize
					if (!exists($IPKEYS{$ip_id})) {
						push(@ { $IPASSIGN{$wsibname}{ipadd_ids} },$ip_id); # add this IP to the same ciname
						$IPKEYS{$ip_id}{wsibname} = $wsibname;
					}
				}
			}
		}
		print "******* LKU OPS db key: " . $refr[0] . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /rvt/ } @dbTables) == 0) {
	print "Table: rvt not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	## Lookup RSCD name
	$sql = "SELECT INET_NTOA(ip.ipv4), rv.id, rv.rscdname, rv.powerstate, rv.vmname, ip.id\n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`rvt` rv \n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON rv.ipadd_id = ip.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ipv4 = (defined($refr[0]) ? $refr[0] : "");
		my $vmname = (defined($refr[4]) ? $refr[4] : "");
		$vmname =~ s/\-/\_/g; # replace dashes with underscores (fix inconsistency in CGI VM naming)
		my $wsibname = "";
		my $rscdname = (defined($refr[2]) ? $refr[2] : "");
		my $ip_id = (defined($refr[5]) ? $refr[5] : "");
		if ($vmname ne "" && $vmname =~ m/\_/) { # name contains underscore?
			my @vmn = split('_',$vmname); # split by underscore
			if ($rscdname eq "" && defined($vmn[0]) && trim($vmn[0]) ne "") {
				$rscdname = lc(trim($vmn[1]));
			}
			if (defined($vmn[1]) && trim($vmn[1]) ne "") {
				$wsibname = lc(trim($vmn[1]));
			}
		}
		if ($ipv4 ne "" && !exists($lkRVTi{$ipv4})) {
			$lkRVTi{$ipv4}{ipv4} = $ipv4; # IPv4
			$lkRVTi{$ipv4}{id} = $refr[1]; # RVTkey
			$lkRVTi{$ipv4}{rscdname} = $rscdname;
			$lkRVTi{$ipv4}{powerstate} = (defined($refr[3]) ? $refr[3] : "");
			$lkRVTi{$ipv4}{vmname} = (defined($refr[4]) ? $refr[4] : "");
			$lkRVTi{$ipv4}{ipadd_id} = $ip_id;
			$lkRVTi{$ipv4}{wsibname} = $wsibname;
		}
		if ($rscdname ne "" && !exists($lkRVTr{$rscdname})) {
			$lkRVTr{$rscdname}{ipv4} = $ipv4; # IPv4
			$lkRVTr{$rscdname}{id} = $refr[1]; # RVTkey
			$lkRVTr{$rscdname}{powerstate} = (defined($refr[3]) ? $refr[3] : "");
			$lkRVTr{$rscdname}{vmname} = (defined($refr[4]) ? $refr[4] : "");
			$lkRVTr{$rscdname}{ipadd_id} = $ip_id;
			$lkRVTr{$rscdname}{wsibname} = $wsibname;
		}

		if ($wsibname ne "" && $ip_id ne "") {
			if (exists($IPASSIGN{$wsibname})) {
				if (!exists($IPKEYS{$ip_id})) {
					push(@ { $IPASSIGN{$wsibname}{ipadd_ids} },$ip_id); # add this IP to the same ciname
					$IPKEYS{$ip_id}{wsibname} = $wsibname;
				}
			} else { # doesn't exist - start a new one
				@ { $IPASSIGN{$wsibname}{ipadd_ids} } = (); # initialize
				if (!exists($IPKEYS{$ip_id})) {
					push(@ { $IPASSIGN{$wsibname}{ipadd_ids} },$ip_id); # add this IP to the same ciname
					$IPKEYS{$ip_id}{wsibname} = $wsibname;
				}
			}
		}
	}
}

if ((grep { /event/ } @dbTables) == 0) {
	print "Table: event not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT name, location_id, id FROM `" . $main::IDB_NAME . "`.`event`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $name = $refr[0];
		my $loc = $refr[1];
		my $lkey = $loc . $name; # a little different than the other lookups to handle the counts
		$lkEV{$lkey}{id} = $refr[2]; # the id table index is the data
		print "******* LKU EV: " . $name . " key: " . $lkEV{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /inventory/ } @dbTables) == 0) {
	print "Table: inventory not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$result = $dbh->do("TRUNCATE `" . $main::IDB_NAME . "`.`inventory`;");    # 2/28/20 -- Always rebuild this table
}

if ((grep { /inviprel/ } @dbTables) == 0) {
	print "Table: inviprel not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$result = $dbh->do("TRUNCATE `" . $main::IDB_NAME . "`.`inviprel`;");    # 4/10/20 -- new table to handle IPs in use
}

if ((grep { /pattern/ } @dbTables) == 0) {
	print "Table: pattern not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	print "\n**** Loading PATTERN lookup table...\n" if ($DEBUGSQL); # debug sql
	$sql = "SELECT name, id FROM `" . $main::IDB_NAME . "`.`pattern`;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $pnm = lc(trim($refr[0]));
		$lkPA{$pnm}{id} = $refr[1];
		$lkPA{$pnm}{name} = $refr[0];
		print "******* LKU PATTERN: name:" . $lkPA{$pnm}{name} . " key: " . $lkPA{$pnm}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /opsys/ } @dbTables) == 0) {
	print "Table: opsys not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT name, id, platform FROM `" . $main::IDB_NAME . "`.`opsys`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0];
		# set up all of the lookup values and later for update comparison
		$lkOS{$lkey}{name} = $refr[0];
		$lkOS{$lkey}{id} = $refr[1];
		$lkOS{$lkey}{platform} = $refr[2];
		print "******* LKU OS: lkey=" . $lkey . " id: " . $lkOS{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /csasset/ } @dbTables) == 0) {
	print "Table: csasset not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	## load the $lkCSA hash table
	$sql = "SELECT cs.hostname, cs.id, ap.stackname, INET_NTOA(ip.ipv4) FROM `" . $main::IDB_NAME . "`.`csasset` cs\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`appstack` ap ON cs.appstack_id = ap.id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON cs.ipadd_id = ip.id\n";
	$sql .= "  WHERE cs.hostname IS NOT NULL;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $hn = $refr[0];
		if (!exists($lkCSA{$hn})) {
			$lkCSA{$hn}{id} = $refr[1];
			$lkCSA{$hn}{stackname} = "";
			$lkCSA{$hn}{stackname} = $refr[2] if (defined($refr[2]));
			$lkCSA{$hn}{ipv4} = $refr[3] if (defined($refr[3]));
		}
		print "******* LKU CSA: " . $hn . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /csasiprel/ } @dbTables) == 0) {
	print "Table: csasiprel not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	## placeholder to load the $lkCSAi hash table
	$sql = "SELECT DISTINCT INET_NTOA(ip.ipv4), csa.hostname, csa.id, ap.stackname FROM `" . $main::IDB_NAME . "`.`csasiprel` cix\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON cix.ipadd_id = ip.id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`csasset` csa ON cix.csasset_id = csa.id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`appstack` ap ON csa.appstack_id = ap.id;\n";
	#$sql .= "  WHERE csa.hostname IS NOT NULL;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ipv4 = $refr[0];
		$lkCSAi{$ipv4}{wsibname} = defined($refr[1]) ? $refr[1] : "";
		$lkCSAi{$ipv4}{csasset_id} = defined($refr[2]) ? $refr[2] : "";
		$lkCSAi{$ipv4}{stackname} = defined($refr[3]) ? $refr[3] : "";
		### do not use CSA for associations
		print "******* LKU CSAi: " . $ipv4 . " belongs to: (" . $lkCSAi{$ipv4}{wsibname} . ") with csasset_id: " . $lkCSAi{$ipv4}{csasset_id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

## SAMI
if ((grep { /sami/ } @dbTables) == 0) { # SAMI table not found
	print "Table: sami not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, wsibname, rscdname, INET_NTOA(ipv4), component FROM `" . $main::IDB_NAME . "`.`sami`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[1]; # wsibname
		# set up all of the lookup values and later for update comparison
		$lkSAMI{$lkey}{id} = $refr[0];
		$lkSAMI{$lkey}{rscdname} = (defined($refr[2]) ? $refr[2] : "");
		$lkSAMI{$lkey}{ipv4} = (defined($refr[3]) ? $refr[3] : "");
		$lkSAMI{$lkey}{component} = (defined($refr[4]) ? $refr[4] : "");
		print "******* LKU SAMI: lkey=" . $lkey . " id: " . $lkSAMI{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

## remove all of the old MASTER errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='master';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

## Set up hash to match primary function if blank
my %hashWSIBApp = (
	"ac"  => "Active Directory Connect",
	"ag"  => "API Gateway",
	"am"  => "Access Manager",
	"ap"  => "Application",
	"ar"  => "TCM Archive",
	"bp"  => "Business Process Manager",
	"bt"  => "Batch Server",
	"cg"  => "Cognos",
	"cs"  => "TCM Content Server",
	"db"  => "Database",
	"dc"  => "Active Directory Domain Controller",
	"de"  => "DataStage Engine",
	"dm"  => "Database Management",
	"dp"  => "DevOps APP Server",
	"ds"  => "LDAP/Directory Server",
	"el"  => "eLearning",
	"ex"  => "Oracle EXADATA Database Machine",
	"fs"  => "Active Directory Federated Services",
	"ft"  => "FTP Server",
	"gd"  => "Guidewire Database",
	"gw"  => "Guidewire Application",
	"hc"  => "HMC",
	"im"  => "Identity Management",
	"in"  => "Integration/MQ/Broker",
	"lb"  => "Load Balancer",
	"ld"  => "Lotus Domino",
	"ls"  => "Language Services",
	"lv"  => "Longview",
	"md"  => "Mid Servers",
	"mp"  => "Richo",
	"na"  => "Network Access Switch",
	"nc"  => "Network Core Switch",
	"nr"  => "Network Router",
	"od"  => "OpenText Directory Server",
	"op"  => "Orchestration/Provisioning",
	"ot"  => "OpenText OTIC",
	"pa"  => "Physical Appliance",
	"ps"  => "Physical Server",
	"pl"  => "Parklane",
	"pm"  => "Performance Monitoring",
	"pr"  => "Print Server",
	"px"  => "WAP Server",
	"rc"  => "Remote Access Connect Broker",
	"rd"  => "Remote Access Web",
	"rf"  => "Right Fax/RFM GW",
	"rg"  => "Remote Access Gateway",
	"sa"  => "SAS Application Group",
	"se"  => "Search Engine",
	"sc"  => "Storage Controller",
	"sl"  => "SDL Group Share",
	"sm"  => "System Management",
	"sp"  => "SharePoint",
	"st"  => "Secure Transfer Server",
	"sw"  => "SolarWind",
	"sx"  => "Storage X",
	"tb"  => "Time Based Testing",
	"td"  => "Tools Database",
	"ts"  => "Terminal Server",
	"vc"  => "Video Conferencing",
	"vw"  => "VMware ESXi",
	"wb"  => "Web Server - HTTP",
	"xm"  => "Exchange Mail Server",
	"xt"  => "OpenText - HP Extreme",
	"sd"  => "SAN Directory",
	"tl"  => "Tape Library",
	"vs"  => "vSphere/vCenter",
	"ze"  => "Symantec EPP",
	"zd"  => "Symantec DCS",
	"zr"  => "Zerto",
);

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

### MASTER WORKSHEET
my $worksheet = $workbook->worksheet('Master');

my $current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
my ( $row_min, $row_max ) = $worksheet->row_range();
my ( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

my $keycount = 0;
my $TotalHeaders	= 19;	# total number of column headers we need to find in this worksheet to proceed with processing
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 2;

for my $row ( $row_min .. $row_max ) {
	$iExcelRows++; # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if 	( $fld =~ m/category/i ) { #1
				$xlsCol{category} = $col;
				$keycount++;
			} elsif ( $fld =~ m/source location/i ) { #
				$xlsCol{srcloc} = $col;
				$keycount++;
			} elsif ( $fld eq 'ip address' ) { # 4/16/20 - Fixed because we now have multiple headers containing 'ip address'
				$xlsCol{ipaddr} = $col;
				$keycount++;
			} elsif ( $fld =~ m/wsib/i && $fld =~ m/hostname/i  ) { #
				$xlsCol{wsibname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/shortname/i ) { #
				$xlsCol{rscdname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/dr scope/i ) { #
				$xlsCol{drscope} = $col;
				$keycount++;
			} elsif ( $fld =~ m/primary server function/i ) { #
				$xlsCol{primaryfunction} = $col;
				$keycount++;
			} elsif ( $fld =~ m/serial num/i ) { #
				$xlsCol{serialnum} = $col;
				$keycount++;
			} elsif ( $fld =~ m/wave seq/i ) { #
				$xlsCol{waveseq} = $col;
				$keycount++;
			} elsif ( $fld =~ m/migration event/i ) { #10
				$xlsCol{eventname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/discovery status/i ) { #
				$xlsCol{discoverystatus} = $col;
				$keycount++;
			} elsif ( $fld =~ m/server disposition/i ) { #
				$xlsCol{sysdisposition} = $col;
				$keycount++;
			} elsif ( $fld =~ m/pattern/i ) { #
				$xlsCol{pattern} = $col;
				$keycount++;
			} elsif ( $fld =~ m/pre-migration/i ) { #
				$xlsCol{premigration} = $col;
				$keycount++;
			} elsif ( $fld =~ m/ip disposition/i ) { #
				$xlsCol{ipdisposition} = $col;
				$keycount++;
			} elsif ( $fld =~ m/baseline delta/i ) { #
				$xlsCol{baselinedelta} = $col;
				$keycount++;
			} elsif ( $fld =~ m/os name/i) { #
				$xlsCol{osname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/migration notes/i ) { #
				$xlsCol{migrationnotes} = $col;
				$keycount++;
			} elsif ( $fld =~ m/migration status/i ) { # 19
				$xlsCol{migrationstatus} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1) ) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders) {
		# new code for localized values
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if $cell;
		}

		# Clean up the Excel data to prep for Database
		$xlsRowVal{category} = trim(substr($xlsRowVal{category},0,255));
		$xlsRowVal{srcloc} = uc(trim(substr($xlsRowVal{srcloc},0,3)));
		$xlsRowVal{ipaddr} = ipfmt(substr($xlsRowVal{ipaddr},0,255));
		$xlsRowVal{wsibname} = lc(trim(substr($xlsRowVal{wsibname},0,255)));
		$xlsRowVal{wsibname} = "" if ($xlsRowVal{wsibname} =~ m/\s+/g);  # 6/18/20 -- can't have whitespace in a hostname
		$xlsRowVal{rscdname} = lc(trim(substr($xlsRowVal{rscdname},0,255)));
		$xlsRowVal{drscope} = lc(trim(substr($xlsRowVal{drscope},0,25)));
		$xlsRowVal{serialnum} = trim(substr($xlsRowVal{serialnum},0,255));
		$xlsRowVal{waveseq} = trim(substr($xlsRowVal{waveseq},0,255));
		$xlsRowVal{eventname} = uc(trim(substr($xlsRowVal{eventname},0,255)));
		$xlsRowVal{discoverystatus} = lc(trim(substr($xlsRowVal{discoverystatus},0,255)));
		$xlsRowVal{sysdisposition} = lc(trim(substr($xlsRowVal{sysdisposition},0,255)));
		$xlsRowVal{pattern} = trim(substr($xlsRowVal{pattern},0,255));
		$xlsRowVal{ipdisposition} = lc(trim(substr($xlsRowVal{ipdisposition},0,255)));
		$xlsRowVal{osname} = trim(substr($xlsRowVal{osname},0,255));
		$xlsRowVal{migrationstatus} = trim(substr($xlsRowVal{migrationstatus},0,255)); ## new on 6/8/20

		## Clean up notation fields
		$xlsRowVal{primaryfunction} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{primaryfunction} = "" if ($xlsRowVal{primaryfunction} =~ m/undetermined/i);
		$xlsRowVal{primaryfunction} = "" if ($xlsRowVal{primaryfunction} =~ m/unavailable/i);
		$xlsRowVal{primaryfunction} = trim(substr($xlsRowVal{primaryfunction},0,255));

		$xlsRowVal{premigration} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{premigration} = trim(substr($xlsRowVal{premigration},0,255));

		$xlsRowVal{baselinedelta} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{baselinedelta} = trim(substr($xlsRowVal{baselinedelta},0,255));

		$xlsRowVal{migrationnotes} =~ s/'/\\'/g; # substitute single quotes with a escaped version
		$xlsRowVal{migrationnotes} = trim(substr($xlsRowVal{migrationnotes},0,2048));

		## Set up these key indicators
		my $assetXLRow = ($row + 1); # row is actually behind by 1
		my $assetLOCkey = "";
		my $assetLOCcode = "";
		my $assetTGTLOCkey = "";
		my $assetIPkey = "";
		my $assetADDMkey = ""; ## 3/27/20
		my $assetSAMIkey = ""; ## 4/2/20
		my $assetIPv4 = "";
		my $assetRVTkey = "";
		my $assetOPSkey = ""; # new!!! 1/10/20
		my $assetCSAkey = ""; # new!!! 2/4/20 - CS Asset key
		my $assetStackname = ""; # new!!! 2/26/20 - Stackname
		my $assetDRscope = "";
		my $assetRVTpowerstate = "";
		my $assetRName = "";
		my $assetWSIBname = "";
		my $assetEVkey = "";
		my $assetEVwaveseq = "";
		my $assetOSkey = "";
		my $assetOSplatform = "";
		my $assetPATkey = "";
		my $assetPATname = "";
		my $assetPreMigration = "";
		my $assetBaselineDelta = "";
		my $assetSerialNum = "";
		my $assetCloudscapeScan = "";
		my $assetSAMIcomponent = "";
		my $assetMigrationStatusCode = "";

		################################################################################
		### BEGIN DATA VALIDATION
		################################################################################
		# 3/27/20 - start with the IP address table as this should contain the IP information
		my $IPfound = 0;
		if ($xlsRowVal{ipaddr} ne "" && is_ipv4($xlsRowVal{ipaddr})) { # if the table shows a valid IP address and it's on IPADD, we have a match
			$assetIPv4 =  $xlsRowVal{ipaddr};
			if (!exists($lkGIP{$assetIPv4})) { # handle: IP was NOT found in lkGIP
				## handle: IP address not found on lkGIP
				$IPfound = 0;
				$iDataErrors++; # this is a data error
				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				$sql .= "   type = \'master\',\n";
				my $sn = $SubClassifier->($assetIPv4); # find the subnet in range quickly
				if (!defined($sn)) { # found a valid IP, but it wasn't in range of our subnets
					$sql .= "   errorlog = \'Master row (". $assetXLRow .") IP ADDRESS (". $assetIPv4 .") IS NOT IN RANGE OF VALID SUBNETS.\',\n";
				} else {
					$sql .= "   errorlog = \'Master row (". $assetXLRow .") IP ADDRESS (". $assetIPv4 .") IS NOT FOUND IN OPERATIONAL STATUS.\',\n";
				}
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				}
			} else { ## IPV4 exists in lkGIP
				$IPfound = 1;
				$assetIPkey = $lkGIP{$assetIPv4}{id};
				$assetCloudscapeScan = $lkGIP{$assetIPv4}{cloudscapescan};
				$assetLOCcode = $lkGIP{$assetIPv4}{loc_code};
				$assetLOCkey = $lkGIP{$assetIPv4}{loc_id};

				## 6/18/20 -- if we found the IP address in ipadd, try and figure out the other key details based on the flags - by level of trust
				if (exists($lkADDMi{$assetIPv4})) { # 3/27/20 - use ADDM
					$assetWSIBname = $lkADDMi{$assetIPv4}{hostname} if ($assetWSIBname eq "" && !($lkADDMi{$assetIPv4}{hostname} =~ m/\s+/g) );
					$assetADDMkey = $lkADDMi{$assetIPv4}{id} if ($assetADDMkey eq "");
					$assetSerialNum = $lkADDMi{$assetIPv4}{serialnum};
				}
				if (exists($lkRVTi{$assetIPv4})) {
					$assetWSIBname = $lkRVTi{$assetIPv4}{wsibname} if ($assetWSIBname eq "" && !($lkRVTi{$assetIPv4}{wsibname} =~ m/\s+/g) );
					$assetRName = $lkRVTi{$assetIPv4}{rscdname} if ($assetRName eq "");
					$assetRVTkey = $lkRVTi{$assetIPv4}{id} if ($assetRVTkey eq "");
					$assetRVTpowerstate = $lkRVTi{$assetIPv4}{powerstate} if ($assetRVTpowerstate eq "");
				}
				if (exists($lkOPSi{$assetIPv4})) {
					$assetWSIBname = $lkOPSi{$assetIPv4}{wsibname} if ($assetWSIBname eq "" && !($lkOPSi{$assetIPv4}{wsibname} =~ m/\s+/g) );
					$assetRName = $lkOPSi{$assetIPv4}{rscdname} if ($assetRName eq "");
					$assetOPSkey = $lkOPSi{$assetIPv4}{id} if ($assetOPSkey eq "");
				}
				if (exists($lkCSAi{$assetIPv4})) {
					$assetWSIBname = $lkCSAi{$assetIPv4}{wsibname} if ($assetWSIBname eq "" && !($lkCSAi{$assetIPv4}{wsibname} =~ m/\s+/g) );
					$assetCSAkey = $lkCSAi{$assetIPv4}{csasset_id} if ($assetCSAkey eq "");
					$assetStackname = $lkCSAi{$assetIPv4}{stackname} if ($assetStackname eq "");
				}
			} ## IPV4 exists in lkGIP
		} else { ## handle: not a valid IPV4 address
			$IPfound = 0;
			$iDataErrors++; # this is a data error
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type = \'master\',\n";
			$sql .= "   errorlog = \'Master row (". $assetXLRow .") IP ADDRESS (". $xlsRowVal{ipaddr} .") IS INVALID OR BLANK.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
		} # this is a valid IP address

		## handle cases where the RVTools primary IP address doesn't match the Operations IP address
		if ($assetRVTkey eq "") {
			my $rscdname = $xlsRowVal{rscdname};
			if ($rscdname ne "" && exists($lkRVTr{$rscdname})) { # find the RSCDname in the RVTools table
				$assetRVTkey = $lkRVTr{$rscdname}{id};
				$assetRName = $rscdname;
				$assetRVTpowerstate = $lkRVTr{$rscdname}{powerstate};
			}
		}

		## if not known so far, try and find out the LOC information from what is input
		$assetLOCcode = $xlsRowVal{srcloc} if ($assetLOCcode eq "" && $xlsRowVal{srcloc} ne "");
		$assetLOCkey = $lkLOC{$assetLOCcode}{id} if ($assetLOCkey eq "" && $assetLOCcode ne "" && exists($lkLOC{$assetLOCcode}));

		## Find the target location
		if ($assetLOCcode ne "") {
			if ($assetLOCcode eq "MDC") {  # Mississauga
				$assetTGTLOCkey =  $lkLOC{"4AN"}{id}; # Markham
			} elsif ($assetLOCcode eq "DDC") { # Dickson-Montreal
				$assetTGTLOCkey =  $lkLOC{"5AW"}{id}; # Viger
			}
		}

		$assetWSIBname = $xlsRowVal{wsibname} if ($assetWSIBname eq ""); ## WSIBname if not filled in so far
		$assetRName = $xlsRowVal{rscdname} if ($assetRName eq ""); ## RSCDname if not filled in so far
		$assetEVwaveseq = $xlsRowVal{waveseq} if (looks_like_number($xlsRowVal{waveseq})); ## wave sequence if it's a number

		# final check for addm key if we didn't find it by IP address
		my $lku = lc($assetWSIBname);
		if ($assetADDMkey eq "" && $lku ne "" && exists($lkADDM{$lku})) {
			$assetADDMkey = $lkADDM{$lku}{id};
			$assetSerialNum = $lkADDM{$lku}{serialnum} if ($assetSerialNum eq "");
		}

		## event key correlation
		## only use location and name
		if ($xlsRowVal{eventname} ne "" && $assetLOCkey ne "") {
			my $eventKey = $assetLOCkey . $xlsRowVal{eventname};
			if (exists($lkEV{$eventKey})) { # event already in the database
				$assetEVkey = $lkEV{$eventKey}{id};
			} else { ## invalid event name for that location
				$assetEVkey = "NULL"; # take out of the wave plan
			}
		} else {
			$assetEVkey = "NULL"; # take out of the wave plan
		}

		## CS Asset connector 2/4/20
		if ($assetCSAkey eq "" && $assetWSIBname ne "") { # we haven't already found the CSA key
			if (exists($lkCSA{$assetWSIBname})) {
				$assetCSAkey = $lkCSA{$assetWSIBname}{id} if ($assetCSAkey eq "");
				$assetStackname = $lkCSA{$assetWSIBname}{stackname};
			}
		}

		## SAMI connector 4/2/20
		if ($assetSAMIkey eq "" && $assetWSIBname ne "") { # we haven't already found the SAMI key
			if (exists($lkSAMI{$assetWSIBname})) {
				$assetSAMIkey = $lkSAMI{$assetWSIBname}{id};
				$assetSAMIcomponent = $lkSAMI{$assetWSIBname}{component};
			}
		}

		## for hardware lift and shift, simply take the serial number in that column
		$assetSerialNum = $xlsRowVal{serialnum} if ($assetSerialNum eq "" && !($xlsRowVal{category} =~ m/vm/i));

		## DR scope -- new code 2/10/20
		$assetDRscope = $main::hashDRScope{none}; # new!!! 2/10/20
		if ($xlsRowVal{drscope} ne "") {
			$assetDRscope = $main::hashDRScope{primary} if (lc($xlsRowVal{drscope}) eq 'yes' || $xlsRowVal{drscope} =~ m/primary/i);
			$assetDRscope = $main::hashDRScope{failover} if (lc($xlsRowVal{drscope}) eq 'dr' || $xlsRowVal{drscope} =~ m/failover/i);
		}

		################################################################################
		### END OF DATA VALIDATION
		################################################################################

		################################################################################
		### BEGINNING OF DATA INTEGRITY SCRUBBING
		################################################################################

		$assetPreMigration = $xlsRowVal{premigration} if ($xlsRowVal{premigration} ne "");
		$assetBaselineDelta = $xlsRowVal{baselinedelta} if ($xlsRowVal{baselinedelta} ne "");

		# figure out the discovery status
		my $assetDiscoveryStatusCode = $main::hashDiscoveryStatus{inprogress}; # start out in progress
		if ($xlsRowVal{discoverystatus} eq 'unknown') {
			$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{unknown};
		} elsif ($xlsRowVal{discoverystatus} eq 'validating') {
				$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{validating};
		} elsif ($xlsRowVal{discoverystatus} eq 'confirmed') {
			$assetDiscoveryStatusCode= $main::hashDiscoveryStatus{confirmed};
		} elsif ($xlsRowVal{discoverystatus} eq 'not found') {
			$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{notfound};
		} elsif ($xlsRowVal{discoverystatus} eq 'removed') {
			$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{removed};
		} elsif ($xlsRowVal{discoverystatus} eq 'override') {
			$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{override};
		}

		# figure out ip disposition
		my $assetIPDispositionCode = $main::hashIPDisposition{retain}; # retain IP is the default
		if ($xlsRowVal{ipdisposition} =~ m/change/i) {
			$assetIPDispositionCode = $main::hashIPDisposition{change};
		} elsif ($xlsRowVal{ipdisposition} =~ m/decomm/i) {
			$assetIPDispositionCode = $main::hashIPDisposition{decomm};
		} elsif ($xlsRowVal{ipdisposition} =~ m/not found/i) {
			$assetIPDispositionCode = $main::hashIPDisposition{notfound};
		} elsif ($xlsRowVal{ipdisposition} =~ m/not migrating/i) {
			$assetIPDispositionCode = $main::hashIPDisposition{notmigrating};
		}

		# figure out the server disposition for the migration
		my $assetSysDispositionCode = $main::hashSYSDisposition{migrating}; # migrating is the default
		if ($xlsRowVal{sysdisposition} eq 'not migrating') {
			$assetSysDispositionCode = $main::hashSYSDisposition{notmigrating};
		} elsif ($xlsRowVal{sysdisposition} eq 'confirm scope') {
			$assetSysDispositionCode = $main::hashSYSDisposition{confirmscope};
		} elsif ($xlsRowVal{sysdisposition} =~ m/removed/i) {
			$assetSysDispositionCode = $main::hashSYSDisposition{removed};
		} elsif ($xlsRowVal{sysdisposition} =~ m/decomm/i) {
			$assetSysDispositionCode = $main::hashSYSDisposition{decomm};
		}

		# find the migration pattern if it's in the pattern table
		$assetPATkey = "";
		$assetPATname = lc(trim($xlsRowVal{pattern}));
		if ($assetPATname ne "" && exists($lkPA{$assetPATname})) {
			$assetPATkey = $lkPA{$assetPATname}{id};
		}

		## OS details
		my $osname = $xlsRowVal{osname};
		if ($osname ne "" && exists($lkOS{$osname})) {
			$assetOSkey = $lkOS{$osname}{id};
			$assetOSplatform = $lkOS{$osname}{platform};
		}

		#### Scope verified?
		my $assetVerifyScope = 0;
		if ($xlsRowVal{category} =~ m/hw/i || $xlsRowVal{category} =~ m/hardware/i) {
			if ($assetSerialNum ne "" && $assetLOCkey) { # we know where it is and it has a serial number
				$assetVerifyScope = 1;
			}

		} elsif ($xlsRowVal{category} =~ m/vm/i || $xlsRowVal{category} =~ m/p-lpar/i) {
			if ($assetIPkey ne "" && $assetOPSkey ne "" && $assetOSkey ne "" && $assetCloudscapeScan eq "1") {
				$assetVerifyScope = 1;
			}
		}

		## Only execute intelligence if we are still Discovering
		if ( $assetDiscoveryStatusCode == $main::hashDiscoveryStatus{inprogress} ) {
			# check to make sure if we are still migrating the asset
			if ( $assetSysDispositionCode == $main::hashSYSDisposition{migrating} ) {
				if ( $assetPATname =~ m/ad solution/i || $xlsRowVal{primaryfunction} =~ m/domain controller/i) {
					## identify AD scope -- will not be migrated
					$assetEVkey = "NULL"; # take out of the wave plan
					$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{removed};
					$assetSysDispositionCode = $main::hashSYSDisposition{removed};
					$assetPATname = lc("AD Solution");
					$assetPATkey = $lkPA{$assetPATname}{id};
					$assetPreMigration = "" if ($xlsRowVal{premigration} eq "");
					$assetIPDispositionCode = $main::hashIPDisposition{notmigrating};
					#$assetBaselineDelta = "Removed as CGI Owned" if ($assetBaselineDelta eq "");
					$assetVerifyScope = 0;
				} elsif ($assetPATname =~ m/stay back/i || $xlsRowVal{primaryfunction} =~ m/sccm/i) {
					## identify Stay Back services systems -- will not be migrated
					$assetEVkey = "NULL"; # take out of the wave plan
					$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{removed};
					$assetSysDispositionCode = $main::hashSYSDisposition{removed};
					$assetPATname = lc("Stay Back");
					$assetPATkey = $lkPA{$assetPATname}{id};
					$assetPreMigration = "" if ($xlsRowVal{premigration} eq "");
					$assetIPDispositionCode = $main::hashIPDisposition{notmigrating};
					#$assetBaselineDelta = "Removed as Stay Back Service" if ($assetBaselineDelta eq "");
					$assetVerifyScope = 0;
				} elsif ($xlsRowVal{category} =~ m/vm/i || $xlsRowVal{category} =~ m/p\-lpar/i) {
					## specific tests for VMs and P-LPARS
					if ($assetIPkey eq "") {
						## are key details (IP address) missing?
						$assetEVkey = "NULL"; # take out of the wave plan
						$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{notfound};
						$assetSysDispositionCode = $main::hashSYSDisposition{notmigrating};
						$assetPATname = lc("Key Details Missing");
						$assetPATkey = $lkPA{$assetPATname}{id};
						$assetPreMigration = "No IP Address" if ($xlsRowVal{premigration} eq "");
						#$assetBaselineDelta = "Removed as asset not identified" if ($assetBaselineDelta eq "");
						$assetIPDispositionCode = $main::hashIPDisposition{notmigrating};
						$assetVerifyScope = 0;
					} elsif ($assetRName eq "") {
						## are key details (rscd shortname) missing?
						$assetEVkey = "NULL"; # take out of the wave plan
						$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{notfound};
						$assetSysDispositionCode = $main::hashSYSDisposition{notmigrating};
						$assetPATname = lc("Key Details Missing");
						$assetPATkey = $lkPA{$assetPATname}{id};
						$assetPreMigration = "No RSCD shortname";
						#$assetBaselineDelta = "Removed as asset not identified" if ($assetBaselineDelta eq "");
						$assetIPDispositionCode = $main::hashIPDisposition{notmigrating};
						$assetVerifyScope = 0;
					} elsif ($xlsRowVal{category} =~ m/vm/i && $assetRVTkey eq "") {
						## if VM isnt found in RVtools, then flag it as not migrating
						$assetEVkey = "NULL"; # take out of the wave plan
						$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{notfound};
						$assetSysDispositionCode = $main::hashSYSDisposition{notmigrating};
						$assetPATname = lc("Key Details Missing");
						$assetPATkey = $lkPA{$assetPATname}{id};
						$assetPreMigration = "Missing in RVTools" if ($xlsRowVal{premigration} eq "");
						if ($assetIPkey ne "") {
							$assetIPDispositionCode = $main::hashIPDisposition{notmigrating};
						} else {
							$assetIPDispositionCode = $main::hashIPDisposition{notfound};
						}
						#$assetBaselineDelta = "Removed as Not Found in RVTools" if ($assetBaselineDelta eq "");
						$assetVerifyScope = 0;
					} elsif ($xlsRowVal{category} =~ m/vm/i && $assetRVTkey ne "" && $assetRVTpowerstate ne "" && $assetRVTpowerstate == $main::hashRVTPowerSt{poweredoff}) {
						## if VM is powered off in RVtools, then flag it as not migrating
						$assetEVkey = "NULL"; # take out of the wave plan
						$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{confirmed};
						$assetSysDispositionCode = $main::hashSYSDisposition{notmigrating};
						$assetPATname = lc("Source Powered Off");
						$assetPATkey = $lkPA{$assetPATname}{id};
						$assetPreMigration = "Confirm VM Powered Off" if ($xlsRowVal{premigration} eq "");
						if ($assetIPkey ne "") {
							$assetIPDispositionCode = $main::hashIPDisposition{notmigrating};
						} else {
							$assetIPDispositionCode = $main::hashIPDisposition{notfound};
						}
						#$assetBaselineDelta = "Removed as VM is Powered Off" if ($assetBaselineDelta eq "");
						$assetVerifyScope = 0;
					}
				} # vm or p-LPAR

				if ($assetVerifyScope && $assetSysDispositionCode == $main::hashSYSDisposition{migrating}) {
					## if we are still migrating the system disposition, make some basic decisions
					$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{inprogress};
					if ($xlsRowVal{category} =~ m/vm/i && ($assetOSplatform eq "Windows" || $assetOSplatform eq "Linux" ) ) {
						$xlsRowVal{category} = "VM";
						$assetSysDispositionCode = $main::hashSYSDisposition{migrating};
						$assetPATname = lc("Zerto V2V");
						$assetPATkey = $lkPA{$assetPATname}{id};
						$assetBaselineDelta = $xlsRowVal{baselinedelta};
					} elsif ($xlsRowVal{category} =~ m/p\-lpar/i || $assetOSplatform eq "AIX") {
						$xlsRowVal{category} = "P-LPAR";
						$assetSysDispositionCode = $main::hashSYSDisposition{migrating};
						$assetPATname = lc("LPAR MOVE");
						$assetPATkey = $lkPA{$assetPATname}{id};
						$assetBaselineDelta = $xlsRowVal{baselinedelta};
					}
				}
				if ($xlsRowVal{category} =~ m/container/i || $xlsRowVal{category} =~ m/hw/i || $xlsRowVal{category} =~ m/hardware/i) {
					## just for containers or hardware, override with what's in the spreadsheet
					$xlsRowVal{category} = "Container" if ($xlsRowVal{category} =~ m/container/i);
					$xlsRowVal{category} = "Hardware" if ($xlsRowVal{category} =~ m/hw/i || $xlsRowVal{category} =~ m/hardware/i);
					$assetVerifyScope = 1; # just for containers
					$assetSysDispositionCode = $main::hashSYSDisposition{migrating};
					$assetPATname = lc("Hardware Lift & Shift");
					$assetPATkey = $lkPA{$assetPATname}{id};
					$assetBaselineDelta = $xlsRowVal{baselinedelta};
				} elsif ($xlsRowVal{category} =~ m/z\-lpar/i || $assetOSplatform =~ m/mainframe/i) {
					$xlsRowVal{category} = "Z-LPAR";
					$assetSysDispositionCode = $main::hashSYSDisposition{migrating};
					$assetPATname = lc("mainframe");
					$assetPATkey = $lkPA{$assetPATname}{id};
					$assetBaselineDelta = $xlsRowVal{baselinedelta};
				}
			} ## END OF migrating the asset still
		} ## END OF still Discovering -- perform some intelligent decisions

		## if the system was otherwise marked as decom on Master and that was confirmed by WSIB
		if ($assetDiscoveryStatusCode == $main::hashDiscoveryStatus{confirmed} && ($assetSysDispositionCode == $main::hashSYSDisposition{decomm} || $assetIPDispositionCode == $main::hashIPDisposition{decomm})) {
			$assetEVkey = "NULL"; # take out of the wave plan
			$assetDiscoveryStatusCode = $main::hashDiscoveryStatus{confirmed};
			$assetSysDispositionCode = $main::hashSYSDisposition{decomm};
			$assetPATname = lc("WSIB Removed");
			$assetPATkey = $lkPA{$assetPATname}{id};
			$assetPreMigration = "";
			$assetIPDispositionCode = $main::hashIPDisposition{decomm};
			$assetBaselineDelta = "Removed per WSIB" if ($assetBaselineDelta eq "");
			$assetVerifyScope = 0;
		}

		## 2/20/20 - Solidify the primary function
		if ($xlsRowVal{primaryfunction} eq "" || lc($xlsRowVal{primaryfunction}) eq "undetermined") { # figure this out by the WSIB hostname
			$xlsRowVal{primaryfunction} = "";
		 	if (length($assetWSIBname) == 8) { ## follows WSIB naming convention
				my $c_app = lc(substr($assetWSIBname,4,2)); # application
				$xlsRowVal{primaryfunction} = $hashWSIBApp{$c_app} if (exists($hashWSIBApp{$c_app})); # use the naming convention primary app
			}
			$xlsRowVal{primaryfunction} = $assetStackname if ($xlsRowVal{primaryfunction} eq ""); # try using the stackname if we haven't found it yet
			$xlsRowVal{primaryfunction} = $assetSAMIcomponent if ($xlsRowVal{primaryfunction} eq ""); # try using the stackname if we haven't found it yet
			$xlsRowVal{primaryfunction} = "Undetermined" if ($xlsRowVal{primaryfunction} eq ""); # if it's still blank, make it undetermined
		}

		## 6/8/20 - Figure out the Migration Status
		## my $assetMigrationStatusCode = "";
		if ($assetDiscoveryStatusCode == $main::hashDiscoveryStatus{confirmed}) {
			if ($xlsRowVal{migrationstatus} eq "" || ($xlsRowVal{migrationstatus} =~ m/not/i && $xlsRowVal{migrationstatus} =~ m/started/i)) {
				$assetMigrationStatusCode = $main::hashMigrationStatus{notstarted};
			} elsif ($xlsRowVal{migrationstatus} =~ m/final/i && $xlsRowVal{migrationstatus} =~ m/validation/i) {
				$assetMigrationStatusCode = $main::hashMigrationStatus{finalvalidation};
			} elsif ($xlsRowVal{migrationstatus} =~ m/started/i) {
				$assetMigrationStatusCode = $main::hashMigrationStatus{started};
			} elsif ($xlsRowVal{migrationstatus} =~ m/completed/i) {
				$assetMigrationStatusCode = $main::hashMigrationStatus{completed};
			} elsif ($xlsRowVal{migrationstatus} =~ m/failback/i) {
				$assetMigrationStatusCode = $main::hashMigrationStatus{failback};
			} elsif ($xlsRowVal{migrationstatus} =~ m/stand/i && $xlsRowVal{migrationstatus} =~ m/down/i) {
				$assetMigrationStatusCode = $main::hashMigrationStatus{standdown};
			} elsif ($xlsRowVal{migrationstatus} =~ m/failed/i) {
				$assetMigrationStatusCode = $main::hashMigrationStatus{failed};
			}
		}

		################################################################################
		### END OF DATA INTEGRITY SCRUBBING
		################################################################################
		## 2/27/20 new sqlcoldata code to simplify NULLs
		#$xlsRowVal{ipaddr}
		my $sqlcoldata = "   excel_row = ". $assetXLRow . ",\n";
		$sqlcoldata .= "   location_id = " . (($assetLOCkey ne "") ? $assetLOCkey : "NULL") . ",\n";
		$sqlcoldata .= "   tgtlocation_id = " . (($assetTGTLOCkey ne "") ? $assetTGTLOCkey : "NULL") . ",\n";
		$sqlcoldata .= "   ipcell = " . (($assetIPv4 ne "") ? "\'". $assetIPv4 . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   wsibname = " . (($assetWSIBname ne "") ? "\'". $assetWSIBname . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   rscdname = " . (($assetRName ne "") ? "\'". $assetRName . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   disasterrecovery = " . (($assetDRscope ne "") ? $assetDRscope : "NULL") . ",\n";
		$sqlcoldata .= "   ipadd_id = " . (($assetIPkey ne "") ? $assetIPkey : "NULL") . ",\n";
		$sqlcoldata .= "   addm_id = " . (($assetADDMkey ne "") ? $assetADDMkey : "NULL") . ",\n";
		$sqlcoldata .= "   opsinv_id = " . (($assetOPSkey ne "") ? $assetOPSkey : "NULL") . ",\n";
		$sqlcoldata .= "   rvt_id = " . (($assetRVTkey ne "") ? $assetRVTkey : "NULL") . ",\n";
		$sqlcoldata .= "   event_id = " . (($assetEVkey ne "") ? $assetEVkey : "NULL") . ",\n";
		$sqlcoldata .= "   pattern_id = " . (($assetPATkey ne "") ? $assetPATkey : "NULL") . ",\n";
		$sqlcoldata .= "   os_id = " . (($assetOSkey ne "") ? $assetOSkey : "NULL") . ",\n";
		$sqlcoldata .= "   csasset_id = " . (($assetCSAkey ne "") ? $assetCSAkey : "NULL") . ",\n";
		$sqlcoldata .= "   sami_id = " . (($assetSAMIkey ne "") ? $assetSAMIkey : "NULL") . ",\n";
		$sqlcoldata .= "   primaryfunction = " . (($xlsRowVal{primaryfunction} ne "") ? "\'". $xlsRowVal{primaryfunction} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   serialnum = " . (($assetSerialNum ne "") ? "\'". $assetSerialNum . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   premigration = " . (($assetPreMigration ne "") ? "\'". $assetPreMigration . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   category = " . (($xlsRowVal{category} ne "") ? "\'". $xlsRowVal{category} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   baselinedelta = " . (($xlsRowVal{baselinedelta} ne "") ? "\'". $xlsRowVal{baselinedelta} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   notes = " . (($xlsRowVal{migrationnotes} ne "") ? "\'". $xlsRowVal{migrationnotes} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   discoverystatus = " . (($assetDiscoveryStatusCode ne "") ? $assetDiscoveryStatusCode : "NULL") . ",\n";
		$sqlcoldata .= "   ipdispositioncode = " . (($assetIPDispositionCode ne "") ? $assetIPDispositionCode : "NULL") . ",\n";
		$sqlcoldata .= "   verifiedscope = " . (($assetVerifyScope ne "") ? $assetVerifyScope : "NULL") . ",\n";
		$sqlcoldata .= "   dispositioncode = " . (($assetSysDispositionCode ne "") ? $assetSysDispositionCode : "NULL") . ",\n";
		$sqlcoldata .= "   migrationstatus = " . (($assetMigrationStatusCode ne "" && $assetMigrationStatusCode != $main::hashMigrationStatus{notstarted}) ? $assetMigrationStatusCode : "NULL") . ",\n";

		if (!exists($lkINV{$assetXLRow})) {
			$sql = "INSERT INTO`" . $main::IDB_NAME . "`.`inventory` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlINVInsert++;
				$lkINV{$assetXLRow}{id} = $dbh->{mysql_insertid};
				$lkINV{$assetXLRow}{location_id} = $assetLOCkey;
				$lkINV{$assetXLRow}{rscdname} = $assetRName;
				$lkINV{$assetXLRow}{ipadd_id} = $assetIPkey;

				## 4/10/20 -- Build the inventory - IP relationship table
				if ($assetWSIBname ne "" && exists($IPASSIGN{$assetWSIBname})) {
					foreach my $ip_id (@ { $IPASSIGN{$assetWSIBname}{ipadd_ids} }) {
						my $lku = $lkINV{$assetXLRow}{id} . $IndexDelimit . $ip_id;
						if (!exists($lkINVIP{$lku})) {
							$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`inviprel` SET \n";
							$sql .= "   inv_id = ". $lkINV{$assetXLRow}{id} . ",\n";
							$sql .= "   ipadd_id = ". $ip_id . ",\n";
							$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
							print $sql . "\n" if ($DEBUGSQL); # debug sql
							$dbh->do($sql);
							if (!defined($dbh) ) {
								print "Error while executing SQL:\n";
								print $sql . "\n";
								print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
								$iSqlErr++;
							} else {
								$iSqlINVIPInsert++;
								$lkINVIP{$lku}{id} = $dbh->{mysql_insertid}; # add to hash
							} # we inserted a record
						} # if (!exists($lkINVIP{$lku})) {
					} # foreach my $ip_id (@ { $lkADDM{$assetWSIBname}{ipadd_ids} }) {
				} # if ($assetWSIBname ne "" && exists($lkADDM{$assetWSIBname})) {
			}
		}

		# UPDATE IP ADDRESS AS VERIFIED IN SCOPE
		if ($assetVerifyScope && $assetIPkey ne "") {	# if we have verified scope, update the ipaddr file
			$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
			$sql .= "   verifiedscope = 1,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
			$sql .= "   WHERE id = " . $assetIPkey . ";\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlIPUpdate++;
			}
		} # update IPadd with verifiedscope = 1

		## HANDLE DATA ERRORS HERE
		## for hardware lift and shift, simply take the serial number in that column
		if ($xlsRowVal{category} =~ m/hardware/i || $xlsRowVal{category} =~ m/hw/i) {
			if ($assetSerialNum eq "") {
				 $iDataErrors++; # this is a data error
				 $sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
				 $sql .= "   type = \'master\',\n";
				 $sql .= "   errorlog = \'Master row (". $assetXLRow .") SERIAL NUMBER IS BLANK.\',\n";
				 $sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				 print $sql . "\n" if ($DEBUGSQL); # debug sql
				 $dbh->do($sql);
				 if (!defined($dbh) ) {
					 print "Error while executing SQL:\n";
					 print $sql . "\n";
					 print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					 $iSqlErr++;
				 }
			}
		}
	} # end if headers have all been found
} # end for row

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-master-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "INV Inserts\t:" . $iSqlINVInsert . "\n";
print "INVIP Inserts\t:" . $iSqlINVIPInsert . "\n";
print "EV Inserts\t:" . $iSqlEVInsert . "\n";
print "EV Updates\t:" . $iSqlEVUpdate . "\n";
print "IP Updates\t:" . $iSqlIPUpdate . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "Errors\t\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
