#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Affinity Generator (Ad Hoc Report)
### No database inserts or updates occur in this script.
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Excel::Writer::XLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
no warnings 'once';

require './ibm-globals.pl';

# accumulators and switch variables --------------------------------------
my $iRows;
my $href;

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkVLAN 				= ();	# hash table to lookup VLAN already in the database
my %lkWAVE 				= ();	# hash table to lookup WAVE sequences already in the database
my %AFFINITY			= ();	# hash table to contain affinity pairs

my $outExcelRows	= 0;  # total number of excel rows written
my $DEBUGSQL 			= 0; 	# set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 		# this is the row to stop checking for headers and fail if all headers haven't been found
my %KEY_DATA_ERRORS	= (); # hash to contain data errors by Excel row (key information not found)

my $FONT_SIZE_HDR = 10;
my $FONT_CELL = 'IBM Plex Sans';
my $FONT_SIZE_CELL = 10;
my $FONT_SIZE_NOTES = 12;
my $ROW_HEIGHT_HDR = 24;
my $MAX_COLS = 18;
my $IndexDelimit = '^';

my $iSqlErr				= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

# -----------------------------------------------------------------------
# LOAD PRIOR DATA FOR LOOKUPS
# -----------------------------------------------------------------------
if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
	}
}

# VLAN table lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
$sql = "SELECT vl.number, lo.code, vl.subnet, vl.name  FROM `" . $main::IDB_NAME . "`.`vlan` vl \n";
$sql .= "   LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON vl.location_id = lo.id; \n";
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $vnum = $refr[0];
	my $lccd = $refr[1];
	my $lkey = $lccd . $vnum;
	# set up all of the lookup values and later for update comparison
	$lkVLAN{$lkey}{number} = $vnum;
	$lkVLAN{$lkey}{subnet} = $refr[2];
	$lkVLAN{$lkey}{vlanname} = $refr[3];
}

# Global IP CSPAIR table lookups
if ((grep { /cspair/ } @dbTables) == 0) {
	print "Table: cspair not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

$sql = "SELECT ls.code, vs.`number`, ld.code, vd.`number`, cspt.hit_count, cst.srcgroup, cst.protocolname\n";
$sql .= " FROM `" . $main::IDB_NAME . "`.`cspair` csp \n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ips ON csp.src_ipadd_id = ips.id \n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vs ON ips.vlan_id = vs.id\n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`location` ls ON vs.location_id = ls.id\n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vd ON ipd.vlan_id = vd.id\n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`location` ld ON vd.location_id = ld.id\n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cspt ON cspt.cspair_id = cspt.id\n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cst ON cspt.cstraf_id = cst.id\n";
$sql .= " WHERE csp.src_ipadd_id IS NOT NULL\n";
$sql .= " AND csp.dest_ipadd_id IS NOT NULL\n";
$sql .= " AND ipd.vlan_id IS NOT NULL;\n";

$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $srcloc = defined($refr[0]) ? $refr[0] : "";
	my $srcvlan = defined($refr[1]) ? $refr[1] : "";
	my $destloc = defined($refr[2]) ? $refr[2] : "";
	my $destvlan = defined($refr[3]) ? $refr[3] : "";
	my $hitcount = defined($refr[4]) ? $refr[4] : 0;
	my $srcgroup = defined($refr[5]) ? $refr[5] : "";
	my $proto = defined($refr[6]) ? $refr[6] : "";

	if ($srcloc ne "" && looks_like_number($srcvlan) && $destloc ne "" && looks_like_number($destvlan)) {
		my $xidx = $srcloc . $IndexDelimit . sprintf("%05d",$srcvlan) . $IndexDelimit . $destloc . $IndexDelimit . sprintf("%05d",$destvlan);
		my $xidx_flip = $destloc . $IndexDelimit . sprintf("%05d",$destvlan) . $IndexDelimit . $srcloc . $IndexDelimit . sprintf("%05d",$srcvlan);
		$xidx = $xidx_flip if (exists($AFFINITY{$xidx_flip}));
	}
	if (exists($AFFINITY{$xidx})) {
		#if ( $vidx ne "" && exists($NetworkDB{$vidx}) && ((grep { /$vidx/ } @ { $WaveDB{$wseq}{vidx} }) == 0) );
		$AFFINITY{$xidx}{hitcount} += $hitcount;
		push (@ { $AFFINITY{$xidx}{srcgroups} },$srcgroup) if ((grep { /$srcgroup/ } @ { $AFFINITY{$xidx}{srcgroups} }) == 0);
		push (@ { $AFFINITY{$xidx}{protocols} },$proto) if ((grep { /$proto/ } @ { $AFFINITY{$xidx}{protocols} }) == 0);
	} else {
		$AFFINITY{$xidx}{hitcount} = $hitcount;
		@ { $AFFINITY{$xidx}{srcgroups} }	= (); # initialize array
		push (@ { $AFFINITY{$xidx}{srcgroups} },$srcgroup);
		@ { $AFFINITY{$xidx}{protocols} }	= (); # initialize array
		push (@ { $AFFINITY{$xidx}{protocols} },$proto);
	}
}

# Wave Sequence EVENT table lookups
if ((grep { /event/ } @dbTables) == 0) {
	print "Table: event not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
$sql = "SELECT wavesequence, name  FROM `" . $main::IDB_NAME . "`.`event`;\n";
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $waveseq = (defined($refr[0])) ? $refr[0] : "";
	my $wavenm = (defined($refr[1])) ? $refr[1] : "";
	if (!exists($lkWAVE{$waveseq})) {
		$lkWAVE{$waveseq}{name} = $wavenm;
	}
}

## wave:# or w:# -- collect all of the traffic for all IP addresses for a specific wave sequence number
## <data ctr code>:<VLAN #> -- collect all of the traffic for all IP addresses on a specific VLAN #

my @VLANs = ();
my @WAVES = ();

my $detail_view = 0; # default is roll up in fewer worksheets

foreach my $arg (@ARGV) {
	my @qrylist = split(/\,/,$arg); # split by comma
	foreach my $qry (@qrylist) {
		if ($qry =~ m/\:/) { # contains a colon separator
			my ($ctl1, $num1) = split(/\:/,$qry); # split into 2 args
			if (lc($ctl1) eq "w" || $ctl1 =~ m/wav/i) { # wave sequence queried
				if ($num1 =~ m/\-/) { # contains a dash separator meaning waves m-n
					my ($wslo, $wshi) = split(/\-/,$num1); # split into 2 args
					if (looks_like_number($wslo) && $wslo > 0 && looks_like_number($wshi) && $wshi > $wslo) {
						for (my $i = $wslo; $i <= $wshi; $i++) {
							push(@WAVES,$i);
						}
					}
				} elsif (looks_like_number($num1) && $num1 > 0) {
					push(@WAVES,$num1);
				}
			} elsif (exists($lkLOC{uc($ctl1)}) && looks_like_number($num1) && $num1 > 0) {
				my $txt = uc($ctl1) . "-" . $num1;
				push(@VLANs,$txt);
			}
		} elsif ($qry =~ m/detail/i) {
			$detail_view = 1; # turn on detail view
		}
	}
}

## figure out the file content
my $file_content = "";
my $valid_queries = 0;

if (scalar @VLANs) {
	my $elecount = scalar @VLANs;
	$valid_queries += $elecount;
	$file_content .= "." if ($file_content ne "");
	$file_content .= $elecount . "xVLAN";
	$file_content .= "s" if ($elecount != 1);
}
if (scalar @WAVES) {
	my $elecount = scalar @WAVES;
	$valid_queries += $elecount;
	$file_content .= "." if ($file_content ne "");
	$file_content .= $elecount . "xWave";
	$file_content .= "s" if ($elecount != 1);
}

if ($valid_queries == 0) { # no valid queries supplied
	$dbh->disconnect(); # Disconnect from the database.
	die "\n*** ERROR: No valid query parameters were supplied as a command line parameters, so cannot proceed.\n\n";
}

# Output a banner to show what we're doing
Display_Pgm_Banner("GENERATING TRAFFIC REPORT");

# other variables --------------------------------------------------------
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
my $today = (1900 + $year) . sprintf("%02d",$mon + 1) . sprintf("%02d",$mday) . "_" . sprintf("%02d",$hour) . sprintf("%02d",$min) . sprintf("%02d",$sec);
my $xlsxfilenm =  $main::SCRIPT_TAG . " " . $main::CUST_NAME . " " . $file_content . " Affinity " . ($detail_view ? "Detail Report" : "Report") . "-v" . $main::SCRIPT_VER . "_" . $today . ".xlsx";

# Create a new workbook --------------------------------------------------
my $workbookout = Excel::Writer::XLSX->new($xlsxfilenm);
die "Problems creating new Excel file: $!" unless defined $workbookout;

$workbookout->set_properties(
	title    	=> 'IBM Affinity ' . ($detail_view ? 'Detail Report' : 'Report'),
	subject  	=> 'IBM Affinity '. $file_content . ($detail_view ? 'Detail Report' : 'Report'),
	author   	=> 'Joseph Blaty',
	company   	=> 'IBM Corporation',
	comments 	=> 'Generated from Flexera Cloudscape Detailed Application Dependency data.',
);

# custom formats and colors ----------------------------------------------
# set_custom_color($index, $red, $green, $blue) --------------------------
my $greenbar = $workbookout->set_custom_color(54, 228, 255, 223); # Green bar color

my $brightblue = $workbookout->set_custom_color(40, 0, 112, 192); # Bright Blue Header Color

my $wavepurple = $workbookout->set_custom_color(41, 204, 192, 218); # Purple Wave Color

my $osorange = $workbookout->set_custom_color(42, 252, 213, 180); # Orange OS Color

my $appskyblue = $workbookout->set_custom_color(43, 183, 222, 232); # Sky Blue App Color

my $title_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'center',
	valign => 'bottom' );

my $title_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'left',
	valign => 'bottom' );

my $title_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'right',
	valign => 'bottom' );

my $wave_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $wavepurple,
		align => 'center',
		valign => 'bottom' );

my $wave_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $wavepurple,
		align => 'left',
		valign => 'bottom' );

my $os_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $osorange,
		align => 'center',
		valign => 'bottom' );

my $os_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $osorange,
		align => 'left',
		valign => 'bottom' );

my $app_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $appskyblue,
		align => 'center',
		valign => 'bottom' );

my $app_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $appskyblue,
		align => 'left',
		valign => 'bottom' );

my $notes_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_NOTES,
	bold => 1,
	border=> 1,
		color => 'red',
	align => 'left',
	text_wrap=> 1,
	valign => 'bottom' );

my $row_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	bold => 1,
	border=> 1,
	align => 'center',
	valign => 'bottom' );

my $cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	align => 'right',
	valign => 'bottom' );

my $cell_fmt_lbl	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	bold => 1,
	border=> 1,
	align => 'right',
	valign => 'bottom' );

my $cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $cell_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'right',
	valign => 'bottom' );

my $gn_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	align => 'right',
	valign => 'bottom' );

my $gn_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $gn_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $totals_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	bold => 1,
	border=> 1,
	color => 'white',
	bg_color => 'grey',
	align => 'right',
	valign => 'bottom' );

my $totals_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	border=> 1,
	bold => 1,
	color => 'white',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $totals_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	bold => 1,
	border=> 1,
	color => 'white',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $ye_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	align => 'right',
	valign => 'bottom' );

my $ye_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $ye_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $re_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	align => 'right',
	valign => 'bottom' );

my $re_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $re_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $grey_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $grey_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

### END OF EXCEL formats

## Set up the columns of the VLAN worksheet
my %xlsOrd=();	# hash table to define spreadsheet column order
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain data

for my $col ( 0 .. ($MAX_COLS - 1)) {
	if 	( $col == 0 ) { #A
		$xlsOrd{$col}{label} = "direction";
		$xlsOrd{$col}{title} = "Direction";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 1 ) { #B
		$xlsOrd{$col}{label} = "srcaddr";
		$xlsOrd{$col}{title} = "Source IP";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 2 ) { #C
		$xlsOrd{$col}{label} = "srcvlan";
		$xlsOrd{$col}{title} = "Source VLAN";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 3 ) { #D
		$xlsOrd{$col}{label} = "srcdc";
		$xlsOrd{$col}{title} = "Source Location";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 4 ) { #E
		$xlsOrd{$col}{label} = "srcvname";
		$xlsOrd{$col}{title} = "Source VLAN Name";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 5 ) { #F
		$xlsOrd{$col}{label} = "srcsubnet";
		$xlsOrd{$col}{title} = "Source Subnet";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 6 ) { #G
		$xlsOrd{$col}{label} = "srchostname";
		$xlsOrd{$col}{title} = "Source Hostname";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 7 ) { #H
		$xlsOrd{$col}{label} = "srcgroup";
		$xlsOrd{$col}{title} = "Source Group";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 8 ) { #I
		$xlsOrd{$col}{label} = "destaddr";
		$xlsOrd{$col}{title} = "Dest. IP";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 9 ) { #J
		$xlsOrd{$col}{label} = "destvlan";
		$xlsOrd{$col}{title} = "Dest. VLAN";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 10 ) { #K
		$xlsOrd{$col}{label} = "destdc";
		$xlsOrd{$col}{title} = "Dest. DC";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 11 ) { #L
		$xlsOrd{$col}{label} = "destvname";
		$xlsOrd{$col}{title} = "Dest. VLAN Name";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 12 ) { #M
		$xlsOrd{$col}{label} = "destsubnet";
		$xlsOrd{$col}{title} = "Dest. Subnet";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 13 ) { #N
		$xlsOrd{$col}{label} = "desthostname";
		$xlsOrd{$col}{title} = "Dest. Hostname";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 14 ) { #O
		$xlsOrd{$col}{label} = "destgroup";
		$xlsOrd{$col}{title} = "Dest. Group";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 15 ) { #P
		$xlsOrd{$col}{label} = "destport";
		$xlsOrd{$col}{title} = "Dest. Port";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 16 ) { #Q
		$xlsOrd{$col}{label} = "protocol";
		$xlsOrd{$col}{title} = "Protocol";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 17 ) { #R
		$xlsOrd{$col}{label} = "hitcount";
		$xlsOrd{$col}{title} = "Hit Count";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} # end if
	$xlsCol{$xlsOrd{$col}{label}}{col} = $col;
} # end for col

my %resWS = (); # hash table for ALL worksheets

## WAVES PARAMETERS WERE PASSED
if (scalar @WAVES) {
	## for each WAVE in scope, loop here
	foreach my $waveseq (@WAVES) {
		next if (!looks_like_number($waveseq));

		# Hostnames in scope for that wave
		my @inscopeHOSTS = ();
		$sql = "SELECT inv.wsibname\n";
		$sql .= "  FROM `" . $main::IDB_NAME . "`.`inventory` inv \n";
		$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`event` ev  ON inv.event_id = ev.id\n";
		$sql .= "  WHERE ev.wavesequence = ". $waveseq ."\n";
		$sql .= "    AND inv.wsibname IS NOT NULL\n";
		$sql .= "  ORDER BY inv.wsibname;\n";
		print $sql . "\n" if ($DEBUGSQL); # debug sql
		$sth = $dbh->prepare($sql);
		if (!$sth) {
			die "Error:" . $dbh->errstr . "\n";
		}
		if (!$sth->execute) {
			die "Error:" . $sth->errstr . "\n";
		}
		my $inscopeHOSTstr = "";
		while (my @refr = $sth->fetchrow_array) {
			$inscopeHOSTstr .= ",\n" if ($inscopeHOSTstr ne "");
			$inscopeHOSTstr .= "\'" . $refr[0] . "\'";
			push(@inscopeHOSTS,$refr[0]); # HOST in scope
		}

		if ($detail_view) { # detail view
			## for each HOST in scope, loop here
			foreach my $hostnm (@inscopeHOSTS) {
				my $wsname = "w" . $waveseq . "_" . $hostnm;
				$resWS{$wsname}{wks}	= $workbookout->add_worksheet($wsname);
				$resWS{$wsname}{row} = 0;

				## column headers
				foreach my $col (sort keys %xlsOrd) {
					$resWS{$wsname}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
					$resWS{$wsname}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
				}
				$resWS{$wsname}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
				$resWS{$wsname}{row} += 1; # increment the row counter

				## now loop twice for outbound and inbound traffic
				for (my $i=0;$i < 2;$i++) {
					$sql = "SELECT ";
					if ($i == 0) {
						$sql .= "'OUTBOUND' as value,";
					} else {
						$sql .= "'INBOUND' as value,";
					}
					$sql .= "INET_NTOA(ips.ipv4) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
					$sql .= "INET_NTOA(ipd.ipv4) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
					$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ips ON csp.src_ipadd_id = ips.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON ips.vlan_id = vls.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";

					if ($i == 0) {
						$sql .= "where csp.srcname = \'";
					} else {
						$sql .= "where csp.destname = \'";
					}
					$sql .= $hostnm . "\'\n";
					if ($i == 0) {
						$sql .= "ORDER BY vls.number, ips.ipv4, ipd.ipv4;\n";
					} else {
						$sql .= "ORDER BY vld.number, ipd.ipv4, ips.ipv4;\n";
					}
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$sth = $dbh->prepare($sql);
					if (!$sth) {
						die "Error:" . $dbh->errstr . "\n";
					}
					if (!$sth->execute) {
						die "Error:" . $sth->errstr . "\n";
					}

					while (my @refr = $sth->fetchrow_array) {
						foreach my $col (sort keys %xlsOrd) {
							my $this_cell_format = $cell_fmt_ct;
							my $this_cell_value = "";
							$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
							$resWS{$wsname}{wks} -> write($resWS{$wsname}{row}, $col, $this_cell_value , $this_cell_format);
							$resWS{$wsname}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
						}
						$resWS{$wsname}{row} += 1; # increment the row counter
					} # sql results loop
				} ## for loop inbound/outbound traffic
				$resWS{$wsname}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
				$resWS{$wsname}{wks} -> freeze_panes(1,0); # freeze panes on the first row
			} ## foreach hostnm
		} else { # rollup view
			my $wsname = "Wave " . $waveseq;
			$resWS{$wsname}{wks}	= $workbookout->add_worksheet($wsname);
			$resWS{$wsname}{row} = 0;

			## column headers
			foreach my $col (sort keys %xlsOrd) {
				$resWS{$wsname}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
				$resWS{$wsname}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
			}
			$resWS{$wsname}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
			$resWS{$wsname}{row} += 1; # increment the row counter

			## now loop twice for outbound and inbound traffic
			for (my $i=0;$i < 2;$i++) {
				if ($inscopeHOSTstr ne "") {
					$sql = "SELECT ";
					if ($i == 0) {
						$sql .= "'OUTBOUND' as value,";
					} else {
						$sql .= "'INBOUND' as value,";
					}
					$sql .= "INET_NTOA(ips.ipv4) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
					$sql .= "INET_NTOA(ipd.ipv4) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
					$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ips ON csp.src_ipadd_id = ips.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON ips.vlan_id = vls.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";

					if ($i == 0) {
						$sql .= "where csp.srcname IN (";
					} else {
						$sql .= "where csp.destname IN (";
					}
					$sql .= $inscopeHOSTstr . ")\n";
					if ($i == 0) {
						$sql .= "ORDER BY vls.number, csp.srcname, ips.ipv4, ipd.ipv4;\n";
					} else {
						$sql .= "ORDER BY vld.number, csp.destname, ipd.ipv4, ips.ipv4;\n";
					}
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$sth = $dbh->prepare($sql);
					if (!$sth) {
						die "Error:" . $dbh->errstr . "\n";
					}
					if (!$sth->execute) {
						die "Error:" . $sth->errstr . "\n";
					}

					while (my @refr = $sth->fetchrow_array) {
						foreach my $col (sort keys %xlsOrd) {
							my $this_cell_format = $cell_fmt_ct;
							my $this_cell_value = "";
							$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
							$resWS{$wsname}{wks} -> write($resWS{$wsname}{row}, $col, $this_cell_value , $this_cell_format);
							$resWS{$wsname}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
						}
						$resWS{$wsname}{row} += 1; # increment the row counter
					} # sql results loop
				} #if ($inscopeHOSTstr ne "") {
			} ## for loop inbound/outbound traffic
			$resWS{$wsname}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
			$resWS{$wsname}{wks} -> freeze_panes(1,0); # freeze panes on the first row
		} # detail or rollup view
	} # foreach @WAVES
} # if scalar @WAVES

## VLAN PARAMETERS WERE PASSED
if (scalar @VLANs) {
	## for each VLAN in scope, loop here
	foreach my $vlanString (@VLANs) {
		my ($dc, $vlanNumber) = split(/\-/,$vlanString); # split by dash

		my $subnetLOCkey = "";
		$subnetLOCkey = $lkLOC{$dc}{id} if ($dc ne "" && exists($lkLOC{$dc}));
		next if ($subnetLOCkey eq ""); # skip if location key not found

		my $vlanHashKey = $subnetLOCkey . $vlanNumber; # hash key is LOCid.VLAN#

		my $worksheetTab = $vlanString; # new 2/12/20 - this is now in DC-VLAN# format
		$resWS{$vlanHashKey}{wks}	= $workbookout->add_worksheet($worksheetTab);
		$resWS{$vlanHashKey}{row} = 0;

		## column headers
		foreach my $col (sort keys %xlsOrd) {
			$resWS{$vlanHashKey}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
			$resWS{$vlanHashKey}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
		}
		$resWS{$vlanHashKey}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
		$resWS{$vlanHashKey}{row} += 1; # increment the row counter


		# IPs in scope
		my @inscopeIPs = ();
		$sql = "SELECT INET_NTOA(ip.ipv4)\n";
		$sql .= "  FROM `" . $main::IDB_NAME . "`.`ipadd` ip \n";
		$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vl  ON ip.vlan_id = vl.id\n";
		$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`inventory` inv ON inv.ipadd_id = ip.id\n";
		$sql .= "  WHERE vl.number = ". $vlanNumber ."\n";
		$sql .= "    AND vl.location_id = " . $subnetLOCkey . "\n";
		$sql .= "    AND inv.ipdispositioncode IN (0,1);\n";
		print $sql . "\n" if ($DEBUGSQL); # debug sql
		$sth = $dbh->prepare($sql);
		if (!$sth) {
			die "Error:" . $dbh->errstr . "\n";
		}
		if (!$sth->execute) {
			die "Error:" . $sth->errstr . "\n";
		}
		my $inscopeIPstr = "";
		while (my @refr = $sth->fetchrow_array) {
			$inscopeIPstr .= ",\n" if ($inscopeIPstr ne "");
			$inscopeIPstr .= "\'" . $refr[0] . "\'";
			push(@inscopeIPs,$refr[0]); # IP in scope
		}

		if ($inscopeIPstr ne "") {
			## now loop twice for outbound and inbound traffic
			for (my $i=0;$i < 2;$i++) {
				$sql = "SELECT ";
				if ($i == 0) {
					$sql .= "'OUTBOUND' as value,";
				} else {
					$sql .= "'INBOUND' as value,";
				}
				$sql .= "INET_NTOA(ips.ipv4) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
				$sql .= "INET_NTOA(ipd.ipv4) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
				$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ips ON csp.src_ipadd_id = ips.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON ips.vlan_id = vls.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
				$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";

				if ($i == 0) {
					$sql .= "where INET_NTOA(ips.ipv4) IN (\n";
				} else {
					$sql .= "where INET_NTOA(ipd.ipv4) IN (\n";
				}
				$sql .= $inscopeIPstr . ")\n";
				if ($i == 0) {
					$sql .= "ORDER BY vls.number, ips.ipv4, ipd.ipv4;\n";
				} else {
					$sql .= "ORDER BY vld.number, ipd.ipv4, ips.ipv4;\n";
				}
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$sth = $dbh->prepare($sql);
				if (!$sth) {
					die "Error:" . $dbh->errstr . "\n";
				}
				if (!$sth->execute) {
					die "Error:" . $sth->errstr . "\n";
				}
				my $inscopeIPstr = "";
				while (my @refr = $sth->fetchrow_array) {
					foreach my $col (sort keys %xlsOrd) {
						my $this_cell_format = $cell_fmt_ct;
						my $this_cell_value = "";
						$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
						$resWS{$vlanHashKey}{wks} -> write($resWS{$vlanHashKey}{row}, $col, $this_cell_value , $this_cell_format);
						$resWS{$vlanHashKey}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
					}
					$resWS{$vlanHashKey}{row} += 1; # increment the row counter
				} # sql results loop
			} ## for loop inbound/outbound traffic
		} # if ($inscopeIPstr ne "") {
		$resWS{$vlanHashKey}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
		$resWS{$vlanHashKey}{wks} -> freeze_panes(1,0); # freeze panes on the first row
	} #foreach my $vlan loop
} # if scalar @VLANs

# Disconnect from the database.
$dbh->disconnect();
$workbookout->close(); # close and write the workbook
exit;
