#!/bin/bash
echo "---- Discovery Sources Aggregator Rebuild ----"
echo
echo "** 1. Priming the database..."
perl ibm-db-primer.pl $1 > test-db-primer.txt
echo
echo "** 2. Loading core network data (network.xlsx)..."
perl ibm-vlan-load.pl network.xlsx > test-vlan-load.txt
echo
echo "** 3a. Loading F5 Load Balancer Pool data (f5pool-MDC.xlsx)..."
perl ibm-lb-load.pl f5pool-MDC.xlsx > test-lb3a-load.txt
echo
echo "** 3b. Loading F5 Load Balancer Pool data (f5pool-DDC.xlsx)..."
perl ibm-lb-load.pl f5pool-DDC.xlsx > test-lb3b-load.txt
echo
echo "** 4. Loading ADDM data (addm-sys.xlsx)..."
perl ibm-addm-load.pl addm-sys.xlsx > test-addm-load.txt
echo
echo "** 5. Loading real-time operations inventory data (cgi-opsinv.xlsx)..."
perl ibm-ops-load.pl cgi-opsinv.xlsx > test-ops-load.txt
echo
echo "** 6a. Loading RVTools data (WSIB_MDC_Dedicated.xlsx)..."
perl ibm-rvt-load.pl WSIB_MDC_Dedicated.xlsx > test-rvt1-load.txt
echo
echo "** 6b. Loading RVTools data (WSIB_MDC_G3.xlsx)..."
perl ibm-rvt-load.pl WSIB_MDC_G3.xlsx > test-rvt2-load.txt
echo
echo "** 6c. Loading RVTools data (WSIB_DDC_Dedicated.xlsx)..."
perl ibm-rvt-load.pl WSIB_DDC_Dedicated.xlsx > test-rvt3-load.txt
echo
echo "** 6d. Loading RVTools data (WSIB_DDC_G3.xlsx)..."
perl ibm-rvt-load.pl WSIB_DDC_G3.xlsx > test-rvt4-load.txt
echo
echo "** 7. Loading Cloudscape Assets (csassets.csv)..."
perl ibm-csasset-load.pl csassets.csv > test-csasset-load.txt
echo
echo "** 8a. Loading Cloudscape Dependencies (export0.csv)..."
perl ibm-csdep-load.pl export0.csv > test-csdep0-load.txt
echo
echo "** 8b. Loading Cloudscape Dependencies (export1.csv)..."
perl ibm-csdep-load.pl export1.csv > test-csdep1-load.txt
echo
echo "** 8c. Loading Cloudscape Dependencies (export2.csv)..."
perl ibm-csdep-load.pl export2.csv > test-csdep2-load.txt
echo
echo "** 8d. Loading Cloudscape Dependencies (export3.csv)..."
perl ibm-csdep-load.pl export3.csv > test-csdep3-load.txt
echo
echo "** 8e. Loading Cloudscape Dependencies (export4.csv)..."
perl ibm-csdep-load.pl export4.csv > test-csdep4-load.txt
echo
echo "** 8f. Loading Cloudscape Dependencies (export5.csv)..."
perl ibm-csdep-load.pl export5.csv > test-csdep5-load.txt
echo
echo "** 8g. Loading Cloudscape Dependencies (export6.csv)..."
perl ibm-csdep-load.pl export6.csv > test-csdep6-load.txt
echo
echo "** 8h. Loading Cloudscape Dependencies (export7.csv)..."
perl ibm-csdep-load.pl export7.csv > test-csdep7-load.txt
echo
echo "** 8i. Loading Cloudscape Dependencies (export8.csv)..."
perl ibm-csdep-load.pl export8.csv > test-csdep8-load.txt
echo
echo "** 9. Loading SAMI reference data (sami.xlsx)..."
perl ibm-sami-load.pl sami.xlsx > test-sami-load.txt
echo
echo "** 10. Loading EVENT data (events.xlsx)..."
perl ibm-events-load.pl events.xlsx > test-events-load.txt
echo
echo "** 11. Loading Master System Inventory data (master.xlsx)..."
perl ibm-master-load.pl master.xlsx > test-master-load.txt
echo
echo "** 12. Loading Storage data (storage.xlsx)..."
perl ibm-storage-load.pl storage.xlsx > test-storage-load.txt
echo
echo "** 13. Loading Database data (database.xlsx)..."
perl ibm-dbms-load.pl database.xlsx > test-dbms-load.txt
echo
echo "** 14. Loading Appstacks (appstacks.xlsx)..."
perl ibm-appstack-load.pl appstacks.xlsx > test-appstacks-load.txt
#echo
echo
echo "---- Discovery Sources Aggregator Rebuild COMPLETED ----"
