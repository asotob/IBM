#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Master Inventory File Generator (Ad Hoc Report)
### No database inserts or updates occur in this script.
### Date:		July 29, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 2/19/20 - Major revamp of IP Address handling
### 2/19/20 - Removed SAMI references
### 6/6/20 - Added the Red Flags worksheet
### 6/19/20 - Parameterized red flag notification via the redflag table
############################################################################
use strict;
use warnings;
use Excel::Writer::XLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::Subnet;
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("GENERATING MASTER SYSTEM INVENTORY");

# accumulators and switch variables --------------------------------------
my $iRows;
my $href;

my %lkSAMI 				= ();	# hash table to lookup SAMI records already in the database (for legacy lookups by wsib hostname)
my %lkSAMIr				= ();	# hash table to lookup SAMI records already in the database (for legacy lookups by rscd shortname)

my %lkINV				= ();	# hash table to lookup INVENTORY record details by wsib hostname
my %lkADMOS				= ();	# hash table to lookup ADDM OS records details by wsib hostname

my %lkDBI				= ();	# hash table to lookup database information by inv_id

my %SANTotals 			= (); # hash to total the SAN storage per asset, indexed by inv_id
my %NASTotals 			= (); # hash to total the NAS storage per asset, indexed by inv_id

my %MasterDB			= ();	# special hash table by indexed row from the database join
my %WaveDB				= ();	# wave planner hash indexed by the waveseq
my %NetworkDB			= ();	# network hash indexed by the source location and vlan number

my %SubnetWave			= ();	# hash indexed by DC^vlannum showing the wave sequence in which the subnet will be migrated

my %IPKEYS				= ();	### hash table to lookup IP addresses already assigned by ipkey - prevent multiple tallies of the same IP address (i.e. load balancing/clustering)

## 4/8/20 v3.4 -- VLAN lookup functionality
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my @FSUBS				= (); # array for fast IP to subnet validation

## 4/10/20 v3.5 -- Additional Network detail scope
my %lkGIP	 			= ();	# hash table to lookup Global IP addresses already in the database
my %lkGIPk 				= ();	### hash table to lookup Global IP addresses already in the database by db key

my %RedFlagTxt			= ();	# hash table to lookup REDFLAG records already in the database (by shortkey)

my %MigrOvr				= ();	# special hash table for the migration overview
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to reset the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$MigrOvr{'Windows VM'}{$disptxt} = 0;
	$MigrOvr{'Linux VM'}{$disptxt} = 0;
	$MigrOvr{'Total VM'}{$disptxt} = 0;
	$MigrOvr{'Container'}{$disptxt} = 0;
	$MigrOvr{'P-LPAR'}{$disptxt} = 0;
	$MigrOvr{'Z-LPAR'}{$disptxt} = 0;
	$MigrOvr{'Hardware'}{$disptxt} = 0;
	$MigrOvr{'Total'}{$disptxt} = 0;
}

$MigrOvr{'Windows VM'}{completed} = 0;
$MigrOvr{'Linux VM'}{completed} = 0;
$MigrOvr{'Total VM'}{completed} = 0;
$MigrOvr{'Container'}{completed} = 0;
$MigrOvr{'P-LPAR'}{completed} = 0;
$MigrOvr{'Z-LPAR'}{completed} = 0;
$MigrOvr{'Hardware'}{completed} = 0;
$MigrOvr{'Total'}{completed} = 0;


my $outExcelRows	= 0;  # total number of excel rows written
my $MasterRows		= 0;  # number of rows found on the assets table
my $outInfoRows	= 0;  # number of rows output to the metrics worksheet
my $outMetricsRows	= 0;  # number of rows output to the metrics worksheet
my $outMasterRows	= 0;  # number of rows output to the master worksheet
my $outWaveRows		= 0;  # number of rows output to the wave summary worksheet
my $outRedFlagRows	= 0;  # number of rows output to the red flags worksheet
my $outAppRows = 0;  # number of rows output to the application worksheet
my $outSANRows = 0;  # number of rows output to the SAN worksheet
my $outNASRows = 0;  # number of rows output to the NAS worksheet
my $outDatabaseRows = 0;  # number of rows output to the database worksheet
my $outDBMSRows = 0;  # number of rows output to the DBMS worksheet
my $outOrphanRows = 0;  # number of rows output to the Orphan IPs worksheet
my $outTrackingRows	= 0;  # number of rows output to the tracking worksheet
my $outNetworkRows = 0;  # number of rows output to the network worksheet
my $outErrorRows	= 0;  # number of rows output to the errors worksheet

my $TotalRedFlags	= 0;  # count the red flags for the red flag worksheet

my $DEBUGSQL 			= 1; 	# set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 		# this is the row to stop checking for headers and fail if all headers haven't been found
my %KEY_DATA_ERRORS	= (); # hash to contain data errors by Excel row (key information not found)

my $FONT_SIZE_HDR = 10;
my $FONT_SIZE_CELL = 10;
my $FONT_SIZE_NOTES = 12;
my $FONT_CELL = 'IBM Plex Sans';
my $ROW_HEIGHT_HDR = 24;
my $MASTER_MAX_COLS = 48;

my $IndexDelimit = '^';

my $iSqlErr				= 0;

# other variables --------------------------------------------------------
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
my $today = (1900 + $year) . sprintf("%02d",$mon + 1) . sprintf("%02d",$mday);
my $today2 = (1900 + $year) . "-" . sprintf("%02d",$mon + 1)  . "-" . sprintf("%02d",$mday)." ". sprintf("%02d",$hour) .":". sprintf("%02d",$min) .":". sprintf("%02d",$sec);
my $xlsxfilenm =  $main::SCRIPT_TAG . " " . $main::CUST_NAME . " Master System Inventory-v" . $main::SCRIPT_VER . "_" . $today . ".xlsx";

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

# -----------------------------------------------------------------------
# CHECK EXISTENCE AND LOAD LOOKUPS
# -----------------------------------------------------------------------
$sql = "SELECT id, wsibname, rscdname, env, component \n";
$sql .= "FROM `" . $main::IDB_NAME . "`.`sami`; \n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $lkey = $refr[1];
	$lkSAMI{$lkey}{id} = $refr[0]; # SAMI table index
	$lkSAMI{$lkey}{rscdname} = "";
	$lkSAMI{$lkey}{rscdname} =  $refr[2] if (defined($refr[2]));
	$lkSAMI{$lkey}{env} = "";
	$lkSAMI{$lkey}{env} =  $refr[3] if (defined($refr[3]));
	$lkSAMI{$lkey}{component} = "";
	$lkSAMI{$lkey}{component} =  $refr[4] if (defined($refr[4]));
	if ($lkSAMI{$lkey}{rscdname} ne "") {
		my $lkey2 = $lkSAMI{$lkey}{rscdname};
		$lkSAMIr{$lkey2}{id} = $lkSAMI{$lkey}{id};
		$lkSAMIr{$lkey2}{env} = $lkSAMI{$lkey}{env};
		$lkSAMIr{$lkey2}{component} = $lkSAMI{$lkey}{component};
		$lkSAMIr{$lkey2}{wsibname} = $lkey;
	}
}

$sql = "SELECT shortkey, notify, resolution \n";
$sql .= "FROM `" . $main::IDB_NAME . "`.`redflag`; \n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $lkey = $refr[0];
	$RedFlagTxt{$lkey}{notify} = defined($refr[1]) ? $refr[1] : 0;
	$RedFlagTxt{$lkey}{resolution} = defined($refr[2]) ? $refr[2] : 0;
} #$RedFlagTxt

## Set up the SQL SELECT statement to grab the data
$sql = "SELECT inv.id, dbm.manufacturer, dbm.dbtype, dbm.edition, dbm.version, d.patchlevel, dbm.latestrel  \n";
$sql .= "  FROM `" . $main::IDB_NAME . "`.`inventory` inv \n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`dbinst` d ON inv.id = d.inv_id \n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`dbms` dbm ON d.dbms_id = dbm.id; \n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $lkey = $refr[0];
	my $rdbms = "";
	$rdbms .= $refr[1] if (defined($refr[1]));
	$rdbms .= " " . $refr[2] if (defined($refr[2]));
	$rdbms .= " " . $refr[3] if (defined($refr[3]));
	$rdbms .= " " . $refr[4] if (defined($refr[4]));
	$rdbms =~ s/^oracle //i;
	$lkDBI{$lkey}{dbms} = $rdbms;
	$lkDBI{$lkey}{dbmspatchlevel} = (defined($refr[5]) ? $refr[5] : "");
	$lkDBI{$lkey}{dbmslatestrel} = (defined($refr[6]) ? $refr[6] : "");
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT vl.number, vl.name, vl.subnet, ls.code, lt.code\n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`vlan` vl\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` ls ON vl.location_id = ls.id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lt ON vl.tgt_location_id = lt.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlannum} = (defined($refr[0]) ? $refr[0] : "");
		$lkSUBNT{$lkey}{subnetdesc} = (defined($refr[1]) ? $refr[1] : "");
		$lkSUBNT{$lkey}{loc_code} = (defined($refr[3]) ? $refr[3] : "");
		$lkSUBNT{$lkey}{tgtloc_code} = (defined($refr[4]) ? $refr[4] : "");
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc: " . $lkSUBNT{$lkey}{loc_code} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

my $SubClassifier = subnet_classifier @FSUBS;

if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT ip.id, INET_NTOA(ip.ipv4), ip.location_id, ip.inaddm, ip.inrvt, ip.inuse, ip.cloudscapeasset, ip.cloudscapescan, vl.id, vl.number, ip.active, ip.loadbal, lo.code \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`ipadd` ip\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON ip.location_id = lo.id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vl ON ip.vlan_id = vl.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ip_id = $refr[0];
		my $fip = $refr[1];
		if (!exists($lkGIP{$fip})) {
			$lkGIP{$fip}{id} = $ip_id;
			$lkGIP{$fip}{location_id} = defined($refr[2]) ? $refr[2] : "";
			$lkGIP{$fip}{inaddm} = defined($refr[3]) ? $refr[3] : 0;
			$lkGIP{$fip}{inrvt} = defined($refr[4]) ? $refr[4] : 0;
			$lkGIP{$fip}{inuse} = defined($refr[5]) ? $refr[5] : 0;
			$lkGIP{$fip}{csasset} = defined($refr[6]) ? $refr[6] : 0;
			$lkGIP{$fip}{csscan} = defined($refr[7]) ? $refr[7] : 0;
			$lkGIP{$fip}{vlan_id} = defined($refr[8]) ? $refr[8] : "";
			$lkGIP{$fip}{vlannum} = defined($refr[9]) ? $refr[9] : "";
			$lkGIP{$fip}{active} = defined($refr[10]) ? $refr[10] : 0;
			$lkGIP{$fip}{loadbal} = defined($refr[11]) ? $refr[11] : 0;
			$lkGIP{$fip}{location_code} = defined($refr[12]) ? $refr[12] : "";
			$lkGIP{$fip}{assigned} = 0; ## assigned to server
			print "******* LKU GIP: fip=" . $fip . " FLAGS - Addm:" . $lkGIP{$fip}{inaddm} . " - Rvt:" . $lkGIP{$fip}{inrvt} . " - CSast:" . $lkGIP{$fip}{csasset} . " - CSscan:" . $lkGIP{$fip}{csscan} . "\n" if ($DEBUGSQL); # debug sql
		}
		$lkGIPk{$ip_id}{ipv4} = $fip; # look up by key
	}
}

# ADDM / ADDMSW table subnet lookups
if ((grep { /addm/ } @dbTables) == 0) {
	print "Table: addm not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT a.name, sw.product\n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`addm` a\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`addmsw` sw ON a.admos_id = sw.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $wsibname = defined($refr[0]) ? lc($refr[0]) : "";
		$lkADMOS{$wsibname}{osname} = (defined($refr[1]) ? $refr[1] : "") if ($wsibname ne "");
		print "******* LKU ADMOS: name: " . $wsibname . " osname: " . $lkADMOS{$wsibname}{osname} . "\n" if ($DEBUGSQL); # debug sql
	}
}

###############################################################################################
### BUILD ACCUMULATOR AND OUTPUT HASHES
###############################################################################################
#### Wave Planner DB Hash
$sql = "SELECT ev.wavesequence, ev.nonprod_cutover, ev.cutover, ev.contingency_cutover, ev.name, ev.description, ls.code, ls.name, lt.code, lt.name\n";
$sql .= "FROM `" . $main::IDB_NAME . "`.`event` ev\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` ls ON ev.location_id = ls.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lt ON ev.tgtlocation_id = lt.id\n";
$sql .= "  ORDER BY ev.wavesequence;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $wseq = sprintf("%03d",$refr[0]) if ($refr[0] ne ""); # waveseq -- the hash index
	$WaveDB{$wseq}{nonprod_cutover} 		= (defined($refr[1])) ? $refr[1] : "";
	$WaveDB{$wseq}{cutover} 				= (defined($refr[2])) ? $refr[2] : "";
	$WaveDB{$wseq}{contingency_cutover}		= (defined($refr[3])) ? $refr[3] : ""; ## 5/14/20 -- added per Nancy Salyer request
	$WaveDB{$wseq}{eventname} 				= (defined($refr[4])) ? $refr[4] : "";
	$WaveDB{$wseq}{eventdesc} 				= (defined($refr[5])) ? $refr[5] : "";
	$WaveDB{$wseq}{srccode} 				= (defined($refr[6])) ? $refr[6] : "";
	$WaveDB{$wseq}{srcname} 				= (defined($refr[7])) ? $refr[7] : "";
	$WaveDB{$wseq}{tgtcode} 				= (defined($refr[8])) ? $refr[8] : "";
	$WaveDB{$wseq}{tgtname} 				= (defined($refr[9])) ? $refr[9] : "";
	## the rest of these are calculated from the actual data, not from the database
	$WaveDB{$wseq}{drprimary} 				= 0; # counter
	$WaveDB{$wseq}{drfailover} 				= 0; # counter
	$WaveDB{$wseq}{windows} 				= 0; # counter
	$WaveDB{$wseq}{linux} 					= 0; # counter
	$WaveDB{$wseq}{aix} 					= 0; # counter
	$WaveDB{$wseq}{solaris}					= 0; # counter
	$WaveDB{$wseq}{other}					= 0; # counter
	$WaveDB{$wseq}{subnets}					= 0; # counter
	$WaveDB{$wseq}{production}				= 0; # counter
	$WaveDB{$wseq}{nonprod}					= 0; # counter
	$WaveDB{$wseq}{vmsizegb}				= 0; # accumulator
	$WaveDB{$wseq}{vlans}					= "";
	$WaveDB{$wseq}{environments}			= "";
	$WaveDB{$wseq}{applications}			= "";
	$WaveDB{$wseq}{connected_subnets}		= ""; ## 5/19/20 add code to show connected subnets on the WAVES worksheet
	@ { $WaveDB{$wseq}{vidx} }				= (); # array to store all of the network keys
}

#### Network planner DB hash
## 4/9/20 - Request from Nancy to show ALL VLANs from the VLAN sheet on this report
## First build the hash with a simple query
$sql = "SELECT vl.location_id, vl.number, vl.name, vl.subnet, vl.zone, vl.env1, vl.env2, lo.code, lo.name \n";
$sql .= "  FROM `i_wsib`.`vlan` vl\n";
$sql .= "    LEFT JOIN `i_wsib`.`location` lo ON vl.location_id = lo.id;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $vidx = $refr[0] . $IndexDelimit . sprintf("%05d",$refr[1]);
	$NetworkDB{$vidx}{vlannum} 					= (defined($refr[1])) ? $refr[1] : "";
	$NetworkDB{$vidx}{vlanname} 				= (defined($refr[2])) ? $refr[2] : "";
	$NetworkDB{$vidx}{subnet} 					= (defined($refr[3])) ? $refr[3] : "";
	$NetworkDB{$vidx}{zone} 					= (defined($refr[4])) ? $refr[4] : "";
	$NetworkDB{$vidx}{env1} 					= (defined($refr[5])) ? $refr[5] : "";
	$NetworkDB{$vidx}{env2} 					= (defined($refr[6])) ? $refr[6] : "";
	$NetworkDB{$vidx}{srccode} 					= (defined($refr[7])) ? $refr[7] : "";
	$NetworkDB{$vidx}{srcname} 					= (defined($refr[8])) ? $refr[8] : "";

	## the rest of these are calculated from the actual data, not from the database
	## these are initializations
	$NetworkDB{$vidx}{inuse} 					= 0;
	$NetworkDB{$vidx}{vips} 					= 0;
	$NetworkDB{$vidx}{pools} 					= 0;
	$NetworkDB{$vidx}{events} 					= ""; # this will list all events with this subnet in scope
	$NetworkDB{$vidx}{windows} 					= 0;
	$NetworkDB{$vidx}{linux}		 			= 0;
	$NetworkDB{$vidx}{aix} 						= 0;
	$NetworkDB{$vidx}{solaris} 					= 0;
	$NetworkDB{$vidx}{other} 					= 0;
	$NetworkDB{$vidx}{assigned}					= 0;
	$NetworkDB{$vidx}{redflags} 				= 0;
	$NetworkDB{$vidx}{stayback} 				= 0;
	$NetworkDB{$vidx}{orphaned} 				= 0;
	$NetworkDB{$vidx}{production} 				= 0;
	$NetworkDB{$vidx}{nonprod} 					= 0;
	$NetworkDB{$vidx}{vmsizegb}					= 0;
}

## Now tally inuse IPs per VLAN (in scope)
foreach my $fip (keys %lkGIP) {
	if ($lkGIP{$fip}{vlan_id} ne "" && looks_like_number($lkGIP{$fip}{location_id}) && looks_like_number($lkGIP{$fip}{vlannum})) {
		my $vidx = $lkGIP{$fip}{location_id} . $IndexDelimit . sprintf("%05d",$lkGIP{$fip}{vlannum});
		$NetworkDB{$vidx}{inuse} += 1 if (exists($NetworkDB{$vidx}) && $lkGIP{$fip}{inuse} == 1);
	}
}

#### Storage Totals hash - for the Master tab only
## SAN storage totals
$sql = "SELECT inv_id, disksizegb \n";
$sql .= "  FROM `i_wsib`.`sanspecs` WHERE inv_id IS NOT NULL;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $assetID = $refr[0];
	my $diskSize = 0;
	$diskSize = $refr[1] if (defined($refr[1]));
	if (exists($SANTotals{$assetID})) {
		$SANTotals{$assetID}{disksize} += $diskSize;
	} else {
		$SANTotals{$assetID}{disksize} = $diskSize;
	}
}

## NAS storage totals
$sql = "SELECT x.inv_id, n.usedcapgb \n";
$sql .= "  FROM `i_wsib`.`nasmap` x\n";
$sql .= "  LEFT JOIN `i_wsib`.`nasspecs` n ON x.nas_id = n.id;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $assetID = $refr[0];
	my $diskSize = 0;
	$diskSize = $refr[1] if (defined($refr[1]));
	if (exists($NASTotals{$assetID})) {
		$NASTotals{$assetID}{disksize} += $diskSize;
	} else {
		$NASTotals{$assetID}{disksize} = $diskSize;
	}
}

#### Master DB Hash
$sql = "SELECT inv.excel_row,\n";
$sql .= "  inv.category,\n"; #1
$sql .= "  ls.code,\n";
$sql .= "  lt.code,\n";
$sql .= "  inv.ipcell,\n";
$sql .= "  ip.loadbal,\n";
$sql .= "  vl.number,\n";
$sql .= "  vl.name,\n";
$sql .= "  vl.subnet,\n";
$sql .= "  inv.wsibname,\n";
$sql .= "  inv.rscdname,\n"; #10
$sql .= "  op.fqdn,\n";
$sql .= "  vc.name,\n";
$sql .= "  rv.powerstate,\n";
$sql .= "  op.id,\n";
$sql .= "  ip.cloudscapescan,\n";
$sql .= "  inv.disasterrecovery,\n";
$sql .= "  inv.primaryfunction,\n";
$sql .= "  inv.serialnum,\n";
$sql .= "  ev.wavesequence,\n";
$sql .= "  ev.cutover,\n"; #20
$sql .= "  ev.name,\n";
$sql .= "  ev.description,\n";
# remove wavegroup and bundlename
$sql .= "  inv.discoverystatus,\n";
$sql .= "  inv.dispositioncode,\n";
$sql .= "  inv.ipdispositioncode,\n";
$sql .= "  pt.name,\n";
$sql .= "  inv.premigration,\n";
$sql .= "  inv.baselinedelta,\n";
$sql .= "  os.platform,\n";
$sql .= "  os.name,\n"; #30
$sql .= "  op.osplatform,\n";
$sql .= "  os.eol,\n";
$sql .= "  os.nminus2,\n";
$sql .= "  aps.stackname,\n";
$sql .= "  inv.notes,\n";
$sql .= "  inv.location_id,\n";
$sql .= "  inv.id,\n";
$sql .= "  ip.id,\n";
$sql .= "  inv.sami_id,\n";
$sql .= "  ip.cloudscapeasset,\n"; #40
$sql .= "  rv.ipadd_id,\n";
$sql .= "  ev.nonprod_cutover,\n";
$sql .= "  rv.inusemb,\n";
$sql .= "  inv.migrationstatus,\n";
$sql .= "  rv.ospertools,\n";
$sql .= "  rv.osperconfig,\n";
$sql .= "  rv.osplatform,\n";
$sql .= "  csa.servos,\n";
$sql .= "  csa.osver,\n";
$sql .= "  rv.disks,\n"; # 7/27/20 - vDisk info
$sql .= "  rv.raw,\n"; # 7/27/20 - vDisk info
$sql .= "  rv.thin,\n"; # 7/27/20 - vDisk info
$sql .= "  rv.clustername\n"; # 7/27/20 - RVTools cluster name
#$sql .= "  INET_NTOA(vip.ipv4)\n"; ## VIP
$sql .= "FROM `" . $main::IDB_NAME . "`.`inventory` inv\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` ls ON inv.location_id = ls.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lt ON inv.tgtlocation_id = lt.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON inv.ipadd_id = ip.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vl ON ip.vlan_id = vl.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`opsinv` op ON inv.opsinv_id = op.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`opsys` os ON op.os_id = os.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`rvt` rv ON inv.rvt_id = rv.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vcenter` vc ON rv.vcenter_id = vc.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`event` ev ON inv.event_id = ev.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`pattern` pt ON inv.pattern_id = pt.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`csasset` csa ON inv.csasset_id = csa.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`appstack` aps ON csa.appstack_id = aps.id\n";
$sql .= "  ORDER BY inv.excel_row;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $xlrow = $refr[0]; # excel row
	## Grab the database values and handle any null conditions
	$MasterDB{$xlrow}{category} 				= (defined($refr[1])) ? $refr[1] : "";
	$MasterDB{$xlrow}{srcloc} 					= (defined($refr[2])) ? $refr[2] : "";
	$MasterDB{$xlrow}{tgtloc} 					= (defined($refr[3])) ? $refr[3] : "";
	$MasterDB{$xlrow}{ipaddr} 					= (defined($refr[4])) ? $refr[4] : "";
	$MasterDB{$xlrow}{loadbalcode}				= (defined($refr[5])) ? $refr[5] : 0; ## now shows lb scope
	$MasterDB{$xlrow}{vlannum} 					= (defined($refr[6])) ? $refr[6] : "";
	$MasterDB{$xlrow}{subnetdesc} 				= (defined($refr[7])) ? $refr[7] : "";
	$MasterDB{$xlrow}{subnet} 					= (defined($refr[8])) ? $refr[8] : "";
	$MasterDB{$xlrow}{wsibname} 				= (defined($refr[9])) ? $refr[9] : "";
	$MasterDB{$xlrow}{rscdname} 				= (defined($refr[10])) ? $refr[10] : "";
	$MasterDB{$xlrow}{fqdn} 					= (defined($refr[11])) ? $refr[11] : "";
	$MasterDB{$xlrow}{vcenter} 					= (defined($refr[12])) ? $refr[12] : "";
	$MasterDB{$xlrow}{powerstate} 				= (defined($refr[13])) ? $refr[13] : "";
	$MasterDB{$xlrow}{opsstate} 				= (defined($refr[14])) ? $refr[14] : "";
	$MasterDB{$xlrow}{cloudscapescan} 			= (defined($refr[15])) ? $refr[15] : 0;
	$MasterDB{$xlrow}{drscope} 					= (defined($refr[16])) ? $refr[16] : $main::hashDRScope{none}; # new on 2/10/20
	$MasterDB{$xlrow}{primaryfunction} 			= (defined($refr[17])) ? $refr[17] : "";
	$MasterDB{$xlrow}{serialnum} 				= (defined($refr[18])) ? $refr[18] : "";
	$MasterDB{$xlrow}{waveseq} 					= (defined($refr[19])) ? $refr[19] : "";
	$MasterDB{$xlrow}{cutover} 					= (defined($refr[20])) ? $refr[20] : "";
	$MasterDB{$xlrow}{eventname} 				= (defined($refr[21])) ? $refr[21] : "";
	$MasterDB{$xlrow}{eventdesc} 				= (defined($refr[22])) ? $refr[22] : "";
	$MasterDB{$xlrow}{discoverystatuscode} 		= (defined($refr[23])) ? $refr[23] : "";
	$MasterDB{$xlrow}{sysdispositioncode} 		= (defined($refr[24])) ? $refr[24] : "";
	$MasterDB{$xlrow}{ipdisposition} 			= (defined($refr[25])) ? $refr[25] : "";
	$MasterDB{$xlrow}{pattern} 					= (defined($refr[26])) ? $refr[26] : "";
	$MasterDB{$xlrow}{premigration} 			= (defined($refr[27])) ? $refr[27] : "";
	$MasterDB{$xlrow}{baselinedelta} 			= (defined($refr[28])) ? $refr[28] : "";
	$MasterDB{$xlrow}{osplatform} 				= (defined($refr[29])) ? $refr[29] : "";
	$MasterDB{$xlrow}{osname} 					= (defined($refr[30])) ? $refr[30] : "";
	$MasterDB{$xlrow}{osarch} 					= (defined($refr[31])) ? $refr[31] : "";
	$MasterDB{$xlrow}{oseol} 					= (defined($refr[32])) ? $refr[32] : "";
	$MasterDB{$xlrow}{osnminus2} 				= (defined($refr[33])) ? $refr[33] : "";
	$MasterDB{$xlrow}{appstack} 				= (defined($refr[34])) ? $refr[34] : "";
	$MasterDB{$xlrow}{migrationnotes} 			= (defined($refr[35])) ? $refr[35] : "";
	$MasterDB{$xlrow}{location_id} 				= (defined($refr[36])) ? $refr[36] : "";
	$MasterDB{$xlrow}{inv_id} 					= (defined($refr[37])) ? $refr[37] : "";
	$MasterDB{$xlrow}{ipadd_id} 				= (defined($refr[38])) ? $refr[38] : "";
	$MasterDB{$xlrow}{sami_id} 					= (defined($refr[39])) ? $refr[39] : "";
	$MasterDB{$xlrow}{cloudscapeasset} 			= (defined($refr[40])) ? $refr[40] : "";
	$MasterDB{$xlrow}{rv_ipadd_id}				= (defined($refr[41])) ? $refr[41] : "";
	$MasterDB{$xlrow}{nonprod_cutover}			= (defined($refr[42])) ? $refr[42] : "";
	$MasterDB{$xlrow}{rvtinusemb}				= (defined($refr[43])) ? $refr[43] : "";
	$MasterDB{$xlrow}{migrationstatuscode} 		= (defined($refr[44])) ? $refr[44] : "";
	$MasterDB{$xlrow}{ospertools} 				= (defined($refr[45])) ? $refr[45] : "";
	$MasterDB{$xlrow}{osperconfig} 				= (defined($refr[46])) ? $refr[46] : "";
	$MasterDB{$xlrow}{rosarch}					= (defined($refr[47])) ? $refr[47] : "";
	$MasterDB{$xlrow}{csservos}					= (defined($refr[48])) ? $refr[48] : "";
	$MasterDB{$xlrow}{csosver} 					= (defined($refr[49])) ? $refr[49] : "";
	$MasterDB{$xlrow}{disks} 					= (defined($refr[50])) ? $refr[50] : "";
	$MasterDB{$xlrow}{raw} 						= (defined($refr[51])) ? $refr[51] : "";
	$MasterDB{$xlrow}{thin} 					= (defined($refr[52])) ? $refr[52] : "";
	$MasterDB{$xlrow}{vcluster} 				= (defined($refr[53])) ? $refr[53] : "";

	## initialize for later
	$MasterDB{$xlrow}{ipcount} = 0;
	$MasterDB{$xlrow}{assignedips} = "";

	## build the asset quick lookup hash table
	if ($MasterDB{$xlrow}{wsibname} ne "") {
		my $hostnm = trim($MasterDB{$xlrow}{wsibname});
		$lkINV{$hostnm}{excel_row} = $xlrow;
		$lkINV{$hostnm}{srcloc} = $MasterDB{$xlrow}{srcloc};
		$lkINV{$hostnm}{ipaddr} = $MasterDB{$xlrow}{ipaddr};
		$lkINV{$hostnm}{vlannum} = $MasterDB{$xlrow}{vlannum};
	}

	## VLAN number matchup if blank
	my $ip = $MasterDB{$xlrow}{ipaddr};

	if ($MasterDB{$xlrow}{vlannum} eq "" && $ip ne "" && is_ipv4($ip) ) {
		my $sn = $SubClassifier->($ip); # find the subnet in range quickly
		if (defined($sn)) {
			$MasterDB{$xlrow}{srcloc} = $lkSUBNT{$sn}{loc_code} if ($MasterDB{$xlrow}{srcloc} eq "");
			$MasterDB{$xlrow}{tgtloc} = $lkSUBNT{$sn}{tgtloc_code} if ($MasterDB{$xlrow}{tgtloc} eq "");
			$MasterDB{$xlrow}{vlannum} = $lkSUBNT{$sn}{vlannum} if ($MasterDB{$xlrow}{vlannum} eq "");
			$MasterDB{$xlrow}{subnet} = $sn if ($MasterDB{$xlrow}{subnet} eq "");
			$MasterDB{$xlrow}{subnetdesc} = $lkSUBNT{$sn}{subnetdesc} if ($MasterDB{$xlrow}{subnetdesc} eq "");
		}
	}

	## RVTools Primary IP Address
	$MasterDB{$xlrow}{rv_ipv4} = "";
	$MasterDB{$xlrow}{vdisk} = "";

	if ($MasterDB{$xlrow}{powerstate} ne "" && $MasterDB{$xlrow}{category} =~ m/vm/i) {
		$MasterDB{$xlrow}{rv_ipv4} = $lkGIPk{$MasterDB{$xlrow}{rv_ipadd_id}}{ipv4} if (($MasterDB{$xlrow}{rv_ipadd_id} ne "" && exists($lkGIPk{$MasterDB{$xlrow}{rv_ipadd_id}})));

		## RVTools vDisk Info
		$MasterDB{$xlrow}{vdisk} = $MasterDB{$xlrow}{disks} . " disk";
		$MasterDB{$xlrow}{vdisk} .=  "s" if ($MasterDB{$xlrow}{disks} != 1);
		$MasterDB{$xlrow}{vdisk} .= "; " . $MasterDB{$xlrow}{raw} . " raw" if ($MasterDB{$xlrow}{raw}); 
		if ($MasterDB{$xlrow}{raw} && $MasterDB{$xlrow}{thin}) {
			$MasterDB{$xlrow}{vdisk} .= ", " . $MasterDB{$xlrow}{thin} . " thin" if ($MasterDB{$xlrow}{thin}); 
		} elsif (!$MasterDB{$xlrow}{raw} && $MasterDB{$xlrow}{thin}) {
			$MasterDB{$xlrow}{vdisk} .= "; " . $MasterDB{$xlrow}{thin} . " thin" if ($MasterDB{$xlrow}{thin});  
		}
		$MasterDB{$xlrow}{powerstate} = $main::txtRVTPowerSt{$MasterDB{$xlrow}{powerstate}} if (looks_like_number($MasterDB{$xlrow}{powerstate}));
	} else {
		$MasterDB{$xlrow}{powerstate} = "Not Found" if ($MasterDB{$xlrow}{powerstate} eq "" && $MasterDB{$xlrow}{category} =~ m/vm/i); # if powerstate eq "" set to not found
	}
	
	## validation 4/2/20
	my $validation_text = "";
	#$validation_text .= "VLAN:" . ($MasterDB{$xlrow}{vlannum} eq "" ? "N" : "Y");
	$validation_text .= "  ADDM:" . ($MasterDB{$xlrow}{sami_id} eq "" ? "N" : "Y");
	$validation_text .= "  OPS:" . ($MasterDB{$xlrow}{opsstate} eq "" ? "N" : "Y");
	$validation_text .= "  RVT:" . ($MasterDB{$xlrow}{powerstate} eq "" ? "N" : "Y");
	$validation_text .= "  CSA:" . ($MasterDB{$xlrow}{cloudscapeasset} eq "" ? "N" : "Y");
	$validation_text .= "  SAMI:" . ($MasterDB{$xlrow}{sami_id} eq "" ? "N" : "Y");
	$MasterDB{$xlrow}{validation}	= $validation_text;

	## assign system disposition
	$MasterDB{$xlrow}{sysdisposition} = ($MasterDB{$xlrow}{sysdispositioncode} ne "" && looks_like_number($MasterDB{$xlrow}{sysdispositioncode})) ? $main::txtSYSDisposition{$MasterDB{$xlrow}{sysdispositioncode}} : "";

	## Accumulate for migration overview
	my $discovery_confirmed = 0;
	$discovery_confirmed = 1 if ($MasterDB{$xlrow}{discoverystatuscode} ne "" && $MasterDB{$xlrow}{discoverystatuscode} == $main::hashDiscoveryStatus{'confirmed'} && $MasterDB{$xlrow}{sysdispositioncode} ne "");

	my $asset_migrating = 0;
	$asset_migrating = 1 if ($MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'migrating'});

	my $migration_completed = 0;
	$migration_completed = 1 if ($MasterDB{$xlrow}{migrationstatuscode} ne "" && $MasterDB{$xlrow}{migrationstatuscode} == $main::hashMigrationStatus{completed});
	if ($MasterDB{$xlrow}{category} =~ m/vm/i) {
		my $akx = "";
		my $disptxt = "";
		$disptxt = $MasterDB{$xlrow}{sysdisposition};
		$akx = "Windows VM" if ($MasterDB{$xlrow}{osplatform} =~ m/windows/i);
		$akx = "Linux VM" if ($MasterDB{$xlrow}{osplatform} =~ m/linux/i);
		if ($akx ne "" && $disptxt ne "") {
			$MigrOvr{$akx}{$disptxt} = $MigrOvr{$akx}{$disptxt} + 1;
			$MigrOvr{'Total VM'}{$disptxt} = $MigrOvr{'Total VM'}{$disptxt} + 1;
			$MigrOvr{'Total'}{$disptxt} = $MigrOvr{'Total'}{$disptxt} + 1;

			if ($discovery_confirmed && $asset_migrating && $migration_completed) {
				$MigrOvr{$akx}{completed} = $MigrOvr{$akx}{completed} + 1;
				$MigrOvr{'Total VM'}{completed} = $MigrOvr{'Total VM'}{completed} + 1;
				$MigrOvr{'Total'}{completed} = $MigrOvr{'Total'}{completed} + 1;
			}
		}
	} else {
		my $akx = $MasterDB{$xlrow}{category};
		my $disptxt = "";
		$disptxt = $MasterDB{$xlrow}{sysdisposition};
		if ($akx ne "" && $disptxt ne "") {
			$MigrOvr{$akx}{$disptxt} = $MigrOvr{$akx}{$disptxt} + 1;
			$MigrOvr{'Total'}{$disptxt} = $MigrOvr{'Total'}{$disptxt} + 1;
			if ($discovery_confirmed && $asset_migrating && $migration_completed) {
				$MigrOvr{$akx}{completed} = $MigrOvr{$akx}{completed} + 1;
				$MigrOvr{'Total'}{completed} = $MigrOvr{'Total'}{completed} + 1;
			}
		}
	}

	## Now, replace any codes with values
	$MasterDB{$xlrow}{loadbal} = "";

	## Discovery Status Code => Text
	if ($MasterDB{$xlrow}{discoverystatuscode} ne "" && looks_like_number($MasterDB{$xlrow}{discoverystatuscode})) {
		$MasterDB{$xlrow}{discoverystatus} = $main::txtDiscoveryStatus{$MasterDB{$xlrow}{discoverystatuscode}};
	}

	## Migration Status Code => Text
	if ($MasterDB{$xlrow}{migrationstatuscode} eq "") {
		$MasterDB{$xlrow}{migrationstatus} = "";
	} elsif (looks_like_number($MasterDB{$xlrow}{migrationstatuscode})) {
		if ($MasterDB{$xlrow}{migrationstatuscode} == $main::hashMigrationStatus{notstarted}) {
			$MasterDB{$xlrow}{migrationstatus} = "";
		}	else {
			$MasterDB{$xlrow}{migrationstatus} = $main::txtMigrationStatus{$MasterDB{$xlrow}{migrationstatuscode}};
		}
	}

	## Subnet description reformatting
	my $subnetdesc = $MasterDB{$xlrow}{subnetdesc};
	my $sn = $MasterDB{$xlrow}{subnet};
	$subnetdesc =~ s/\Q$sn//; # remove the subnet from the description
	$subnetdesc =~ s/^\/*\_*//; # remove slash underscores at the front
	$subnetdesc =~ s/^ *\-* *//; # remove dash at the front
	$subnetdesc =~ s/^ *\-* *//; # remove dash at the front
	$subnetdesc = trim($subnetdesc); # get rid of any whitespace
	$MasterDB{$xlrow}{subnetdesc} = $subnetdesc;

	## 2/20/20 - get this from the hostname
 	$MasterDB{$xlrow}{wsibenv} = "";
 	my $wsib_name = $MasterDB{$xlrow}{wsibname};
 	if (length($wsib_name) == 8) { ## follows WSIB naming convention
		my $c_env = lc(substr($wsib_name,0,1)); # environment
	 	$MasterDB{$xlrow}{wsibenv} = $main::hashWSIBEnv{$c_env} if (exists($main::hashWSIBEnv{$c_env}));
	}

	## if we haven't found the environment yet, try using the legacy WSIB naming convention
	if (length($wsib_name) == 9 && lc(substr($wsib_name,0,2)) eq "sr") { ## follows LEGACY WSIB naming convention
		my $c_env = lc(substr($wsib_name,6,1));
		if ($c_env eq "p") {
			$MasterDB{$xlrow}{wsibenv} = "PRD";
		} elsif ($c_env eq "d") {
			$MasterDB{$xlrow}{wsibenv} = "DEV";
		} elsif ($c_env eq "u") {
			$MasterDB{$xlrow}{wsibenv} = "UAT";
		} elsif ($c_env eq "t") {
			$MasterDB{$xlrow}{wsibenv} = "TEST";
		}
	}

	## if we still haven't found the environment, use the SAMI
	if ($MasterDB{$xlrow}{wsibenv} eq "" && exists($lkSAMI{$wsib_name})) { # do we have a legacy SAMI record?
		$MasterDB{$xlrow}{wsibenv} = $lkSAMI{$wsib_name}{env}; # get the env from the SAMI instead
	}
	## if still not found, try the rscdname
	if ($MasterDB{$xlrow}{wsibenv} eq "" &&
			$MasterDB{$xlrow}{rscdname} ne "" &&
			exists($lkSAMIr{$MasterDB{$xlrow}{rscdname}})) { # do we have a legacy SAMI record by rscdname?
			$MasterDB{$xlrow}{wsibenv} = $lkSAMIr{$MasterDB{$xlrow}{rscdname}}{env}; # get the env from the SAMI instead
	}

	$MasterDB{$xlrow}{ipdisposition} = $main::txtIPDisposition{$MasterDB{$xlrow}{ipdisposition}} if ($MasterDB{$xlrow}{ipdisposition} ne "" && looks_like_number($MasterDB{$xlrow}{ipdisposition}));
	$MasterDB{$xlrow}{osnminus2} = ($MasterDB{$xlrow}{osnminus2} ne "" && $MasterDB{$xlrow}{osnminus2} == 1) ? "Yes" : "";
	$MasterDB{$xlrow}{drscope} = ($MasterDB{$xlrow}{drscope} == $main::hashDRScope{none}) ? "" : $main::txtDRScope{$MasterDB{$xlrow}{drscope}}; # 2/10/20 -- New Code for DR Scope

	## storage totals for this asset
	$MasterDB{$xlrow}{santotal} = "";
	$MasterDB{$xlrow}{nastotal} = "";

	## calculate vm size in GB
	my $vmsize = (looks_like_number($MasterDB{$xlrow}{rvtinusemb})) ? $MasterDB{$xlrow}{rvtinusemb} : 0;
	$vmsize = $vmsize / 1024; # convert MB to GB
	$vmsize = int($vmsize * 100 + 0.5) / 100; ## round up to nearest hundredth
	$MasterDB{$xlrow}{vmsizegb} = $vmsize > 0 ? $vmsize : "";

	my $assetID = $MasterDB{$xlrow}{inv_id};
	$MasterDB{$xlrow}{dbms} = "";
	$MasterDB{$xlrow}{dbmspatchlevel} = "";
	if ($assetID ne "") {
		$MasterDB{$xlrow}{santotal} = num_commify($SANTotals{$assetID}{disksize}) if (looks_like_number($SANTotals{$assetID}{disksize}) && $SANTotals{$assetID}{disksize} > 0);
		$MasterDB{$xlrow}{nastotal} = num_commify($NASTotals{$assetID}{disksize}) if (looks_like_number($NASTotals{$assetID}{disksize}) && $NASTotals{$assetID}{disksize} > 0);

		## database information
		if (exists($lkDBI{$assetID})) {
			$MasterDB{$xlrow}{dbms} = $lkDBI{$assetID}{dbms};
			$MasterDB{$xlrow}{dbmspatchlevel} = $lkDBI{$assetID}{dbmspatchlevel};
			$MasterDB{$xlrow}{dbmslatestrel} = $lkDBI{$assetID}{dbmslatestrel};
		}
	}

	## 8/6/20 - Fix red flag if RDS Solution
	## This is the criteria for counting red flags
	my $redflag = 0;
	$redflag = 1 if (!$asset_migrating && !$discovery_confirmed); # if we are NOT migrating and discovery isn't confirmed
	$redflag = 1 if ($MasterDB{$xlrow}{pattern} =~ m/rds solution/i && !$discovery_confirmed); # if we are NOT migrating and discovery isn't confirmed
	$TotalRedFlags += $redflag; ## add 1 to total if this is a red flag

	## this is the counter for stay back
	my $stayback = ($MasterDB{$xlrow}{pattern} =~ m/stay back/i);

	## Fill in blank information about the OS if needed
	if ($MasterDB{$xlrow}{osname} eq "") {
		if ($MasterDB{$xlrow}{wsibname} ne "" && exists($lkADMOS{$MasterDB{$xlrow}{wsibname}})) { # check ADDM for the osname
			$MasterDB{$xlrow}{osname} = $lkADMOS{$MasterDB{$xlrow}{wsibname}}{osname};
		}
		if ($MasterDB{$xlrow}{osname} eq "") { # check RVTools
			$MasterDB{$xlrow}{osname} = $MasterDB{$xlrow}{ospertools} if ($MasterDB{$xlrow}{ospertools} ne "");
			$MasterDB{$xlrow}{osname} = $MasterDB{$xlrow}{osperconfig} if ($MasterDB{$xlrow}{osname} eq "" && $MasterDB{$xlrow}{osperconfig} ne "");
			if ($MasterDB{$xlrow}{osname} ne "") { # found something in RVTools
				if ($MasterDB{$xlrow}{osarch} eq "" && $MasterDB{$xlrow}{osname} ne "") {
					$MasterDB{$xlrow}{osarch} = $MasterDB{$xlrow}{rosarch};
				}
				$MasterDB{$xlrow}{osname} =~ s/\(\d\d\-bit\)//i;
				$MasterDB{$xlrow}{osname} = trim($MasterDB{$xlrow}{osname});
			}
		}
		if ($MasterDB{$xlrow}{osname} eq "") { # not found in ADDM or RVTools, let's check Cloudscape as a last resort
			## Use what was found in Cloudscape if it wasn't found in RVTools
			$MasterDB{$xlrow}{osname} = $MasterDB{$xlrow}{csosver} if ($MasterDB{$xlrow}{osname} eq "" && $MasterDB{$xlrow}{csosver} ne "");
		}
		if ($MasterDB{$xlrow}{osplatform} eq "") {
			if ($MasterDB{$xlrow}{osname} =~ m/windows +server/i) {
				$MasterDB{$xlrow}{osplatform} = "Windows";
			} elsif ($MasterDB{$xlrow}{osname} =~ m/red hat/i && $MasterDB{$xlrow}{osname} =~ m/linux/i) {
				$MasterDB{$xlrow}{osplatform} = "Linux";
			} elsif ($MasterDB{$xlrow}{osname} ne "" && !($MasterDB{$xlrow}{osname} =~ m/not collected/i)) {
				$MasterDB{$xlrow}{osplatform} = "Unsupported";
			} else {
				$MasterDB{$xlrow}{osname} = "Not Found in any Data Source";
				$MasterDB{$xlrow}{osplatform} = "Unknown";
			}
		}
	}

	## cutover_target
	## figure out vidx (vlan index) for use in network calculations
	my $vidx = "";
	if ($MasterDB{$xlrow}{location_id} ne "" && $MasterDB{$xlrow}{vlannum} ne "") {
		$vidx = $MasterDB{$xlrow}{location_id} . $IndexDelimit . sprintf("%05d",$MasterDB{$xlrow}{vlannum});
		$vidx = "" if ( !exists($NetworkDB{$vidx}) ); # non-existent network index
	}
	$MasterDB{$xlrow}{vidx} = $vidx;

	## Network processing
	if ($vidx ne "") {
		$NetworkDB{$vidx}{inscope} = 1; ## in scope for this report
		$NetworkDB{$vidx}{redflags} += 1 if ($redflag);
		$NetworkDB{$vidx}{stayback} += 1 if ($stayback);

		if ($asset_migrating) {
			my $enm = $MasterDB{$xlrow}{eventname};
			if ($enm ne "") {
				$NetworkDB{$vidx}{events} = $NetworkDB{$vidx}{events} . $enm . ";" if (!($NetworkDB{$vidx}{events} =~ m/\Q$enm/i));
			}
			my $osplat = lc($MasterDB{$xlrow}{osplatform});
			if ($osplat eq "windows") {
				$NetworkDB{$vidx}{windows} = $NetworkDB{$vidx}{windows} + 1;
			} elsif ($osplat eq "linux") {
				$NetworkDB{$vidx}{linux} = $NetworkDB{$vidx}{linux} + 1;
			} elsif ($osplat eq "aix") {
				$NetworkDB{$vidx}{aix} = $NetworkDB{$vidx}{aix} + 1;
			} elsif ($osplat eq "solaris") {
				$NetworkDB{$vidx}{solaris} = $NetworkDB{$vidx}{solaris} + 1;
			} else {
				$NetworkDB{$vidx}{other}	= $NetworkDB{$vidx}{other} + 1;
			}
			my $wx = trim($MasterDB{$xlrow}{wsibenv});
			$wx =~ s/\r\n//g; # get rid of carriage return line feeds
			if ($wx eq "" || $wx =~ m/prd/i) {
				$NetworkDB{$vidx}{production}	+= 1;
			} else {
				$NetworkDB{$vidx}{nonprod}	+= 1;
			}
			## calculate total vm size per subnet
			if (looks_like_number($MasterDB{$xlrow}{vmsizegb})) {
				$NetworkDB{$vidx}{vmsizegb} += $MasterDB{$xlrow}{vmsizegb};
			}
		} # if $asset_migrating
	} #if ($MasterDB{$xlrow}{vidx} ne "") {

	## Now do the wave summary processing for that row
	my $wseq = "";
	$wseq = sprintf("%03d",$MasterDB{$xlrow}{waveseq}) if ($MasterDB{$xlrow}{waveseq} ne "");
	if ($wseq ne "" && exists($WaveDB{$wseq})) {
		if ($asset_migrating) {
			my $osplat = lc($MasterDB{$xlrow}{osplatform});
			if ($osplat eq "windows") {
				$WaveDB{$wseq}{windows} = $WaveDB{$wseq}{windows} + 1;
			} elsif ($osplat eq "linux") {
				$WaveDB{$wseq}{linux} = $WaveDB{$wseq}{linux} + 1;
			} elsif ($osplat eq "aix") {
				$WaveDB{$wseq}{aix} = $WaveDB{$wseq}{aix} + 1;
			} elsif ($osplat eq "solaris") {
				$WaveDB{$wseq}{solaris} = $WaveDB{$wseq}{solaris} + 1;
			} else {
				$WaveDB{$wseq}{other}	= $WaveDB{$wseq}{other} + 1;
			}
			$WaveDB{$wseq}{drprimary}		= $WaveDB{$wseq}{drprimary} + 1 if ($MasterDB{$xlrow}{drscope} =~ m/primary/i);
			$WaveDB{$wseq}{drfailover} 	= $WaveDB{$wseq}{drfailover} + 1 if ($MasterDB{$xlrow}{drscope} =~ m/failover/i);
			my $vlan = "";
			$vlan = sprintf("%05d",$MasterDB{$xlrow}{vlannum}) if ($MasterDB{$xlrow}{vlannum} ne "");
			if ($vlan ne "" && !($WaveDB{$wseq}{vlans} =~ m/\Q$vlan/i)) {
				$WaveDB{$wseq}{vlans} = $WaveDB{$wseq}{vlans} . $vlan . ";";
				$WaveDB{$wseq}{subnets} = $WaveDB{$wseq}{subnets} + 1;
				if ( $vidx ne "" && exists($NetworkDB{$vidx}) && ((grep { /$vidx/ } @ { $WaveDB{$wseq}{vidx} }) == 0) ) {
					push(@ { $WaveDB{$wseq}{vidx} },$vidx);
					$SubnetWave{$vidx}{wseq} = $wseq;
				}
			}
			## new processing of env on 2/22/20
			my $wx = trim($MasterDB{$xlrow}{wsibenv});
			$wx =~ s/\r\n//g; # get rid of carriage return line feeds
			if ($wx ne "" && !($WaveDB{$wseq}{environments} =~ m/\Q$wx/i)) {
				$WaveDB{$wseq}{environments} .= ", " if ($WaveDB{$wseq}{environments} ne "");
				$WaveDB{$wseq}{environments} .= $wx;
			}
			if ($wx eq "" || $wx =~ m/prd/i) {
				$WaveDB{$wseq}{production} += 1;
			} else {
				$WaveDB{$wseq}{nonprod} += 1;
			}
			## new processing of apps on 2/22/20
			$wx = trim($MasterDB{$xlrow}{appstack});
			$wx =~ s/\r\n//g; # get rid of carriage return line feeds
			if ($wx ne "" && !($WaveDB{$wseq}{applications} =~ m/\Q$wx/i)) {
				$WaveDB{$wseq}{applications} .= ", " if ($WaveDB{$wseq}{applications} ne "");
				$WaveDB{$wseq}{applications} .= $wx;
			}
			## calculate total vm size per wave
			if (looks_like_number($MasterDB{$xlrow}{vmsizegb})) {
				$WaveDB{$wseq}{vmsizegb} += $MasterDB{$xlrow}{vmsizegb};
			}
		}
	} # if $wseq

	$MasterRows++; # last one for that master row from the database
} # master row database processing while loop

## 4/15/20 - A query to build the assigned IP Addresses
## This section of the code connects IP addresses with servers in scope for migration (in inventory)
$sql = "SELECT inv.excel_row,\n";
$sql .= "  INET_NTOA(ip.ipv4),\n";
$sql .= "  lo.code,\n";
$sql .= "  vl.number,\n";
$sql .= "  lo.id,\n";
$sql .= "  ip.inuse,\n";
$sql .= "  ip.id,\n";
$sql .= "  ip.loadbal,\n";
$sql .= "  INET_NTOA(vip.ipv4),\n";
$sql .= "  vl.name,\n";
$sql .= "  ev.wavesequence\n";
$sql .= "  FROM `" . $main::IDB_NAME . "`.`inviprel` iix\n";
$sql .= "    LEFT JOIN `" . $main::IDB_NAME . "`.`inventory` inv ON iix.inv_id = inv.id\n";
$sql .= "    LEFT JOIN `" . $main::IDB_NAME . "`.`event` ev ON inv.event_id = ev.id\n";
$sql .= "    LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON iix.ipadd_id = ip.id\n";
$sql .= "    LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vl ON ip.vlan_id = vl.id\n";
$sql .= "    LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` vip ON ip.vs_ipadd_id = vip.id\n";
$sql .= "    LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON vl.location_id = lo.id;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $xlrow = $refr[0]; # excel row
	my $ipv4 = $refr[1]; # individual IP address
	my $loc = (defined($refr[2])) ? $refr[2] : ""; # individual Location Code
	my $vlnum = (defined($refr[3])) ? $refr[3] : ""; # individual VLAN number
	my $loc_id = (defined($refr[4])) ? $refr[4] : ""; # individual Location id
	my $inuse = (defined($refr[5])) ? $refr[5] : 0; # inuse flag
	my $ip_id = (defined($refr[6])) ? $refr[6] : ""; # ipadd id (key)
	my $loadbal = (defined($refr[7])) ? $refr[7] : 0; # loadbal status
	my $vipv4 = (defined($refr[8])) ? $refr[8] : ""; # vip ipv4
	my $vlname = (defined($refr[9])) ? $refr[9] : ""; # vlan name / subnet desc
	my $waveseq = (defined($refr[10])) ? $refr[10] : ""; # wave sequence number

	## Network Hash Index
	my $vidx = "";
	if ($loc_id ne "" && $vlnum ne "") {
		$vidx = $loc_id . $IndexDelimit . sprintf("%05d",$vlnum);
	}

	## IPs assigned with servers
	if (exists($MasterDB{$xlrow}) && $vidx ne "" && $inuse) {
		if ($ip_id ne "" && !exists($IPKEYS{$ip_id}) && $lkGIP{$ipv4}{loadbal} != $main::hashLBScope{vip}) {
			$NetworkDB{$vidx}{assigned} += 1; ## increment assigned counter
			$IPKEYS{$ip_id} = 1;
			$lkGIP{$ipv4}{assigned} += 1 if (exists($lkGIP{$ipv4}));
		}
		## checks for VIPs
		if ($vipv4 ne "" && exists($lkGIP{$vipv4}) && !($MasterDB{$xlrow}{loadbal} =~ m/$vipv4/)) {
			my $vlan_txt = "unknown";
			my $zloc = "";
			$zloc = $lkGIP{$vipv4}{location_code} if ($lkGIP{$vipv4}{location_code} ne "");
			my $vlnum = "";
			$vlnum = $lkGIP{$vipv4}{vlannum} if ($lkGIP{$vipv4}{vlannum} ne "");
			if ($zloc ne "" && $vlnum ne "") {
				$vlan_txt = $zloc . "#" . $vlnum;
			}
			$MasterDB{$xlrow}{loadbal} .= "\n" if ($MasterDB{$xlrow}{loadbal} ne "");
			$MasterDB{$xlrow}{loadbal} .= $vipv4 . " (" . $vlan_txt . ")";
		}
	}

	my $vlan_txt = "unknown";
	if ($loc ne "" && $vlnum ne "") {
		if ($ipv4 =~ m/^192.168./) {
			my $zloc = "PVT";
			$zloc = $MasterDB{$xlrow}{srcloc} if ($MasterDB{$xlrow}{srcloc} ne "");
			$vlan_txt = $zloc . "#" . $vlnum;
		} else {
			$vlan_txt = $loc . "#" . $vlnum;
		}
 	}

	my $classtxt = "";
	$classtxt = $main::txtLBScope{$loadbal} . ": " if ($loadbal != 0);
	$classtxt = "HNAS: " if ($classtxt eq "" && $vlname =~ m/_hnas/i);

	if (exists($MasterDB{$xlrow}) && defined($MasterDB{$xlrow}{assignedips})) {
		$MasterDB{$xlrow}{assignedips} .= "\n" if ($MasterDB{$xlrow}{assignedips} ne "");
		$MasterDB{$xlrow}{assignedips} .= $classtxt . $ipv4 . " (" . $vlan_txt . ")";
		$MasterDB{$xlrow}{ipcount} += 1 if ($inuse); ## add 1 to the IP counter
	} else {
		$MasterDB{$xlrow}{assignedips} = $classtxt . $ipv4 . " (" . $vlan_txt . ")";
		$MasterDB{$xlrow}{ipcount} = 1 if ($inuse);
	}
	my $wseq = "";
	$wseq = sprintf("%03d",$waveseq) if ($waveseq ne ""); # waveseq -- the hash index
	if ($vlan_txt ne "unknown" && $wseq ne "" && exists($WaveDB{$wseq}) && !($WaveDB{$wseq}{connected_subnets} =~ m/$vlan_txt/)) {
		$WaveDB{$wseq}{connected_subnets} .= "; " if ($WaveDB{$wseq}{connected_subnets} ne "");
		$WaveDB{$wseq}{connected_subnets} .= $vlan_txt;
	}
}

## Now tally categories of IPs per VLAN (in scope)
foreach my $fip (keys %lkGIP) {
	if ($lkGIP{$fip}{vlan_id} ne "" && looks_like_number($lkGIP{$fip}{location_id}) && looks_like_number($lkGIP{$fip}{vlannum})) {
		my $vidx = $lkGIP{$fip}{location_id} . $IndexDelimit . sprintf("%05d",$lkGIP{$fip}{vlannum});

		if (exists($NetworkDB{$vidx})) {
			if ($lkGIP{$fip}{inuse} && !exists($IPKEYS{$lkGIP{$fip}{id}}) && $lkGIP{$fip}{loadbal} == $main::hashLBScope{vip}) { # don't double-count VIPs
				$NetworkDB{$vidx}{vips} += 1;
				$IPKEYS{$lkGIP{$fip}{id}} = 1;
			}
			## if the IP isn't assigned to a server, then it's possibly an orphan
			$NetworkDB{$vidx}{orphaned} += 1 if ($lkGIP{$fip}{inuse} && !$lkGIP{$fip}{assigned} && $lkGIP{$fip}{loadbal} != $main::hashLBScope{vip}); # orphaned
			$NetworkDB{$vidx}{pools} += 1 if ($lkGIP{$fip}{inuse} && $lkGIP{$fip}{loadbal} == $main::hashLBScope{pool}); # tally pools
		}
	}
}

## fill in the remaining blanks by row
foreach my $xlrow (keys %MasterDB) {
	$MasterDB{$xlrow}{assignedips} = "None" if ($MasterDB{$xlrow}{ipcount} == 0);
	my $cutover = "";
	if ($MasterDB{$xlrow}{waveseq} ne "") {
		my $wseq = sprintf("%03d",$MasterDB{$xlrow}{waveseq});
		if ($WaveDB{$wseq}{production} == 0) {
			$cutover = $WaveDB{$wseq}{nonprod_cutover};
		} else {
			$cutover = $WaveDB{$wseq}{cutover};
		}
	}
	$MasterDB{$xlrow}{cutover_target} = $cutover;

	## 6/22/20 - Figure out the targetedevent
	$MasterDB{$xlrow}{targetedevent} = "None";
	my $vidx = $MasterDB{$xlrow}{vidx};
	if ($vidx ne "" && exists($SubnetWave{$vidx})) {
		my $wnum = sprintf('%d',$SubnetWave{$vidx}{wseq});
		$MasterDB{$xlrow}{targetedevent} =  '#' . $wnum . ' - ' . $WaveDB{$SubnetWave{$vidx}{wseq}}{eventname} if ($SubnetWave{$vidx}{wseq} ne "");
	}
}

########################################################################################################################################
# CREATE WORKBOOK --------------------------------------------------
########################################################################################################################################
my $workbookout = Excel::Writer::XLSX->new($xlsxfilenm);
die "Problems creating new Excel file: $!" unless defined $workbookout;

$workbookout->set_properties(
	title    	=> 'IBM Master Server Inventory',
	subject  	=> 'IBM Master Server Inventory',
	author   	=> 'Joseph Blaty',
	company   	=> 'IBM Corporation',
	comments 	=> 'Created by merging data from external trusted sources.',
);

# custom formats and colors ----------------------------------------------
# set_custom_color($index, $red, $green, $blue) --------------------------
my $greenbar = $workbookout->set_custom_color(54, 228, 255, 223); # Green bar color

my $brightblue = $workbookout->set_custom_color(40, 0, 112, 192); # Bright Blue Header Color

my $wavepurple = $workbookout->set_custom_color(41, 204, 192, 218); # Purple Wave Color

my $osorange = $workbookout->set_custom_color(42, 252, 213, 180); # Orange OS Color

my $appskyblue = $workbookout->set_custom_color(43, 183, 222, 232); # Sky Blue App Color

my $purplerain = $workbookout->set_custom_color(44, 112, 48, 160); # Purple Cell color in honor of Prince

my $darkgreen = $workbookout->set_custom_color(45, 0, 72, 34); # Dark Green Cell color

my $ferrarired= $workbookout->set_custom_color(46, 216, 12, 12); # Ferrari Rich Red Cell color

my $darkred = $workbookout->set_custom_color(47, 95, 0, 0); # Dark Red Cell color

my $title_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'center',
	valign => 'bottom' );

my $title_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'left',
	valign => 'bottom' );

my $title_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $brightblue,
	align => 'right',
	valign => 'bottom' );

my $wave_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $wavepurple,
		align => 'center',
		valign => 'bottom' );

my $wave_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $wavepurple,
		align => 'left',
		valign => 'bottom' );

my $os_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $osorange,
		align => 'center',
		valign => 'bottom' );

my $os_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $osorange,
		align => 'left',
		valign => 'bottom' );

my $app_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $appskyblue,
		align => 'center',
		valign => 'bottom' );

my $app_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'black',
		bg_color => $appskyblue,
		align => 'left',
		valign => 'bottom' );

my $red_title_fmt	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'white',
		bg_color => $ferrarired,
		align => 'center',
		valign => 'bottom' );

my $red_title_fmt_lf	= $workbookout->add_format(
		font=> $FONT_CELL,
		size=> $FONT_SIZE_HDR,
		bold => 1,
		border=> 1,
			color => 'white',
		bg_color => $ferrarired,
		align => 'left',
		valign => 'bottom' );

my $notes_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_NOTES,
	bold => 1,
	border=> 1,
		color => 'red',
	align => 'left',
	text_wrap=> 1,
	valign => 'bottom' );

my $row_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	bold => 1,
	border=> 1,
	align => 'center',
	valign => 'bottom' );

my $cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	align => 'right',
	valign => 'bottom' );

my $cell_fmt_lbl	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	bold => 1,
	border=> 1,
	align => 'right',
	valign => 'bottom' );

my $cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $cell_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	text_wrap=> 1,
	align => 'right',
	valign => 'bottom' );

my $gn_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	align => 'right',
	valign => 'bottom' );

my $gn_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $gn_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => $greenbar,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $totals_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	bold => 1,
	border=> 1,
	color => 'white',
	bg_color => 'grey',
	align => 'right',
	valign => 'bottom' );

my $totals_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	border=> 1,
	bold => 1,
	color => 'white',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $totals_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> ($FONT_SIZE_CELL + 2),
	bold => 1,
	border=> 1,
	color => 'white',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $ye_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	align => 'right',
	valign => 'bottom' );

my $ye_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $ye_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'yellow',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $re_cell_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	align => 'right',
	valign => 'bottom' );

my $re_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $re_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	bg_color => 'red',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $grey_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'yellow',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $grey_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'yellow',
	bg_color => 'grey',
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $purple_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $purplerain,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $purple_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $purplerain,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $dkgn_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $darkgreen,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $dkgn_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $darkgreen,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $dkgn_cell_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $darkgreen,
	text_wrap=> 1,
	align => 'right',
	valign => 'bottom' );

my $dkred_cell_fmt_ct	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $darkred,
	text_wrap=> 1,
	align => 'center',
	valign => 'bottom' );

my $dkred_cell_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_CELL,
	border=> 1,
	color => 'white',
	bg_color => $darkred,
	text_wrap=> 1,
	align => 'left',
	valign => 'bottom' );

my $dkgn_title_fmt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $darkgreen,
	align => 'center',
	valign => 'bottom' );

my $dkgn_title_fmt_lf	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $darkgreen,
	align => 'left',
	valign => 'bottom' );

my $dkgn_title_fmt_rt	= $workbookout->add_format(
	font=> $FONT_CELL,
	size=> $FONT_SIZE_HDR,
	bold => 1,
	border=> 1,
		color => 'white',
	bg_color => $darkgreen,
	align => 'right',
	valign => 'bottom' );
### END OF EXCEL formats

########################################################################################################################################
## Create the INFO worksheet (first section)
########################################################################################################################################
my $info_ws 	= $workbookout->add_worksheet('Info');
$info_ws->set_tab_color( 'gray' );

# Set column widths -------------------------------------------------------
$info_ws	->set_column(0, 0, 46); 	# Column A width
$info_ws	->set_column(1, 1, 36); 	# Column B width
$info_ws	->set_column(2, 2, 36); 	# Column C width
$info_ws	->set_column(3, 3, 22); 	# Column D width
$info_ws	->set_column(4, 4, 22); 	# Column E width

# Spreadsheet Title Row --------------------------------------------------
$info_ws	->merge_range($outInfoRows,0,$outInfoRows,4, 'Master System Inventory', $title_fmt); # merge cells on the title row
$info_ws	->set_row($outInfoRows, $ROW_HEIGHT_HDR); # Set row height
$outInfoRows++;
$outExcelRows++;
$info_ws 	->write($outInfoRows, 0, 'Workbook Name:', $cell_fmt_lbl);
$info_ws	->merge_range($outInfoRows,1,$outInfoRows,4, $xlsxfilenm , $cell_fmt_lf); # merge cells on the data cells
$outInfoRows++;
$outExcelRows++;
$info_ws 	->write($outInfoRows, 0, 'Created on:', $cell_fmt_lbl);
$info_ws	->merge_range($outInfoRows,1,$outInfoRows,4, $today2 , $cell_fmt_lf); # merge cells on the data cells
$outInfoRows++;
$outExcelRows++;
$info_ws 	->write($outInfoRows, 0, 'Customer Name:', $cell_fmt_lbl);
$info_ws	->merge_range($outInfoRows,1,$outInfoRows,4, $main::CUST_NAME , $cell_fmt_lf); # merge cells on the data cells
$outInfoRows++;
$outExcelRows++;

########################################################################################################################################
## Create the MASTER worksheet
########################################################################################################################################
my $master_ws 	= $workbookout->add_worksheet("Master");
$master_ws->set_tab_color( 'green' );

## set up the Excel workbook for parsing
my %xlsOrd=();	# hash table to define spreadsheet column order
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain data

for my $col ( 0 .. ($MASTER_MAX_COLS - 1)) {
	if 	( $col == 0 ) { #A
		$xlsOrd{$col}{label} = "category";
		$xlsOrd{$col}{title} = "Asset Category";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 1 ) { #B
		$xlsOrd{$col}{label} = "srcloc";
		$xlsOrd{$col}{title} = "Source Location";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 2 ) { #C
		$xlsOrd{$col}{label} = "tgtloc";
		$xlsOrd{$col}{title} = "Target Location";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 3 ) { #D
		$xlsOrd{$col}{label} = "ipaddr";
		$xlsOrd{$col}{title} = "IP Address";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 4 ) { #E
		$xlsOrd{$col}{label} = "loadbal";
		$xlsOrd{$col}{title} = "Load Bal. VIP(s)";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 5 ) { #F
		$xlsOrd{$col}{label} = "vlannum";
		$xlsOrd{$col}{title} = "VLAN";
		$xlsOrd{$col}{width} = 15;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 6 ) { #G
		$xlsOrd{$col}{label} = "subnetdesc";
		$xlsOrd{$col}{title} = "Subnet Description";
		$xlsOrd{$col}{width} = 28;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 7 ) { #H
		$xlsOrd{$col}{label} = "subnet";
		$xlsOrd{$col}{title} = "Subnet";
		$xlsOrd{$col}{width} = 20;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 8 ) { #I
		$xlsOrd{$col}{label} = "wsibname";
		$xlsOrd{$col}{title} = "WSIB hostname";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 9 ) { #J
		$xlsOrd{$col}{label} = "rscdname";
		$xlsOrd{$col}{title} = "CGI RSCD shortname";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 10 ) { #K
		$xlsOrd{$col}{label} = "fqdn";
		$xlsOrd{$col}{title} = "FQDN";
		$xlsOrd{$col}{width} = 32;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 11 ) { #L
		$xlsOrd{$col}{label} = "assignedips";
		$xlsOrd{$col}{title} = "Assigned IP Address(es)";
		$xlsOrd{$col}{width} = 30;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 12 ) { #M
		$xlsOrd{$col}{label} = "vcenter";
		$xlsOrd{$col}{title} = "RVT vCenter";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 13 ) { #N
		$xlsOrd{$col}{label} = "rv_ipv4";
		$xlsOrd{$col}{title} = "RVT Primary IP";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 14 ) { #O
		$xlsOrd{$col}{label} = "powerstate";
		$xlsOrd{$col}{title} = "RVT Powerstate";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 15 ) { #P
		$xlsOrd{$col}{label} = "vmsizegb";
		$xlsOrd{$col}{title} = "VM Size (GB)";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 16 ) { #Q -- 7/13/20 add vDisk info
		$xlsOrd{$col}{label} = "vdisk";
		$xlsOrd{$col}{title} = "RVT vDisk";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 17 ) { #R -- 7/27/20 add Source Cluster Name
		$xlsOrd{$col}{label} = "vcluster";
		$xlsOrd{$col}{title} = "RVT Cluster Name";
		$xlsOrd{$col}{width} = 28;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 18 ) { #S
		$xlsOrd{$col}{label} = "opsstate";
		$xlsOrd{$col}{title} = "Operations State";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 19 ) { #T
		$xlsOrd{$col}{label} = "cloudscape";
		$xlsOrd{$col}{title} = "Cloudscape";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 20 ) { #U
		$xlsOrd{$col}{label} = "drscope";
		$xlsOrd{$col}{title} = "DR Scope";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 21 ) { #V
		$xlsOrd{$col}{label} = "primaryfunction";
		$xlsOrd{$col}{title} = "Primary Server Function";
		$xlsOrd{$col}{width} = 32;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 22 ) { #W
		$xlsOrd{$col}{label} = "wsibenv";
		$xlsOrd{$col}{title} = "Environment";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 23 ) { #X
		$xlsOrd{$col}{label} = "dbms";
		$xlsOrd{$col}{title} = "DBMS";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 24 ) { #Y
		$xlsOrd{$col}{label} = "dbmspatchlevel";
		$xlsOrd{$col}{title} = "DBMS Patch Level";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 25 ) { #Z
		$xlsOrd{$col}{label} = "serialnum";
		$xlsOrd{$col}{title} = "Serial Number";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 26 ) { #AA
		$xlsOrd{$col}{label} = "santotal";
		$xlsOrd{$col}{title} = "SAN Total GB";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 27 ) { #AB
		$xlsOrd{$col}{label} = "nastotal";
		$xlsOrd{$col}{title} = "NAS Total GB";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 28 ) { #AC
		$xlsOrd{$col}{label} = "waveseq";
		$xlsOrd{$col}{title} = "Wave Seq.";
		$xlsOrd{$col}{width} = 16;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 29 ) { #AD
		$xlsOrd{$col}{label} = "cutover_target";
		$xlsOrd{$col}{title} = "Cutover Target";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 30 ) { #AE
		$xlsOrd{$col}{label} = "eventname";
		$xlsOrd{$col}{title} = "Migration Event";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 31 ) { #AF
		$xlsOrd{$col}{label} = "eventdesc";
		$xlsOrd{$col}{title} = "Event Desc.";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 32 ) { #AG
		$xlsOrd{$col}{label} = "discoverystatus";
		$xlsOrd{$col}{title} = "Discovery Status";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 33 ) { #AH
		$xlsOrd{$col}{label} = "sysdisposition";
		$xlsOrd{$col}{title} = "Server Disposition";
		$xlsOrd{$col}{width} = 22;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 34 ) { #AI
		$xlsOrd{$col}{label} = "ipdisposition";
		$xlsOrd{$col}{title} = "IP Disposition";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 35 ) { #AJ
		$xlsOrd{$col}{label} = "pattern";
		$xlsOrd{$col}{title} = "Migration Pattern";
		$xlsOrd{$col}{width} = 28;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 36 ) { #AK
		$xlsOrd{$col}{label} = "premigration";
		$xlsOrd{$col}{title} = "Pre-Migration Remediation";
		$xlsOrd{$col}{width} = 32;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 37 ) { #AL
		$xlsOrd{$col}{label} = "baselinedelta";
		$xlsOrd{$col}{title} = "Baseline Delta";
		$xlsOrd{$col}{width} = 28;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 38 ) { #AM - 6/22/20 - NEW!
		$xlsOrd{$col}{label} = "targetedevent";
		$xlsOrd{$col}{title} = "Targeted Event";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 39 ) { #AN - 6/8/20 - NEW!
		$xlsOrd{$col}{label} = "migrationstatus";
		$xlsOrd{$col}{title} = "Migration Status";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $wave_title_fmt;
	} elsif ( $col == 40 ) { #AO
		$xlsOrd{$col}{label} = "osplatform";
		$xlsOrd{$col}{title} = "OS Platform";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $os_title_fmt;
	} elsif ( $col == 41 ) { #AP
		$xlsOrd{$col}{label} = "osname";
		$xlsOrd{$col}{title} = "OS Name";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $os_title_fmt;
	} elsif ( $col == 42 ) { #AQ
		$xlsOrd{$col}{label} = "osarch";
		$xlsOrd{$col}{title} = "OS Arch.";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $os_title_fmt;
	} elsif ( $col == 43 ) { #AR
		$xlsOrd{$col}{label} = "oseol";
		$xlsOrd{$col}{title} = "EOL Notes";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $os_title_fmt;
	} elsif ( $col == 44 ) { #AS
		$xlsOrd{$col}{label} = "osnminus2";
		$xlsOrd{$col}{title} = "OS > N-2";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $os_title_fmt;
	} elsif ( $col == 45 ) { #AT
		$xlsOrd{$col}{label} = "appstack";
		$xlsOrd{$col}{title} = "Application Stack Name";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $app_title_fmt;
	} elsif ( $col == 46 ) { #AU
		$xlsOrd{$col}{label} = "validation";
		$xlsOrd{$col}{title} = "Validation";
		$xlsOrd{$col}{width} = 34;
		$xlsOrd{$col}{hformat} = $app_title_fmt;
	} elsif ( $col == 47 ) { #AV
		$xlsOrd{$col}{label} = "migrationnotes";
		$xlsOrd{$col}{title} = "Migration Notes";
		$xlsOrd{$col}{width} = 84;
		$xlsOrd{$col}{hformat} = $app_title_fmt;
	} # end if
	$xlsCol{$xlsOrd{$col}{label}}{col} = $col;

	## Now write out the header row info for that column
	$master_ws 	->write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
	$master_ws	->set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
} # end for col

## Finish up with the header row
$master_ws	->set_row(0, $ROW_HEIGHT_HDR); # Set row height
$outExcelRows++;
$outMasterRows++;

## Output the rest of the rows of the Master worksheet
for my $row ( 1 .. $MasterRows) {
	# Now pull up the corresponding Excel row index in the $MasterDB hash
	my $xlrow = $row + 1; # the actual Excel Row is +1 to the index counter
	my $discovery_confirmed = 0;
	my $asset_migrating = 0; ## new on 6/9/20
	my $migration_completed = 0;  ## new on 6/9/20
	my $background_override = 0;  ## new on 6/9/20
	$discovery_confirmed = 1 if ($MasterDB{$xlrow}{discoverystatuscode} ne "" && $MasterDB{$xlrow}{discoverystatuscode} == $main::hashDiscoveryStatus{'confirmed'} && $MasterDB{$xlrow}{sysdispositioncode} ne "");

	$asset_migrating = 1 if ($MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'migrating'});
	$migration_completed = 1 if ($MasterDB{$xlrow}{migrationstatuscode} ne "" && $MasterDB{$xlrow}{migrationstatuscode} == $main::hashMigrationStatus{completed});

	# loop through the hash by column sorted
	foreach my $col (sort keys %xlsOrd) {
		my $this_cell_format = $cell_fmt_ct;
		my $this_cell_format_lf = $cell_fmt_lf;
		if ($discovery_confirmed) {
			if ($migration_completed) {
				if ($asset_migrating) {
					$this_cell_format = $dkgn_cell_fmt_ct;
					$this_cell_format_lf = $dkgn_cell_fmt_lf;
					$background_override = 1;
				} else {
					$this_cell_format = $dkred_cell_fmt_ct;
					$this_cell_format_lf = $dkred_cell_fmt_lf;
					$background_override = 1;
				}
			} else {
				if ($asset_migrating) {
					$this_cell_format = $gn_cell_fmt_ct;
					$this_cell_format_lf = $gn_cell_fmt_lf;
					$background_override = 1;
				} elsif ($MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'notmigrating'} ||
					$MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'removed'} ||
					$MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'decomm'}) {
					$this_cell_format = $grey_cell_fmt_ct;
					$this_cell_format_lf = $grey_cell_fmt_lf;
					$background_override = 1;
				}
			}
		}

		# do we need to highlight this cell in a different color? do that here!
		#$xlsCol{$xlsOrd{$col}{label}}{col} = $col;
		$this_cell_format = $ye_cell_fmt_ct if (!$background_override && $col == $xlsCol{srcloc}{col} && $MasterDB{$xlrow}{srcloc} eq "");
		$this_cell_format = $ye_cell_fmt_ct if (!$background_override && $col == $xlsCol{srcloc}{col} && $MasterDB{$xlrow}{tgtloc} eq "");

		if (!$background_override && $col == $xlsCol{ipaddr}{col}){
			$this_cell_format = $ye_cell_fmt_ct if ($MasterDB{$xlrow}{ipaddr} eq "" || $MasterDB{$xlrow}{ipadd_id} eq "");
			$this_cell_format = $re_cell_fmt_ct if ($MasterDB{$xlrow}{rv_ipv4} ne "" && $MasterDB{$xlrow}{ipaddr} ne $MasterDB{$xlrow}{rv_ipv4});
			$this_cell_format = $ye_cell_fmt_ct if ($MasterDB{$xlrow}{ipaddr} =~ m/^192.168./); #private
			$this_cell_format = $re_cell_fmt_ct if ($MasterDB{$xlrow}{ipaddr} =~ m/^169.254./); #automatic private
		}

		if (!$background_override && $col == $xlsCol{assignedips}{col}){
			$this_cell_format = $re_cell_fmt_ct if ($MasterDB{$xlrow}{ipcount} == 0);
		}

		if (!$background_override && $MasterDB{$xlrow}{category} =~ m/vm/i) { ## special highlighting for VMs only
			if ($col == $xlsCol{rv_ipv4}{col}){
				$this_cell_format = $ye_cell_fmt_ct if ($MasterDB{$xlrow}{rv_ipv4} eq "");
				$this_cell_format = $re_cell_fmt_ct if ($MasterDB{$xlrow}{rv_ipv4} ne "" && $MasterDB{$xlrow}{ipaddr} ne $MasterDB{$xlrow}{rv_ipv4});
				$this_cell_format = $ye_cell_fmt_ct if ($MasterDB{$xlrow}{rv_ipv4} =~ m/^192.168./); #private
				$this_cell_format = $re_cell_fmt_ct if ($MasterDB{$xlrow}{rv_ipv4} =~ m/^169.254./); #automatic private
			}
			if ($col == $xlsCol{vcenter}{col} || $col == $xlsCol{powerstate}{col} || $col == $xlsCol{serialnum}{col}) {
				$this_cell_format = $ye_cell_fmt_ct if ($col == $xlsCol{vcenter}{col} && $MasterDB{$xlrow}{vcenter} eq "");
				$this_cell_format = $ye_cell_fmt_ct if ($col == $xlsCol{powerstate}{col} && $MasterDB{$xlrow}{powerstate} =~ m/not found/i);
				$this_cell_format = $re_cell_fmt_ct if ($col == $xlsCol{serialnum}{col} && $MasterDB{$xlrow}{serialnum} ne ""); ## 6/24/20 - non-blank serial number on a VM indicates physical hardware (P2V)
			}
			if ($col == $xlsCol{sysdisposition}{col} && $MasterDB{$xlrow}{sysdisposition} eq $main::txtSYSDisposition{$main::hashSYSDisposition{decomm}}) { #this is a decomm VM
				$this_cell_format = $ye_cell_fmt_ct if ($MasterDB{$xlrow}{powerstate} =~ m/poweredon/i);
			}
		} ## special highlighting for VMs only

		## 2/26/20 - Flag not migrating if not confirmed
		if (!$background_override &&
			($col == $xlsCol{sysdisposition}{col} || $col == $xlsCol{ipdisposition}{col} || $col == $xlsCol{pattern}{col} || $col == $xlsCol{discoverystatus}{col})
			) {
			if ($MasterDB{$xlrow}{sysdisposition} eq $main::txtSYSDisposition{$main::hashSYSDisposition{notmigrating}} ||
			$MasterDB{$xlrow}{sysdisposition} eq $main::txtSYSDisposition{$main::hashSYSDisposition{decomm}} ||
			$MasterDB{$xlrow}{sysdisposition} eq $main::txtSYSDisposition{$main::hashSYSDisposition{removed}}
			) {
				if ($MasterDB{$xlrow}{discoverystatuscode} == $main::hashDiscoveryStatus{'validating'}) {
					$this_cell_format = $purple_cell_fmt_ct;
				} else {
					$this_cell_format = $re_cell_fmt_ct;
				}
			}
		}
		if (!$background_override && !($MasterDB{$xlrow}{pattern} =~ m/cgi owned/i) && !($MasterDB{$xlrow}{pattern} =~ m/stay back/i)) { #this isn't a WSIB server
			$this_cell_format = $ye_cell_fmt_ct if ($col == $xlsCol{rscdname}{col} && $MasterDB{$xlrow}{rscdname} eq "" && !($MasterDB{$xlrow}{category} =~ m/z\-lpar/i) && !($MasterDB{$xlrow}{category} =~ m/hardware/i));
		}
		if ($col == $xlsCol{opsstate}{col}) { # operational state
			$this_cell_format = $ye_cell_fmt_ct if (!$background_override && $MasterDB{$xlrow}{opsstate} eq "" && !($MasterDB{$xlrow}{category} =~ m/z\-lpar/i)); # not operational
			if ($MasterDB{$xlrow}{opsstate} ne "") {
				$MasterDB{$xlrow}{opsstate} = "Operational";
			} else {
				$MasterDB{$xlrow}{opsstate} = "Not Found";
			}
		}
		if ($col == $xlsCol{cloudscape}{col}) { # cloudscapescan
			my $csstring = "";
			if ($MasterDB{$xlrow}{cloudscapeasset} ne "") {
				$csstring .= "Found/";
			} else {
				$csstring .= "Not Found/";
				$this_cell_format = $ye_cell_fmt_ct if (!$background_override);
			}
			if ($MasterDB{$xlrow}{cloudscapescan}) {
				$csstring .= "Scanned";
			} else {
				$csstring .= "Not Scanned";
				$this_cell_format = $ye_cell_fmt_ct if (!$background_override);
			}
			$MasterDB{$xlrow}{cloudscape} = $csstring;
		}
		if ($col == $xlsCol{wsibname}{col} && !$background_override && length($MasterDB{$xlrow}{wsibname}) != 8) { ## 2/20/20 - hostname follows WSIB naming convention?
	 		$this_cell_format = $ye_cell_fmt_ct;
		}
		if ($col == $xlsCol{dbmspatchlevel}{col} && $MasterDB{$xlrow}{dbmslatestrel} ne "") { ## 3/6/20 - Database Patch Level
			## check to see if this patch level is not equal to the latestrel
			my $latestrel = $MasterDB{$xlrow}{dbmslatestrel};
			my $patchlvl = substr($MasterDB{$xlrow}{dbmspatchlevel},0,length($latestrel));
	 		$this_cell_format = $ye_cell_fmt_ct if (!$background_override && $latestrel ne $patchlvl);
		}
		if ($col == $xlsCol{wsibenv}{col} && !$background_override && ($MasterDB{$xlrow}{wsibenv} eq "" || $MasterDB{$xlrow}{wsibenv} =~ m/n\/a/i) ) {
	 		$this_cell_format = $ye_cell_fmt_ct;
		}
		if ($col == $xlsCol{appstack}{col} && !$background_override) { ## 2/26/20 - highlight missing appstacks
			$this_cell_format = $ye_cell_fmt_ct if ($MasterDB{$xlrow}{appstack} eq "" || $MasterDB{$xlrow}{appstack} =~ m/out of scope/i);
			$this_cell_format = $re_cell_fmt_ct if ($MasterDB{$xlrow}{appstack} =~ m/riscdecom/i);
		}
		if ($col == $xlsCol{primaryfunction}{col} && !$background_override && $MasterDB{$xlrow}{primaryfunction} =~ m/undetermined/i) { ## 2/26/20 - highlight missing appstacks
			$this_cell_format = $ye_cell_fmt_ct;
		}
		if (!$background_override && ($col == $xlsCol{osname}{col} || $col == $xlsCol{osplatform}{col})) { ## 6/10/20 - highlight unsupported osplatform
			$this_cell_format = $re_cell_fmt_ct if ($MasterDB{$xlrow}{osplatform} =~ m/unsupported/i);
			$this_cell_format = $ye_cell_fmt_ct if ($MasterDB{$xlrow}{osplatform} =~ m/unknown/i);
		}

		################### FINALLY WRITE THE DATA:
		if ($col == $xlsCol{serialnum}{col}) {
			$master_ws 	-> write_string($row, $col, $MasterDB{$xlrow}{$xlsOrd{$col}{label}} , $this_cell_format); # force output to a string in the cell
		} elsif ($col == $xlsCol{migrationnotes}{col}) {
			$master_ws 	-> write($row, $col, $MasterDB{$xlrow}{$xlsOrd{$col}{label}} , $this_cell_format_lf);
		} else {
			$master_ws 	-> write($row, $col, $MasterDB{$xlrow}{$xlsOrd{$col}{label}} , $this_cell_format);
		}
		$master_ws	->set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
		#$master_ws	->set_row($row, 30); # Set row height
	}
	$outExcelRows++;
	$outMasterRows++;
} # end for row

$master_ws->autofilter(0,0,0,($MASTER_MAX_COLS - 1)); # set autofilter
$master_ws->freeze_panes(1,4); # freeze panes on the first row
#$master_ws->autofilter(0,0,($inExcelRows - 1),($TotalHeaders - 1));

########################################################################################################################################
## WAVES worksheet
########################################################################################################################################
my $waves_ws 	= $workbookout->add_worksheet('Waves');
$waves_ws->set_tab_color( $wavepurple );

# Set column widths -------------------------------------------------------
$waves_ws ->set_column(0, 0, 12); 	# Column A width
$waves_ws ->set_column(1, 1, 26); 	# Column B width
$waves_ws ->set_column(2, 2, 20); 	# Column C width
$waves_ws ->set_column(3, 3, 18); 	# Column D width
$waves_ws ->set_column(4, 4, 38); 	# Column E width
$waves_ws ->set_column(5, 5, 20); 	# Column F width
$waves_ws ->set_column(6, 6, 20); 	# Column G width
$waves_ws ->set_column(7, 7, 14); 	# Column H width
$waves_ws ->set_column(8, 8, 30); 	# Column I width ## insert connected VLANs below
$waves_ws ->set_column(9, 9, 30); 	# Column J width
$waves_ws ->set_column(10, 10, 30); 	# Column K width
$waves_ws ->set_column(11, 11, 16); 	# Column L width - Prod
$waves_ws ->set_column(12, 12, 16); 	# Column M width
$waves_ws ->set_column(13, 13, 16); 	# Column N width
$waves_ws ->set_column(14, 14, 16); 	# Column O width
$waves_ws ->set_column(15, 15, 18); 	# Column P width orphaned
$waves_ws ->set_column(16, 16, 18); 	# Column Q width
$waves_ws ->set_column(17, 17, 24); 	# Column R width
$waves_ws ->set_column(18, 18, 26); 	# Column S width
$waves_ws ->set_column(19, 19, 16); 	# Column T width
$waves_ws ->set_column(20, 20, 16); 	# Column U width
$waves_ws ->set_column(21, 21, 16); 	# Column V width
$waves_ws ->set_column(22, 22, 16); 	# Column W width
$waves_ws ->set_column(23, 23, 16); 	# Column X width
$waves_ws ->set_column(24, 24, 16); 	# Column Y width
$waves_ws ->set_column(25, 25, 100); 	# Column Z width

# Spreadsheet Title Row --------------------------------------------------
$waves_ws	->set_row($outWaveRows, $ROW_HEIGHT_HDR); # Set row height

$waves_ws 	->write($outWaveRows, 0, 'Wave #', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 1, 'Migration Cutover Target', $wave_title_fmt); ### add contingency date below
$waves_ws 	->write($outWaveRows, 2, 'Contingency Date', $wave_title_fmt); ### add contingency date below
$waves_ws 	->write($outWaveRows, 3, 'Migration Event', $wave_title_fmt); ## continuation
$waves_ws 	->write($outWaveRows, 4, 'Event Description', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 5, 'Source Location', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 6, 'Target Location', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 7, '# Subnets', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 8, 'VLAN Numbers', $wave_title_fmt); ##
$waves_ws 	->write($outWaveRows, 9, 'Connected VLANs', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 10, 'Environments', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 11, 'Production', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 12, 'Non-Prod', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 13, 'Red Flags', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 14, 'Stay Back', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 15, 'Orphaned IPs', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 16, 'VM Size GB', $wave_title_fmt); 
$waves_ws 	->write($outWaveRows, 17, 'VM Sync Est. (@' . sprintf('%1.1f',$main::MINMIGRATIONBANDWIDTHGbps) . 'Gb/s)', $wave_title_fmt); 
$waves_ws 	->write($outWaveRows, 18, 'DR (Primary/Failover)', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 19, 'Windows', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 20, 'Linux', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 21, 'AIX', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 22, 'Solaris', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 23, 'Other', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 24, 'Total', $wave_title_fmt);
$waves_ws 	->write($outWaveRows, 25, 'Application Stacks (Cloudscape)', $wave_title_fmt);
$outExcelRows++;
$outWaveRows++;

my $tlSubnets = 0;
my $tlWindows = 0;
my $tlLinux = 0;
my $tlAIX = 0;
my $tlSolaris = 0;
my $tlOther = 0;
my $tlDRPrimary = 0;
my $tlDRFailover = 0;
my $tlSystems = 0;
my $tlProd = 0;
my $tlNonProd = 0;
my $tlRedFlags = 0;
my $tlStayBack = 0;
my $tlOrphaned = 0;
my $tlVMsizeGB = 0;
my $tlVMxferhours = 0;
foreach my $wseq (sort keys %WaveDB) {
	## Calculate redflags and staybacks for the wave (which aren't included in the wave)
	## @ { $WaveDB{$wseq}{vidx} }

	$WaveDB{$wseq}{redflags}					= 0; # counter
	$WaveDB{$wseq}{stayback}					= 0; # counter
	$WaveDB{$wseq}{orphaned}					= 0; # counter
	foreach my $vidx (@ { $WaveDB{$wseq}{vidx} }) {
		$WaveDB{$wseq}{redflags} += $NetworkDB{$vidx}{redflags};
		$WaveDB{$wseq}{stayback} += $NetworkDB{$vidx}{stayback};
		$WaveDB{$wseq}{orphaned} += $NetworkDB{$vidx}{orphaned};
	}

	$waves_ws 	->write($outWaveRows, 0, sprintf("%d",$wseq), $cell_fmt_ct);
	my $cutover_txt = "";
	if ($WaveDB{$wseq}{production} == 0) {
		$cutover_txt .= $WaveDB{$wseq}{nonprod_cutover} . " (NON-PRD)" if ($WaveDB{$wseq}{nonprod_cutover} ne "");
	} else {
		$cutover_txt .= $WaveDB{$wseq}{cutover} if ($WaveDB{$wseq}{cutover} ne "");
	}
	$waves_ws 	->write($outWaveRows, 1, $cutover_txt, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 2, $WaveDB{$wseq}{contingency_cutover}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 3, $WaveDB{$wseq}{eventname}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 4, $WaveDB{$wseq}{eventdesc}, $cell_fmt_ct);
	my $srcloc = $WaveDB{$wseq}{srccode} . " - " . $WaveDB{$wseq}{srcname};
	$waves_ws 	->write($outWaveRows, 5, $srcloc, $cell_fmt_ct);
	my $tgtloc = $WaveDB{$wseq}{tgtcode} . " - " . $WaveDB{$wseq}{tgtname};
	$waves_ws 	->write($outWaveRows, 6, $tgtloc, $cell_fmt_ct);
	my $this_cell_format = $cell_fmt_ct;
	$this_cell_format = $ye_cell_fmt_ct if ($WaveDB{$wseq}{subnets} == 0);
	$waves_ws 	->write($outWaveRows, 7, $WaveDB{$wseq}{subnets}, $this_cell_format);
	my $vlans = $WaveDB{$wseq}{vlans};
	$vlans = reorder_vlans($vlans);
	$waves_ws 	->write($outWaveRows, 8, $vlans, $cell_fmt_ct);
	my $connected = reorder_connected_vlans($WaveDB{$wseq}{connected_subnets});
	$waves_ws 	->write($outWaveRows, 9, $connected, $cell_fmt_ct); ## 5/19/20
	my $envs = $WaveDB{$wseq}{environments};
	$envs = reorder($envs);
	$waves_ws 	->write($outWaveRows, 10, $envs, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 11, $WaveDB{$wseq}{production}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 12, $WaveDB{$wseq}{nonprod}, $cell_fmt_ct);
	$this_cell_format = ($WaveDB{$wseq}{redflags} > 0) ? $re_cell_fmt_ct : $cell_fmt_ct;
	$waves_ws 	->write($outWaveRows, 13, $WaveDB{$wseq}{redflags}, $this_cell_format);
	$waves_ws 	->write($outWaveRows, 14, $WaveDB{$wseq}{stayback}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 15, $WaveDB{$wseq}{orphaned}, $cell_fmt_ct); ## 4/28
	$waves_ws 	->write($outWaveRows, 16, $WaveDB{$wseq}{vmsizegb}, $cell_fmt_ct);
	
	## 7/1/20 - Calculate sync estimate (data transfer time)
	my $totaldatabits = $WaveDB{$wseq}{vmsizegb} * 8589934592; # convert gigabytes to bits
	my $xfertime = 0;
	my $xfertxt = "";
	if ($totaldatabits > 0) {
		my $transferbw = $main::MINMIGRATIONBANDWIDTHBITSPERSEC;
		my $transfertimesecs = $totaldatabits / $transferbw;
		$transfertimesecs += ($transfertimesecs * ($main::TRANSFEROVERHEADPCT / 100)); ## add in latency and encryption overhead
		$xfertime = $transfertimesecs / 3600; ## convert to hours
		my $xfermin = ($xfertime - int($xfertime)) * 60; ## convert the remaining fractional hour to minutes
		my $xfersec = ($xfermin - int($xfermin)) * 60; ## convert the remaining fractional minute to seconds
		$xfertxt = int($xfertime) . 'h ' . int($xfermin) . 'm ' . int($xfersec) . 's';
	}	
	$waves_ws 	->write($outWaveRows, 17, $xfertxt, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 18, $WaveDB{$wseq}{drprimary} . " / " . $WaveDB{$wseq}{drfailover}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 19, $WaveDB{$wseq}{windows}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 20, $WaveDB{$wseq}{linux}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 21, $WaveDB{$wseq}{aix}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 22, $WaveDB{$wseq}{solaris}, $cell_fmt_ct);
	$waves_ws 	->write($outWaveRows, 23, $WaveDB{$wseq}{other}, $cell_fmt_ct);
	my $total_sys = $WaveDB{$wseq}{windows} + $WaveDB{$wseq}{linux} + $WaveDB{$wseq}{aix} + $WaveDB{$wseq}{solaris} + $WaveDB{$wseq}{other};
	$waves_ws 	->write($outWaveRows, 24, $total_sys, $cell_fmt_ct);
	my $apps = $WaveDB{$wseq}{applications};
	$apps = reorder($apps);
	$waves_ws 	->write($outWaveRows, 25, $apps, $cell_fmt_lf);
	## accumulators
	$tlSubnets += $WaveDB{$wseq}{subnets};
	$tlWindows += $WaveDB{$wseq}{windows};
	$tlLinux += $WaveDB{$wseq}{linux};
	$tlAIX += $WaveDB{$wseq}{aix};
	$tlSolaris += $WaveDB{$wseq}{solaris};
	$tlOther += $WaveDB{$wseq}{other};
	$tlDRPrimary += $WaveDB{$wseq}{drprimary};
	$tlDRFailover += $WaveDB{$wseq}{drfailover};
	$tlProd += $WaveDB{$wseq}{production};
	$tlNonProd += $WaveDB{$wseq}{nonprod};
	$tlRedFlags += $WaveDB{$wseq}{redflags};
	$tlStayBack += $WaveDB{$wseq}{stayback};
	$tlOrphaned += $WaveDB{$wseq}{orphaned};
	$tlVMsizeGB += $WaveDB{$wseq}{vmsizegb};
	$tlSystems += $total_sys;
	$tlVMxferhours += $xfertime; ## add to total hours
	$outExcelRows++;
	$outWaveRows++;
}

## Wave Totals row
$waves_ws	->merge_range($outWaveRows,0,$outWaveRows,6,'TOTALS ', $totals_cell_fmt);
$waves_ws 	->write($outWaveRows, 7, $tlSubnets, $totals_cell_fmt_ct);
$waves_ws	->merge_range($outWaveRows,8,$outWaveRows,10,' ', $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 11, $tlProd, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 12, $tlNonProd, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 13, $tlRedFlags, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 14, $tlStayBack, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 15, $tlOrphaned, $totals_cell_fmt_ct); ##
$waves_ws 	->write($outWaveRows, 16, $tlVMsizeGB, $totals_cell_fmt_ct);
my $xferday = $tlVMxferhours / 24; ## calculate the number of days
my $xferhr 	= ($xferday - int($xferday)) * 24; ## convert the remaining fractional day to hours
my $xfermin = ($xferhr - int($xferhr)) * 60; ## convert the remaining fractional hour to minutes
my $xfersec = ($xfermin - int($xfermin)) * 60; ## convert the remaining fractional minute to seconds
my $xfertxt = int($xferday) . 'd ' . int($xferhr) . 'h ' . int($xfermin) . 'm ' . int($xfersec) . 's';
$waves_ws 	->write($outWaveRows, 17, $xfertxt, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 18, $tlDRPrimary . " / " . $tlDRFailover, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 19, $tlWindows, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 20, $tlLinux, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 21, $tlAIX, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 22, $tlSolaris, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 23, $tlOther, $totals_cell_fmt_ct);
$waves_ws 	->write($outWaveRows, 24, $tlSystems, $totals_cell_fmt_ct);
$outExcelRows++;
$outWaveRows++;

$waves_ws->autofilter(0,0,0,23); # set autofilter
$waves_ws->freeze_panes(1,4); # freeze panes on the first row

########################################################################################################################################
## RED FLAGS worksheet
########################################################################################################################################
if ($TotalRedFlags > 0) {
	my $redflags_ws 	= $workbookout->add_worksheet("Red Flags");
	$redflags_ws->set_tab_color( $ferrarired );

	## set up the Excel workbook for parsing
	my %xlsOrd=();	# hash table to define spreadsheet column order
	my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain data

	for my $col ( 0 .. 18 ) {
		if 	( $col == 0 ) { #A
			$xlsOrd{$col}{label} = "masterrow";
			$xlsOrd{$col}{title} = "Master Row #";
			$xlsOrd{$col}{width} = 16;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif 	( $col == 1 ) { #B
			$xlsOrd{$col}{label} = "waveseq";
			$xlsOrd{$col}{title} = "Wave Seq.";
			$xlsOrd{$col}{width} = 16;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 2 ) { #C
			$xlsOrd{$col}{label} = "eventname";
			$xlsOrd{$col}{title} = "Migration Event";
			$xlsOrd{$col}{width} = 22;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 3 ) { #D
			$xlsOrd{$col}{label} = "cutover_target";
			$xlsOrd{$col}{title} = "Cutover Target";
			$xlsOrd{$col}{width} = 22;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 4 ) { #E
			$xlsOrd{$col}{label} = "eventdesc";
			$xlsOrd{$col}{title} = "Event Desc.";
			$xlsOrd{$col}{width} = 40;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 5 ) { #F
			$xlsOrd{$col}{label} = "category";
			$xlsOrd{$col}{title} = "Asset Category";
			$xlsOrd{$col}{width} = 18;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 6 ) { #G
			$xlsOrd{$col}{label} = "srcloc";
			$xlsOrd{$col}{title} = "Source Location";
			$xlsOrd{$col}{width} = 18;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 7 ) { #H
			$xlsOrd{$col}{label} = "ipaddr";
			$xlsOrd{$col}{title} = "IP Address";
			$xlsOrd{$col}{width} = 18;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 8 ) { #I
			$xlsOrd{$col}{label} = "vlannum";
			$xlsOrd{$col}{title} = "VLAN";
			$xlsOrd{$col}{width} = 15;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 9 ) { #J
			$xlsOrd{$col}{label} = "wsibname";
			$xlsOrd{$col}{title} = "WSIB hostname";
			$xlsOrd{$col}{width} = 24;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 10 ) { #K
			$xlsOrd{$col}{label} = "assignedips";
			$xlsOrd{$col}{title} = "Assigned IP Address(es)";
			$xlsOrd{$col}{width} = 30;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 11 ) { #L
			$xlsOrd{$col}{label} = "primaryfunction";
			$xlsOrd{$col}{title} = "Primary Server Function";
			$xlsOrd{$col}{width} = 32;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 12 ) { #M
			$xlsOrd{$col}{label} = "appstack";
			$xlsOrd{$col}{title} = "Application Stack Name";
			$xlsOrd{$col}{width} = 38;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 13 ) { #N
			$xlsOrd{$col}{label} = "discoverystatus";
			$xlsOrd{$col}{title} = "Discovery Status";
			$xlsOrd{$col}{width} = 22;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 14 ) { #O
			$xlsOrd{$col}{label} = "sysdisposition";
			$xlsOrd{$col}{title} = "Server Disposition";
			$xlsOrd{$col}{width} = 22;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 15 ) { #P
			$xlsOrd{$col}{label} = "pattern";
			$xlsOrd{$col}{title} = "Migration Pattern";
			$xlsOrd{$col}{width} = 28;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 16 ) { #Q
			$xlsOrd{$col}{label} = "premigration";
			$xlsOrd{$col}{title} = "Pre-Migration Remediation";
			$xlsOrd{$col}{width} = 32;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 17 ) { #R - RED FLAG RESOLUTION
			$xlsOrd{$col}{label} = "redflagresolution";
			$xlsOrd{$col}{title} = "Red Flag Resolution";
			$xlsOrd{$col}{width} = 64;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} elsif ( $col == 18 ) { #S
			$xlsOrd{$col}{label} = "migrationnotes";
			$xlsOrd{$col}{title} = "Migration Notes";
			$xlsOrd{$col}{width} = 84;
			$xlsOrd{$col}{hformat} = $red_title_fmt;
		} # end if
		$xlsCol{$xlsOrd{$col}{label}}{col} = $col;

		## Now write out the header row info for that column
		$redflags_ws 	->write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
		$redflags_ws	->set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
	} # end for col

	## Finish up with the header row
	$redflags_ws	->set_row(0, $ROW_HEIGHT_HDR); # Set row height
	$outExcelRows++;
	$outRedFlagRows++;

	my %RedFlagRow = (); # set up a hash for the red flags

	## Output the rest of the rows of the Master worksheet
	for my $row ( 1 .. $MasterRows) {
		# Now pull up the corresponding Excel row index in the $MasterDB hash
		my $xlrow = $row + 1; # the actual Excel Row is +1 to the index counter
		my $this_is_a_red_flag = 0;

		## figure out what constitutes a red flag to report based on criteria
		next if ($MasterDB{$xlrow}{discoverystatuscode} ne "" && $MasterDB{$xlrow}{discoverystatuscode} == $main::hashDiscoveryStatus{'inprogress'} && $MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'migrating'});
		if ($MasterDB{$xlrow}{discoverystatuscode} ne "" && $MasterDB{$xlrow}{discoverystatuscode} != $main::hashDiscoveryStatus{'confirmed'}) {
			$this_is_a_red_flag = 1;
		}

		if ($this_is_a_red_flag) {
			foreach my $col (sort keys %xlsOrd) {
				my $vidx = $MasterDB{$xlrow}{vidx}; # figure out the VLAN index vidx for this row
				if ($vidx ne "") {
					my $wseq = "";
					if (exists($SubnetWave{$vidx})) {
						$wseq = sprintf("%03d",$SubnetWave{$vidx}{wseq}); # figure out the wave sequence number
					}
					my $widx = "";
					if ($wseq ne "") {
						$widx = $wseq . $IndexDelimit . $xlrow;
					} else {
						$widx = 999 . $IndexDelimit . $xlrow; # sort to the end
					}

					## wave related fields we need to fill in based on the subnets
					if ($xlsOrd{$col}{label} eq 'masterrow') {
						$RedFlagRow{$widx}{masterrow} = $xlrow;
					} elsif ($xlsOrd{$col}{label} eq 'waveseq') {
						$RedFlagRow{$widx}{waveseq} = $wseq ne "" ? $SubnetWave{$vidx}{wseq} : "None";
					} elsif ($xlsOrd{$col}{label} eq 'cutover_target') {
						## cutover_target
						my $cutover = "";
						if ($wseq ne "") {
							if ($WaveDB{$wseq}{production} == 0) {
								$cutover = $WaveDB{$wseq}{nonprod_cutover};
							} else {
								$cutover = $WaveDB{$wseq}{cutover};
							}
						}
						$RedFlagRow{$widx}{cutover_target} = $cutover;
					} elsif ($xlsOrd{$col}{label} eq 'eventname') {
						$RedFlagRow{$widx}{eventname} = $wseq ne "" ? $WaveDB{$wseq}{eventname} : "";
					} elsif ($xlsOrd{$col}{label} eq 'eventdesc') {
						$RedFlagRow{$widx}{eventdesc} = $wseq ne "" ? $WaveDB{$wseq}{eventdesc} : "VLAN not associated with any migration event";
					} elsif ($xlsOrd{$col}{label} eq 'redflagresolution') {
						## figure out the red flag resolution for this row
						$RedFlagRow{$widx}{redflagresolution} = "";
						if ($MasterDB{$xlrow}{discoverystatuscode} == $main::hashDiscoveryStatus{'notfound'} || $MasterDB{$xlrow}{pattern} =~ m/details missing/i) {
							if ($MasterDB{$xlrow}{category} =~ m/vm/i) {
								$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{vmrvtnotfound}{resolution} if ( $RedFlagTxt{vmrvtnotfound}{notify} );
							} else {
								$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{sysnotfound}{resolution} if ( $RedFlagTxt{sysnotfound}{notify} );
							}
						}
						if ($MasterDB{$xlrow}{pattern} =~ m/rds solution/i) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{rdssolution}{resolution} if ( $RedFlagTxt{rdssolution}{notify} );
						}
						if ($MasterDB{$xlrow}{pattern} =~ m/ad solution/i) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{adsolution}{resolution} if ( $RedFlagTxt{adsolution}{notify} );
						}
						if ($MasterDB{$xlrow}{pattern} =~ m/stay back/i) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{stayback}{resolution} if ( $RedFlagTxt{stayback}{notify} );
						}
						if ($MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'decomm'} || $MasterDB{$xlrow}{pattern} =~ m/decommission/i) {
							if ($MasterDB{$xlrow}{pattern} =~ m/dr solution/i) {
								$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{drdecomm}{resolution} if ( $RedFlagTxt{drdecomm}{notify} );
							} else {
								$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{sysdecomm}{resolution} if ( $RedFlagTxt{sysdecomm}{notify} );
							}
						}
						if ($MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'confirmscope'}) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{confirmscope}{resolution} if ( $RedFlagTxt{confirmscope}{notify} );
						}
						if ($MasterDB{$xlrow}{category} =~ m/vm/i && ($MasterDB{$xlrow}{ipaddr} =~ m/^169.254./ || $MasterDB{$xlrow}{rv_ipv4} =~ m/^169.254./)) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{rvtprimaryapipa}{resolution} if ( $RedFlagTxt{rvtprimaryapipa}{notify} );
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{resolvepriormigration}{resolution} if ( $RedFlagTxt{resolvepriormigration}{notify} );
							if ($wseq eq "") {
								$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{pvtvlannotmigrating}{resolution} if ( $RedFlagTxt{pvtvlannotmigrating}{notify} );
							}
						} elsif ($MasterDB{$xlrow}{ipaddr} =~ m/^169.254./) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{sysprimaryapipa}{resolution} if ( $RedFlagTxt{sysprimaryapipa}{notify} );
							if ($wseq eq "") {
								$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{pvtvlannotmigrating}{resolution} if ( $RedFlagTxt{pvtvlannotmigrating}{notify} );
							}
						}
						if ($MasterDB{$xlrow}{category} =~ m/vm/i && $MasterDB{$xlrow}{rv_ipv4} =~ m/^192.168./) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{rvtprimaryipprivate}{resolution} if ( $RedFlagTxt{rvtprimaryipprivate}{notify} );
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{pvtvlannotmigrating}{resolution} if ( $RedFlagTxt{pvtvlannotmigrating}{notify} );
						}
						if ($MasterDB{$xlrow}{ipaddr} =~ m/^192.168./) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{sysprimaryipprivate}{resolution} if ( $RedFlagTxt{sysprimaryipprivate}{notify} );
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{pvtvlannotmigrating}{resolution} if ( $RedFlagTxt{pvtvlannotmigrating}{notify} );
						}
						if ($MasterDB{$xlrow}{category} =~ m/vm/i && $MasterDB{$xlrow}{pattern} =~ m/appliance/i) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{virtualappliance}{resolution} if ( $RedFlagTxt{virtualappliance}{notify} );
						}
						if ($MasterDB{$xlrow}{sysdispositioncode} == $main::hashSYSDisposition{'removed'} || $MasterDB{$xlrow}{pattern} =~ m/undetermined/i) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{sysremoved}{resolution} if ( $RedFlagTxt{sysremoved}{notify} );
						}
						if ($MasterDB{$xlrow}{osplatform} =~ m/unsupported/i) {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{sysosunsupported}{resolution} if ( $RedFlagTxt{sysosunsupported}{notify} );
						}
						if ($MasterDB{$xlrow}{category} =~ m/vm/i && $MasterDB{$xlrow}{serialnum} ne "") {
							$RedFlagRow{$widx}{redflagresolution} .= (($RedFlagRow{$widx}{redflagresolution} ne "") ? " " : "") . $RedFlagTxt{vmwithserialnum}{resolution} if ( $RedFlagTxt{vmwithserialnum}{notify} );
						}
					} else {
						$RedFlagRow{$widx}{$xlsOrd{$col}{label}} = exists($MasterDB{$xlrow}{$xlsOrd{$col}{label}}) ? $MasterDB{$xlrow}{$xlsOrd{$col}{label}} : "";
					}
				} ## if ($vidx ne "")
			} ## foreach my $col (sort keys %xlsOrd)
		} ## if ($this_is_a_red_flag)
	} # end for row

	## sort the Red Flag hash and output
	foreach my $widx (sort keys %RedFlagRow) {
		foreach my $col (sort keys %xlsOrd) {
			my $this_cell_fmt = $cell_fmt_ct;
			$this_cell_fmt = $cell_fmt_lf if ($xlsOrd{$col}{label} eq 'redflagresolution' || $xlsOrd{$col}{label} eq 'migrationnotes');
			$redflags_ws 	-> write($outRedFlagRows, $col, $RedFlagRow{$widx}{$xlsOrd{$col}{label}} , $this_cell_fmt);
			$redflags_ws	->set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
			#$redflags_ws	->set_row($row, 30); # Set row height
		}
		$outExcelRows++;
		$outRedFlagRows++;
	}

	$redflags_ws->autofilter(0,0,0,17); # set autofilter
	$redflags_ws->freeze_panes(1,3); # freeze panes on the first row, column D
	%RedFlagRow = (); # free the hash memory
	#$redflags_ws->autofilter(0,0,($inExcelRows - 1),($TotalHeaders - 1));
} # if totalredflags > 0

########################################################################################################################################
## APPLICATIONS worksheet
########################################################################################################################################
my $apps_ws 	= $workbookout->add_worksheet('Applications');
$apps_ws->set_tab_color( $appskyblue );

## Set up the SQL SELECT statement to grab the data
$sql = "SELECT stackname, description, ownname1, ownphone1, ownemail1, ownname2, ownphone2, ownemail2, \n";
$sql .= "      ownname3, ownphone3, ownemail3, ownname4, ownphone4, ownemail4, \n";
$sql .= "      criticality, notes \n";
$sql .= "FROM `" . $main::IDB_NAME . "`.`appstack` ORDER by stackname;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}

# Set column widths -------------------------------------------------------
$apps_ws ->set_column(0, 0, 50); 	# Column A width
$apps_ws ->set_column(1, 1, 50); 	# Column B width
$apps_ws ->set_column(2, 2, 28); 	# Column C width
$apps_ws ->set_column(3, 3, 28); 	# Column D width
$apps_ws ->set_column(4, 4, 28); 	# Column E width
$apps_ws ->set_column(5, 5, 28); 	# Column F width
$apps_ws ->set_column(6, 6, 18); 	# Column G width
$apps_ws ->set_column(7, 7, 60); 	# Column H width

# Spreadsheet Title Row --------------------------------------------------
$apps_ws	->set_row($outAppRows, $ROW_HEIGHT_HDR); # Set row height

$apps_ws 	->write($outAppRows, 0, 'Stack Name', $app_title_fmt);
$apps_ws 	->write($outAppRows, 1, 'Description', $app_title_fmt);
$apps_ws 	->write($outAppRows, 2, 'Custodian 1', $app_title_fmt);
$apps_ws 	->write($outAppRows, 3, 'Custodian 2', $app_title_fmt);
$apps_ws 	->write($outAppRows, 4, 'Custodian 3', $app_title_fmt);
$apps_ws 	->write($outAppRows, 5, 'Custodian 4', $app_title_fmt);
$apps_ws 	->write($outAppRows, 6, 'Criticality', $app_title_fmt);
$apps_ws 	->write($outAppRows, 7, 'Notes', $app_title_fmt);
$outExcelRows++;
$outAppRows++;

# Loop through the results from the SQL query
while (my @refr = $sth->fetchrow_array) {
	$apps_ws 	->write($outAppRows, 0, $refr[0], $cell_fmt_ct);
	$apps_ws 	->write($outAppRows, 1, $refr[1], $cell_fmt_ct);
	my $own_contact = "";
	if (defined($refr[2])) {
		$own_contact = $refr[2];
		$own_contact .= "\nPhone: " . $refr[3] if (defined($refr[3]));
		$own_contact .= "\nEmail:" . $refr[4] if (defined($refr[4]));
	}
	$apps_ws 	->write($outAppRows, 2, $own_contact, $cell_fmt_lf);
	$own_contact = "";
	if (defined($refr[5])) {
		$own_contact = $refr[5];
		$own_contact .= "\nPhone: " . $refr[6] if (defined($refr[6]));
		$own_contact .= "\nEmail:" . $refr[7] if (defined($refr[7]));	}
	$apps_ws 	->write($outAppRows, 3, $own_contact, $cell_fmt_lf);
	$own_contact = "";
	if (defined($refr[8])) {
		$own_contact = $refr[8];
		$own_contact .= "\nPhone: " . $refr[9] if (defined($refr[9]));
		$own_contact .= "\nEmail:" . $refr[10] if (defined($refr[10]));	}
	$apps_ws 	->write($outAppRows, 4, $own_contact, $cell_fmt_lf);
	$own_contact = "";
	if (defined($refr[11])) {
		$own_contact = $refr[11];
		$own_contact .= "\nPhone: " . $refr[12] if (defined($refr[12]));
		$own_contact .= "\nEmail:" . $refr[13] if (defined($refr[13]));	}
	$apps_ws 	->write($outAppRows, 5, $own_contact, $cell_fmt_lf);
	my $criticality = (defined($refr[14])) ? $main::txtAppCriticality{$refr[14]} :  $main::txtAppCriticality{$main::hashAppCriticality{low}};
	$apps_ws 	->write($outAppRows, 6, $criticality, $cell_fmt_ct);
	$apps_ws 	->write($outAppRows, 7, $refr[15], $cell_fmt_lf);
	$outExcelRows++;
	$outAppRows++;
}

$apps_ws->autofilter(0,0,0,7); # set autofilter
$apps_ws->freeze_panes(1,1); # freeze panes on the first row


########################################################################################################################################
## SAN worksheet
########################################################################################################################################
my $san_ws 	= $workbookout->add_worksheet('SAN');
$san_ws->set_tab_color( 'yellow' );

## Set up the SQL SELECT statement to grab the data
$sql = "SELECT lo.code, s.lunid, s.rscdname1, s.rscdname2, s.serialnum, s.class, s.alias1, s.alias2, s.servername, s.environment, s.vgname, s.diskname, s.disksizegb, s.serveros \n";
$sql .= "  FROM `" . $main::IDB_NAME . "`.`sanspecs` s\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON s.location_id = lo.id\n";
$sql .= "ORDER by s.serialnum, s.lunid;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}

# Set column widths -------------------------------------------------------
$san_ws ->set_column(0, 0, 16); 	# Column A width
$san_ws ->set_column(1, 1, 16); 	# Column B width
$san_ws ->set_column(2, 2, 24); 	# Column C width
$san_ws ->set_column(3, 3, 16); 	# Column D width
$san_ws ->set_column(4, 4, 16); 	# Column E width
$san_ws ->set_column(5, 5, 38); 	# Column F width
$san_ws ->set_column(6, 6, 18); 	# Column G width
$san_ws ->set_column(7, 7, 18); 	# Column H width
$san_ws ->set_column(8, 8, 20); 	# Column I width
$san_ws ->set_column(9, 9, 18); 	# Column J width
$san_ws ->set_column(10, 10, 18); 	# Column K width
$san_ws ->set_column(11, 11, 16); 	# Column L width
$san_ws ->set_column(12, 12, 18); 	# Column M width

# Spreadsheet Title Row --------------------------------------------------
$san_ws	->set_row($outSANRows, $ROW_HEIGHT_HDR); # Set row height

$san_ws 	->write($outSANRows, 0, 'Location', $title_fmt);
$san_ws 	->write($outSANRows, 1, 'LUN ID', $title_fmt);
$san_ws 	->write($outSANRows, 2, 'RSCD Shortname(s)', $title_fmt);
$san_ws 	->write($outSANRows, 3, 'Serial Number', $title_fmt);
$san_ws 	->write($outSANRows, 4, 'Class', $title_fmt);
$san_ws 	->write($outSANRows, 5, 'Alias(es)', $title_fmt);
$san_ws 	->write($outSANRows, 6, 'Server Name', $title_fmt);
$san_ws 	->write($outSANRows, 7, 'Master Row #', $title_fmt);
$san_ws 	->write($outSANRows, 8, 'WSIB Environment', $title_fmt);
$san_ws 	->write($outSANRows, 9, 'VG Name', $title_fmt);
$san_ws 	->write($outSANRows, 10, 'Disk Name', $title_fmt);
$san_ws 	->write($outSANRows, 11, 'Disk Size (GB)', $title_fmt);
$san_ws 	->write($outSANRows, 12, 'Server OS', $title_fmt);
$outExcelRows++;
$outSANRows++;

# Loop through the results from the SQL query
while (my @refr = $sth->fetchrow_array) { # 14 columns returned
	$san_ws 	->write($outSANRows, 0, $refr[0], $cell_fmt_ct);
	$san_ws 	->write($outSANRows, 1, $refr[1], $cell_fmt_ct);
	my $rscd = "";
	$rscd = $refr[2] if (defined($refr[2]));
	$rscd .= "\n" . $refr[3] if (defined($refr[3]));
	$san_ws 	->write($outSANRows, 2, $rscd, $cell_fmt_ct);
	$san_ws 	->write($outSANRows, 3, $refr[4], $cell_fmt_ct);
	$san_ws 	->write($outSANRows, 4, $refr[5], $cell_fmt_ct);
	my $alias = "";
	$alias = $refr[6] if (defined($refr[6]));
	$alias .= "\n" . $refr[7] if (defined($refr[7]));
	$san_ws 	->write($outSANRows, 5, $alias, $cell_fmt_ct);
	my $hostnm = (defined($refr[8]) ? $refr[8] : "");
	$san_ws 	->write($outSANRows, 6, $hostnm, $cell_fmt_ct);
	my $mxl = "Not found";
	my $this_cell_fmt = $cell_fmt_ct;
	if ($hostnm ne "" && exists($lkINV{$hostnm})) {
		$mxl = $lkINV{$hostnm}{excel_row};
	} else {
		$this_cell_fmt = $ye_cell_fmt_ct;
	}
	$san_ws 	->write($outSANRows, 7, $mxl, $this_cell_fmt);
	$san_ws 	->write($outSANRows, 8, $refr[9], $cell_fmt_ct);
	$san_ws 	->write($outSANRows, 9, $refr[10], $cell_fmt_ct);
	$san_ws 	->write($outSANRows, 10, $refr[11], $cell_fmt_ct);
	$san_ws 	->write($outSANRows, 11, $refr[12], $cell_fmt_ct);
	$san_ws 	->write($outSANRows, 12, $refr[13], $cell_fmt_ct);
	$outExcelRows++;
	$outSANRows++;
}

$san_ws->autofilter(0,0,0,12); # set autofilter
$san_ws->freeze_panes(1,0); # freeze panes on the first row

########################################################################################################################################
## NAS worksheet
########################################################################################################################################
my $nas_ws 	= $workbookout->add_worksheet('NAS');
$nas_ws->set_tab_color( 'lime' );

## Set up the SQL SELECT statement to grab the data
$sql = "SELECT lo.code, n.evsid, n.evslabel, INET_NTOA(n.evsip), n.sharename, n.alloccapgb, n.usedcapgb,\n";
$sql .= "  n.protocol, n.filesystem, n.path, n.replication, n.mountpoint, n.serversmapped, n.security \n";
$sql .= "  FROM `" . $main::IDB_NAME . "`.`nasspecs` n\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON n.location_id = lo.id\n";
$sql .= "  ORDER BY n.id;\n";

print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}

# Set column widths -------------------------------------------------------
$nas_ws ->set_column(0, 0, 14); 	# Column A width
$nas_ws ->set_column(1, 1, 12); 	# Column B width
$nas_ws ->set_column(2, 2, 24); 	# Column C width
$nas_ws ->set_column(3, 3, 24); 	# Column D width
$nas_ws ->set_column(4, 4, 38); 	# Column E width
$nas_ws ->set_column(5, 5, 22); 	# Column F width
$nas_ws ->set_column(6, 6, 22); 	# Column G width
$nas_ws ->set_column(7, 7, 14); 	# Column H width
$nas_ws ->set_column(8, 8, 34); 	# Column I width
$nas_ws ->set_column(9, 9, 34); 	# Column J width
$nas_ws ->set_column(10, 10, 14); 	# Column K width
$nas_ws ->set_column(11, 11, 60); 	# Column L width
$nas_ws ->set_column(12, 12, 60); 	# Column M width
$nas_ws ->set_column(13, 13, 80); 	# Column M width

# Spreadsheet Title Row --------------------------------------------------
$nas_ws	->set_row($outNASRows, $ROW_HEIGHT_HDR); # Set row height

$nas_ws 	->write($outNASRows, 0, 'Location', $title_fmt);
$nas_ws 	->write($outNASRows, 1, 'EVS ID', $title_fmt);
$nas_ws 	->write($outNASRows, 2, 'EVS Label', $title_fmt);
$nas_ws 	->write($outNASRows, 3, 'EVS IP', $title_fmt);
$nas_ws 	->write($outNASRows, 4, 'Sharename', $title_fmt);
$nas_ws 	->write($outNASRows, 5, 'Allocated Capacity (GB)', $title_fmt);
$nas_ws 	->write($outNASRows, 6, 'Used Capacity (GB)', $title_fmt);
$nas_ws 	->write($outNASRows, 7, 'Protocol', $title_fmt);
$nas_ws 	->write($outNASRows, 8, 'File System', $title_fmt);
$nas_ws 	->write($outNASRows, 9, 'Path', $title_fmt);
$nas_ws 	->write($outNASRows, 10, 'Replication', $title_fmt);
$nas_ws 	->write($outNASRows, 11, 'Mount Point', $title_fmt);
$nas_ws 	->write($outNASRows, 12, 'Servers Mapped', $title_fmt);
$nas_ws 	->write($outNASRows, 13, 'Security', $title_fmt);
$outExcelRows++;
$outNASRows++;

# Loop through the results from the SQL query
while (my @refr = $sth->fetchrow_array) { # 14 columns returned
	$nas_ws 	->write($outNASRows, 0, $refr[0], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 1, $refr[1], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 2, $refr[2], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 3, $refr[3], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 4, $refr[4], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 5, $refr[5], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 6, $refr[6], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 7, $refr[7], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 8, $refr[8], $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 9, $refr[9], $cell_fmt_ct);
	my $repl = (defined($refr[10]) && $refr[10] ne "" && $refr[10] == 1) ? "YES" : "NO";
	$nas_ws 	->write($outNASRows, 10, $repl, $cell_fmt_ct);
	$nas_ws 	->write($outNASRows, 11, $refr[11], $cell_fmt_lf);
	$nas_ws 	->write($outNASRows, 12, $refr[12], $cell_fmt_lf);
	$nas_ws 	->write($outNASRows, 13, $refr[13], $cell_fmt_lf);
	$outExcelRows++;
	$outNASRows++;
}

$nas_ws->autofilter(0,0,0,13); # set autofilter
$nas_ws->freeze_panes(1,0); # freeze panes on the first row

########################################################################################################################################
## Database worksheet
########################################################################################################################################
my $database_ws 	= $workbookout->add_worksheet('Database');
$database_ws->set_tab_color( $purplerain );

## Set up the SQL SELECT statement to grab the data
$sql = "SELECT l.code, v.number, INET_NTOA(ip.ipv4), INET_NTOA(vip.ipv4), inv.wsibname, inv.rscdname, d.dbname, d.wsibenv, d.instancename, d.appassociated, dbm.manufacturer, dbm.dbtype, dbm.edition, dbm.version, d.patchlevel, d.supported, d.cluster, d.notes  \n";
$sql .= "  FROM `" . $main::IDB_NAME . "`.`dbinst` d\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`dbms` dbm ON d.dbms_id = dbm.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`inventory` inv ON d.inv_id = inv.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`opsinv` op ON inv.opsinv_id = op.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON d.ipadd_id = ip.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` v ON ip.vlan_id = v.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` l ON ip.location_id = l.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` vip ON d.vipadd_id = vip.id\n";
$sql .= "ORDER by ip.ipv4, d.dbname;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}

# Set column widths -------------------------------------------------------
$database_ws ->set_column(0, 0, 16); 	# Column A width
$database_ws ->set_column(1, 1, 16); 	# Column B width
$database_ws ->set_column(2, 2, 18); 	# Column C width
$database_ws ->set_column(3, 3, 18); 	# Column D width
$database_ws ->set_column(4, 4, 20); 	# Column E width
$database_ws ->set_column(5, 5, 20); 	# Column F width
$database_ws ->set_column(6, 6, 24); 	# Column G width
$database_ws ->set_column(7, 7, 22); 	# Column H width
$database_ws ->set_column(8, 8, 30); 	# Column I width
$database_ws ->set_column(9, 9, 32); 	# Column J width
$database_ws ->set_column(10, 10, 36); 	# Column K width
$database_ws ->set_column(11, 11, 22); 	# Column L width
$database_ws ->set_column(12, 12, 16); 	# Column M width
$database_ws ->set_column(13, 13, 16); 	# Column N width
$database_ws ->set_column(14, 14, 60); 	# Column O width

# Spreadsheet Title Row --------------------------------------------------
$database_ws	->set_row($outDatabaseRows, $ROW_HEIGHT_HDR); # Set row height

$database_ws 	->write($outDatabaseRows, 0, 'Location', $title_fmt);
$database_ws 	->write($outDatabaseRows, 1, 'VLAN', $title_fmt);
$database_ws 	->write($outDatabaseRows, 2, 'IP Address', $title_fmt);
$database_ws 	->write($outDatabaseRows, 3, 'VIP Address', $title_fmt);
$database_ws 	->write($outDatabaseRows, 4, 'WSIB Hostname', $title_fmt);
$database_ws 	->write($outDatabaseRows, 5, 'RSCD Shortname', $title_fmt);
$database_ws 	->write($outDatabaseRows, 6, 'DB Name', $title_fmt);
$database_ws 	->write($outDatabaseRows, 7, 'WSIB Environment', $title_fmt);
$database_ws 	->write($outDatabaseRows, 8, 'Instance Name', $title_fmt);
$database_ws 	->write($outDatabaseRows, 9, 'Associated Application', $title_fmt);
$database_ws 	->write($outDatabaseRows, 10, 'DBMS', $title_fmt);
$database_ws 	->write($outDatabaseRows, 11, 'Patch Level', $title_fmt);
$database_ws 	->write($outDatabaseRows, 12, 'Supported', $title_fmt);
$database_ws 	->write($outDatabaseRows, 13, 'Cluster', $title_fmt);
$database_ws 	->write($outDatabaseRows, 14, 'Notes', $title_fmt);
$outExcelRows++;
$outDatabaseRows++;

# Loop through the results from the SQL query
while (my @refr = $sth->fetchrow_array) { # 14 columns returned
	$database_ws 	->write($outDatabaseRows, 0, $refr[0], $cell_fmt_ct); # Location
	$database_ws 	->write($outDatabaseRows, 1, $refr[1], $cell_fmt_ct); # VLAN
	$database_ws 	->write($outDatabaseRows, 2, $refr[2], $cell_fmt_ct); # IP Address
	$database_ws 	->write($outDatabaseRows, 3, $refr[3], $cell_fmt_ct); # VIP Address
	$database_ws 	->write($outDatabaseRows, 4, $refr[4], $cell_fmt_ct); # WSIB name
	$database_ws 	->write($outDatabaseRows, 5, $refr[5], $cell_fmt_ct); # RSCD name
	$database_ws 	->write($outDatabaseRows, 6, $refr[6], $cell_fmt_ct); # DBname
	$database_ws 	->write($outDatabaseRows, 7, $refr[7], $cell_fmt_ct); # WSIB Env
	$database_ws 	->write($outDatabaseRows, 8, $refr[8], $cell_fmt_ct); # Instance name
	$database_ws 	->write($outDatabaseRows, 9, $refr[9], $cell_fmt_ct); # Associated App
	my $rdbms = "";
	$rdbms .= $refr[10] if (defined($refr[10]));
	$rdbms .= " " . $refr[11] if (defined($refr[11]));
	$rdbms .= " " . $refr[12] if (defined($refr[12]));
	$rdbms .= " " . $refr[13] if (defined($refr[13]));
	$rdbms =~ s/^oracle //i;
	$database_ws 	->write($outDatabaseRows, 10, $rdbms, $cell_fmt_ct); # DBMS
	my $this_cell_format = $cell_fmt_ct;
	my $supported = (defined($refr[15]) && $refr[15] ne "" && $refr[15] == 1) ? "YES" : "NO";
	$this_cell_format = $ye_cell_fmt_ct if ($supported eq "NO");
	$database_ws 	->write($outDatabaseRows, 11, $refr[14], $this_cell_format); # patch level
	$database_ws 	->write($outDatabaseRows, 12, $supported, $this_cell_format);
	my $clust = (defined($refr[16]) && $refr[16] ne "" && $refr[16] == 1) ? "YES" : "NO";
	$database_ws 	->write($outDatabaseRows, 13, $clust, $cell_fmt_ct);
	$database_ws 	->write($outDatabaseRows, 14, $refr[17], $cell_fmt_lf);
	$outExcelRows++;
	$outDatabaseRows++;
}

$database_ws->autofilter(0,0,0,14); # set autofilter
$database_ws->freeze_panes(1,0); # freeze panes on the first row


########################################################################################################################################
## NETWORK worksheet
########################################################################################################################################
my $netwk_ws 	= $workbookout->add_worksheet('Network');
$netwk_ws->set_tab_color( 'blue' );

# Set column widths -------------------------------------------------------
$netwk_ws ->set_column(0, 0, 24); 	# Column A width
$netwk_ws ->set_column(1, 1, 12); 	# Column B width
$netwk_ws ->set_column(2, 2, 42); 	# Column C width
$netwk_ws ->set_column(3, 3, 24); 	# Column D width
$netwk_ws ->set_column(4, 4, 18); 	# Column E width
$netwk_ws ->set_column(5, 5, 18); 	# Column F width
$netwk_ws ->set_column(6, 6, 18); 	# Column G width
$netwk_ws ->set_column(7, 7, 18); 	# Column H width ## VIPs
$netwk_ws ->set_column(8, 8, 18); 	# Column I width ## Pools
$netwk_ws ->set_column(9, 9, 18); 	# Column J width ## IPs Migrating -> Server IPs
$netwk_ws ->set_column(10, 10, 16); 	# Column K width
$netwk_ws ->set_column(11, 11, 18); 	# Column L width
$netwk_ws ->set_column(12, 12, 18); 	# Column M width
$netwk_ws ->set_column(13, 13, 18); 	# Column N width
$netwk_ws ->set_column(14, 14, 18); 	# Column O width
$netwk_ws ->set_column(15, 15, 20); 	# Column P width
$netwk_ws ->set_column(16, 16, 20); 	# Column Q width
$netwk_ws ->set_column(17, 17, 20); 	# Column R width
$netwk_ws ->set_column(18, 18, 14); 	# Column S width
$netwk_ws ->set_column(19, 19, 14); 	# Column T width
$netwk_ws ->set_column(20, 20, 14); 	# Column U width
$netwk_ws ->set_column(21, 21, 14); 	# Column V width
$netwk_ws ->set_column(22, 22, 14); 	# Column W width
$netwk_ws ->set_column(23, 23, 14); 	# Column X width
$netwk_ws ->set_column(24, 24, 14); 	# Column Y width

# Spreadsheet Title Row --------------------------------------------------
$netwk_ws	->set_row($outNetworkRows, $ROW_HEIGHT_HDR); # Set row height

#$netwk_ws 	->write(0, 0, 'Migration', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 0, 'Source Location', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 1, 'VLAN', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 2, 'Subnet Description', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 3, 'Subnet', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 4, 'Production', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 5, 'Non-Prod', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 6, 'IPs Operational', $title_fmt); ## new columns below
$netwk_ws 	->write($outNetworkRows, 7, 'LB VIPs', $title_fmt); ## new - vips
$netwk_ws 	->write($outNetworkRows, 8, 'LB Pool IPs', $title_fmt); ## new - pools
$netwk_ws 	->write($outNetworkRows, 9, 'Server IPs', $title_fmt); ## continuing with old cols
$netwk_ws 	->write($outNetworkRows, 10, 'Orphaned IPs', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 11, 'IPs Remaining', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 12, 'Red Flags', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 13, 'Stay Back', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 14, 'VM Size GB', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 15, 'Zone', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 16, 'Environment 1', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 17, 'Environment 2', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 18, 'Wave(s)', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 19, 'Windows', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 20, 'Linux', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 21, 'AIX', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 22, 'Solaris', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 23, 'Other', $title_fmt);
$netwk_ws 	->write($outNetworkRows, 24, 'Total', $title_fmt);
$outExcelRows++;
$outNetworkRows++;

foreach my $vidx (sort keys %NetworkDB) {
	my $this_cell_format = $cell_fmt_ct;
	my $total_sys = $NetworkDB{$vidx}{windows} + $NetworkDB{$vidx}{linux} + $NetworkDB{$vidx}{aix} + $NetworkDB{$vidx}{solaris} + $NetworkDB{$vidx}{other};
	$this_cell_format = $cell_fmt_ct;
	#$netwk_ws 	->write($outNetworkRows, 0, $migration_flag, $this_cell_format);
	$netwk_ws 	->write($outNetworkRows, 0, $NetworkDB{$vidx}{srccode} . ' - ' . $NetworkDB{$vidx}{srcname}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 1, $NetworkDB{$vidx}{vlannum}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 2, $NetworkDB{$vidx}{vlanname}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 3, $NetworkDB{$vidx}{subnet}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 4, $NetworkDB{$vidx}{production}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 5, $NetworkDB{$vidx}{nonprod}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 6, $NetworkDB{$vidx}{inuse}, $cell_fmt_ct);
	### 5/12/20 -- New Load Balancer Counts
	$netwk_ws 	->write($outNetworkRows, 7, $NetworkDB{$vidx}{vips}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 8, $NetworkDB{$vidx}{pools}, $cell_fmt_ct);
	$this_cell_format = $cell_fmt_ct;
	$this_cell_format = $ye_cell_fmt_ct if ($NetworkDB{$vidx}{assigned} && $NetworkDB{$vidx}{events} eq "" && $NetworkDB{$vidx}{inuse} > 0); # we have ips in use, but this subnet isn't in a wave group
	$netwk_ws 	->write($outNetworkRows, 9, $NetworkDB{$vidx}{assigned}, $this_cell_format);
	$this_cell_format = $cell_fmt_ct;
	$this_cell_format = $ye_cell_fmt_ct if ($NetworkDB{$vidx}{orphaned} > 0); # we have orphaned ips
	$netwk_ws 	->write($outNetworkRows, 10, $NetworkDB{$vidx}{orphaned}, $this_cell_format);
	my $ips_remaining = $NetworkDB{$vidx}{inuse} - $NetworkDB{$vidx}{vips} - $NetworkDB{$vidx}{assigned} - $NetworkDB{$vidx}{orphaned};
	$this_cell_format = $cell_fmt_ct;
	$this_cell_format = $ye_cell_fmt_ct if ($ips_remaining > 0); # we have ips remaining in this subnet that are not assigned to a server
	$netwk_ws 	->write($outNetworkRows, 11, $ips_remaining, $this_cell_format);
	$this_cell_format = $cell_fmt_ct;
	$this_cell_format = $re_cell_fmt_ct if ($NetworkDB{$vidx}{redflags} > 0); # we have red flags
	$netwk_ws 	->write($outNetworkRows, 12, $NetworkDB{$vidx}{redflags}, $this_cell_format);
	$netwk_ws 	->write($outNetworkRows, 13, $NetworkDB{$vidx}{stayback}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 14, $NetworkDB{$vidx}{vmsizegb}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 15, $NetworkDB{$vidx}{zone}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 16, $NetworkDB{$vidx}{env1}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 17, $NetworkDB{$vidx}{env2}, $cell_fmt_ct);
	$this_cell_format = $cell_fmt_ct;
	$NetworkDB{$vidx}{events} = reorder($NetworkDB{$vidx}{events});
	$this_cell_format = $ye_cell_fmt_ct if ($NetworkDB{$vidx}{assigned} && $NetworkDB{$vidx}{events} eq "" && $NetworkDB{$vidx}{inuse} > 0); # we have ips in use, but this subnet isn't in a wave group
	$netwk_ws 	->write($outNetworkRows, 18, $NetworkDB{$vidx}{events}, $this_cell_format);
	$netwk_ws 	->write($outNetworkRows, 19, $NetworkDB{$vidx}{windows}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 20, $NetworkDB{$vidx}{linux}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 21, $NetworkDB{$vidx}{aix}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 22, $NetworkDB{$vidx}{solaris}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 23, $NetworkDB{$vidx}{other}, $cell_fmt_ct);
	$netwk_ws 	->write($outNetworkRows, 24, $total_sys, $cell_fmt_ct);
	$outExcelRows++;
	$outNetworkRows++;
}

$netwk_ws->autofilter(0,0,0,24); # set autofilter
$netwk_ws->freeze_panes(1,2); # freeze panes on the first row

########################################################################################################################################
## ORPHANED IPs worksheet -- 4/28/20
########################################################################################################################################
my $orphans_ws 	= $workbookout->add_worksheet('Orphaned IPs');
$orphans_ws->set_tab_color( 'magenta' );

## first, we need to collect and build the list of $lkGIP keys for those identified as orphans -- for the SQL query to grab all of the relevant data
my $orphan_list = "";
foreach my $fip (keys %lkGIP) {
	if ($lkGIP{$fip}{vlan_id} ne "" && $lkGIP{$fip}{location_id} ne "" && !$lkGIP{$fip}{assigned} && $lkGIP{$fip}{inuse} && $lkGIP{$fip}{loadbal} != $main::hashLBScope{vip}) {
		$orphan_list .= "," if ($orphan_list ne "");
		$orphan_list .= $lkGIP{$fip}{id};
	}
}

$sql = "SELECT lo.code, INET_NTOA(ip.ipv4), vl.number, vl.subnet, vl.name, \n";
$sql .= "  	ops.rscdname, ops.wsibname, adm.name, csa.hostname, adm.`type`,\n";
$sql .= "  	csa.devicetype, ak.stackname, vc.name, rv.vmname, rv.rscdname,\n";
$sql .= "  	rv.osperconfig, aos.product, aos.modelver, ops.ostype, ops.osversion, lo.id, ip.loadbal\n";
$sql .= "  FROM `" . $main::IDB_NAME . "`.`ipadd` ip\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON ip.location_id = lo.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vl ON ip.vlan_id = vl.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`opsinv` ops ON ops.ipadd_id = ip.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`adiprel` adr ON adr.ipadd_id = ip.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`addm` adm ON adr.addm_id = adm.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`addmsw` aos ON adm.admos_id = aos.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`rvt` rv ON rv.ipadd_id = ip.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vcenter` vc ON rv.vcenter_id = vc.id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`csasset` csa ON ip.id = csa.ipadd_id\n";
$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`appstack` ak ON csa.appstack_id = ak.id\n";
$sql .= "  WHERE ip.id IN (" . $orphan_list . ") \n";
#$sql .= "    AND ip.loadbal <> 2 \n"; ## 5/12/20 - new filter of VIPs
$sql .= "  ORDER BY lo.code, vl.number, ip.ipv4;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}

# Set column widths -------------------------------------------------------
$orphans_ws ->set_column(0, 0, 16); 	# Column A width
$orphans_ws ->set_column(1, 1, 18); 	# Column B width
$orphans_ws ->set_column(2, 2, 14); 	# Column C width ## Pingable/Active IP
$orphans_ws ->set_column(3, 3, 14); 	# Column D width ## Load Bal 5/12/20
$orphans_ws ->set_column(4, 4, 14); 	# Column E width
$orphans_ws ->set_column(5, 5, 24); 	# Column F width
$orphans_ws ->set_column(6, 6, 40); 	# Column G width
$orphans_ws ->set_column(7, 7, 32); 	# Column H width
$orphans_ws ->set_column(8, 8, 22); 	# Column I width
$orphans_ws ->set_column(9, 9, 12); 	# Column J width
$orphans_ws ->set_column(10, 10, 12); 	# Column K width
$orphans_ws ->set_column(11, 11, 12); 	# Column L width
$orphans_ws ->set_column(12, 12, 12); 	# Column M width
$orphans_ws ->set_column(13, 13, 18); 	# Column N width ##
$orphans_ws ->set_column(14, 14, 18); 	# Column O width
$orphans_ws ->set_column(15, 15, 24); 	# Column P width
$orphans_ws ->set_column(16, 16, 30); 	# Column Q width
$orphans_ws ->set_column(17, 17, 24); 	# Column R width
$orphans_ws ->set_column(18, 18, 24); 	# Column S width
$orphans_ws ->set_column(19, 19, 42); 	# Column T width
$orphans_ws ->set_column(20, 20, 50); 	# Column U width

# Spreadsheet Title Row --------------------------------------------------
$orphans_ws	->set_row($outOrphanRows, $ROW_HEIGHT_HDR); # Set row height
$orphans_ws 	->write($outOrphanRows, 0, 'Location', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 1, 'IP Address', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 2, 'Up/Active', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 3, 'Load Bal.', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 4, 'VLAN #', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 5, 'Subnet', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 6, 'Subnet Description', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 7, 'WSIB Hostname', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 8, 'RSCD Shortname', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 9, 'ADDM', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 10, 'RVTools', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 11, 'CS-Asset', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 12, 'CS-Scan', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 13, 'Wave(s)', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 14, 'ADDM Type', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 15, 'Device Type', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 16, 'Stack Name', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 17, 'vCenter', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 18, 'VM Name', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 19, 'OS/NOS', $title_fmt);
$orphans_ws 	->write($outOrphanRows, 20, 'Analysis', $title_fmt);
$outExcelRows++;
$outOrphanRows++;

# Loop through the results from the SQL query
while (my @refr = $sth->fetchrow_array) {
	my %Orphan = (); # build a local hash for convenience
	$Orphan{location_code} = defined($refr[0]) ? $refr[0] : "";
	$Orphan{ipv4} = defined($refr[1]) ? $refr[1] : "";
	$Orphan{vlannum} = defined($refr[2]) ? $refr[2] : "";
	$Orphan{subnet} = defined($refr[3]) ? $refr[3] : "";
	$Orphan{subnetdesc} = defined($refr[4]) ? $refr[4] : "";
	$Orphan{opsrscdname} = defined($refr[5]) ? $refr[5] : "";
	$Orphan{opswsibname} = defined($refr[6]) ? $refr[6] : "";
	$Orphan{admwsibname} = defined($refr[7]) ? $refr[7] : "";
	$Orphan{csawsibname} = defined($refr[8]) ? $refr[8] : "";
	$Orphan{admtype} = defined($refr[9]) ? $refr[9] : "";
	$Orphan{csadevicetype} = defined($refr[10]) ? $refr[10] : "";
	$Orphan{stackname} = defined($refr[11]) ? $refr[11] : "";
	$Orphan{vcname} = defined($refr[12]) ? $refr[12] : "";
	$Orphan{vmname} = defined($refr[13]) ? $refr[13] : "";
	$Orphan{rvrscdname} = defined($refr[14]) ? $refr[14] : "";
	$Orphan{osperconfig} = defined($refr[15]) ? $refr[15] : "";
	$Orphan{osproduct} = defined($refr[16]) ? $refr[16] : "";
	$Orphan{osmodelver} = defined($refr[17]) ? $refr[17] : "";
	$Orphan{ostype} = defined($refr[18]) ? $refr[18] : "";
	$Orphan{osversion} = defined($refr[19]) ? $refr[19] : "";
	$Orphan{location_id} = defined($refr[20]) ? $refr[20] : "";
	$Orphan{loadbal} = defined($refr[21]) ? $refr[21] : 0;

	my $ipv4 = is_ipv4($Orphan{ipv4}) ? $Orphan{ipv4} : "";
	$Orphan{inaddm} = "";
	$Orphan{inrvt} = "";
	$Orphan{csasset} = "";
	$Orphan{csscan} = "";
	$Orphan{active} = "";
	if ($ipv4 ne "" && exists($lkGIP{$ipv4})) {
		$Orphan{inaddm} = "Y" if ($lkGIP{$ipv4}{inaddm});
		$Orphan{inrvt} = "Y" if ($lkGIP{$ipv4}{inrvt});
		$Orphan{csasset} = "Y" if ($lkGIP{$ipv4}{csasset});
		$Orphan{csscan} = "Y" if ($lkGIP{$ipv4}{csscan});
		$Orphan{active} = "Y" if ($lkGIP{$ipv4}{active});
	}

	## find wsibname, if possible
	$Orphan{wsibname} = "";
	$Orphan{wsibname} = $Orphan{admwsibname} if ($Orphan{wsibname} eq "" && $Orphan{admwsibname} ne "");
	$Orphan{wsibname} = $Orphan{csawsibname} if ($Orphan{wsibname} eq "" && $Orphan{csawsibname} ne "");
	$Orphan{wsibname} = $Orphan{opswsibname} if ($Orphan{wsibname} eq "" && $Orphan{opswsibname} ne "");

	## find rscdname, if possible
	$Orphan{rscdname} = "";
	$Orphan{rscdname} = $Orphan{opsrscdname} if ($Orphan{rscdname} eq "" && $Orphan{opsrscdname} ne "");
	$Orphan{rscdname} = $Orphan{rvrscdname} if ($Orphan{rscdname} eq "" && $Orphan{rvrscdname} ne "");

	## find the addmtype
	my $addm_type = "";
	$addm_type = uc($main::txtADDMtype{$Orphan{admtype}}) if (looks_like_number($Orphan{admtype}));

	## find the OS desc
	$Orphan{osdesc} = "";
	if ($Orphan{osproduct} ne "") {
		$Orphan{osdesc} = $Orphan{osproduct};
		#$Orphan{osdesc} .= " " . $Orphan{osmodelver} if ($Orphan{osmodelver} ne "");
	} elsif ($Orphan{osperconfig} ne "") {
		$Orphan{osdesc} = $Orphan{osperconfig};
	} elsif ($Orphan{ostype} ne "") {
		$Orphan{osdesc} = $Orphan{ostype};
		$Orphan{osdesc} .= " " . $Orphan{osversion} if ($Orphan{osversion} ne "");
	}

	## build a local vidx to figure out which waves are impacted
	$Orphan{events} = "";
	if ($Orphan{location_id} ne "" && looks_like_number($Orphan{vlannum})) {
		my $vidx = $Orphan{location_id} . $IndexDelimit . sprintf("%05d",$Orphan{vlannum});
		$Orphan{events} = $NetworkDB{$vidx}{events} if (exists($NetworkDB{$vidx}));
	}

	## 5/12/20 load balancer data added
	my $lbtxt = "";
	$lbtxt = $main::txtLBScope{$Orphan{loadbal}} if ($Orphan{loadbal} != 0);
	$Orphan{loadbal} = $lbtxt;

	## Perform an analysis based on the known data
	my $data_analysis = "";
	my $not_migrating = 0;
	my $this_is_a_server = 0;
	my $pool_not_connected = 0;
	my $not_orphaned = 0;
	my $marked_decomm = 0;

	## highlight servers
	if($Orphan{csadevicetype} =~ m/server/i || $addm_type =~ /^vm/i) {
		$this_is_a_server = 1;
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Asset appears to be a Server or Appliance that may not be included or missed in the Master Inventory.";
		if ($Orphan{stackname} =~ m/decom/i) {
			$data_analysis .= " Marked as potentially targeted for decommission in Cloudscape Application Stack Name.";
			$marked_decomm = 1;
		}
	}

	if ($addm_type =~ m/^switch/i) {
		$not_migrating = 1;
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Asset appears to be a network switch and will NOT be migrated.";
	}

	if ($Orphan{loadbal} =~ m/^pool/i && $Orphan{wsibname} eq "") {
		$pool_not_connected = 1;
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Asset appears to be a Pool (load balanced) IP address not associated to a server.";
	}

	if ($Orphan{subnetdesc} =~ m/^user_wifi/i && $Orphan{wsibname} eq "" && $Orphan{csscan} eq "Y") {
		$not_migrating = 1;
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Cloudscape scanned asset appears to be an end-user WiFi device on a user WiFi VLAN and will NOT be migrated.";
	}

	if ($Orphan{subnetdesc} =~ m/_ibmzerto_/ig) {
		$not_migrating = 1;
		if ($Orphan{wsibname} eq "" && $Orphan{vmname} =~ /z\-vra/i) {
			$data_analysis .= " " if ($data_analysis ne "");
			$data_analysis .= "Asset appears to be a Zerto VRA Appliance and will NOT be migrated (used during migration only and decommissioned at end of migration).";
		} elsif ($Orphan{wsibname} ne "") {
			$data_analysis .= " " if ($data_analysis ne "");
			$data_analysis .= "Asset appears to be a Zerto ZVM server and will NOT be migrated (used during migration only and decommissioned at end of migration).";
		}
	}

	if ($Orphan{subnetdesc} =~ m/_ibmstoragex_/ig) {
		$not_migrating = 1;
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Asset appears to be associated with StorageX NAS storage migration and will NOT be migrated (used during migration only and decommissioned at end of migration).";
	}

	if ($Orphan{subnetdesc} =~ m/_ibmtransition_mgmt/ig) {
		$not_migrating = 1;
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Asset appears to be associated with Cirrus SAN storage migration and will NOT be migrated (used during migration only and decommissioned at end of migration).";
	}

	if ($Orphan{subnetdesc} =~ m/_mainframe_/ig && $Orphan{wsibname} eq "" && $Orphan{csscan} eq "Y" && $Orphan{events} ne "" && !($addm_type =~ m/^switch/i)) {
		$not_orphaned = 1;
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Asset appears to be a mainframe LPAR and will be migrated along with the mainframe (not an Orphaned IP).";
	}

	if ($Orphan{subnetdesc} =~ m/_ltm_/ig) {
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "Subnet appears to be an F5 Load Balancer VLAN, but the IP address doesn't appear to be associated to a VIP. IP address may be F5 interface OR a firewall OR switch interface into that subnet.";
	}

	if ($Orphan{subnetdesc} =~ m/_hnas/ig) {
		$data_analysis .= " " if ($data_analysis ne "");
		$data_analysis .= "IP address appears to be on an HNAS VLAN, likely indicating a mapping to NAS storage.";
	}

	### output data
	my $this_cell_format = $cell_fmt_ct;
	$this_cell_format = $grey_cell_fmt_ct if ($not_migrating && $data_analysis ne ""); # grey out the row if not migrating and we know why
	$this_cell_format = $gn_cell_fmt_ct if ($not_orphaned && $data_analysis ne ""); # green the row if migrating (not orphaned) and we know why
	$orphans_ws 	->write($outOrphanRows, 0, $Orphan{location_code}, $this_cell_format);
	$this_cell_format = $ye_cell_fmt_ct if (!$not_migrating && ($this_is_a_server || $pool_not_connected));
	$orphans_ws 	->write($outOrphanRows, 1, $ipv4, $this_cell_format);
	$this_cell_format = $cell_fmt_ct if (!$not_migrating && !$not_orphaned);
	$orphans_ws 	->write($outOrphanRows, 2, $Orphan{active}, $this_cell_format);
	$this_cell_format = $ye_cell_fmt_ct if (!$not_migrating && $Orphan{loadbal} ne "" && ($this_is_a_server || $pool_not_connected));
	$orphans_ws 	->write($outOrphanRows, 3, $Orphan{loadbal}, $this_cell_format);
	$this_cell_format = $cell_fmt_ct if (!$not_migrating && !$not_orphaned);
	$orphans_ws 	->write($outOrphanRows, 4, $Orphan{vlannum}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 5, $Orphan{subnet}, $this_cell_format);
	$this_cell_format = $ye_cell_fmt_ct if (!$not_migrating && $Orphan{subnetdesc} ne "" && $pool_not_connected);
	$orphans_ws 	->write($outOrphanRows, 6, $Orphan{subnetdesc}, $this_cell_format);
	$this_cell_format = $cell_fmt_ct if (!$not_migrating && !$not_orphaned);
	$this_cell_format = $ye_cell_fmt_ct if (!$not_migrating && $Orphan{wsibname} ne "" && $this_is_a_server);
	$orphans_ws 	->write($outOrphanRows, 7, $Orphan{wsibname}, $this_cell_format);
	$this_cell_format = $cell_fmt_ct if (!$not_migrating && !$not_orphaned);
	$orphans_ws 	->write($outOrphanRows, 8, $Orphan{rscdname}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 9, $Orphan{inaddm}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 10, $Orphan{inrvt}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 11, $Orphan{csasset}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 12, $Orphan{csscan}, $this_cell_format);
	$this_cell_format = $ye_cell_fmt_ct if (!$not_migrating && $Orphan{events} ne "" && $this_is_a_server);
	$orphans_ws 	->write($outOrphanRows, 13, $Orphan{events}, $this_cell_format); ##
	$this_cell_format = $cell_fmt_ct if (!$not_migrating && !$not_orphaned);
	$orphans_ws 	->write($outOrphanRows, 14, $addm_type, $this_cell_format);
	$this_cell_format = $ye_cell_fmt_ct if (!$not_migrating && $this_is_a_server);
	$orphans_ws 	->write($outOrphanRows, 15, $Orphan{csadevicetype}, $this_cell_format);
	$this_cell_format = $cell_fmt_ct if (!$not_migrating && !$not_orphaned);
	$this_cell_format = $ye_cell_fmt_ct if (!$not_migrating && $marked_decomm);
	$orphans_ws 	->write($outOrphanRows, 16, $Orphan{stackname}, $this_cell_format);
	$this_cell_format = $cell_fmt_ct if (!$not_migrating && !$not_orphaned);
	$orphans_ws 	->write($outOrphanRows, 17, $Orphan{vcname}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 18, $Orphan{vmname}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 19, $Orphan{osdesc}, $this_cell_format);
	$orphans_ws 	->write($outOrphanRows, 20, $data_analysis, $this_cell_format);

	$outExcelRows++;
	$outOrphanRows++;
}

$orphans_ws->autofilter(0,0,0,19); # set autofilter
$orphans_ws->freeze_panes(1,2); # freeze panes on the first row

########################################################################################################################################
## DBMS worksheet
########################################################################################################################################
my $dbms_ws 	= $workbookout->add_worksheet('DBMS');
$dbms_ws->set_tab_color( 'cyan' );

## Set up the SQL SELECT statement to grab the data
$sql = "SELECT manufacturer, dbtype, edition, version, latestrel, eol, eoxs, speol, supported, notes \n";
$sql .= "  FROM `" . $main::IDB_NAME . "`.`dbms`\n";
$sql .= "ORDER by shortname;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}

# Set column widths -------------------------------------------------------
$dbms_ws ->set_column(0, 0, 18); 	# Column A width
$dbms_ws ->set_column(1, 1, 18); 	# Column B width
$dbms_ws ->set_column(2, 2, 18); 	# Column C width
$dbms_ws ->set_column(3, 3, 18); 	# Column D width
$dbms_ws ->set_column(4, 4, 18); 	# Column E width
$dbms_ws ->set_column(5, 5, 18); 	# Column F width
$dbms_ws ->set_column(6, 6, 24); 	# Column G width
$dbms_ws ->set_column(7, 7, 24); 	# Column H width
$dbms_ws ->set_column(8, 8, 18); 	# Column I width
$dbms_ws ->set_column(9, 9, 60); 	# Column J width

# Spreadsheet Title Row --------------------------------------------------
$dbms_ws	->set_row($outDBMSRows, $ROW_HEIGHT_HDR); # Set row height

$dbms_ws 	->write($outDBMSRows, 0, 'Manufacturer', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 1, 'Type', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 2, 'Edition', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 3, 'Version', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 4, 'Latest Release', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 5, 'End of Life', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 6, 'End of Extended Support', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 7, 'Service Pack End of Life', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 8, 'Supported', $title_fmt);
$dbms_ws 	->write($outDBMSRows, 9, 'Notes', $title_fmt);
$outExcelRows++;
$outDBMSRows++;

# Loop through the results from the SQL query
while (my @refr = $sth->fetchrow_array) { # 14 columns returned
	my $supported = (defined($refr[8]) && $refr[8] ne "" && $refr[8] == 1) ? "YES" : "NO";
	my $this_cell_format = ($supported eq "YES") ? $cell_fmt_ct : $ye_cell_fmt_ct;
	$dbms_ws 	->write($outDBMSRows, 0, $refr[0], $cell_fmt_ct); # manufacturer
	$dbms_ws 	->write($outDBMSRows, 1, $refr[1], $cell_fmt_ct); # type
	$dbms_ws 	->write($outDBMSRows, 2, $refr[2], $cell_fmt_ct); # edition
	$dbms_ws 	->write($outDBMSRows, 3, $refr[3], $cell_fmt_ct); # version
	$dbms_ws 	->write($outDBMSRows, 4, $refr[4], $cell_fmt_ct); # latest rel
	$dbms_ws 	->write($outDBMSRows, 5, $refr[5], $this_cell_format); # end of life
	$dbms_ws 	->write($outDBMSRows, 6, $refr[6], $this_cell_format); # end of ext. support
	$dbms_ws 	->write($outDBMSRows, 7, $refr[7], $this_cell_format); # service pack eol
	$dbms_ws 	->write($outDBMSRows, 8, $supported, $this_cell_format); # supported
	$dbms_ws 	->write($outDBMSRows, 9, $refr[9], $cell_fmt_lf); # notes
	$outExcelRows++;
	$outDBMSRows++;
}

$dbms_ws->autofilter(0,0,0,9); # set autofilter
$dbms_ws->freeze_panes(1,0); # freeze panes on the first row

########################################################################################################################################
## TRACKING worksheet
########################################################################################################################################
$sql = "SELECT type, message, lastupdate \n";
$sql .= "FROM `" . $main::IDB_NAME . "`.`notify` ORDER by type, id;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
## Only create the workbook if there are more than 0 rows
if ( $sth->rows > 0 ) {
	my $tracking_ws 	= $workbookout->add_worksheet('Tracking');
	$tracking_ws->set_tab_color( 'white' );

	# Set column widths -------------------------------------------------------
	$tracking_ws ->set_column(0, 0, 10); 	# Column A width
	$tracking_ws ->set_column(1, 1, 16); 	# Column B width
	$tracking_ws ->set_column(2, 2, 80); 	# Column C width
	$tracking_ws ->set_column(3, 3, 24); 	# Column D width

	# Spreadsheet Title Row --------------------------------------------------
	$tracking_ws	->set_row(0, $ROW_HEIGHT_HDR); # Set row height

	$tracking_ws 	->write(0, 0, 'ID #', $title_fmt);
	$tracking_ws 	->write(0, 1, 'Type', $title_fmt_lf);
	$tracking_ws 	->write(0, 2, 'Message', $title_fmt_lf);
	$tracking_ws 	->write(0, 3, 'Last Update', $title_fmt_lf);
	$outExcelRows++;
	$outTrackingRows++;

	# Loop through the results from the SQL query
	my $iRows = 1;
	while (my @refr = $sth->fetchrow_array) {
		$tracking_ws 	->write($iRows, 0, $iRows, $cell_fmt_ct);
		$tracking_ws 	->write($iRows, 1, $refr[0], $cell_fmt_lf);
		$tracking_ws 	->write($iRows, 2, $refr[1], $cell_fmt_lf);
		$tracking_ws 	->write($iRows, 3, $refr[2], $cell_fmt_lf);
		$outExcelRows++;
		$outTrackingRows++;
		$iRows++;
	}
	$tracking_ws->autofilter(0,0,0,3); # set autofilter
	$tracking_ws->freeze_panes(1,0); # freeze panes on the first row
}

########################################################################################################################################
## DATA ERRORS worksheet
########################################################################################################################################
$sql = "SELECT type, errorlog, lastupdate \n";
$sql .= "FROM `" . $main::IDB_NAME . "`.`errors` ORDER by type, id;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
## Only create the workbook if there are more than 0 rows
if ( $sth->rows > 0 ) {
	my $errors_ws 	= $workbookout->add_worksheet('Data Errors');
	$errors_ws->set_tab_color( 'orange' );

	# Set column widths -------------------------------------------------------
	$errors_ws ->set_column(0, 0, 10); 	# Column A width
	$errors_ws ->set_column(1, 1, 16); 	# Column B width
	$errors_ws ->set_column(2, 2, 80); 	# Column C width
	$errors_ws ->set_column(3, 3, 24); 	# Column D width

	# Spreadsheet Title Row --------------------------------------------------
	$errors_ws	->set_row(0, $ROW_HEIGHT_HDR); # Set row height

	$errors_ws 	->write(0, 0, 'ID #', $title_fmt);
	$errors_ws 	->write(0, 1, 'Type', $title_fmt_lf);
	$errors_ws 	->write(0, 2, 'Error Log', $title_fmt_lf);
	$errors_ws 	->write(0, 3, 'Last Update', $title_fmt_lf);
	$outExcelRows++;
	$outErrorRows++;

	# Loop through the results from the SQL query
	my $iRows = 1;
	while (my @refr = $sth->fetchrow_array) {
		$errors_ws 	->write($iRows, 0, $iRows, $cell_fmt_ct);
		$errors_ws 	->write($iRows, 1, $refr[0], $cell_fmt_lf);
		$errors_ws 	->write($iRows, 2, $refr[1], $cell_fmt_lf);
		$errors_ws 	->write($iRows, 3, $refr[2], $cell_fmt_lf);
		$outExcelRows++;
		$outErrorRows++;
		$iRows++;
	}
	#$errors_ws->autofilter('A0:B0') if ($iRows > 1);    # Set autofilters
	$errors_ws->autofilter(0,0,0,3); # set autofilter
	$errors_ws->freeze_panes(1,0); # freeze panes on the first row
}

########################################################################################################################################
## Create the METRICS worksheet
########################################################################################################################################
my $metrics_ws 	= $workbookout->add_worksheet('Metrics');
$metrics_ws->set_tab_color( $darkgreen );

$metrics_ws ->set_column(0, 0, 28); 	# Column A width
$metrics_ws ->set_column(1, 1, 28); 	# Column B width
$metrics_ws ->set_column(2, 2, 28); 	# Column C width

$metrics_ws	->merge_range($outMetricsRows,0,$outMetricsRows,2, 'System Migration Overview', $dkgn_title_fmt); # merge cells on the title row
$metrics_ws	->set_row($outMetricsRows, $ROW_HEIGHT_HDR); # Set row height
$outMetricsRows++;
$outExcelRows++;

## Build the rows from the MigrOvr accumulators
$metrics_ws 	->write($outMetricsRows, 0, 'Windows VMs', $dkgn_title_fmt);
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to show the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$metrics_ws 	->write($outMetricsRows, 1, $disptxt . ':' , $dkgn_cell_fmt_rt);
	$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Windows VM'}{$disptxt} , $gn_cell_fmt_lf);
	$outMetricsRows++;
	$outExcelRows++;
}

$metrics_ws 	->write($outMetricsRows, 1, 'Migrations Completed:' , $dkgn_cell_fmt_rt);
$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Windows VM'}{completed} , $gn_cell_fmt_lf);
$outMetricsRows++;
$outExcelRows++;

## skip a row
$outMetricsRows++;
$outExcelRows++;

$metrics_ws 	->write($outMetricsRows, 0, 'Linux VMs', $dkgn_title_fmt);
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to show the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$metrics_ws 	->write($outMetricsRows, 1, $disptxt . ':' , $dkgn_cell_fmt_rt);
	$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Linux VM'}{$disptxt} , $gn_cell_fmt_lf);
	$outMetricsRows++;
	$outExcelRows++;
}

$metrics_ws 	->write($outMetricsRows, 1, 'Migrations Completed:' , $dkgn_cell_fmt_rt);
$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Linux VM'}{completed} , $gn_cell_fmt_lf);
$outMetricsRows++;
$outExcelRows++;

## skip a row
$outMetricsRows++;
$outExcelRows++;

$metrics_ws 	->write($outMetricsRows, 0, 'Total VMs', $dkgn_title_fmt);
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to show the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$metrics_ws 	->write($outMetricsRows, 1, $disptxt . ':' , $dkgn_cell_fmt_rt);
	$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Total VM'}{$disptxt} , $gn_cell_fmt_lf);
	$outMetricsRows++;
	$outExcelRows++;
}

$metrics_ws 	->write($outMetricsRows, 1, 'Migrations Completed:' , $dkgn_cell_fmt_rt);
$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Total VM'}{completed} , $gn_cell_fmt_lf);
$outMetricsRows++;
$outExcelRows++;

## skip a row
$outMetricsRows++;
$outExcelRows++;

$metrics_ws 	->write($outMetricsRows, 0, 'P-LPARs', $dkgn_title_fmt);
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to show the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$metrics_ws 	->write($outMetricsRows, 1, $disptxt . ':' , $dkgn_cell_fmt_rt);
	$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'P-LPAR'}{$disptxt} , $gn_cell_fmt_lf);
	$outMetricsRows++;
	$outExcelRows++;
}

$metrics_ws 	->write($outMetricsRows, 1, 'Migrations Completed:' , $dkgn_cell_fmt_rt);
$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'P-LPAR'}{completed} , $gn_cell_fmt_lf);
$outMetricsRows++;
$outExcelRows++;

## skip a row
$outMetricsRows++;
$outExcelRows++;

$metrics_ws 	->write($outMetricsRows, 0, 'Solaris Containers', $dkgn_title_fmt);
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to show the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$metrics_ws 	->write($outMetricsRows, 1, $disptxt . ':' , $dkgn_cell_fmt_rt);
	$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Container'}{$disptxt} , $gn_cell_fmt_lf);
	$outMetricsRows++;
	$outExcelRows++;
}

$metrics_ws 	->write($outMetricsRows, 1, 'Migrations Completed:' , $dkgn_cell_fmt_rt);
$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Container'}{completed} , $gn_cell_fmt_lf);
$outMetricsRows++;
$outExcelRows++;

## skip a row
$outMetricsRows++;
$outExcelRows++;

$metrics_ws 	->write($outMetricsRows, 0, 'Hardware', $dkgn_title_fmt);
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to show the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$metrics_ws 	->write($outMetricsRows, 1, $disptxt . ':' , $dkgn_cell_fmt_rt);
	$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Hardware'}{$disptxt} , $gn_cell_fmt_lf);
	$outMetricsRows++;
	$outExcelRows++;
}

$metrics_ws 	->write($outMetricsRows, 1, 'Migrations Completed:' , $dkgn_cell_fmt_rt);
$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Hardware'}{completed} , $gn_cell_fmt_lf);
$outMetricsRows++;
$outExcelRows++;

## skip a row
$outMetricsRows++;
$outExcelRows++;

$metrics_ws 	->write($outMetricsRows, 0, 'Total Program', $dkgn_title_fmt);
foreach my $key (sort keys %main::txtSYSDisposition) { ## loop through all of the system dispositions to show the counts
	my $disptxt = $main::txtSYSDisposition{$key};
	$metrics_ws 	->write($outMetricsRows, 1, $disptxt . ':' , $dkgn_cell_fmt_rt);
	$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Total'}{$disptxt} , $gn_cell_fmt_lf);
	$outMetricsRows++;
	$outExcelRows++;
}

$metrics_ws 	->write($outMetricsRows, 1, 'Migrations Completed:' , $dkgn_cell_fmt_rt);
$metrics_ws 	->write($outMetricsRows, 2, $MigrOvr{'Total'}{completed} , $gn_cell_fmt_lf);
$outMetricsRows++;
$outExcelRows++;

########################################################################################################################################
## Update and continue the INFO worksheet with the run metrics
########################################################################################################################################
$info_ws	->merge_range($outInfoRows,0,$outInfoRows,4, '', $cell_fmt_lbl); # skip a row
$outInfoRows++;
$outExcelRows++;

$info_ws 	->write($outInfoRows, 0, 'Seq/Script Name', $title_fmt);
$info_ws 	->write($outInfoRows, 1, 'Script Name/Description', $title_fmt);
$info_ws 	->write($outInfoRows, 2, 'Data Source Constraints', $title_fmt);
$info_ws 	->write($outInfoRows, 3, 'Last Run', $title_fmt);
$info_ws 	->write($outInfoRows, 4, 'File Rows I/O', $title_fmt);
$info_ws	->set_row($outInfoRows, $ROW_HEIGHT_HDR); # Set row height
$outInfoRows++;
$outExcelRows++;

## Update stats
$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_out = " . $outMasterRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-master-gen.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

## Read DSATtrack table -- new on 3/12/20
$sql = "SELECT datasrcscript, lastrun, rows_in, rows_out, datasrcname, datasrcdesc, datasrcconst, script_seq  \n";
$sql .= " FROM `" . $main::IDB_NAME . "`.`dsattrack` ORDER BY script_seq;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $scriptname = $refr[0];
	my $lastrun = (defined($refr[1])) ? $refr[1] : "";
	my $rows_in = (defined($refr[2])) ? $refr[2] : "";
	my $rows_out = (defined($refr[3])) ? $refr[3] : "";
	my $srcname = (defined($refr[4])) ? $refr[4] : "";
	my $srcdesc = (defined($refr[5])) ? $refr[5] : "";
	my $srcconst = (defined($refr[6])) ? $refr[6] : "";
	my $seq = (defined($refr[7])) ? $refr[7] : "";
	$info_ws 	->write($outInfoRows, 0, $seq  . ". " . $srcname , $cell_fmt_ct);
	$info_ws 	->write($outInfoRows, 1, $scriptname . "\n" . $srcdesc , $cell_fmt_ct);
	$info_ws 	->write($outInfoRows, 2, $srcconst , $cell_fmt_ct);
	$info_ws 	->write($outInfoRows, 3, $lastrun , $cell_fmt_ct);
	my $rowsrpt = "";
	$rowsrpt = "In: " . num_commify($rows_in) if ($rows_in ne "");
	$rowsrpt = "Out: " . num_commify($rows_out) if ($rows_out ne "");
	$info_ws 	->write($outInfoRows, 4, $rowsrpt , $cell_fmt_ct);
	$outInfoRows++;
	$outExcelRows++;
}

print "\n************************\n";
print "Excel Writes\t:" . $outExcelRows . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
$workbookout->close(); # close and write the workbook
exit;

############################################################################
sub reorder_vlans
############################################################################
{
	# Localize the variables used in this subroutine.
	my($strin) = @_;
	my $strout = "";
	return "" if ( !defined($strin) );
	$strin =~ s/\r\n//g; # remove the carriage returns and line feeds
	my @inarray = split(/;\s*/,$strin); # split out to an array
	foreach my $vln (sort @inarray) {
		$strout .= ", " if ($strout ne ""); # add a separator
		$strout .= sprintf("%d",$vln); # remove the leading zeros
	}
	return($strout);
}	##reorder_vlans

############################################################################
sub reorder_connected_vlans
############################################################################
{
	# Localize the variables used in this subroutine.
	my($strin) = @_;
	my $strout = "";
	return "" if ( !defined($strin) );
	$strin =~ s/\r\n//g; # remove the carriage returns and line feeds
	my @inarray = split(/;\s*/,$strin); # split out to an array
	my @fmtarray = ();
	foreach my $vlan (@inarray) {
		my ($loc, $vlnum) = split(/\#/,$vlan); # split into a pair - loc vlnum
		my $refmt = $loc . "#" . sprintf("%05d",$vlnum);
		push (@fmtarray,$refmt);
	}
	foreach my $vlan (sort @fmtarray) {
		my ($loc, $vlnum) = split(/\#/,$vlan); # split into a pair - loc vlnum
		my $refmt = $loc . "#" . sprintf("%d",$vlnum);
		$strout .= ", " if ($strout ne ""); # add a separator
		$strout .= $refmt;
	}
	return($strout);
}	##reorder_vlans
