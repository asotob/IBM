#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	RVTools File Load (Import)
### Date:		July 27, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 2/19/20 - Major revamp of IP Address handling
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("RVTOOLS LOAD/UPDATE");

die "You must provide an RVTools Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

# reset data?
my $fResetData;
$fResetData = (defined($ARGV[1]) && lc($ARGV[1]) eq "reset") ? 1 : 0;

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkRVT	 				= ();	# hash table to lookup RVT records already in the database
my %lkVC	 				= ();	# hash table to lookup VCENTER records already in the database
my %lkGIP	 				= ();	# hash table to lookup Global IP addresses already in the database
my %lkOPS	 				= ();	# hash table to lookup OPS records already in the database by rscd shortname
my %lkSUBNT					= ();	# hash table to lookup SUBNET already in the VLAN database
my @FSUBS					= (); 	# array for fast IP to subnet validation
my %vDisk	 				= ();	# hash table for vDisk info by VM uuid

my $iExcelRows 				= 0;  # total number of excel rows read
my $DEBUGSQL 				= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 		# this is the row to stop checking for headers and fail if all headers haven't been found

my $FileLocCode	= $file; # start by copying the filename
$FileLocCode =~ s/^WSIB_//i; # if the string starts with WSIB_ remove that chunk
$FileLocCode =~ s/^MTL_//i; # if the new string starts with MTL_ remove that chunk
my $FileVCenter		= trim($FileLocCode); # the rest of the string up to the . in the filename should be the Vcenter name
$FileLocCode = uc(substr($FileLocCode,0,3)); #first 3 characters are the location code
$FileVCenter =~ s/\..*//; # remove everything after the ., including the .
$FileVCenter = uc($FileVCenter); # uppercase the VCENTER for consistency
$FileVCenter =~ s/\_/ /; # all the underscores in the name become blanks

my $iSqlErr	= 0;
my $iSqlRVInsert = 0;
my $iSqlVCInsert = 0;
my $iSqlVCUpdate = 0;
my $iSqlRVUpdate = 0;
my $iSqlIPInsert = 0;
my $iSqlIPUpdate = 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		print "******* LKU LOC: " . $cd . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
	}
}
# Assure that we have a valid location code, or die
if ($FileLocCode ne "" && !exists($lkLOC{$FileLocCode})) {
	$dbh->disconnect();
	die "Location provided in the filename: " . $FileLocCode . " does not exist. Please assure the first 3 characters of the filename indicate the location.\n";
}

if ((grep { /opsinv/ } @dbTables) == 0) {
	print "Table: opsinv not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT op.rscdname, op.id, op.ipadd_id \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`opsinv` op \n";
	$sql .= "  WHERE op.ipadd_id IS NOT NULL;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0]; # rscdname
		$lkOPS{$lkey}{id} = $refr[1];
		$lkOPS{$lkey}{ipadd_id} = "";
		$lkOPS{$lkey}{ipadd_id} = $refr[2] if (defined($refr[2]));
		print "******* LKU OPS: lkey=" .  $lkey . " db key: " . $lkOPS{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /vcenter/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: vcenter not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, vmuuid FROM `" . $main::IDB_NAME . "`.`rvt`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $lkLOC{$FileLocCode}{id} . $refr[1]; # location ID + VMUUID
		$lkRVT{$lkey}{id} = $refr[0];
		print "******* LKU RVT: " . $lkey . " dbid: " . $lkRVT{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /rvt/ } @dbTables) == 0) {
	print "Table: rvt not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} elsif ( $fResetData && (grep { /rvt/ } @dbTables) > 0) {		# process reset
	print "**** Remove all rows and refresh\n";
	$result = $dbh->do("TRUNCATE `" . $main::IDB_NAME . "`.`rvt`;");    # delete all the rows from the table and reset the autoincrement
} else {
	$sql = "SELECT 	id, name, INET_NTOA(ipv4) \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`vcenter`\n";
	$sql .= "  WHERE location_id = " . $lkLOC{$FileLocCode}{id} . ";\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		print "******* LKU VC: lkey=" .  $refr[1] . " db key: " . $refr[0] . "\n" if ($DEBUGSQL); # debug sql
		$lkVC{$refr[1]}{id} = $refr[0];
		$lkVC{$refr[1]}{ipv4} = $refr[2];
	}
}

# IP table lookups
$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), location_id, id, inrvt FROM `" . $main::IDB_NAME . "`.`ipadd`");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $fip = $refr[0];
	$lkGIP{$fip}{location_id} = (defined($refr[1]) ? $refr[1] : "");
	$lkGIP{$fip}{id} = $refr[2]; # the id table index is the data
	$lkGIP{$fip}{inrvt} = (defined($refr[3]) ? $refr[3] : 0);
	$lkGIP{$fip}{this_inrvt} = 0; # tracking
	$lkGIP{$fip}{this_run} = 0; # tracking - touched this run
	print "******* LKU GIP: fip=" . $fip . " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}
## New code 2/19/20 - Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

## Check to see if the VCENTER record exists
if (!exists($lkVC{$FileVCenter})) {
	$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`vcenter` SET \n";
	$sql .= "   location_id = ". $lkLOC{$FileLocCode}{id} . ",\n";
	$sql .= "   name = \'". $FileVCenter . "\',\n";
	$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		$iSqlVCInsert++;
		$lkVC{$FileVCenter}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
		$lkVC{$FileVCenter}{ipv4} = "";
	}
}

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

my $current_sheet = "";
my $keycount = 0;
my $TotalHeaders	= 2;
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
my $row_min=0;
my $row_max=0;
my $col_min=0;
my $col_max=0;

### vMetaData WORKSHEET
my $vmeta_ws = $workbook->worksheet('vMetaData');

if (defined($vmeta_ws)) {
	$current_sheet = trim($vmeta_ws->get_name());

	# Find out the worksheet ranges
	( $row_min, $row_max ) = $vmeta_ws->row_range();
	( $col_min, $col_max ) = $vmeta_ws->col_range();

	print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

	$keycount = 0;
	$TotalHeaders	= 2;	# total number of column headers we need to find in this worksheet to proceed with processing
	%xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
	$FIRST_DATA_ROW = 2;

	for my $row ( $row_min .. $row_max ) {
		$iExcelRows++; # increment total Excel row counter
		if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
			for my $col ( $col_min .. $col_max ) {
				my $cell = $vmeta_ws->get_cell( $row, $col ); # Return the cell object at $row and $col
				next unless $cell;
				my $fld = lc(trim($cell->value()));
				if 	( $fld =~ m/xlsx creation/i ) {
					$xlsCol{lastrun} = $col;
					$keycount++;
				} elsif ( $fld =~ m/server/i ) {
					$xlsCol{vcenteripv4} = $col;
					$keycount++;
				} # end if
			} # end for col
		} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
			print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
			print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
			print "****        KEYS FOUND:\n";
			foreach my $key (sort keys %xlsCol) {
				print "****           $key\n";
			}
			$dbh->disconnect(); # disconnect gracefully
			die;
		} elsif ($keycount == $TotalHeaders) {
			# new code for localized values
			my %xlsRowVal	= ();	# hash table to contain excel row values
			foreach my $key (keys %xlsCol) {
				my $cell = $vmeta_ws->get_cell( $row, $xlsCol{$key} );
				$xlsRowVal{$key} = "";
				$xlsRowVal{$key} = trim($cell->value()) if $cell;
			}

			$xlsRowVal{lastrun} = substr($xlsRowVal{lastrun},0,255);
			$xlsRowVal{vcenteripv4} = ipfmt(substr($xlsRowVal{vcenteripv4},0,255));

			if (exists($lkVC{$FileVCenter})) {
				$sql = "UPDATE `" . $main::IDB_NAME . "`.`vcenter` SET \n";
				$sql .= "   ipv4 = INET_ATON(\'" . $xlsRowVal{vcenteripv4} . "\'),\n" if (defined($xlsRowVal{vcenteripv4}) && is_ipv4($xlsRowVal{vcenteripv4}));
				$sql .= "   lastrun = \'". $xlsRowVal{lastrun} . "\',\n" if ($xlsRowVal{lastrun} ne "");
				$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
				$sql .= "   WHERE id = ". $lkVC{$FileVCenter}{id} . ";\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlVCUpdate++;
				}
			}
		} # found headers
	} # for my row loop
} # if vMetaData worksheet defined

### VDISK WORKSHEET
my $vdisk_ws = $workbook->worksheet('vDisk');

if (!defined($vdisk_ws)) {
	$dbh->disconnect();
	die "ERROR -- vDisk worksheet not found.\n";
}

$current_sheet = trim($vdisk_ws->get_name());

# Find out the worksheet ranges
( $row_min, $row_max ) = $vdisk_ws->row_range();
( $col_min, $col_max ) = $vdisk_ws->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

$keycount = 0;
$TotalHeaders	= 3;	# total number of column headers we need to find in this worksheet to proceed with processing
%xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 2;

if (defined($vdisk_ws)) {
	for my $row ( $row_min .. $row_max ) {
		$iExcelRows++; # increment total Excel row counter
		if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
			for my $col ( $col_min .. $col_max ) {
				my $cell = $vdisk_ws->get_cell( $row, $col ); # Return the cell object at $row and $col
				next unless $cell;
				my $fld = lc(trim($cell->value()));
				if 	( $fld =~ m/vm uuid/i ) {
					$xlsCol{vmuuid} = $col;
					$keycount++;
				} elsif ( $fld =~ m/raw/i ) {
					$xlsCol{raw} = $col;
					$keycount++;
				} elsif ( $fld =~ m/thin/i ) {
					$xlsCol{thin} = $col;
					$keycount++;
				} # end if
			} # end for col
		} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
			print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
			print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
			print "****        KEYS FOUND:\n";
			foreach my $key (sort keys %xlsCol) {
				print "****           $key\n";
			}
			$dbh->disconnect(); # disconnect gracefully
			die;
		} elsif ($keycount == $TotalHeaders) {
			# new code for localized values
			my %xlsRowVal	= ();	# hash table to contain excel row values
			foreach my $key (keys %xlsCol) {
				my $cell = $vdisk_ws->get_cell( $row, $xlsCol{$key} );
				$xlsRowVal{$key} = "";
				$xlsRowVal{$key} = trim($cell->value()) if $cell;
			}
			## tally the vDisk info by vmuuid
			$xlsRowVal{vmuuid} = substr($xlsRowVal{vmuuid},0,40);
			my $assetVMuuid = $xlsRowVal{vmuuid};
			my $assetRaw = ($xlsRowVal{raw} =~ m/true/i) ? 1 : 0;
			my $assetThin = ($xlsRowVal{thin} =~ m/true/i) ? 1 : 0;
			if (exists($vDisk{$assetVMuuid})) {
				$vDisk{$assetVMuuid}{raw} += $assetRaw;
				$vDisk{$assetVMuuid}{thin} += $assetThin;
			} else { # vDisk{uuid} doesn't exist
				$vDisk{$assetVMuuid}{raw} = $assetRaw;
				$vDisk{$assetVMuuid}{thin} = $assetThin;
			}
		} # found headers
	} # for my row loop
} # if vDisk worksheet defined

### VINFO WORKSHEET
my $worksheet = $workbook->worksheet('vInfo');

if (!defined($worksheet)) {
	$dbh->disconnect();
	die "ERROR -- vInfo worksheet not found.\n";
}

$current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
( $row_min, $row_max ) = $worksheet->row_range();
( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

$keycount = 0;
$TotalHeaders	= 22;	# total number of column headers we need to find in this worksheet to proceed with processing
%xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 2;

for my $row ( $row_min .. $row_max ) {
	$iExcelRows++; # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if 	( $fld eq 'vm' ) {
				$xlsCol{vmname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/powerstate/i ) {
				$xlsCol{powerstate} = $col;
				$keycount++;
			} elsif ( $fld =~ m/template/i ) {
				$xlsCol{template} = $col;
				$keycount++;
			} elsif ( $fld =~ m/dns name/i ) {
				$xlsCol{dnsname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/connection state/i ) {
				$xlsCol{connectstate} = $col;
				$keycount++;
			} elsif ( $fld =~ m/guest state/i ) {
				$xlsCol{gueststate} = $col;
				$keycount++;
			} elsif ( $fld =~ m/cpus/i ) {
				$xlsCol{cpus} = $col;
				$keycount++;
			} elsif ( $fld =~ m/memory/i ) {
				$xlsCol{memory} = $col;
				$keycount++;
			} elsif ( $fld =~ m/nics/i ) {
				$xlsCol{nics} = $col;
				$keycount++;
			} elsif ( $fld =~ m/disks/i ) {
				$xlsCol{disks} = $col;
				$keycount++;
			} elsif ( $fld =~ m/latency sens/i ) {
				$xlsCol{latencysens} = $col;
				$keycount++;
			} elsif ( $fld =~ m/primary ip add/i ) {
				$xlsCol{primaryip} = $col;
				$keycount++;
			} elsif ( $fld =~ m/network #1/i ) {
				$xlsCol{nw1} = $col;
				$keycount++;
			} elsif ( $fld =~ m/network #2/i ) {
				$xlsCol{nw2} = $col;
				$keycount++;
			} elsif ( $fld =~ m/network #3/i ) {
				$xlsCol{nw3} = $col;
				$keycount++;
			} elsif ( $fld =~ m/network #4/i ) {
				$xlsCol{nw4} = $col;
				$keycount++;
			} elsif ( $fld =~ m/cluster/i ) { # new on 7/24/20
				$xlsCol{clustername} = $col;
				$keycount++;
			} elsif ( $fld eq "provisioned mb" ) {
				$xlsCol{provisionmb} = $col;
				$keycount++;
			} elsif ( $fld eq "in use mb" ) { # new on 7/24/20
				$xlsCol{inusemb} = $col;
				$keycount++;
			} elsif ( $fld =~ m/vm uuid/i ) {
				$xlsCol{vmuuid} = $col;
				$keycount++;
			} elsif ( $fld =~ m/according to the configuration/i ) {
				$xlsCol{vmosconfig} = $col;
				$keycount++;
			} elsif ( $fld =~ m/according to the vmware tools/i ) {
				$xlsCol{vmostools} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		# NEW CODE TO LOCALIZE ROW VALUES
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if $cell;
		}
		next if ($xlsRowVal{vmname} eq ""); # skip if there is no VMname
		next if ($xlsRowVal{vmuuid} eq ""); # skip if there is no VM UUID = key

		# SET UP THE SQL CODE FOR INSERT OR UPDATE OF IPADDR TABLE
		my $assetIPkey = "";
		my $assetOPSkey = ""; # new!!! 1/10/20
		my $assetRName = "";
		my $assetVMuuid = "";
		my $XLRow = $row + 1;

		$xlsRowVal{vmname} = substr($xlsRowVal{vmname},0,255);
		if (exists($xlsRowVal{vmname}) && $xlsRowVal{vmname} =~ m/\_/) { # name contains underscore?
			my @vmn = split('_',$xlsRowVal{vmname}); # split by underscore
			if (defined($vmn[0]) && trim($vmn[0]) ne "") {
				$assetRName = lc(trim($vmn[0]));
			}
		}
		if ($assetRName eq "" && exists($xlsRowVal{vmname}) && $xlsRowVal{vmname} =~ m/\-/) { # name contains dash?
			my @vmn = split('-',$xlsRowVal{vmname}); # split by underscore
			if (defined($vmn[0]) && trim($vmn[0]) ne "") {
				$assetRName = lc(trim($vmn[0]));
			}
		}

		## lookup the OPS key
		if ($assetRName ne "" && exists($lkOPS{$assetRName})) {
			$assetOPSkey = $lkOPS{$assetRName}{id};
			$assetIPkey = $lkOPS{$assetRName}{ipadd_id};
		}

		## 2/19/20 - Check if the IP is in a valid subnet range
		my $assetPrimaryIP = ipfmt($xlsRowVal{primaryip});
		if (is_ipv4($assetPrimaryIP)) { # we still have a valid IPv4 format
			my $sn = $SubClassifier->($assetPrimaryIP); # find the subnet in range quickly
			my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
			my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

			if (exists($lkGIP{$assetPrimaryIP})) {
				$assetIPkey = $lkGIP{$assetPrimaryIP}{id};
				$lkGIP{$assetPrimaryIP}{this_inrvt} = 1; # now in RVTools
				$lkGIP{$assetPrimaryIP}{this_run} = 1; # tracking - touched this run
			} else { # IP doesn't exist already
				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
				$sql .= "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
				$sql .= "   ipv4 = INET_ATON(\'" . $assetPrimaryIP  . "\'),\n";
				$sql .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
				$sql .= "   inrvt = 1,\n";
				$sql .= "   inuse = 1,\n";
				$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlIPInsert++;
					$lkGIP{$assetPrimaryIP}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
					$assetIPkey = $lkGIP{$assetPrimaryIP}{id};
					$lkGIP{$assetPrimaryIP}{inrvt} = 1; # now in RVTools
					$lkGIP{$assetPrimaryIP}{this_inrvt} = 1; # now in RVTools
					$lkGIP{$assetPrimaryIP}{this_run} = 0; # tracking - touched this run (no need to update because we just inserted)
				} # we inserted a record
			} # lkGIP found
		} else {
			$assetPrimaryIP  = ""; # not a valid IP address
		}

		# continue on with the RVT specific fields
		my $istemplate = 0;
		$istemplate = 1  if (lc($xlsRowVal{template}) eq "true");

		# clean up the values to assure clean db queries
		$xlsRowVal{vmuuid} = substr($xlsRowVal{vmuuid},0,40);
		$assetVMuuid = $xlsRowVal{vmuuid};
		$xlsRowVal{dnsname} = substr($xlsRowVal{dnsname},0,255);
		$xlsRowVal{nw1} = substr($xlsRowVal{nw1},0,255);
		$xlsRowVal{nw2} = substr($xlsRowVal{nw2},0,255);
		$xlsRowVal{nw3} = substr($xlsRowVal{nw3},0,255);
		$xlsRowVal{nw4} = substr($xlsRowVal{nw4},0,255);
		$xlsRowVal{vmosconfig} = substr($xlsRowVal{vmosconfig},0,255);
		$xlsRowVal{vmostools} = substr($xlsRowVal{vmostools},0,255);
		$xlsRowVal{cpus} = stripchr($xlsRowVal{cpus});
		$xlsRowVal{memory} = stripchr($xlsRowVal{memory});
		$xlsRowVal{nics} = stripchr($xlsRowVal{nics});
		$xlsRowVal{disks} = stripchr($xlsRowVal{disks});
		$xlsRowVal{provisionmb} = stripchr($xlsRowVal{provisionmb});
		$xlsRowVal{inusemb} = stripchr($xlsRowVal{inusemb}); # new on 7/24/20 - get rid of commas

		my $osplat = "x86";
		$osplat = "x86_64" if ($xlsRowVal{vmosconfig} =~ m/\(64-bit\)/i);

		# SET UP THE SQL CODE FOR INSERT OR UPDATE
		## 2/27/20 new sqlcoldata code to simplify NULLs
		my $sqlcoldata = "   ipadd_id = ". (($assetIPkey ne "") ? $assetIPkey : "NULL") . ",\n";
		$sqlcoldata .= "   opsinv_id = " . (($assetOPSkey ne "") ? $assetOPSkey : "NULL") . ",\n";
		$sqlcoldata .= "   vcenter_id = ". $lkVC{$FileVCenter}{id} . ",\n";
		$sqlcoldata .= "   vmname = " . (($xlsRowVal{vmname} ne "") ? "\'". $xlsRowVal{vmname} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   rscdname = " . (($assetRName ne "") ? "\'". $assetRName . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   vmuuid = " . (($xlsRowVal{vmuuid} ne "") ? "\'". $xlsRowVal{vmuuid} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   dnsname = " . (($xlsRowVal{dnsname} ne "") ? "\'". $xlsRowVal{dnsname} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   network1 = " . (($xlsRowVal{nw1} ne "") ? "\'". $xlsRowVal{nw1} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   network2 = " . (($xlsRowVal{nw2} ne "") ? "\'". $xlsRowVal{nw2} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   network3 = " . (($xlsRowVal{nw3} ne "") ? "\'". $xlsRowVal{nw3} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   network4 = " . (($xlsRowVal{nw4} ne "") ? "\'". $xlsRowVal{nw4} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   osperconfig = " . (($xlsRowVal{vmosconfig} ne "") ? "\'". $xlsRowVal{vmosconfig} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ospertools = " . (($xlsRowVal{vmostools} ne "") ? "\'". $xlsRowVal{vmostools} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   clustername = " . (($xlsRowVal{clustername} ne "") ? "\'". $xlsRowVal{clustername} . "\'" : "NULL") . ",\n"; # new on 7/24/20
		$sqlcoldata .= "   osplatform = " . (($osplat ne "") ? "\'". $osplat . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   cpus = " . (($xlsRowVal{cpus} ne "") ? $xlsRowVal{cpus} : "NULL") . ",\n";
		$sqlcoldata .= "   memory = " . (($xlsRowVal{memory} ne "") ? $xlsRowVal{memory} : "NULL") . ",\n";
		$sqlcoldata .= "   nics = " . (($xlsRowVal{nics} ne "") ? $xlsRowVal{nics} : "NULL") . ",\n";
		$sqlcoldata .= "   disks = " . (($xlsRowVal{disks} ne "") ? $xlsRowVal{disks} : "NULL") . ",\n";
		if (exists($vDisk{$assetVMuuid})) {
			$sqlcoldata .= "   raw = " . $vDisk{$assetVMuuid}{raw} . ",\n";
			$sqlcoldata .= "   thin = " . $vDisk{$assetVMuuid}{thin} . ",\n";
		} 
		$sqlcoldata .= "   provisionmb = " . (($xlsRowVal{provisionmb} ne "") ? $xlsRowVal{provisionmb} : "NULL") . ",\n";
		$sqlcoldata .= "   inusemb = " . (($xlsRowVal{inusemb} ne "") ? $xlsRowVal{inusemb} : "NULL") . ",\n"; # new on 7/24/20
		$sqlcoldata .= "   latencysens = " . (($xlsRowVal{latencysens} ne "") ? $main::hashRVTLatencySensitivity{lc($xlsRowVal{latencysens})} : "NULL") . ",\n";
		$sqlcoldata .= "   powerstate = " . (($xlsRowVal{powerstate} ne "") ? $main::hashRVTPowerSt{lc($xlsRowVal{powerstate})} : "NULL") . ",\n";
		$sqlcoldata .= "   gueststate = " . (($xlsRowVal{gueststate} ne "") ? $main::hashRVTGuestSt{lc($xlsRowVal{gueststate})} : "NULL") . ",\n";
		$sqlcoldata .= "   connectstate = " . (($xlsRowVal{connectstate} ne "") ? $main::hashRVTConnectSt{lc($xlsRowVal{connectstate})} : "NULL") . ",\n";
		$sqlcoldata .= "   template = ". $istemplate . ",\n";

		my $rvKey = $lkLOC{$FileLocCode}{id} . $assetVMuuid;
		if (exists($lkRVT{$rvKey}) && $assetIPkey ne "") { # already in the database, so we need to update
			$sql = "UPDATE `" . $main::IDB_NAME . "`.`rvt` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastseen = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
			$sql .= "   WHERE id = " . $lkRVT{$rvKey}{id} . ";\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlRVUpdate++;
			}
		} elsif ($assetIPkey ne "") { # there isn't a row in the database, so we need to insert
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`rvt` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastseen = CURRENT_TIMESTAMP,\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlRVInsert++;
				$lkRVT{$rvKey}{id} = $dbh->{mysql_insertid};
			}
		} # end insert or update to database
	} # end if headers have all been found
} # end for row

## tracking update corresponding IP addresses
foreach my $lkey (keys %lkGIP) {
	## only update the IP addresses touched in this run of the script
	if ($lkGIP{$lkey}{this_run} && $lkGIP{$lkey}{inrvt} ne $lkGIP{$lkey}{this_inrvt}) { ## operational status has changed for this IP address
		$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
		$sql .= "   inrvt = " . $lkGIP{$lkey}{this_inrvt} . ",\n";
		$sql .= "   inuse = 1,\n" if ($lkGIP{$lkey}{this_inrvt}); # set inuse only if in operation
		$sql .= "   lastseen = CURRENT_TIMESTAMP,\n"  if ($lkGIP{$lkey}{this_inrvt});
		$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
		$sql .= "   WHERE id = " . $lkGIP{$lkey}{id} . ";\n";
		print $sql . "\n" if ($DEBUGSQL); # debug sql
		$dbh->do($sql);
		if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
			$iSqlErr++;
		} else {
			$iSqlIPUpdate++;
			$lkGIP{$lkey}{inrvt} = $lkGIP{$lkey}{this_inrvt};
		}
	}
}

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-rvt-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "RVT Inserts\t:" . $iSqlRVInsert . "\n";
print "RVT Updates\t:" . $iSqlRVUpdate . "\n";
print "IP Inserts\t:" . $iSqlIPInsert . "\n";
print "IP Updates\t:" . $iSqlIPUpdate . "\n";
print "VC Inserts\t:" . $iSqlVCInsert . "\n";
print "VC Updates\t:" . $iSqlVCUpdate . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
