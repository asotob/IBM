#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	VPG Generator (CSV Generator for VPGs for input into automation scripts)
### No database inserts or updates occur in this script.
### Date:		July 21, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Text::CSV_XS;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use JSON::MaybeXS qw(encode_json); # encode to JSON format
no warnings 'once';

require './ibm-globals.pl';

# accumulators and switch variables --------------------------------------
my $iRows;
my $href;

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkVLAN 				= ();	# hash table to lookup VLAN already in the database
my %lkWAVE 				= ();	# hash table to lookup WAVE sequences already in the database
my %lkGIP 				= ();	# hash table to lookup GLOBAL IP Address (from cspair) already in the Cloudscape data
my %lkHOST 				= ();	# hash table to lookup HOSTNAMES already in the Cloudscape data

my $outExcelRows	= 0;  # total number of excel rows written
my $DEBUGSQL 			= 1; 	# set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 		# this is the row to stop checking for headers and fail if all headers haven't been found
my %KEY_DATA_ERRORS	= (); # hash to contain data errors by Excel row (key information not found)
my $MAX_VPG_SIZE 	= 0; ## maximum size threshold for VPG in GB; set to ZERO for 1 VM per VPG

my $FONT_SIZE_HDR = 10;
my $FONT_CELL = 'IBM Plex Sans';
my $FONT_SIZE_CELL = 10;
my $FONT_SIZE_NOTES = 12;
my $ROW_HEIGHT_HDR = 24;
my $MAX_COLS = 18;

my $iSqlErr				= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

# -----------------------------------------------------------------------
# LOAD PRIOR DATA FOR LOOKUPS
# -----------------------------------------------------------------------
if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		$lkLOC{$cd}{id} = $refr[1]; # the id table index is the data
	}
}

# VLAN table lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
$sql = "SELECT vl.number, lo.code, vl.subnet, vl.name  FROM `" . $main::IDB_NAME . "`.`vlan` vl \n";
$sql .= "   LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON vl.location_id = lo.id; \n";
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $vnum = $refr[0];
	my $lccd = $refr[1];
	my $lkey = $lccd . $vnum;
	# set up all of the lookup values and later for update comparison
	$lkVLAN{$lkey}{number} = $vnum;
	$lkVLAN{$lkey}{subnet} = $refr[2];
	$lkVLAN{$lkey}{vlanname} = $refr[3];
}


if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT ip.id, INET_NTOA(ip.ipv4), ip.location_id, ip.inaddm, ip.inrvt, ip.inuse, ip.cloudscapeasset, ip.cloudscapescan, vl.id, vl.number, ip.pingable, ip.loadbal, lo.code \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`ipadd` ip\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`location` lo ON ip.location_id = lo.id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vl ON ip.vlan_id = vl.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ip_id = $refr[0];
		my $fip = $refr[1];
		if (!exists($lkGIP{$fip})) {
			$lkGIP{$fip}{id} = $ip_id;
			$lkGIP{$fip}{location_id} = defined($refr[2]) ? $refr[2] : "";
			$lkGIP{$fip}{inaddm} = defined($refr[3]) ? $refr[3] : 0;
			$lkGIP{$fip}{inrvt} = defined($refr[4]) ? $refr[4] : 0;
			$lkGIP{$fip}{inuse} = defined($refr[5]) ? $refr[5] : 0;
			$lkGIP{$fip}{csasset} = defined($refr[6]) ? $refr[6] : 0;
			$lkGIP{$fip}{csscan} = defined($refr[7]) ? $refr[7] : 0;
			$lkGIP{$fip}{vlan_id} = defined($refr[8]) ? $refr[8] : "";
			$lkGIP{$fip}{vlannum} = defined($refr[9]) ? $refr[9] : "";
			$lkGIP{$fip}{pingable} = defined($refr[10]) ? $refr[10] : 0;
			$lkGIP{$fip}{loadbal} = defined($refr[11]) ? $refr[11] : 0;
			$lkGIP{$fip}{location_code} = defined($refr[12]) ? $refr[12] : 0;
			$lkGIP{$fip}{assigned} = 0; ## assigned to server
			print "******* LKU GIP: fip=" . $fip . " FLAGS - Addm:" . $lkGIP{$fip}{inaddm} . " - Rvt:" . $lkGIP{$fip}{inrvt} . " - CSast:" . $lkGIP{$fip}{csasset} . " - CSscan:" . $lkGIP{$fip}{csscan} . "\n" if ($DEBUGSQL); # debug sql
		}
	}
}

# Wave Sequence EVENT table lookups
if ((grep { /event/ } @dbTables) == 0) {
	print "Table: event not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
$sql = "SELECT wavesequence, name  FROM `" . $main::IDB_NAME . "`.`event`;\n";
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $waveseq = (defined($refr[0])) ? $refr[0] : "";
	my $wavenm = (defined($refr[1])) ? $refr[1] : "";
	if (!exists($lkWAVE{$waveseq})) {
		$lkWAVE{$waveseq}{name} = $wavenm;
		@ { $lkWAVE{$waveseq}{sys} } = (); # set up a array of systems
	}
}

# Host lookups
if ((grep { /inventory/ } @dbTables) == 0) {
	print "Table: inventory not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}
$sql = "SELECT inv.wsibname, ev.wavesequence, rv.vmname\n";
$sql .= " FROM `" . $main::IDB_NAME . "`.`inventory` inv \n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`event` ev ON inv.event_id = ev.id \n";
$sql .= " LEFT JOIN `" . $main::IDB_NAME . "`.`rvt` rv ON inv.rvt_id = rv.id \n";
$sql .= " WHERE inv.category = 'VM' \n"; # system is a VM
$sql .= "   AND inv.wsibname IS NOT NULL \n"; # hostname isn't blank
$sql .= "   AND inv.event_id IS NOT NULL \n"; # assigned to a migration event
$sql .= "   AND inv.rvt_id IS NOT NULL \n"; # must have an associated rvtools record
$sql .= "   AND inv.discoverystatus = " . $main::hashDiscoveryStatus{confirmed} . " \n"; # discovery confirmed
$sql .= "   AND inv.dispositioncode = " . $main::hashSYSDisposition{migrating} . " \n"; # system is migrating
$sql .= "   AND (inv.migrationstatus IS NULL  \n"; # we haven't migrated it already
$sql .= "    OR inv.migrationstatus = " . $main::hashMigrationStatus{notstarted} . " \n"; # we haven't migrated it already
$sql .= "    OR inv.migrationstatus = " . $main::hashMigrationStatus{failback} . ") \n"; # we tried and had to failback - trying again
$sql .= "; \n"; ## end of SQL
$sth = $dbh->prepare($sql);
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	my $wsibname = (defined($refr[0])) ? $refr[0] : "";
	my $waveseq = (defined($refr[1])) ? $refr[1] : "";

	## we want all references to an IP address in the database for this lookup
	if ($wsibname ne "") {
		$lkHOST{$wsibname}{waveseq} = $waveseq;
	}
}

## wave:# or w:# -- collect all of the traffic for all IP addresses for a specific wave sequence number
## ip address -- collect all of the traffic for a specific IP address
## <data ctr code>:<VLAN #> -- collect all of the traffic for all IP addresses on a specific VLAN #

my @WAVES = ();
my @HOSTS = ();

foreach my $arg (@ARGV) {
	my @qrylist = split(/\,/,$arg); # split by comma
	foreach my $qry (@qrylist) {
		print "=> QRY: " . $qry . "\n" if ($DEBUGSQL);
		if ($qry =~ m/\:/) { # contains a colon separator
			my ($ctl1, $num1) = split(/\:/,$qry); # split into 2 args
			if (lc($ctl1) eq "w" || $ctl1 =~ m/wav/i) { # wave sequence queried
				if ($num1 =~ m/\-/) { # contains a dash separator meaning waves m-n
					my ($wslo, $wshi) = split(/\-/,$num1); # split into 2 args
					if (looks_like_number($wslo) && $wslo > 0 && looks_like_number($wshi) && $wshi > $wslo) {
						for (my $i = $wslo; $i <= $wshi; $i++) {
							print "\tWAVE Found: " . $i . "\n" if ($DEBUGSQL);
							push(@WAVES,$i);
						}
					}
				} elsif (looks_like_number($num1) && $num1 > 0) {
					print "\tWAVE Found: " . $num1 . "\n" if ($DEBUGSQL);
					push(@WAVES,$num1);
				}
			}
		} elsif (length($qry) > 4 && exists($lkHOST{lc($qry)})) {
			print "\tHOST Found: " . $qry . "\n" if ($DEBUGSQL);
			push(@HOSTS,lc($qry));
		}
	}
}

## figure out the file content
my $file_content = "";
my $valid_queries = 0;

if (scalar @WAVES) {
	my $elecount = scalar @WAVES;
	$valid_queries += $elecount;
	$file_content .= "." if ($file_content ne "");
	$file_content .= $elecount . "xWave";
	$file_content .= "s" if ($elecount != 1);
}
if (scalar @HOSTS) {
	my $elecount = scalar @HOSTS;
	$valid_queries += $elecount;
	$file_content .= "." if ($file_content ne "");
	$file_content .= $elecount . "xHost";
	$file_content .= "s" if ($elecount != 1);
}

if ($valid_queries == 0) { # no valid queries supplied
	$dbh->disconnect(); # Disconnect from the database.
	die "\n*** ERROR: No valid query parameters were supplied as a command line parameters, so cannot proceed.\n\n";
}

# Output a banner to show what we're doing
Display_Pgm_Banner("GENERATING AUTOMATION EXTRACT");

# other variables --------------------------------------------------------
my ($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time);
my $today = (1900 + $year) . sprintf("%02d",$mon + 1) . sprintf("%02d",$mday) . "_" . sprintf("%02d",$hour) . sprintf("%02d",$min) . sprintf("%02d",$sec);
my $xlsxfilenm =  $main::SCRIPT_TAG . " " . $main::CUST_NAME . " " . $file_content . " VPG-Automation-v" . $main::SCRIPT_VER . "_" . $today . ".xlsx";


## Set up the columns of the VLAN worksheet
my %xlsOrd=();	# hash table to define spreadsheet column order
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain data

for my $col ( 0 .. ($MAX_COLS - 1)) {
	if 	( $col == 0 ) { #A
		$xlsOrd{$col}{label} = "direction";
		$xlsOrd{$col}{title} = "Direction";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 1 ) { #B
		$xlsOrd{$col}{label} = "srcaddr";
		$xlsOrd{$col}{title} = "Source IP";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 2 ) { #C
		$xlsOrd{$col}{label} = "srcvlan";
		$xlsOrd{$col}{title} = "Source VLAN";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 3 ) { #D
		$xlsOrd{$col}{label} = "srcdc";
		$xlsOrd{$col}{title} = "Source Location";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 4 ) { #E
		$xlsOrd{$col}{label} = "srcvname";
		$xlsOrd{$col}{title} = "Source VLAN Name";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 5 ) { #F
		$xlsOrd{$col}{label} = "srcsubnet";
		$xlsOrd{$col}{title} = "Source Subnet";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 6 ) { #G
		$xlsOrd{$col}{label} = "srchostname";
		$xlsOrd{$col}{title} = "Source Hostname";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 7 ) { #H
		$xlsOrd{$col}{label} = "srcgroup";
		$xlsOrd{$col}{title} = "Source Group";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 8 ) { #I
		$xlsOrd{$col}{label} = "destaddr";
		$xlsOrd{$col}{title} = "Dest. IP";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 9 ) { #J
		$xlsOrd{$col}{label} = "destvlan";
		$xlsOrd{$col}{title} = "Dest. VLAN";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 10 ) { #K
		$xlsOrd{$col}{label} = "destdc";
		$xlsOrd{$col}{title} = "Dest. DC";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 11 ) { #L
		$xlsOrd{$col}{label} = "destvname";
		$xlsOrd{$col}{title} = "Dest. VLAN Name";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 12 ) { #M
		$xlsOrd{$col}{label} = "destsubnet";
		$xlsOrd{$col}{title} = "Dest. Subnet";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 13 ) { #N
		$xlsOrd{$col}{label} = "desthostname";
		$xlsOrd{$col}{title} = "Dest. Hostname";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 14 ) { #O
		$xlsOrd{$col}{label} = "destgroup";
		$xlsOrd{$col}{title} = "Dest. Group";
		$xlsOrd{$col}{width} = 38;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 15 ) { #P
		$xlsOrd{$col}{label} = "destport";
		$xlsOrd{$col}{title} = "Dest. Port";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 16 ) { #Q
		$xlsOrd{$col}{label} = "protocol";
		$xlsOrd{$col}{title} = "Protocol";
		$xlsOrd{$col}{width} = 24;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} elsif ( $col == 17 ) { #R
		$xlsOrd{$col}{label} = "hitcount";
		$xlsOrd{$col}{title} = "Hit Count";
		$xlsOrd{$col}{width} = 18;
		$xlsOrd{$col}{hformat} = $title_fmt;
	} # end if
	$xlsCol{$xlsOrd{$col}{label}}{col} = $col;
} # end for col

my %resWS = (); # hash table for ALL worksheets

## WAVES PARAMETERS WERE PASSED
if (scalar @WAVES) {
	## for each WAVE in scope, loop here
	foreach my $waveseq (@WAVES) {
		next if (!looks_like_number($waveseq));

		# Hostnames in scope for that wave
		my @inscopeHOSTS = ();
		$sql = "SELECT DISTINCT inv.wsibname\n";
		$sql .= "  FROM `" . $main::IDB_NAME . "`.`inventory` inv \n";
		$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`event` ev  ON inv.event_id = ev.id\n";
		$sql .= "  WHERE ev.wavesequence = ". $waveseq ."\n";
		$sql .= "    AND inv.wsibname IS NOT NULL\n";
		$sql .= "  ORDER BY inv.wsibname;\n";
		print $sql . "\n" if ($DEBUGSQL); # debug sql
		$sth = $dbh->prepare($sql);
		if (!$sth) {
			die "Error:" . $dbh->errstr . "\n";
		}
		if (!$sth->execute) {
			die "Error:" . $sth->errstr . "\n";
		}
		my $inscopeHOSTstr = "";
		while (my @refr = $sth->fetchrow_array) {
			$inscopeHOSTstr .= ",\n" if ($inscopeHOSTstr ne "");
			$inscopeHOSTstr .= "\'" . $refr[0] . "\'";
			push(@inscopeHOSTS,$refr[0]); # HOST in scope
		}

		if ($detail_view) { # detail view
			## for each HOST in scope, loop here
			foreach my $hostnm (@inscopeHOSTS) {
				my $wsname = "w" . $waveseq . "_" . $hostnm;
				$resWS{$wsname}{wks}	= $workbookout->add_worksheet($wsname);
				$resWS{$wsname}{row} = 0;

				## column headers
				foreach my $col (sort keys %xlsOrd) {
					$resWS{$wsname}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
					$resWS{$wsname}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
				}
				$resWS{$wsname}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
				$resWS{$wsname}{row} += 1; # increment the row counter

				## now loop twice for outbound and inbound traffic
				for (my $i=0;$i < 2;$i++) {
					$sql = "SELECT ";
					if ($i == 0) {
						$sql .= "'OUTBOUND' as value,";
					} else {
						$sql .= "'INBOUND' as value,";
					}
					$sql .= "INET_NTOA(ips.ipv4) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
					$sql .= "INET_NTOA(ipd.ipv4) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
					$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ips ON csp.src_ipadd_id = ips.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON ips.vlan_id = vls.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";

					if ($i == 0) {
						$sql .= "where csp.srcname = \'";
					} else {
						$sql .= "where csp.destname = \'";
					}
					$sql .= $hostnm . "\'\n";
					if ($i == 0) {
						$sql .= "ORDER BY vls.number, ips.ipv4, ipd.ipv4;\n";
					} else {
						$sql .= "ORDER BY vld.number, ipd.ipv4, ips.ipv4;\n";
					}
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$sth = $dbh->prepare($sql);
					if (!$sth) {
						die "Error:" . $dbh->errstr . "\n";
					}
					if (!$sth->execute) {
						die "Error:" . $sth->errstr . "\n";
					}

					while (my @refr = $sth->fetchrow_array) {
						foreach my $col (sort keys %xlsOrd) {
							my $this_cell_format = $cell_fmt_ct;
							my $this_cell_value = "";
							$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
							$resWS{$wsname}{wks} -> write($resWS{$wsname}{row}, $col, $this_cell_value , $this_cell_format);
							$resWS{$wsname}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
						}
						$resWS{$wsname}{row} += 1; # increment the row counter
					} # sql results loop
				} ## for loop inbound/outbound traffic
				$resWS{$wsname}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
				$resWS{$wsname}{wks} -> freeze_panes(1,0); # freeze panes on the first row
			} ## foreach hostnm
		} else { # rollup view
			my $wsname = "Wave " . $waveseq;
			$resWS{$wsname}{wks}	= $workbookout->add_worksheet($wsname);
			$resWS{$wsname}{row} = 0;

			## column headers
			foreach my $col (sort keys %xlsOrd) {
				$resWS{$wsname}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
				$resWS{$wsname}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
			}
			$resWS{$wsname}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
			$resWS{$wsname}{row} += 1; # increment the row counter

			## now loop twice for outbound and inbound traffic
			for (my $i=0;$i < 2;$i++) {
				if ($inscopeHOSTstr ne "") {
					$sql = "SELECT ";
					if ($i == 0) {
						$sql .= "'OUTBOUND' as value,";
					} else {
						$sql .= "'INBOUND' as value,";
					}
					$sql .= "INET_NTOA(ips.ipv4) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
					$sql .= "INET_NTOA(ipd.ipv4) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
					$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ips ON csp.src_ipadd_id = ips.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON ips.vlan_id = vls.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
					$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";

					if ($i == 0) {
						$sql .= "where csp.srcname IN (";
					} else {
						$sql .= "where csp.destname IN (";
					}
					$sql .= $inscopeHOSTstr . ")\n";
					if ($i == 0) {
						$sql .= "ORDER BY vls.number, csp.srcname, ips.ipv4, ipd.ipv4;\n";
					} else {
						$sql .= "ORDER BY vld.number, csp.destname, ipd.ipv4, ips.ipv4;\n";
					}
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$sth = $dbh->prepare($sql);
					if (!$sth) {
						die "Error:" . $dbh->errstr . "\n";
					}
					if (!$sth->execute) {
						die "Error:" . $sth->errstr . "\n";
					}

					while (my @refr = $sth->fetchrow_array) {
						foreach my $col (sort keys %xlsOrd) {
							my $this_cell_format = $cell_fmt_ct;
							my $this_cell_value = "";
							$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
							$resWS{$wsname}{wks} -> write($resWS{$wsname}{row}, $col, $this_cell_value , $this_cell_format);
							$resWS{$wsname}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
						}
						$resWS{$wsname}{row} += 1; # increment the row counter
					} # sql results loop
				} #if ($inscopeHOSTstr ne "") {
			} ## for loop inbound/outbound traffic
			$resWS{$wsname}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
			$resWS{$wsname}{wks} -> freeze_panes(1,0); # freeze panes on the first row
		} # detail or rollup view
	} # foreach @WAVES
} # if scalar @WAVES

## HOSTNAME PARAMETERS WERE PASSED
if (scalar @HOSTS) {
	## for each HOST in scope, loop here
	foreach my $hostnm (@HOSTS) {
		$resWS{$hostnm}{wks}	= $workbookout->add_worksheet($hostnm);
		$resWS{$hostnm}{row} = 0;

		## column headers
		foreach my $col (sort keys %xlsOrd) {
			$resWS{$hostnm}{wks} -> write(0, $col, $xlsOrd{$col}{title} ,$xlsOrd{$col}{hformat}); # Header title
			$resWS{$hostnm}{wks} -> set_column(0, $col, $xlsOrd{$col}{width}); 	# Column width
		}
		$resWS{$hostnm}{wks} -> set_row(0, $ROW_HEIGHT_HDR); # Set row height
		$resWS{$hostnm}{row} += 1; # increment the row counter

		## now loop twice for outbound and inbound traffic
		for (my $i=0;$i < 2;$i++) {
			$sql = "SELECT ";
			if ($i == 0) {
				$sql .= "'OUTBOUND' as value,";
			} else {
				$sql .= "'INBOUND' as value,";
			}
			$sql .= "INET_NTOA(ips.ipv4) 'srcaddr', vls.number 'srcvlan', los.code 'srcdc', vls.name 'srcvname', vls.subnet 'srcsubnet', csp.srcname, cstr.srcgroup, \n";
			$sql .= "INET_NTOA(ipd.ipv4) 'destaddr', vld.number 'destvlan', lod.code 'destdc', vld.name 'destvname', vld.subnet 'destsubnet', csp.destname, cstr.destgroup, cstr.destport, cstr.protocolname, cpr.hit_count\n";
			$sql .= "FROM `" . $main::IDB_NAME . "`.`cspair` csp\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`csptrel` cpr ON csp.id = cpr.cspair_id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`cstraf` cstr ON cpr.cstraf_id = cstr.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ips ON csp.src_ipadd_id = ips.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vls ON ips.vlan_id = vls.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` los ON vls.location_id = los.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ipd ON csp.dest_ipadd_id = ipd.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`vlan` vld ON ipd.vlan_id = vld.id\n";
			$sql .= "LEFT JOIN `" . $main::IDB_NAME . "`.`location` lod ON vld.location_id = lod.id\n";

			if ($i == 0) {
				$sql .= "where csp.srcname = \'";
			} else {
				$sql .= "where csp.destname = \'";
			}
			$sql .= $hostnm . "\'\n";
			if ($i == 0) {
				$sql .= "ORDER BY vls.number, ips.ipv4, ipd.ipv4;\n";
			} else {
				$sql .= "ORDER BY vld.number, ipd.ipv4, ips.ipv4;\n";
			}
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$sth = $dbh->prepare($sql);
			if (!$sth) {
				die "Error:" . $dbh->errstr . "\n";
			}
			if (!$sth->execute) {
				die "Error:" . $sth->errstr . "\n";
			}
			my $inscopeIPstr = "";
			while (my @refr = $sth->fetchrow_array) {
				foreach my $col (sort keys %xlsOrd) {
					my $this_cell_format = $cell_fmt_ct;
					my $this_cell_value = "";
					$this_cell_value = $refr[$col] if (defined($refr[$col])); # handle null values
					$resWS{$hostnm}{wks} -> write($resWS{$hostnm}{row}, $col, $this_cell_value , $this_cell_format);
					$resWS{$hostnm}{wks} -> set_column($col, $col, $xlsOrd{$col}{width}); 	# Column width
				}
				$resWS{$hostnm}{row} += 1; # increment the row counter
			} # sql results loop
		} ## for loop inbound/outbound traffic
		$resWS{$hostnm}{wks} -> autofilter(0,0,0,($MAX_COLS - 1)); # set autofilter
		$resWS{$hostnm}{wks} -> freeze_panes(1,0); # freeze panes on the first row
	} ## foreach hostnm
} # if scalar @HOSTS

# Disconnect from the database.
$dbh->disconnect();
$workbookout->close(); # close and write the workbook
exit;
