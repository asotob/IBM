#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Cloudscape Asset Load (Import) from CSV file
### Date:		June 3, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 2/19/20 - Major revamp of IP Address handling
############################################################################
use strict;
use warnings;
use Text::CSV_XS;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Time::Piece;
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("CLOUSDCAPE ASSET LOAD/UPDATE");

die "You must provide an CSV filename to $0 to be parsed" unless @ARGV;
my $infile = $ARGV[0];
die "File " . $infile . " does not exist, so cannot proceed.\n" if (!(-e $infile));

my %lkCSA	 				= ();	# hash table to lookup CS ASSET rows already in the database
my %lkADDMi				= ();	# hash table to lookup ADDM records already in the database by IP address

my %lkGIP	 				= ();	# hash table to lookup Global IP addresses already in the database
my %lkAPS	 				= ();	# hash table to lookup AppStack records already in the database by stackname
my %lkAPSIP				= ();	# hash table to lookup AppStack IP relationship records built to prevent duplication
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my @FSUBS					= (); # array for fast IP to subnet validation

my $iCSVRows			= 0; 	# number of CSV rows read
my %xlsCol 				= (); # Empty the column hash table
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console

my $iSqlErr				= 0;
my $iSqlIPInsert 	= 0;
my $iSqlIPUpdate 	= 0;
my $iSqlCSInsert 	= 0;
my $iSqlCSUpdate 	= 0;
my $iSqlCSAIPInsert	= 0;
my $iSqlAPSInsert = 0;
my $iSqlAPSUpdate = 0;
my $iDataErrors 	= 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Need the errors table here to track run errors
if ((grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

# -----------------------------------------------------------------------
# LOAD PRIOR DATA FOR LOOKUPS
# -----------------------------------------------------------------------
## ADDM lookups
if ((grep { /addm/ } @dbTables) == 0) {
	print "Table: addm not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT a.id, a.name, a.type, a.serialnum, INET_NTOA(ip.ipv4)  FROM `" . $main::IDB_NAME . "`.`addm` a";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`adiprel` ix ON a.id = ix.addm_id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON ix.ipadd_id = ip.id;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ciname = $refr[1]; ## ciname
		my $ipv4 = (defined($refr[4]) ? $refr[4] : "");
		if ($ipv4 ne "" && !exists($lkADDMi{$ipv4}) && is_ipv4($ipv4)) {
			$lkADDMi{$ipv4}{id} = $refr[0];
			$lkADDMi{$ipv4}{type} = (defined($refr[2]) ? $refr[2] : "");
			$lkADDMi{$ipv4}{hostname} = $ciname;
			$lkADDMi{$ipv4}{serialnum} = (defined($refr[3]) ? $refr[3] : "");
			#push(@ { $lkADDMw{$ciname}{ipaddresses} },$ipv4);
			print "******* LKU ADDMi: (" . $ipv4 . ") belongs to: " . $ciname . "\n" if ($DEBUGSQL); # debug sql
		}
	}
}

## IPadd LOOKUPS
if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), location_id, id, cloudscapeasset FROM `" . $main::IDB_NAME . "`.`ipadd`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $fip = $refr[0];
		if (!exists($lkGIP{$fip})) {
			$lkGIP{$fip}{location_id} = (defined($refr[1]) ? $refr[1] : "");
			$lkGIP{$fip}{id} = $refr[2];
			$lkGIP{$fip}{cloudscapeasset} = (defined($refr[3]) ? $refr[3] : 0);
			$lkGIP{$fip}{updated_this} = 0;
		}
		print "******* LKU GIP: fip=" . $fip . " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /csasset/ } @dbTables) == 0) {
	print "Table: csasset not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	## placeholder to load the $lkCSA hash table
	$sth = $dbh->prepare("SELECT uid, id FROM `" . $main::IDB_NAME . "`.`csasset`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $uid = $refr[0];
		$lkCSA{$uid}{id} = $refr[1];
		print "******* LKU CSA: " . $uid . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /appstack/ } @dbTables) == 0) {
	print "Table: appstack not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT id, stackname, disposition \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`appstack`;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[1]; # stackname
		$lkAPS{$lkey}{id} = $refr[0];
		$lkAPS{$lkey}{disposition} = $main::hashAppDisposition{retain}; ## global disposition default = retain
		$lkAPS{$lkey}{disposition} = $refr[2] if (defined($refr[2]));
		print "******* LKU APS: lkey=\"" .  $lkey . "\" db key: " . $lkAPS{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## New code 2/19/20 - Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

## remove all of the old CSASSET errors
$sql = "DELETE FROM `" . $main::IDB_NAME . "`.`errors` \n";
$sql .= "   WHERE type='csasset';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

## TRUNCATE the csasiprel to rebuild the relationships
$sql = "TRUNCATE `" . $main::IDB_NAME . "`.`csasiprel`; \n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

## UPDATE the ipadd table with cloudscape asset = 0
$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
$sql .= "   cloudscapeasset = 0,\n";
$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

# -----------------------------------------------------------------------
# SETUP THE CSV FILES FOR I/O
# -----------------------------------------------------------------------
# open up the CSV file input file
my $csvin = Text::CSV_XS->new( { binary => 1, auto_diag => 1, sep_char => ',', allow_loose_quotes => 1 } ); # set up the csv parser
open(my $fhin,"<:encoding(UTF-8)",$infile) or die "Could not open '$infile' $!\n";

# parse the CSV input and write the new CSV output
my $row = 0;
my @last_rowout=();

while (my $line = $csvin->getline($fhin)) {
	my @fields = @$line; # put all of the parsed fields into an array
	my %xlsRowVal	= ();	# hash table to contain excel row values
	$iCSVRows++; # increment row counter for output

	if ($row == 0) { # on the header row
		for (my $i=0;$i < @fields;$i++) { # loop through the columns
			my $fld = lc(trim($fields[$i]));
			$xlsCol{hostname} = $i if ($fld eq 'hostname');
			$xlsCol{devicetype} = $i if ($fld eq 'device type');
			$xlsCol{cpucount} = $i if ($fld eq 'cpu count');
			$xlsCol{cpufrequency} = $i if ($fld =~ m/cpu frequency/i);
			$xlsCol{memorygb} = $i if ($fld =~ m/memory in gb/i);
			$xlsCol{servos} = $i if ($fld eq 'os');
			$xlsCol{osver} = $i if ($fld eq 'os version');
			$xlsCol{ipaddresses} = $i if ($fld eq 'ip addresses');
			$xlsCol{stacknames} = $i if ($fld eq 'stack names');
			$xlsCol{assetid} = $i if ($fld eq 'asset_id');
			$xlsCol{processors} = $i if ($fld eq 'processors');
			$xlsCol{cores} = $i if ($fld eq 'cores');
			$xlsCol{hwvendor} = $i if ($fld eq 'hardware vendor');
			$xlsCol{hwmodel} = $i if ($fld eq 'hardware model');
			$xlsCol{inscope} = $i if ($fld =~ m/in scope/i);
			$xlsCol{dnsarecord} = $i if ($fld =~ m/dns a record/i);
			$xlsCol{wsib_os} = $i if ($fld =~ m/wsib_os/i);
			$xlsCol{wsib_hostname} = $i if ($fld =~ m/wsib_hostname/i);
			$xlsCol{wsib_devicedetails} = $i if ($fld =~ m/wsib_device_details/i);
			$xlsCol{referencetag} = $i if ($fld =~ m/reference tag/i);
			$xlsCol{tier} = $i if ($fld =~ m/tier/i);
			$xlsCol{dbinstance} = $i if ($fld =~ m/database instance/i);
			$xlsCol{scopenotes} = $i if ($fld =~ m/scope_issues_or/i);
		} # loop
	} elsif ($row > 0) { # past the header row
		# new code for localized values
		foreach my $key (keys %xlsCol) {
			$xlsRowVal{$key} = $fields[$xlsCol{$key}];
		}

		# Clean up the Excel data to prep for Database
		$xlsRowVal{hostname} = trim(substr($xlsRowVal{hostname},0,255));
		$xlsRowVal{devicetype} = trim(substr($xlsRowVal{devicetype},0,255));
		$xlsRowVal{cpucount} = trim(substr($xlsRowVal{cpucount},0,255));
		$xlsRowVal{cpufrequency} = trim(substr($xlsRowVal{cpufrequency},0,255));
		$xlsRowVal{memorygb} = trim(substr($xlsRowVal{memorygb},0,255));
		$xlsRowVal{servos} = trim(substr($xlsRowVal{servos},0,255));
		$xlsRowVal{osver} = trim(substr($xlsRowVal{osver},0,255));
		$xlsRowVal{ipaddresses} = trim(substr($xlsRowVal{ipaddresses},0,2048));
		$xlsRowVal{stacknames} = trim(substr($xlsRowVal{stacknames},0,255));
		$xlsRowVal{assetid} = trim(substr($xlsRowVal{assetid},0,255));
		$xlsRowVal{processors} = trim(substr($xlsRowVal{processors},0,255));
		$xlsRowVal{cores} = trim(substr($xlsRowVal{cores},0,255));
		$xlsRowVal{hwvendor} = trim(substr($xlsRowVal{hwvendor},0,255));
		$xlsRowVal{hwmodel} = trim(substr($xlsRowVal{hwmodel},0,255));
		$xlsRowVal{inscope} = trim(substr($xlsRowVal{inscope},0,255));
		$xlsRowVal{dnsarecord} = lc(trim(substr($xlsRowVal{dnsarecord},0,255)));
		$xlsRowVal{wsib_os} = trim(substr($xlsRowVal{wsib_os},0,255));
		$xlsRowVal{wsib_hostname} = trim(substr($xlsRowVal{wsib_hostname},0,255));
		$xlsRowVal{wsib_devicedetails} = trim(substr($xlsRowVal{wsib_devicedetails},0,255));
		$xlsRowVal{referencetag} = trim(substr($xlsRowVal{referencetag},0,255));
		$xlsRowVal{tier} = trim(substr($xlsRowVal{tier},0,255));
		$xlsRowVal{dbinstance} = trim(substr($xlsRowVal{dbinstance},0,255));
		$xlsRowVal{scopenotes} = trim(substr($xlsRowVal{scopenotes},0,1024));

		## Set up some important variables to locate the database records
		my $assetUID = $xlsRowVal{assetid};
		$assetUID =~ s/uid\://i; # remove uid: text from the Unique ID

		next if ($assetUID eq ""); # skip if there's no asset id -- should be on every record

		my $assetLocation_ID = "";
		my $assetHostname = "";
		my $assetPrimaryIP = "";
		my $assetPrimaryIPkey = "";
		my @validIPs = ();

		my @iplist = split(/\,\s*/,$xlsRowVal{ipaddresses}); # split by ", "
		foreach my $ip (@iplist) {
			$ip =~ s/riscdecom-//i; # remove riscdecom- if there
			$ip = ipfmt($ip);
			# is the IP in our range of subnets?
			if ($ip ne "" && is_ipv4($ip)) { # we still have a valid IPv4 format
				my $sn = $SubClassifier->($ip); # find the subnet in range quickly
				my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
				my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

				my $sqlcoldata =  "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
				$sqlcoldata .= "   ipv4 = INET_ATON(\'" . $ip  . "\'),\n";
				$sqlcoldata .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
				$sqlcoldata .= "   cloudscapeasset = 1,\n";
				#$sqlcoldata .= "   inuse = 1,\n"; ## 4/15/20 Don't set inuse here as csassets may contain decom ips

				if (exists($lkGIP{$ip}) && !$lkGIP{$ip}{updated_this}) {
					$assetPrimaryIPkey = $lkGIP{$ip}{id};
					$assetPrimaryIP = $ip if ($assetPrimaryIP eq "");
					$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
					$sql .= $sqlcoldata;
					$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
					$sql .= "   WHERE id = " . $lkGIP{$ip}{id} . ";\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$lkGIP{$ip}{updated_this} = 1;
						push(@validIPs,$ip);
						$iSqlIPUpdate++;
					}
				} else { ## IP in range but not found
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
					$sql .= $sqlcoldata;
					$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$assetPrimaryIP = $ip if ($assetPrimaryIP eq "");
						$iSqlIPInsert++;
						$lkGIP{$ip}{location_id} = $loc_id;
						$lkGIP{$ip}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
						$assetPrimaryIPkey = $lkGIP{$ip}{id};
						$lkGIP{$ip}{cloudscapeasset} = 1;
						push(@validIPs,$ip);
					} # we inserted a record

					$assetLocation_ID = $loc_id if ($assetLocation_ID eq "");
					if (exists($lkADDMi{$ip})) {
						$assetHostname = $lkADDMi{$ip}{hostname} if ($assetHostname eq "" && $lkADDMi{$ip}{hostname} ne "");
					}
				} # if ($ip ne "" && is_ipv4($ip)) { # we still have a valid IPv4 format
			} # IP address ne ""
		}
		next if (scalar(@validIPs) == 0); # if we didn't find any IP addresses in scope, then skip this record

		next if ($xlsRowVal{devicetype} =~ m/inaccessible/i || $xlsRowVal{devicetype} =~ m/unknown/i); # filter if the device type is inaccessible or unknown

		# fix up the hostname
		$assetHostname = lc($xlsRowVal{hostname}) if ($assetHostname eq "");
		next if ($assetHostname =~ m/unknown/i); # skip if the hostname is unknown
		$assetHostname =~ s/riscdecom - //ig;
		$assetHostname =~ s/\..*$//; # fqdn - this removes fqdn! comment next 2 lines if you want the source and dest names to contain fqdn
		next if (looks_like_number($assetHostname)); # if the host was an IP address, filter it
		next if ($assetHostname =~ m/inaccessible/i); # if the hostname is inaccessible, filter it
		next if ($assetHostname eq ""); # if hostname is blank, skip it
		if (exists($lkADDMi{$assetPrimaryIP})) {
			$assetHostname = $lkADDMi{$assetPrimaryIP}{hostname}; ## update the hostname from ADDM
		}

		## NEED TO LOOK UP THE $assetAppStack_ID TO FILL IN THAT FIELD -- based on stacknames which is always a single value in the data
		my $assetAppStack_ID = "";
		my $assetStackname = $xlsRowVal{stacknames};
		$assetStackname =~ s/^"//; #get rid of leading double quotes
		$assetStackname =~ s/"$//; #get rid of trailing double quotes
		$assetStackname =~ s/^\s+//; #get rid of leading whitespace

		## 2/28/20 - Combine APPSTACK LOAD code here to prevent data inconsistencies
		if ($assetStackname eq "") {
			$iDataErrors++;
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`errors` SET \n";
			$sql .= "   type=\'csasset\',\n";
			$sql .= "   errorlog = \'CSASSET row (". $iCSVRows .") Stack Name is BLANK.\',\n";
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			}
		} else {
			my $sqlcoldata = "   stackname = \'". $assetStackname . "\',\n";
			if (exists($lkAPS{$assetStackname})) {
				$sql = "UPDATE `" . $main::IDB_NAME . "`.`appstack` SET \n";
				$sql .= $sqlcoldata;
				$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
				$sql .= "   WHERE id = " . $lkAPS{$assetStackname}{id} . ";\n";
				$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlAPSUpdate++;
				}
			} else { ## insert
				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`appstack` SET \n";
				$sql .= $sqlcoldata;
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlAPSInsert++;
					$lkAPS{$assetStackname}{id} = $dbh->{mysql_insertid};
				}
			}
		}
		$assetAppStack_ID = $lkAPS{$assetStackname}{id} if ($assetStackname ne "" && exists($lkAPS{$assetStackname}));

		## Fix numeric values to integers
		my $assetCPUcount = "";
		$assetCPUcount = int($xlsRowVal{cpucount} + 0.5) if (looks_like_number($xlsRowVal{cpucount}));
		my $assetCPUfreq = "";
		$assetCPUfreq = int($xlsRowVal{cpufrequency} + 0.5) if (looks_like_number($xlsRowVal{cpufrequency}));
		my $assetMEMgb = "";
		$assetMEMgb = int($xlsRowVal{memorygb} + 0.5) if (looks_like_number($xlsRowVal{memorygb}));
		my $assetPROCS = "";
		$assetPROCS = int($xlsRowVal{processors} + 0.5) if (looks_like_number($xlsRowVal{processors}));
		my $assetCORES = "";
		$assetCORES = int($xlsRowVal{cores} + 0.5)  if (looks_like_number($xlsRowVal{cores}));

		my $dbUpdated = 0; # flag if the database was updated successfully

		## 2/27/20 new sqlcoldata code to simplify NULLs
		my $sqlcoldata = "   location_id = " . (($assetLocation_ID ne "") ? $assetLocation_ID : "NULL") . ",\n";
		$sqlcoldata .= "   appstack_id = " . (($assetAppStack_ID ne "") ? $assetAppStack_ID : "NULL") . ",\n";
		$sqlcoldata .= "   uid = \'". 	$assetUID . "\',\n";
		$sqlcoldata .= "   hostname = " . (($assetHostname ne "") ? "\'". $assetHostname . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ipadd_id = " . (($assetPrimaryIPkey ne "") ? $assetPrimaryIPkey : "NULL") . ",\n";
		$sqlcoldata .= "   devicetype = " . (($xlsRowVal{devicetype} ne "") ? "\'". $xlsRowVal{devicetype} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   cpucount = " . (($assetCPUcount ne "") ? $assetCPUcount : "NULL") . ",\n";
		$sqlcoldata .= "   cpufrequency = " . (($assetCPUfreq ne "") ? $assetCPUfreq : "NULL") . ",\n";
		$sqlcoldata .= "   memorygb = " . (($assetMEMgb ne "") ? $assetMEMgb : "NULL") . ",\n";
		$sqlcoldata .= "   processors = " . (($assetPROCS ne "") ? $assetPROCS : "NULL") . ",\n";
		$sqlcoldata .= "   cores = " . (($assetCORES ne "") ? $assetCORES : "NULL") . ",\n";
		$sqlcoldata .= "   servos = " . (($xlsRowVal{servos} ne "") ? "\'". $xlsRowVal{servos} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   osver = " . (($xlsRowVal{osver} ne "") ? "\'". $xlsRowVal{osver} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   hwvendor = " . (($xlsRowVal{hwvendor} ne "") ? "\'". $xlsRowVal{hwvendor} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   hwmodel = " . (($xlsRowVal{hwmodel} ne "") ? "\'". $xlsRowVal{hwmodel} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   inscope = " . (($xlsRowVal{inscope} ne "") ? "\'". $xlsRowVal{inscope} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   dnsarecord = " . (($xlsRowVal{dnsarecord} ne "") ? "\'". $xlsRowVal{dnsarecord} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   wsib_os = " . (($xlsRowVal{wsib_os} ne "") ? "\'". $xlsRowVal{wsib_os} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   wsib_hostname = " . (($xlsRowVal{wsib_hostname} ne "") ? "\'". $xlsRowVal{wsib_hostname} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   wsib_devicedetails = " . (($xlsRowVal{wsib_devicedetails} ne "") ? "\'". $xlsRowVal{wsib_devicedetails} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   referencetag = " . (($xlsRowVal{referencetag} ne "") ? "\'". $xlsRowVal{referencetag} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   tier = " . (($xlsRowVal{tier} ne "") ? "\'". $xlsRowVal{tier} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   dbinstance = " . (($xlsRowVal{dbinstance} ne "") ? "\'". $xlsRowVal{dbinstance} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   scopenotes = " . (($xlsRowVal{scopenotes} ne "") ? "\'". $xlsRowVal{scopenotes} . "\'" : "NULL") . ",\n";

		if (exists($lkCSA{$assetUID})) {	# update record
			$sql = "UPDATE `" . $main::IDB_NAME . "`.`csasset` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
			$sql .= "   WHERE id = " . $lkCSA{$assetUID}{id} . ";\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$result = $dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlCSUpdate++;
				$dbUpdated = 1;
			}
		} else { # insert record
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`csasset` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   firstadd = CURRENT_TIMESTAMP,\n"; # insert only
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$result = $dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlCSInsert++;
				$lkCSA{$assetUID}{id} = $dbh->{mysql_insertid};
				$dbUpdated = 1;
			}
		}
		# build the cs asset to ip relationships
		if ($dbUpdated) {
			foreach my $ip (@validIPs) {
				my $rkey = $lkCSA{$assetUID}{id} . "_" . $lkGIP{$ip}{id};
				if (!exists($lkAPSIP{$rkey})) {
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`csasiprel` SET \n";
					$sql .= "   csasset_id = ". $lkCSA{$assetUID}{id} .",\n";
					$sql .= "   ipadd_id = ". $lkGIP{$ip}{id} .",\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlCSAIPInsert++;
						$lkAPSIP{$rkey} = 1; # all we need to do is check for the existence of the key
					}
				}
			}
		}
	}
	$row++; # increment row counter
} # while loop by row/line

## update tracking record with new data
$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iCSVRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-csasset-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "CSV Rows Read\t:" . $iCSVRows . "\n";
print "CS Asset Inserts\t:" . $iSqlCSInsert . "\n";
print "CS Asset Updates\t:" . $iSqlCSUpdate . "\n";
print "CS IP Rel Inserts\t:" . $iSqlCSAIPInsert . "\n";
print "APS Inserts\t:" . $iSqlAPSInsert . "\n";
print "APS Updates\t:" . $iSqlAPSUpdate . "\n";
print "IP Inserts\t:" . $iSqlIPInsert . "\n";
print "IP Updates\t:" . $iSqlIPUpdate . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
close($fhin);
exit;
