#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Cloudscape Dependencies Load (Import) from CSV file
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### 2/19/20 - Major revamp of IP Address handling
############################################################################
use strict;
use warnings;
use Text::CSV_XS;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
use Time::Piece;
use Net::Subnet; ## new code for 2/19/20
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("CLOUSDCAPE DEPENDENCY LOAD/UPDATE");

die "You must provide an CSV filename to $0 to be parsed" unless @ARGV;
my $infile = $ARGV[0];
die "File " . $infile . " does not exist, so cannot proceed.\n" if (!(-e $infile));

my %lkLOC	 				= ();	# hash table to lookup LOCATION already in the database
my %lkCSD	 				= ();	# hash table to lookup CS DEP rows already in the database
my %lkADDMi				= ();	### hash table to lookup ADDM records already in the database by IP address
my %lkAPS	 				= ();	# hash table to lookup AppStack records already in the database by stackname
my %lkCSA	 				= ();	# hash table to lookup CS ASSET rows already in the database
my %lkCSP	 				= ();	# hash table to lookup CSPAIR rows already in the database
my %lkCST	 				= ();	# hash table to lookup CSTRAF rows already in the database
my %lkCSPTR				= ();	# hash table to lookup CSPTREF rows already in the database
my %lkGIP	 				= ();	# hash table to lookup Global IP addresses already in the database
my %lkSUBNT				= ();	# hash table to lookup SUBNET already in the VLAN database
my @FSUBS					= (); # array for fast IP to subnet validation

my $iCSVRows			= 0; 	# number of CSV rows read
my %xlsCol 				= (); # Empty the column hash table
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console

my $iSqlErr				= 0;
my $iSqlIPInsert 	= 0;
my $iSqlIPUpdate 	= 0;
my $iSqlCSPInsert 		= 0;
my $iSqlCSPUpdate 		= 0;
my $iSqlCSTInsert 		= 0;
my $iSqlCSTUpdate 		= 0;
my $iSqlCSPTRInsert 	= 0;
my $iSqlCSPTRUpdate 	= 0;
my $iDataErrors 	= 0;

my $IndexDelimit = '^';

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

# -----------------------------------------------------------------------
# LOAD PRIOR DATA FOR LOOKUPS
# -----------------------------------------------------------------------
if ((grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT code, id FROM `" . $main::IDB_NAME . "`.`location`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $cd = $refr[0];
		print "******* LKU LOC: " . $cd . " key: " . $refr[1] . "\n" if ($DEBUGSQL); # debug sql
		$lkLOC{$cd}{id} = $refr[1];
	}
}

## 4/13/20 v3.5 - ADDM lookups
if ((grep { /addm/ } @dbTables) == 0) {
	print "Table: addm not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT a.id, a.name, INET_NTOA(ip.ipv4) FROM `" . $main::IDB_NAME . "`.`addm` a";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`adiprel` ix ON a.id = ix.addm_id\n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON ix.ipadd_id = ip.id;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $ciname = $refr[1]; ## ciname
		my $ipv4 = (defined($refr[2]) ? $refr[2] : "");
		if (is_ipv4($ipv4)) {
			if (!exists($lkADDMi{$ipv4})) {
				$lkADDMi{$ipv4}{id} = $refr[0];
				$lkADDMi{$ipv4}{wsibname} = $ciname;
			}
			print "******* LKU ADDMi: (" . $ipv4 . ") belongs to: " . $ciname . "\n" if ($DEBUGSQL); # debug sql
		}
	}
}

## CSPAIR lookups
if ((grep { /cspair/ } @dbTables) == 0) {
	print "Table: cspair not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, src_ipadd_id, dest_ipadd_id FROM `" . $main::IDB_NAME . "`.`cspair`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $tblid = $refr[0]; # table index
		my $srcip = (defined($refr[1]) ? $refr[1] : "");
		my $destip = (defined($refr[2]) ? $refr[2] : "");
		my $pkey = $srcip . $IndexDelimit . $destip;
		$lkCSP{$pkey}{id} = $tblid;
		print "******* LKU CSPAIR: pkey=" . $pkey . " db key: " . $lkCSP{$pkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

## CSTRAF lookups
if ((grep { /cstraf/ } @dbTables) == 0) {
	print "Table: cstraf not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, srcgroup, destgroup, destport, protocolname FROM `" . $main::IDB_NAME . "`.`cstraf`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $tblid = $refr[0]; # table index
		my $srcgrp = (defined($refr[1]) ? $refr[1] : "");
		my $destgrp = (defined($refr[2]) ? $refr[2] : "");
		my $destport = (defined($refr[3]) ? $refr[3] : "");
		my $proto = (defined($refr[4]) ? $refr[4] : "");
		my $lkey = $srcgrp . $IndexDelimit . $destgrp . $IndexDelimit . $destport . $IndexDelimit . $proto;
		$lkCST{$lkey}{id} = $tblid;
		print "******* LKU CSTRAF: lkey=" . $lkey . " db key: " . $lkCST{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

## CSPTREL lookups
if ((grep { /csptrel/ } @dbTables) == 0) {
	print "Table: csptrel not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT id, cspair_id, cstraf_id FROM `" . $main::IDB_NAME . "`.`csptrel`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $tblid = $refr[0]; # table index
		my $csp_id = (defined($refr[1]) ? $refr[1] : "");
		my $cst_id = (defined($refr[2]) ? $refr[2] : "");
		my $lkey = $csp_id . $IndexDelimit . $cst_id;
		$lkCSPTR{$lkey}{id} = $tblid;
		print "******* LKU CSPTREL: lkey=" . $lkey . " db key: " . $lkCSPTR{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

## CS APPSTACK
if ((grep { /appstack/ } @dbTables) == 0) {
	print "Table: appstack not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT id, stackname, disposition \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`appstack`;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[1]; # stackname
		$lkAPS{$lkey}{id} = $refr[0];
		$lkAPS{$lkey}{disposition} = $main::hashAppDisposition{retain}; ## global disposition default = retain
		$lkAPS{$lkey}{disposition} = $refr[2] if (defined($refr[2]));
		print "******* LKU APS: lkey=" .  $lkey . " db key: " . $lkAPS{$lkey}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

## CSASSET
if ((grep { /csasset/ } @dbTables) == 0) {
	print "Table: csasset not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	## load the $lkCSA hash table
	$sql = "SELECT csa.id, INET_NTOA(ip.ipv4), csa.hostname, csa.appstack_id \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`csasset` csa \n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON csa.ipadd_id = ip.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $primaryip = (defined($refr[1]) ? $refr[1] : "");
		my $hostname = (defined($refr[2]) ? $refr[2] : "");
		my $stackid = (defined($refr[3]) ? $refr[3] : "");
		$lkCSA{$primaryip}{id} = $refr[0];
		$lkCSA{$primaryip}{hostname} = $hostname;
		$lkCSA{$primaryip}{appstack_id} = $stackid;
		print "******* LKU CSA: " . $primaryip . " id: " . $lkCSA{$primaryip}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

## IPadd LOOKUPS
if ((grep { /ipadd/ } @dbTables) == 0) { # IP address assignment table not found
	print "Table: ipadd not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT INET_NTOA(ipv4), location_id, id, inuse FROM `" . $main::IDB_NAME . "`.`ipadd`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $fip = $refr[0];
		if (!exists($lkGIP{$fip})) {
			$lkGIP{$fip}{location_id} = (defined($refr[1]) ? $refr[1] : "");
			$lkGIP{$fip}{id} = $refr[2];
			$lkGIP{$fip}{inuse} = (defined($refr[3]) ? $refr[3] : 0);
			$lkGIP{$fip}{this_cloudscapescan} = 0;
		}
		print "******* LKU GIP: fip=" . $fip . " db key: " . $lkGIP{$fip}{id} . "\n" if ($DEBUGSQL); # debug sql
	}
}

# VLAN table subnet lookups
if ((grep { /vlan/ } @dbTables) == 0) {
	print "Table: vlan not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sth = $dbh->prepare("SELECT location_id, id, subnet FROM `" . $main::IDB_NAME . "`.`vlan`");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[2]; # subnet
		$lkSUBNT{$lkey}{vlan_id} = $refr[1];
		$lkSUBNT{$lkey}{loc_id} = $refr[0];
		push @FSUBS, $lkey; # load FSUBS array for fast lookups
		print "******* LKU SUBNT: loc_id: " . $lkSUBNT{$lkey}{loc_id} . " subnet: " . $lkey . "\n" if ($DEBUGSQL); # debug sql
	}
}

## New code 2/19/20 - Subnet Classifier for Fast Subnet LOOKUPS
my $SubClassifier = subnet_classifier @FSUBS;

# -----------------------------------------------------------------------
# SETUP THE CSV FILES FOR I/O
# -----------------------------------------------------------------------
# open up the CSV file input file
my $csvin = Text::CSV_XS->new( { binary => 1, auto_diag => 1, sep_char => ',', allow_loose_quotes => 1 } ); # set up the csv parser
open(my $fhin,"<:encoding(UTF-8)",$infile) or die "Could not open '$infile' $!\n";

# parse the CSV input and write the new CSV output
my $row = 0;
my @last_rowout=();

while (my $line = $csvin->getline($fhin)) {
	my @fields = @$line; # put all of the parsed fields into an array
	my %xlsRowVal	= ();	# hash table to contain excel row values
	$iCSVRows++; # increament row counter for output

	if ($row == 0) { # on the header row
		for (my $i=0;$i < @fields;$i++) { # loop through the columns
			my $fld = lc(trim($fields[$i]));
			$xlsCol{srcname} = $i if ($fld =~ m/srcname/i);
			$xlsCol{srcgroup} = $i if ($fld eq 'srcgroup');
			$xlsCol{srcaddr} = $i if ($fld eq 'srcaddr');
			$xlsCol{destname} = $i if ($fld eq 'destname');
			$xlsCol{destgroup} = $i if ($fld eq 'destgroup');
			$xlsCol{destaddr} = $i if ($fld eq 'destaddr');
			$xlsCol{destport} = $i if ($fld eq 'destport');
			$xlsCol{protocolname} = $i if ($fld eq 'protocolname');
			$xlsCol{lastseen} = $i if ($fld eq 'lastseen');
		} # loop
	} elsif ($row > 0) { # past the header row
		# new code for localized values
		foreach my $key (sort keys %xlsCol) {
			$xlsRowVal{$key} = $fields[$xlsCol{$key}];
		}

		# Clean up the Excel data to prep for Database
		$xlsRowVal{srcname} = trim(substr($xlsRowVal{srcname},0,255));
		$xlsRowVal{srcgroup} = trim(substr($xlsRowVal{srcgroup},0,255));
		$xlsRowVal{srcaddr} = ipfmt($xlsRowVal{srcaddr});
		$xlsRowVal{destname} = trim(substr($xlsRowVal{destname},0,255));
		$xlsRowVal{destgroup} = trim(substr($xlsRowVal{destgroup},0,255));
		$xlsRowVal{destaddr} = ipfmt($xlsRowVal{destaddr});
		$xlsRowVal{destport} = looks_like_number($xlsRowVal{destport}) ? sprintf("%d",$xlsRowVal{destport}) : "";
		$xlsRowVal{protocolname} = trim(substr($xlsRowVal{protocolname},0,64));
		$xlsRowVal{lastseen} = trim(substr($xlsRowVal{lastseen},0,255));

		## Set up some important variables to locate the database records
		my $csSrcIP = "";
		my $csDestIP = "";
		my $csSrcIPkey = "";
		my $csDestIPkey = "";
		my $csSrcAPSkey = "";
		my $csDestAPSkey = "";
		my $csSrcCSAkey = "";
		my $csDestCSAkey = "";
		my $csSrcName = "";
		my $csDestName = "";

		$csSrcName = lc($xlsRowVal{srcname}) if ($xlsRowVal{srcname} ne "");
		$csDestName = lc($xlsRowVal{destname})  if ($xlsRowVal{destname} ne "");;

		## Try to locate the source or dest ip address
		## LOOK AT THE SRC IP?
		if ($xlsRowVal{srcaddr} ne "" && is_ipv4($xlsRowVal{srcaddr})) { # we still have a valid IPv4 format
			$csSrcIP = $xlsRowVal{srcaddr};
			my $sn = $SubClassifier->($csSrcIP); # find the subnet in range quickly
			next if (!defined($sn)); ## skip this row if the source IP doesn't belong in one of our subnets

			if (exists($lkGIP{$csSrcIP})) {
				if (!$lkGIP{$csSrcIP}{this_cloudscapescan}) { # only update once per run
					$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
					$sql .= "   ipv4 = INET_ATON(\'" . $csSrcIP  . "\'),\n";
					$sql .= "   cloudscapescan = 1,\n";
					$sql .= "   inuse = 1,\n";
					$sql .= "   lastseen = CURRENT_TIMESTAMP,\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
					$sql .= "   WHERE id = " . $lkGIP{$csSrcIP}{id} . ";\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlIPUpdate++;
						$lkGIP{$csSrcIP}{this_cloudscapescan} = 1;
					}
				}
				$csSrcIPkey = $lkGIP{$csSrcIP}{id};
			} else { # in a valid subnet, but IP address is not on file
				my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
				my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
				$sql .= "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
				$sql .= "   ipv4 = INET_ATON(\'" . $csSrcIP  . "\'),\n";
				$sql .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
				$sql .= "   cloudscapescan = 1,\n";
				$sql .= "   inuse = 1,\n";
				$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlIPInsert++;
					$lkGIP{$csSrcIP}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
					$lkGIP{$csSrcIP}{this_cloudscapescan} = 1;
					$csSrcIPkey = $lkGIP{$csSrcIP}{id};
				} # we inserted a record
			} # ip exists or not
		} # IP not blank and it is a valid IPv4

		## LOOK AT THE DEST IP?
		if ($xlsRowVal{destaddr} ne "" && is_ipv4($xlsRowVal{destaddr})) { # we still have a valid IPv4 format
			$csDestIP = $xlsRowVal{destaddr};

			if (exists($lkGIP{$csDestIP})) {
				if (!$lkGIP{$csDestIP}{this_cloudscapescan}) { ## only update once per run
					$sql = "UPDATE `" . $main::IDB_NAME . "`.`ipadd` SET \n";
					$sql .= "   ipv4 = INET_ATON(\'" . $csDestIP  . "\'),\n";
					$sql .= "   cloudscapescan = 1,\n";
					$sql .= "   inuse = 1,\n";
					$sql .= "   lastseen = CURRENT_TIMESTAMP,\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
					$sql .= "   WHERE id = " . $lkGIP{$csDestIP}{id} . ";\n";
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlIPUpdate++;
						$lkGIP{$csDestIP}{this_cloudscapescan} = 1;
					}
				}
				$csDestIPkey = $lkGIP{$csDestIP}{id};
			} else { # in a valid subnet, but IP address is not on file
				my $sn = $SubClassifier->($csDestIP); # find the subnet in range quickly
				my $vlan_id =  (defined($sn) ? $lkSUBNT{$sn}{vlan_id} : "");
				my $loc_id =  (defined($sn) ? $lkSUBNT{$sn}{loc_id} : "");

				$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`ipadd` SET \n";
				$sql .= "   location_id = ". (($loc_id ne "") ? $loc_id : "NULL")  . ",\n";
				$sql .= "   ipv4 = INET_ATON(\'" . $csDestIP  . "\'),\n";
				$sql .= "   vlan_id = ". (($vlan_id ne "") ? $vlan_id : "NULL")  . ",\n";
				$sql .= "   cloudscapescan = 1,\n";
				$sql .= "   inuse = 1,\n";
				$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
				$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
				print $sql . "\n" if ($DEBUGSQL); # debug sql
				$dbh->do($sql);
				if (!defined($dbh) ) {
					print "Error while executing SQL:\n";
					print $sql . "\n";
					print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
					$iSqlErr++;
				} else {
					$iSqlIPInsert++;
					$lkGIP{$csDestIP}{id} = $dbh->{mysql_insertid}; # add to the lookup hash table
					$lkGIP{$csDestIP}{this_cloudscapescan} = 1;
					$csDestIPkey = $lkGIP{$csDestIP}{id};
				} # we inserted a record
			} # IP not blank and it is a valid IPv4
		} # ip not blank

		# filters
		#next if ($csSrcName =~ m/unknown/i); # skip if the sourcename is unknown

		# fixers
		$csSrcName = "" if ($csSrcName =~ m/unknown/i);
		$csDestName = "" if ($csDestName =~ m/unknown/i);

		$csSrcName = "" if (looks_like_number($csSrcName));
		$csDestName = "" if (looks_like_number($csDestName));

		$csSrcName =~ s/^riscdecom - //ig;
		$csDestName =~ s/^riscdecom - //ig;

		# fqdn - this removes fqdn! comment next 2 lines if you want the source and dest names to contain fqdn
		$csSrcName =~ s/\..*$//;
		$csDestName =~ s/\..*$//;

		## we found either the source or destination IP on file
		if ($csSrcIPkey ne "") { # we know the source IP
			## format the src and dest names
			$csSrcName = $lkADDMi{$csSrcIP}{wsibname} if ($csSrcIPkey ne "" && exists($lkADDMi{$csSrcIP}));
			$csDestName = $lkADDMi{$csDestIP}{wsibname}  if ($csDestIPkey ne "" && exists($lkADDMi{$csDestIP}));

			## reformat Cloudscape's last seen into lastscan for the database
			my $CSlastscan = "";
			if ($xlsRowVal{lastseen} ne "") {
				my $t = Time::Piece->strptime($xlsRowVal{lastseen}, '%Y/%m/%d %T'); # standard date time format
				$CSlastscan = $t->strftime('%F %T'); # mysql formatted
			}

			## figure out the appstack ID for source and target
			if (exists($lkAPS{$xlsRowVal{srcgroup}})) {
				$csSrcAPSkey = $lkAPS{$xlsRowVal{srcgroup}}{id};
			}
			if (exists($lkAPS{$xlsRowVal{destgroup}})) {
				$csDestAPSkey = $lkAPS{$xlsRowVal{destgroup}}{id};
			}

			## figure out the csasset ID for source and target
			if ($csSrcIP ne "" && exists($lkCSA{$csSrcIP})) {
				$csSrcCSAkey = $lkCSA{$csSrcIP}{id};
			}
			if ($csDestIP ne "" && exists($lkCSA{$csDestIP})) {
				$csDestCSAkey = $lkCSA{$csDestIP}{id};
			}

			## CSPAIR updates/inserts
			## 2/27/20 new sqlcoldata code to simplify NULLs
			my $sqlcoldata = "   srcname = " . (($csSrcName ne "") ? "\'". $csSrcName . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   destname = " . (($csDestName ne "") ? "\'". $csDestName . "\'" : "NULL") . ",\n";
			$sqlcoldata .= "   src_ipadd_id = " . (($csSrcIPkey ne "") ? $csSrcIPkey : "NULL") . ",\n";
			$sqlcoldata .= "   dest_ipadd_id = " . (($csDestIPkey ne "") ? $csDestIPkey : "NULL") . ",\n";
			$sqlcoldata .= "   src_appstack_id = " . (($csSrcAPSkey ne "") ? $csSrcAPSkey : "NULL") . ",\n";
			$sqlcoldata .= "   dest_appstack_id = " . (($csDestAPSkey ne "") ? $csDestAPSkey : "NULL") . ",\n";
			$sqlcoldata .= "   src_csasset_id = " . (($csSrcCSAkey ne "") ? $csSrcCSAkey : "NULL") . ",\n";
			$sqlcoldata .= "   dest_csasset_id = " . (($csDestCSAkey ne "") ? $csDestCSAkey : "NULL") . ",\n";
			$sqlcoldata .= "   lastscan = " . (($CSlastscan ne "") ? "\'". $CSlastscan . "\'" : "NULL") . ",\n";

			if ($csSrcIPkey ne "" && $csDestIPkey ne "" && $csSrcIPkey ne $csDestIPkey) {
				my $pkey = $csSrcIPkey  . $IndexDelimit . $csDestIPkey;
				if (exists($lkCSP{$pkey})) { # already in the database
					$sql = "UPDATE `" . $main::IDB_NAME . "`.`cspair` SET \n";
					$sql .= $sqlcoldata;
					$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
					$sql .= "   WHERE id = " . $lkCSP{$pkey}{id} . ";\n";
					$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$result = $dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlCSPUpdate++;
					}
				} else {
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`cspair` SET \n";
					$sql .= $sqlcoldata;
					$sql .= "   firstadd = CURRENT_TIMESTAMP,\n";
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$result = $dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlCSPInsert++;
						$lkCSP{$pkey}{id} = $dbh->{mysql_insertid};
					}
				}

				## CSTRAF update/inserts
				my $srcgrp = "";
				$srcgrp = $xlsRowVal{srcgroup} if ($xlsRowVal{srcgroup} ne "" && !($xlsRowVal{srcgroup} =~ m/none/i));
				my $destgrp = "";
				$destgrp  = $xlsRowVal{destgroup} if ($xlsRowVal{destgroup} ne "" && !($xlsRowVal{destgroup} =~ m/none/i));
				my $destport = "";
				$destport  = $xlsRowVal{destport} if ($xlsRowVal{destport} ne "" && looks_like_number($xlsRowVal{destport}));
				my $proto = "";
				$proto  = $xlsRowVal{protocolname} if ($xlsRowVal{protocolname} ne "");

				## 2/27/20 new sqlcoldata code to simplify NULLs
				$sqlcoldata = "   srcgroup = " . (($srcgrp ne "") ? "\'". $srcgrp . "\'" : "NULL") . ",\n";
				$sqlcoldata .= "   destgroup = " . (($destgrp ne "") ? "\'". $destgrp . "\'" : "NULL") . ",\n";
				$sqlcoldata .= "   destport = " . (($destport ne "") ? $destport : "NULL") . ",\n";
				$sqlcoldata .= "   protocolname = " . (($proto ne "") ? "\'". $proto . "\'" : "NULL") . ",\n";

				my $tkey = $srcgrp . $IndexDelimit . $destgrp . $IndexDelimit . $destport . $IndexDelimit . $proto;
				if (exists($lkCST{$tkey})) { # already in the database
					$sql = "UPDATE `" . $main::IDB_NAME . "`.`cstraf` SET \n";
					$sql .= $sqlcoldata;
					$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
					$sql .= "   WHERE id = " . $lkCST{$tkey}{id} . ";\n";
					$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$result = $dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlCSTUpdate++;
					}
				} else {
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`cstraf` SET \n";
					$sql .= $sqlcoldata;
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$result = $dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlCSTInsert++;
						$lkCST{$tkey}{id} = $dbh->{mysql_insertid};
					}
				}

				## CSPTREL update/inserts
				my $ptrkey = $lkCSP{$pkey}{id} . $IndexDelimit . $lkCST{$tkey}{id};
				if (exists($lkCSPTR{$ptrkey})) { # already in the database
					$sql = "UPDATE `" . $main::IDB_NAME . "`.`csptrel` SET \n";
					$sql .= "   hit_count = hit_count + 1,\n";
					$sql .= "   lastscan = \'". $CSlastscan . "\',\n" if ($CSlastscan ne "");
					$sql .= "   lastupdate = CURRENT_TIMESTAMP\n";
					$sql .= "   WHERE id = " . $lkCSPTR{$ptrkey}{id} . ";\n";
					$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$result = $dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlCSPTRUpdate++;
					}
				} else {
					$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`csptrel` SET \n";
					$sql .= "   cspair_id = ". $lkCSP{$pkey}{id} . ",\n";
					$sql .= "   cstraf_id = ". $lkCST{$tkey}{id}. ",\n";
					$sql .= "   hit_count = 1,\n";
					$sql .= "   lastscan = \'". $CSlastscan . "\',\n" if ($CSlastscan ne "");
					$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
					$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
					print $sql . "\n" if ($DEBUGSQL); # debug sql
					$result = $dbh->do($sql);
					if (!defined($dbh) ) {
						print "Error while executing SQL:\n";
						print $sql . "\n";
						print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
						$iSqlErr++;
					} else {
						$iSqlCSPTRInsert++;
						$lkCSPTR{$ptrkey}{id} = $dbh->{mysql_insertid};
					}
				}
			} # if src IP and dest IP aren't blank
		} # if we know the source IP
	} # if we are past the header row
	$row++; # increment row counter
} # while loop by row/line

## update tracking record with new data
$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iCSVRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-csdep-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "CSV Rows Read\t:" . $iCSVRows . "\n";
print "PAIR Inserts\t:" . $iSqlCSPInsert . "\n";
print "PAIR Updates\t:" . $iSqlCSPUpdate . "\n";
print "TRAF Inserts\t:" . $iSqlCSTInsert . "\n";
print "TRAF Updates\t:" . $iSqlCSTUpdate . "\n";
print "PTR Inserts\t:" . $iSqlCSPTRInsert . "\n";
print "PTR Updates\t:" . $iSqlCSPTRUpdate . "\n";
print "IP Inserts\t:" . $iSqlIPInsert . "\n";
print "IP Updates\t:" . $iSqlIPUpdate . "\n";
print "Data Errors\t:" . $iDataErrors . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
close($fhin);
exit;
