#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	SAMI (System and Application Master Inventory) File RE-Load (Import)
### Date:		May 1, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
############################################################################
use strict;
use warnings;
use Spreadsheet::ParseXLSX;
use DBI;
use Scalar::Util qw(looks_like_number);
use Data::Validate::IP qw(is_ipv4);
no warnings 'once';

require './ibm-globals.pl';

# Output a banner to show what we're doing
Display_Pgm_Banner("WSIB SAMI LOAD/UPDATE");

die "You must provide a SAMI Excel XLSX filename to $0 to be parsed" unless @ARGV;
my $file = $ARGV[0];
die "File " . $file . " does not exist, so cannot proceed.\n" if (!(-e $file));

my %lkSAMI 				= ();	# hash table to lookup SAMI records already in the database
my %lkOPS	 				= ();	# hash table to lookup OPS records already in the database by wsib hostname

my $iExcelRows 		= 0;  # total number of excel rows read
my $DEBUGSQL 			= 1; # set this = 1 to debug SQL statements -- sends output to console
my $FIRST_DATA_ROW; 	# this is the row to stop checking for headers and fail if all headers haven't been found

my $iSqlErr	= 0;
my $iSqlSAInsert = 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
#my $dbh = DBI->connect("DBI:mysql:database=". $main::IDB_NAME .";host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1});
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	print "Database not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

## Only load SAMI records that have corresponding operational systems
if ((grep { /opsinv/ } @dbTables) == 0) {
	print "Table: opsinv not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$sql = "SELECT op.wsibname, op.rscdname, op.id, INET_NTOA(ip.ipv4) \n";
	$sql .= "  FROM `" . $main::IDB_NAME . "`.`opsinv` op \n";
	$sql .= "  LEFT JOIN `" . $main::IDB_NAME . "`.`ipadd` ip ON op.ipadd_id = ip.id;\n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$sth = $dbh->prepare($sql);
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		my $lkey = $refr[0]; # wsibname
		$lkOPS{$lkey}{rscdname} = (defined($refr[1]) ? $refr[1] : "");
		$lkOPS{$lkey}{id} = $refr[2];
		$lkOPS{$lkey}{ipv4} = (defined($refr[3]) ? $refr[3] : "");
		print "******* LKU OPS: lkey=" .  $lkey . " shortname: " . $lkOPS{$lkey}{rscdname}  . "\n" if ($DEBUGSQL); # debug sql
	}
}

if ((grep { /sami/ } @dbTables) == 0) { # SAMI table not found
	print "Table: sami not found. Please run " . $main::DB_CREATE_SCRIPT . " before running this script.\n";
	$dbh->disconnect();
	die;
} else {
	$result = $dbh->do("TRUNCATE `" . $main::IDB_NAME . "`.`sami`;");    # 2/28/20 -- Always rebuild this table
}

# -----------------------------------------------------------------------
# SET UP THE EXCEL WORKBOOK
# -----------------------------------------------------------------------
print "\n**** Starting Excel parser...\n";
my $parser   = Spreadsheet::ParseXLSX->new();
my $workbook = $parser->parse($file);
die $parser->error(), ".\n" if ( !defined $workbook );

### MASTER SYSTEM MAPPING WORKSHEET
my $worksheet = $workbook->worksheet('Master System Mapping List');

my $current_sheet = trim($worksheet->get_name());

# Find out the worksheet ranges
my ( $row_min, $row_max ) = $worksheet->row_range();
my ( $col_min, $col_max ) = $worksheet->col_range();

print "\n**** Loading worksheet: " . uc($current_sheet) . " - " . ($row_max + 1) . " row(s)\n";

my $keycount = 0;
my $TotalHeaders	= 5;	# total number of column headers we need to find in this worksheet to proceed with processing
my %xlsCol=();	# hash table to define spreadsheet columns from which to obtain SQL data
$FIRST_DATA_ROW = 6;

for my $row ( $row_min .. $row_max ) {
	$iExcelRows++; # increment total Excel row counter
	if ( $keycount < $TotalHeaders && $row < ($FIRST_DATA_ROW - 1) ) {	# set up the column identifiers so that parsing works in the rest of the worksheet - find in the first 3 rows or die
		for my $col ( $col_min .. $col_max ) {
			my $cell = $worksheet->get_cell( $row, $col ); # Return the cell object at $row and $col
			next unless $cell;
			my $fld = lc(trim($cell->value()));
			if ( $fld eq 'environment' ) {
				$xlsCol{env} = $col;
				$keycount++;
			} elsif ( $fld eq 'server name cgi' ) {
				$xlsCol{rscdname} = $col;
				$keycount++;
			} elsif ( $fld eq 'server name wsib' ) {
				$xlsCol{wsibname} = $col;
				$keycount++;
			} elsif ( $fld =~ m/application component/i ) {
				$xlsCol{component} = $col;
				$keycount++;
			} elsif ( $fld eq 'nic1 ip') {
				$xlsCol{primaryip} = $col;
				$keycount++;
			} # end if
		} # end for col
	} elsif ($keycount < $TotalHeaders && $row >= ($FIRST_DATA_ROW - 1)) {
		print "\n**** ERROR: Found only $keycount key\(s\) of $TotalHeaders expected in the column header row.\n";
		print "****        Check input spreadsheet \(" . $file . "\) format column header row.\n";
		print "****        KEYS FOUND:\n";
		foreach my $key (sort keys %xlsCol) {
			print "****           $key\n";
		}
		$dbh->disconnect(); # disconnect gracefully
		die;
	} elsif ($keycount == $TotalHeaders) {
		# NEW CODE TO LOCALIZE ROW VALUES
		my %xlsRowVal	= ();	# hash table to contain excel row values
		foreach my $key (keys %xlsCol) {
			my $cell = $worksheet->get_cell( $row, $xlsCol{$key} );
			$xlsRowVal{$key} = "";
			$xlsRowVal{$key} = trim($cell->value()) if $cell;
		}

		my $assetWSIBname = lc(substr($xlsRowVal{wsibname},0,64));
		my $assetRSCDname = lc(substr($xlsRowVal{rscdname},0,64));
		my $assetPrimaryIP = (is_ipv4($xlsRowVal{primaryip}) ? $xlsRowVal{primaryip} : "");

		if ($assetWSIBname ne "" && exists($lkOPS{$assetWSIBname})) {
			$assetRSCDname = $lkOPS{$assetWSIBname}{rscdname};
			$assetPrimaryIP = $lkOPS{$assetWSIBname}{ipv4};
		} else {
			$assetWSIBname = ""; # no match means skip it
		}
		next if ($assetWSIBname eq ""); # skip this one

		# clean up the values to assure clean db queries
		$xlsRowVal{env} = "PRD" if ($xlsRowVal{env} =~ m/prd/i); # prod supercedes all others
		$xlsRowVal{env} =~ s/\;.*$//; # replace everything after the first ; with nothing if multiple environments
		$xlsRowVal{env} = substr($xlsRowVal{env},0,64);

		$xlsRowVal{component} =~ s/\v/ /g; # replace any /n or /r with a space
		$xlsRowVal{component} = substr($xlsRowVal{component},0,255);

		## 2/28/20 new sqlcoldata code to simplify NULLs
		my $sqlcoldata =  "   wsibname = \'". $assetWSIBname . "\',\n";
		$sqlcoldata .= "   rscdname = " . (($assetRSCDname ne "") ? "\'". $assetRSCDname . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   ipv4 = " . (($assetPrimaryIP ne "") ? "INET_ATON(\'". $assetPrimaryIP . "\')" : "NULL") . ",\n";
		$sqlcoldata .= "   env = " . (($xlsRowVal{env} ne "") ? "\'". $xlsRowVal{env} . "\'" : "NULL") . ",\n";
		$sqlcoldata .= "   component = " . (($xlsRowVal{component}  ne "") ? "\'". $xlsRowVal{component}  . "\'" : "NULL") . ",\n";

		if (!exists($lkSAMI{$assetWSIBname})) {
			$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`sami` SET \n";
			$sql .= $sqlcoldata;
			$sql .= "   lastupdate = CURRENT_TIMESTAMP;\n";
			$sql =~ s/[^[:ascii:]]+//g; # remove any non-ascii chars
			print $sql . "\n" if ($DEBUGSQL); # debug sql
			$dbh->do($sql);
			if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
				$iSqlErr++;
			} else {
				$iSqlSAInsert++;
				my $lkey = $assetWSIBname;
				$lkSAMI{$lkey}{id} = $dbh->{mysql_insertid}; # SAMI key
			}
		} # end insert or update to database
	} # end if headers have all been found
} # end for row

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_in = " . $iExcelRows . "\n";
$sql .= "   WHERE datasrcscript='ibm-sami-load.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "Excel Rows\t:" . $iExcelRows . "\n";
print "SAMI Inserts\t:" . $iSqlSAInsert . "\n";
print "SQL Errors\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
