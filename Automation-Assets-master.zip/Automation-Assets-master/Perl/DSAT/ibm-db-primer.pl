#!/usr/bin/perl
############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	DB PRIMER - This script primes the database with tables and basic data
### Date:		August 19, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### 1. ibm-db-primer.pl - run this script first to assure database and tables are created. Must be run first.
### 2. ibm-vlan-load.pl - run this script to load loc, vlan and ipadd tables. Must be run second.
### 3. ibm-addm-load.pl - run this script load the addm table and update the ipadd table.
### 4. ibm-ops-load.pl - run this script load the opsinv table and update the ipadd table.
### 5. ibm-rvt-load.pl - run this script to load the rvt table and update ipadd table.
### 6. ibm-csasset-load.pl - run this script to load the appstack, csasset and csasiprel tables (from Cloudscape) and update ipadd table.
### 7. ibm-csdep-load.pl - run this script to load the cspair, cstraf and csptref tables (from Cloudscape) and update ipadd table.
### 8. ibm-sami-load.pl - run this script to load the sami reference table for legacy environment lookups.
### 9. ibm-master-load.pl - run this script to build the inventory, inviprel and event tables.
### 10. ibm-storage-load.pl - run this script to build the sanspecs and nasspecs tables.
### 11. ibm-dbms-load.pl - run this script to build the dbms and dbinst tables.
### 12. ibm-appstack-load.pl - run this script to enrich the appstack table.
### 13. ibm-master-gen.pl - run this script to generate a new master inventory workbook.
### 14. ibm-profile-gen.pl - run this script to generate a migration profiles workbook (ad hoc report).
### 15. ibm-traffic-gen.pl - run this script to generate a traffic profiles workbook by vlan (ad hoc report).
### ---- MAJOR MILESTONE HISTORY: -----
### 2/19/20 - Rewrite IP address code to only place what is operational in the subnet
### 2/19/20 - Business decision to remove SAMI from trusted sources
### 2/24/20 - Found a whole wave group bundle 8A that was missed (DDCDR1)
### 4/10/20 - Added new code to ibm-master-load.pl and ibm-master-gen.pl to capture "other IPs" than primary
### 4/13/20 - Now picking up all IP addresses from data sources, regardless of in the VLAN sheet scope or not
### 6/23/20 - Split out the events table initial build to a new import script and subsequent spreadsheet for easy maintenance of event schedule
############################################################################
use strict;
use warnings;
use DBI;
no warnings 'once';

require './ibm-globals.pl';

my $fNewDB 				= 0; 	# This is a new installation?
my $DEBUGSQL 			= 1; 	# set this = 1 to debug SQL statements -- sends output to console
my $iSqlErr				= 0;

# Output a banner to show what we're doing
Display_Pgm_Banner("PRIMING THE DATABASE");

# reset data - this means drop the database and start from scratch?
my $fResetData;
$fResetData = (defined($ARGV[0]) && ($ARGV[0] =~ m/complete/i ) )  ? 1 : 0;

# ------------------------------------------------------------------------
# PERL MYSQL DBI CONNECT()
# ------------------------------------------------------------------------
my $dbh = DBI->connect("$main::IDB_DBI;host=". $main::IDB_HOST, $main::IDB_USER, $main::IDB_PWD,{'RaiseError' => 1}); # connect to the mysql server
my $sql;
my $sth;
my @refr = ();
my $result;

$sql = "SHOW DATABASES LIKE '" . $main::IDB_NAME ."'";
$result = $dbh->do($sql);
if ($result != 1) {
	# create the database
	print "Database: ". $main::IDB_NAME . " not found. Creating new database.\n";
	$sql = "CREATE DATABASE " . $main::IDB_NAME;
	$result = $dbh->do($sql);
	$fNewDB = 1;
} else {
	if ($fResetData) {
		# drop and re-create the database
		print "Dropping database: ". $main::IDB_NAME . " and creating new database.\n";
		$sql = "DROP DATABASE " . $main::IDB_NAME;
		$result = $dbh->do($sql);
		$sql = "CREATE DATABASE " . $main::IDB_NAME;
		$result = $dbh->do($sql);
		$fNewDB = 1;
	} else {
			print "Database: ". $main::IDB_NAME . " already exists.\n";
	}
}

my @dbTables = ();	# database table array
$sth = $dbh->prepare("SHOW TABLES IN `" . $main::IDB_NAME . "`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	push @dbTables, lc($refr[0]);
}

if (scalar @dbTables > 0) {
	print "The following tables exist in database ". $main::IDB_NAME . ":\n";
	foreach my $tbl (@dbTables) {
		print "\t$tbl\n";
	}
}
# -----------------------------------------------------------------------
# CREATE NEW TABLES
# -----------------------------------------------------------------------

# create the LOCATION table
if ($fNewDB || (grep { /location/ } @dbTables) == 0) {
	print "Table: location not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`location` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `code` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `name` VARCHAR(255) NULL,\n";
	$sql .= "  `citycountry` VARCHAR(255) NULL,\n";
	$sql .= "  `dcowner` VARCHAR(255) NULL,\n";
	$sql .= "  `migcontext` CHAR(1) NOT NULL,\n"; # migration context
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "location";
	}
}

# create the VLAN table
if ($fNewDB || (grep { /vlan/ } @dbTables) == 0) { # IP address assignment table
	print "Table: vlan not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`vlan` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `tgt_location_id` INT UNSIGNED NULL,\n";
	$sql .= "  `subnet` VARCHAR(255) NOT NULL,\n"; ## 2/19/20 -- must have the subnet
	$sql .= "  `number` INT UNSIGNED NOT NULL,\n"; ## must have logical VLAN number
	$sql .= "  `name` VARCHAR(255) NULL,\n";
	$sql .= "  `zone` VARCHAR(255) NULL,\n";
	$sql .= "  `env1` VARCHAR(255) NULL,\n";
	$sql .= "  `env2` VARCHAR(255) NULL,\n";
	$sql .= "  `status` CHAR(1) NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  KEY `vln_key_IDX` (`location_id`,`number`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "vlan";
	}
}

# create the IP Address IPADD table
if ($fNewDB || (grep { /ipadd/ } @dbTables) == 0) {
	print "Table: ipadd not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`ipadd` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NULL,\n";
	$sql .= "  `ipv4` INT UNSIGNED NOT NULL,\n"; # store IP addresses as INT UNSIGNED
	$sql .= "  `name` VARCHAR(255) NULL,\n"; # 7/21/20 Added for nmap device or host name if provided
	$sql .= "  `vlan_id` INT UNSIGNED NULL,\n"; ## 4/12/20 if vlan_id = NULL, this is not in the VLAN sheet
	$sql .= "  `vs_ipadd_id` INT UNSIGNED NULL,\n"; ## 5/7/20 adding VIP if there is a parent VIP and this is in a load balanced pool
	$sql .= "  `active` TINYINT NULL,\n"; ## 7/21/20 Added for active IP if provided - placeholder for real-time operations reporting
	$sql .= "  `inuse` TINYINT NULL,\n";
	$sql .= "  `loadbal` TINYINT NULL,\n"; ## 5/7/20 0 or NULL = not load balanced; 1=IP in a load balanced pool; 2=IP is a VIP
	$sql .= "  `inaddm` TINYINT NULL,\n";
	$sql .= "  `inrvt` TINYINT NULL,\n";
	$sql .= "  `inopsinv` TINYINT NULL,\n"; ## 6/19/20 -- added back for optimization of master load
	$sql .= "  `verifiedscope` TINYINT NULL,\n";
	$sql .= "  `cloudscapescan` TINYINT NULL,\n";
	$sql .= "  `cloudscapeasset` TINYINT NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastseen` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  KEY `ipv4_key_IDX` (`location_id`,`ipv4`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "ipadd";
	}
}

# create the ADDM table
if ($fNewDB || (grep { /addm/ } @dbTables) == 0) {
	print "Table: addm not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`addm` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `name` VARCHAR(255) NOT NULL,\n"; # this is the CI NAME from Column B (CI Name) nd Column R (System CI Name)
	$sql .= "  `type` TINYINT NOT NULL,\n"; # type classifier
	$sql .= "  `product` VARCHAR(255) NULL,\n"; # this is the product name from Column F
	$sql .= "  `manufacturer` VARCHAR(255) NULL,\n"; # this is the manufacturer from Column H
	$sql .= "  `serialnum` VARCHAR(255) NULL,\n"; # this is the serial number from Column I
	$sql .= "  `admos_id` INT UNSIGNED NULL,\n"; # key to the OS software
	$sql .= "  `cpu` INT UNSIGNED NULL,\n"; # calculated Tier1="IT Hardware", Tier2="Component", Tier3=~m/cpu/i per CI Name
	$sql .= "  `ipsinrange` INT UNSIGNED NULL,\n"; # calculated - number of IPs in range
	$sql .= "  `createdate` TIMESTAMP NULL,\n";
	$sql .= "  `modifydate` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `nm_key_IDX` (`name`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "addm";
	}
}

# create the ADDMSW table
if ($fNewDB || (grep { /addmsw/ } @dbTables) == 0) {
	print "Table: addmsw not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`addmsw` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `product` VARCHAR(255) NOT NULL,\n"; # this is the product name from Column F
	$sql .= "  `type` TINYINT NOT NULL,\n"; # type classifier
	$sql .= "  `modelver` VARCHAR(255) NULL,\n"; # this is the model/version number from Column G
	$sql .= "  `manufacturer` VARCHAR(255) NULL,\n"; # this is the manufacturer from Column H
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  KEY `sw_key_IDX` (`type`,`product`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "addmsw";
	}
}

# create the ADIPREL table
if ($fNewDB || (grep { /adiprel/ } @dbTables) == 0) {
	print "Table: adiprel not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`adiprel` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `addm_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED NOT NULL,\n"; # key to the respective table
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "adiprel";
	}
}

# create the ADSWREL table
if ($fNewDB || (grep { /adswrel/ } @dbTables) == 0) {
	print "Table: adswrel not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`adswrel` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `addm_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `addmsw_id` INT UNSIGNED NOT NULL,\n"; # key to the respective table
	$sql .= "  `instname` VARCHAR(255) NULL,\n"; # this is the instance name (i.e. database or application instance)
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "adswrel";
	}
}

# create the LBPOOL table 5/10/20
if ($fNewDB || (grep { /lbpool/ } @dbTables) == 0) {
	print "Table: lbpool not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`lbpool` ( \n";
	$sql .= "  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `lbdev_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `vs_name` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `pool_name` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `vs_ipv4` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `pool_ipv4` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `pool_membername` VARCHAR(255) NULL,\n";
	$sql .= "  `vs_ipadd_id` INT UNSIGNED NULL,\n";
	$sql .= "  `pool_ipadd_id` INT UNSIGNED NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "lbpool";
	}
}

# create the LBDEV table
if ($fNewDB || (grep { /lbdev/ } @dbTables) == 0) {
	print "Table: lbdev not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`lbdev` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `name` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `lbd_key_IDX` (`location_id`,`name`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "lbdev";
	}
}

# create the OPSINV table
if ($fNewDB || (grep { /opsinv/ } @dbTables) == 0) {
	print "Table: opsinv not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`opsinv` ( \n";
	$sql .= "  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `wsibname` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `rscdname` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED NULL,\n";
	$sql .= "  `os_id` INT UNSIGNED NULL,\n";
	$sql .= "  `fqdn` VARCHAR(255) NULL,\n";
	$sql .= "  `ostype` VARCHAR(255) NULL,\n";
	$sql .= "  `osplatform` VARCHAR(255) NULL,\n";
	$sql .= "  `osversion` VARCHAR(255) NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastseen` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `opsinv_nm_key_IDX` (`rscdname`),\n";
	$sql .= "  KEY `opsinv_wnm_key_IDX` (`wsibname`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
				print "Error while executing SQL:\n";
				print $sql . "\n";
				print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "opsinv";
	}
}

# create the RVT table
if ($fNewDB || (grep { /rvt/ } @dbTables) == 0) {
	print "Table: rvt not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`rvt` ( \n";
	$sql .= "  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED NULL,\n";
	$sql .= "  `vcenter_id` INT UNSIGNED NULL,\n";
	$sql .= "  `opsinv_id` INT UNSIGNED NULL,\n";
	$sql .= "  `vmname` VARCHAR(512) NULL,\n";
	$sql .= "  `rscdname` VARCHAR(255) NULL,\n";
	$sql .= "  `vmuuid` VARCHAR(40) NOT NULL,\n";
	$sql .= "  `dnsname` VARCHAR(255) NULL,\n";
	$sql .= "  `network1` VARCHAR(255) NULL,\n";
	$sql .= "  `network2` VARCHAR(255) NULL,\n";
	$sql .= "  `network3` VARCHAR(255) NULL,\n";
	$sql .= "  `network4` VARCHAR(255) NULL,\n";
	$sql .= "  `clustername` VARCHAR(255) NULL,\n";
	$sql .= "  `osperconfig` VARCHAR(255) NULL,\n";
	$sql .= "  `ospertools` VARCHAR(255) NULL,\n";
	$sql .= "  `osplatform` VARCHAR(10) NULL,\n";
	$sql .= "  `cpus` INT UNSIGNED NULL,\n";
	$sql .= "  `memory` INT UNSIGNED NULL,\n";
	$sql .= "  `nics` INT UNSIGNED NULL,\n";
	$sql .= "  `disks` INT UNSIGNED NULL,\n";
	$sql .= "  `raw` INT UNSIGNED NULL,\n";
	$sql .= "  `thin` INT UNSIGNED NULL,\n";
	$sql .= "  `latencysens` INT UNSIGNED NULL,\n";
	$sql .= "  `provisionmb` INT UNSIGNED NULL,\n";
	$sql .= "  `inusemb` INT UNSIGNED NULL,\n";
	$sql .= "  `powerstate` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `gueststate` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `connectstate` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `template` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastseen` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `rvu_key_IDX` (`vcenter_id`,`vmuuid`),\n";
	$sql .= "  KEY `rvu_cnm_key_IDX` (`rscdname`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "rvt";
	}
}

# create the VCENTER table
if ($fNewDB || (grep { /vcenter/ } @dbTables) == 0) {
	print "Table: vcenter not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`vcenter` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `name` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `ipv4` INT UNSIGNED NULL,\n"; # we won't be migrating vCenters, so not important to link to a ipadd row
	$sql .= "  `lastrun` VARCHAR(255) NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `vc_key_IDX` (`location_id`,`name`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "vcenter";
	}
}

# create the INVENTORY table
if ($fNewDB || (grep { /inventory/ } @dbTables) == 0) {
	print "Table: inventory not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`inventory` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `excel_row` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `category` VARCHAR(255) NULL,\n";
	$sql .= "  `ipcell` VARCHAR(255) NULL,\n";
	$sql .= "  `wsibname` VARCHAR(255) NULL,\n";
	$sql .= "  `rscdname` VARCHAR(255) NULL,\n";
	$sql .= "  `location_id` INT UNSIGNED NULL,\n";
	$sql .= "  `tgtlocation_id` INT UNSIGNED NULL,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED NULL,\n";
	$sql .= "  `addm_id` INT UNSIGNED NULL,\n";
	$sql .= "  `opsinv_id` INT UNSIGNED NULL,\n";
	$sql .= "  `rvt_id` INT UNSIGNED NULL,\n";
	$sql .= "  `os_id` INT UNSIGNED NULL,\n";
	$sql .= "  `event_id` INT UNSIGNED NULL,\n";
	$sql .= "  `pattern_id` INT UNSIGNED NULL,\n";
	$sql .= "  `csasset_id` INT UNSIGNED NULL,\n";
	$sql .= "  `sami_id` INT UNSIGNED NULL,\n";
	$sql .= "  `premigration` VARCHAR(255) NULL,\n";
	$sql .= "  `serialnum` VARCHAR(255) NULL,\n";
	$sql .= "  `primaryfunction` VARCHAR(255) NULL,\n";
	$sql .= "  `baselinedelta` VARCHAR(255) NULL,\n";
	$sql .= "  `riskfactor` TINYINT UNSIGNED NULL,\n"; # input from master for this asset
	$sql .= "  `calcriskfactor` INT UNSIGNED NULL,\n"; # calculated from all risk factors
	$sql .= "  `notes` VARCHAR(2048) NULL,\n";
	$sql .= "  `verifiedscope` TINYINT NULL,\n";
	$sql .= "  `discoverystatus` TINYINT NULL,\n";
	$sql .= "  `dispositioncode` TINYINT NULL,\n";
	$sql .= "  `ipdispositioncode` TINYINT NULL,\n";
	$sql .= "  `disasterrecovery` TINYINT NULL,\n";
	$sql .= "  `migrationstatus` TINYINT NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  KEY `inv_key_IDX` (`excel_row`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "inventory";
	}
}

# create the INVIPREL table
if ($fNewDB || (grep { /inviprel/ } @dbTables) == 0) {
	print "Table: inviprel not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`inviprel` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `inv_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED NOT NULL,\n"; # ip address key
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "inviprel";
	}
}

# create the OPSYS table
if ($fNewDB || (grep { /opsys/ } @dbTables) == 0) {
	print "Table: opsys not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`opsys` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `name` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `platform` VARCHAR(255) NULL,\n";
	$sql .= "  `eol` VARCHAR(255) NULL,\n";
	$sql .= "  `eoxs` VARCHAR(255) NULL,\n";
	$sql .= "  `nminus2` TINYINT NULL,\n";
	$sql .= "  `riskfactor` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `os_key_IDX` (`name`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "opsys";
	}
}

# create the DSATTRAC table
if ($fNewDB || (grep { /dsattrack/ } @dbTables) == 0) {
	print "Table: dsattrack not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`dsattrack` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `datasrcscript` VARCHAR(255) NOT NULL,\n"; # script name
	$sql .= "  `datasrcname` VARCHAR(255) NULL,\n"; # name
	$sql .= "  `datasrcdesc` VARCHAR(255) NULL,\n"; # description
	$sql .= "  `datasrcconst` VARCHAR(255) NULL,\n"; # constraints
	$sql .= "  `script_seq` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `lastrun` TIMESTAMP NULL,\n";
	$sql .= "  `rows_in` INT UNSIGNED NULL,\n";
	$sql .= "  `rows_out` INT UNSIGNED NULL,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `tr_key_IDX` (`datasrcscript`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "dsattrack";
	}
}

# create the ERROR table
if ($fNewDB || (grep { /errors/ } @dbTables) == 0) {
	print "Table: errors not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`errors` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `type` VARCHAR(25) NOT NULL,\n";
	$sql .= "  `errorlog` VARCHAR(512) NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "errors";
	}
}

# create the NOTIFY table
if ($fNewDB || (grep { /notify/ } @dbTables) == 0) {
	print "Table: notify not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`notify` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `type` VARCHAR(25) NOT NULL,\n";
	$sql .= "  `message` VARCHAR(512) NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "notify";
	}
}

# create the EVENT table
if ($fNewDB || (grep { /event/ } @dbTables) == 0) {
	print "Table: event not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`event` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `tgtlocation_id` INT UNSIGNED NULL,\n";
	$sql .= "  `name` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `wavesequence` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `description` VARCHAR(255) NULL,\n";
	$sql .= "  `nonprod_cutover` VARCHAR(30) NULL,\n"; # split cutover target between non-prod and prod
	$sql .= "  `cutover` VARCHAR(30) NULL,\n";
	$sql .= "  `contingency_cutover` VARCHAR(30) NULL,\n";
	$sql .= "  `notes` VARCHAR(1024) NULL,\n";
	$sql .= "  `riskfactor` TINYINT UNSIGNED NULL,\n"; # risk factor for the event (prod is higher than non-prod, etc.
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `evt_key_IDX` (`location_id`,`name`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "event";
	}
}

# create the PATTERN table
if ($fNewDB || (grep { /pattern/ } @dbTables) == 0) {
	print "Table: pattern not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`pattern` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `name` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `detail` VARCHAR(1024) NULL,\n";
	$sql .= "  `riskfactor` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  KEY `ptn_key_IDX` (`name`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "pattern";
	}
}


# create the APPSTACK table
if ($fNewDB || (grep { /appstack/ } @dbTables) == 0) {
	print "Table: appstack not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`appstack` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `stackname` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `description` VARCHAR(1024) NULL,\n";
	$sql .= "  `ownname1` VARCHAR(255) NULL,\n";
	$sql .= "  `ownphone1` VARCHAR(255) NULL,\n";
	$sql .= "  `ownemail1` VARCHAR(255) NULL,\n";
	$sql .= "  `ownname2` VARCHAR(255) NULL,\n";
	$sql .= "  `ownphone2` VARCHAR(255) NULL,\n";
	$sql .= "  `ownemail2` VARCHAR(255) NULL,\n";
	$sql .= "  `ownname3` VARCHAR(255) NULL,\n";
	$sql .= "  `ownphone3` VARCHAR(255) NULL,\n";
	$sql .= "  `ownemail3` VARCHAR(255) NULL,\n";
	$sql .= "  `ownname4` VARCHAR(255) NULL,\n";
	$sql .= "  `ownphone4` VARCHAR(255) NULL,\n";
	$sql .= "  `ownemail4` VARCHAR(255) NULL,\n";
	$sql .= "  `criticality` TINYINT NULL,\n";
	$sql .= "  `disposition` TINYINT NULL,\n";
	$sql .= "  `notes` VARCHAR(1024) NULL,\n";
	$sql .= "  `riskfactor` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  KEY `app_key_IDX` (`stackname`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "appstack";
	}
}

# create the CSASSET table
if ($fNewDB || (grep { /csasset/ } @dbTables) == 0) {
	print "Table: csasset not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`csasset` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NULL,\n";
	$sql .= "  `appstack_id` INT UNSIGNED NULL,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED NULL,\n"; # primary IP address
	$sql .= "  `uid` VARCHAR(255) NOT NULL,\n"; #unique ID from Cloudscape Tag
	$sql .= "  `hostname` VARCHAR(255) NULL,\n";
	$sql .= "  `devicetype` VARCHAR(255) NULL,\n";
	$sql .= "  `cpucount` INT UNSIGNED NULL,\n";
	$sql .= "  `cpufrequency` INT UNSIGNED NULL,\n";
	$sql .= "  `memorygb` INT UNSIGNED NULL,\n";
	$sql .= "  `processors` INT UNSIGNED NULL,\n";
	$sql .= "  `cores` INT UNSIGNED NULL,\n";
	$sql .= "  `servos` VARCHAR(255) NULL,\n";
	$sql .= "  `osver` VARCHAR(255) NULL,\n";
	$sql .= "  `hwvendor` VARCHAR(255) NULL,\n";
	$sql .= "  `hwmodel` VARCHAR(255) NULL,\n";
	$sql .= "  `inscope` VARCHAR(255) NULL,\n";
	$sql .= "  `dnsarecord` VARCHAR(255) NULL,\n";
	$sql .= "  `wsib_os` VARCHAR(255) NULL,\n";
	$sql .= "  `wsib_hostname` VARCHAR(255) NULL,\n";
	$sql .= "  `wsib_devicedetails` VARCHAR(255) NULL,\n";
	$sql .= "  `referencetag` VARCHAR(255) NULL,\n";
	$sql .= "  `tier` VARCHAR(255) NULL,\n";
	$sql .= "  `dbinstance` VARCHAR(255) NULL,\n";
	$sql .= "  `scopenotes` VARCHAR(1024) NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `csassetuid_key_IDX` (`uid`))\n";
	#$sql .= "  UNIQUE KEY `csassetip_key_IDX` (`primaryip`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "csasset";
	}
}

# create the CSASIPREL table
if ($fNewDB || (grep { /csasiprel/ } @dbTables) == 0) {
	print "Table: csasiprel not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`csasiprel` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `csasset_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED NOT NULL,\n"; # ip address key
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "csasiprel";
	}
}

# create the CSPAIR table
if ($fNewDB || (grep { /cspair/ } @dbTables) == 0) {
	print "Table: cspair not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`cspair` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `srcname` VARCHAR(255) NULL,\n";
	$sql .= "  `destname` VARCHAR(255) NULL,\n";
	$sql .= "  `src_ipadd_id` INT UNSIGNED NULL,\n";
	$sql .= "  `dest_ipadd_id` INT UNSIGNED NULL,\n";
	$sql .= "  `src_appstack_id` INT UNSIGNED NULL,\n";
	$sql .= "  `dest_appstack_id` INT UNSIGNED NULL,\n";
	$sql .= "  `src_csasset_id` INT UNSIGNED NULL,\n";
	$sql .= "  `dest_csasset_id` INT UNSIGNED NULL,\n";
	$sql .= "  `lastscan` TIMESTAMP NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "cspair";
	}
}

# create the CSTRAF table
if ($fNewDB || (grep { /cstraf/ } @dbTables) == 0) {
	print "Table: cstraf not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`cstraf` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `srcgroup` VARCHAR(255) NULL,\n";
	$sql .= "  `destgroup` VARCHAR(255) NULL,\n";
	$sql .= "  `destport` INT UNSIGNED NULL,\n";
	$sql .= "  `protocolname` VARCHAR(64) NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "cstraf";
	}
}

# create the CSPTREL table
if ($fNewDB || (grep { /csptrel/ } @dbTables) == 0) {
	print "Table: csptrel not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`csptrel` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `cspair_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `cstraf_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `hit_count` INT UNSIGNED DEFAULT 1,\n";
	$sql .= "  `lastscan` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `cspt_key_IDX` (`cspair_id`, `cstraf_id`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "csptrel";
	}
}

# create the SANSPECS table
if ($fNewDB || (grep { /sanspecs/ } @dbTables) == 0) {
	print "Table: sanspecs not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`sanspecs` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `lunid` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `rscdname1` VARCHAR(255) NULL,\n";
	$sql .= "  `rscdname2` VARCHAR(255) NULL,\n";
	$sql .= "  `serialnum` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `class` VARCHAR(255) NULL,\n";
	$sql .= "  `alias1` VARCHAR(255) NULL,\n";
	$sql .= "  `alias2` VARCHAR(255) NULL,\n";
	$sql .= "  `servername` VARCHAR(255) NULL,\n";
	$sql .= "  `inv_id` INT UNSIGNED NULL,\n";
	$sql .= "  `environment` VARCHAR(255) NULL,\n";
	$sql .= "  `vgname` VARCHAR(255) NULL,\n";
	$sql .= "  `diskname` VARCHAR(255) NULL,\n";
	$sql .= "  `disksizegb` INT UNSIGNED NULL,\n";
	$sql .= "  `serveros` VARCHAR(255) NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `san_key_IDX` (`location_id`,`serialnum`,`lunid`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "sanspecs";
	}
}

# create the NASSPECS table
if ($fNewDB || (grep { /nasspecs/ } @dbTables) == 0) {
	print "Table: nasspecs not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`nasspecs` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `evsid` INT UNSIGNED NULL,\n";
	$sql .= "  `evsip` INT UNSIGNED NULL,\n"; # store IP addresses as INT UNSIGNED
	$sql .= "  `evslabel` VARCHAR(255) NULL,\n";
	$sql .= "  `sharename` VARCHAR(255) NULL,\n";
	$sql .= "  `alloccapgb` INT UNSIGNED NULL,\n";
	$sql .= "  `usedcapgb` INT UNSIGNED NULL,\n";
	$sql .= "  `protocol` VARCHAR(30) NULL,\n";
	$sql .= "  `filesystem` VARCHAR(255) NULL,\n";
	$sql .= "  `path` VARCHAR(255) NULL,\n";
	$sql .= "  `replication` TINYINT NULL,\n";
	$sql .= "  `mountpoint` VARCHAR(255) NULL,\n";
	$sql .= "  `serversmapped` VARCHAR(255) NULL,\n";
	$sql .= "  `security` VARCHAR(1024) NULL,\n";
	$sql .= "  `firstadd` TIMESTAMP NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "nasspecs";
	}
}

# create the NASMAP table
if ($fNewDB || (grep { /nasmap/ } @dbTables) == 0) {
	print "Table: nasmap not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`nasmap` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `inv_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `nas_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `nas_ip` INT UNSIGNED NULL,\n"; # private IP address
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "nasmap";
	}
}

# create the DBINSTANCE table
if ($fNewDB || (grep { /dbinst/ } @dbTables) == 0) {
	print "Table: dbinst not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`dbinst` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `dbms_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `ipadd_id` INT UNSIGNED,\n";
	$sql .= "  `vipadd_id` INT UNSIGNED,\n";
	$sql .= "  `inv_id` INT UNSIGNED,\n";
	$sql .= "  `dbname` VARCHAR(255) NULL,\n";
	$sql .= "  `instancename` VARCHAR(255) NULL,\n";
	$sql .= "  `appassociated` VARCHAR(255) NULL,\n";
	$sql .= "  `wsibenv` VARCHAR(255) NULL,\n";
	$sql .= "  `cluster` TINYINT NULL,\n";
	$sql .= "  `patchlevel` VARCHAR(255) NULL,\n";
	$sql .= "  `supported` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `notes` VARCHAR(512) NULL,\n";
	$sql .= "  `riskfactor` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "dbinst";
	}
}

# create the DBMS table
if ($fNewDB || (grep { /dbms/ } @dbTables) == 0) {
	print "Table: dbms not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`dbms` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `shortname` VARCHAR(255) NOT NULL,\n"; # DBMS unique shortname
	$sql .= "  `manufacturer` VARCHAR(255) NULL,\n"; # DBMS manufacturer ("Oracle","Microsoft","IBM", etc.)
	$sql .= "  `dbtype` VARCHAR(255) NULL,\n"; # DBMS Type (“Oracle”,”SQL Server”, etc.)
	$sql .= "  `edition` VARCHAR(255) NULL,\n"; # DBMS Edition
	$sql .= "  `version` VARCHAR(255) NULL,\n"; # DBMS Version
	$sql .= "  `latestrel` VARCHAR(255) NULL,\n"; # DBMS Latest Release
	$sql .= "  `eol` VARCHAR(255) NULL,\n"; # DBMS End of Life Information
	$sql .= "  `eoxs` VARCHAR(255) NULL,\n"; # DBMS End of Extended Support Information
	$sql .= "  `speol` VARCHAR(255) NULL,\n"; # DBMS Service Pack End of Life Information
	$sql .= "  `supported` TINYINT NULL,\n"; # DBMS Supported by Manufacturer y/n
	$sql .= "  `notes` VARCHAR(512) NULL,\n";
	$sql .= "  `riskfactor` TINYINT UNSIGNED NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `dbms_key_IDX` (`shortname`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "dbms";
	}
}

## 2/26/20 Legacy SAMI file support for failed lookups
# create the SAMI table
if ($fNewDB || (grep { /sami/ } @dbTables) == 0) {
	print "Table: sami not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`sami` ( \n";
	$sql .= "  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `ipv4` INT UNSIGNED NULL,\n"; ## just for legacy lookups
	$sql .= "  `wsibname` VARCHAR(64) NOT NULL,\n";
	$sql .= "  `rscdname` VARCHAR(64) NULL,\n";
	$sql .= "  `env` VARCHAR(64) NULL,\n";
	$sql .= "  `component` VARCHAR(255) NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `sami_key_IDX` (`wsibname`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "sami";
	}
}

# 7/14/20 Create the vmtarget table (for VPG creation automation)
if ($fNewDB || (grep { /vmtarget/ } @dbTables) == 0) {
	print "Table: vmtarget not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`vmtarget` ( \n";
	$sql .= "  `id` INT unsigned NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `location_id` INT UNSIGNED NOT NULL,\n";
	$sql .= "  `recoverysitename` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `clustername` VARCHAR(255) NOT NULL,\n";
	$sql .= "  `datastorename` VARCHAR(255) NULL,\n";
	$sql .= "  `env` CHAR(1) NOT NULL,\n";
	$sql .= "  `platform` CHAR(1) NOT NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  KEY `vmtgt_key_IDX` (`location_id`,`clustername`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "vmtarget";
	}
}

## 6/19/20 Legacy SAMI file support for failed lookups
# create the REDFLAG table
if ($fNewDB || (grep { /redflag/ } @dbTables) == 0) {
	print "Table: redflag not found. Creating new table.\n";
	$sql = "CREATE TABLE `" . $main::IDB_NAME . "`.`redflag` ( \n";
	$sql .= "  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,\n";
	$sql .= "  `shortkey` VARCHAR(64) NOT NULL,\n";
	$sql .= "  `notify` TINYINT NULL,\n";
	$sql .= "  `resolution` VARCHAR(255) NULL,\n";
	$sql .= "  `lastupdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,\n";
	$sql .= "  PRIMARY KEY (`id`),\n";
	$sql .= "  UNIQUE INDEX `id_key_UNIQUE` (`id` ASC),\n";
	$sql .= "  UNIQUE KEY `redflag_key_IDX` (`shortkey`))\n";
	$sql .= "ENGINE = InnoDB\n";
	$sql .= "DEFAULT CHARACTER SET = utf8\n";
	$sql .= "COLLATE = utf8_unicode_ci;\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$result = $dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	} else {
		push @dbTables, "redflag";
	}
}

# -----------------------------------------------------------------------
# LOAD BASIC DATA
# -----------------------------------------------------------------------
my $rowsOut = 0;
my $pattern_rows = 0;
$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`pattern`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	$pattern_rows = $refr[0];
}

if ($fNewDB || $pattern_rows == 0) {
	## MIGRATION PATTERNS
	$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`pattern` (name,detail,riskfactor,lastupdate) VALUES  \n";
	$sql .= "('Undetermined','Discovery still in progress. Migration pattern has yet to be determined.',255,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Key Details Missing','System details are missing and cannot be identified/discovered at the source location. Will not be migrated.',175,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Pending Subnet Plan','Source subnet details are inconsistent and must be finalized before a migration strategy can be determined.',200,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Function Exclusive to Source','System functions only the source location. Will not be migrated.',255,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Decommission Before Migration','System will be decommissioned at the source and will not be migrating within the scope of this project.',0,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Source Powered Off','Source system is in a powered off state and is offline. Will not be migrated in a powered off state.',175,CURRENT_TIMESTAMP) \n";
	$sql .= ",('AD Solution','Active Directory system is not being migrated and will be handled by a separate work stream.',0,CURRENT_TIMESTAMP) \n";
	$sql .= ",('DR System Retiring','Source system is a DR system being retired and will not be migrated.',1,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Build New at Target-New IP','New system will be built at the target location with a new IP address.',10,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Build New at Target-Same IP','New system will be built at the target location with a the same IP address as the source. Warning that the same IP address cannot be on the same subnet or there will be a conflict.',80,CURRENT_TIMESTAMP) \n";
	$sql .= "; \n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	}

	$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`pattern` (name,detail,riskfactor,lastupdate) VALUES  \n";
	$sql .= "('Cirrus Block Storage','Cirrus SAN/block storage hardware replication appliances.',10,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Hardware Lift & Shift','Shutdown hardware at source. Prepare hardware for shipping per vendor specs. Ship the hardware to the target. Unpack hardware per vendor specs. Rack, stack, cable and power on hardware at target.',200,CURRENT_TIMESTAMP) \n";
	$sql .= ",('LPAR Move','Live Partition Mobility (LPM) or mksysb method of migration. LPM can provide near zero downtime for LPAR migration. This is a virtual migration.',30,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Mainframe','Separate mainframe migration work stream. Move LPARs to swing gear and physical lift and shift of the existing mainframe hardware.',30,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Stay Back','System will not be migrated as it has been identified as a stay back service.',0,CURRENT_TIMESTAMP) \n";
	$sql .= ",('StorageX File','StorageX file based migration. Typically used for NAS data.',10,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Virtual Appliance','Virtual appliances are not migrated.',255,CURRENT_TIMESTAMP) \n";
	$sql .= ",('WSIB Removed','WSIB explicitly directed IBM to remove from migration scope. See Migration Notes for further details.',0,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Swing Lift & Shift','Install new temporary hardware at the target location. V2V the servers and replicate data from source to target. Move the old hardware from source to target and then cutover from the swing gear. Decommission the swing gear.',60,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Zerto V2V','Zerto V2V migrates VMs from a source to a target VMware infrastructure, retaining the same IP address. It is important to monitor bandwidth consumption across production networks during replication. Replication should begin at least 7 days before cutover.',30,CURRENT_TIMESTAMP) \n";
	$sql .= ",('NAS+Zerto V2V','Copy NAS storage to VM and then use Zerto V2V to migrate VM from a source to a target VMware infrastructure, retaining the same IP address. It is important to monitor bandwidth consumption across production networks during replication. Replication should begin at least 7 days before cutover.',30,CURRENT_TIMESTAMP) \n";
	$sql .= ",('DR Solution','The DR solution leveraging SRM will remove the necessity to migrate failover/DR VMs.',10,CURRENT_TIMESTAMP) \n";
	$sql .= ",('RDS Solution','Windows Terminal (Remote Desktop) Services. Requires a separate migration pattern to maintain global developer access to manage application development.',200,CURRENT_TIMESTAMP) \n";
	$sql .= ",('RSA Solution','RSA Security system which is not being migrated and will be handled by a separate RSA work stream.',0,CURRENT_TIMESTAMP) \n";
	$sql .= ",('Migration Support Only','System is in the source location only to support migration efforts. Will be decommissioned after migration completes.',0,CURRENT_TIMESTAMP) \n";
	$sql .= "; \n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	}
	$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`pattern`;");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		$rowsOut += $refr[0];
	}
}

# -----------------------------------------------------------------------
# LOAD CLIENT/PROJECT SPECIFIC DATA
# -----------------------------------------------------------------------

my $location_rows = 0;
$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`location`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	$location_rows = $refr[0];
}

if ($fNewDB || $location_rows == 0) {
	## SOURCE DATA CENTER LOCATIONS
	$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`location` (code,name,citycountry,dcowner,migcontext,lastupdate) VALUES  \n";
	$sql .= "('MDC','CGI Mississauga','Toronto, Ontario, Canada','CGI','s',CURRENT_TIMESTAMP) \n";
	$sql .= ",('DDC','CGI Dickson','Montreal, Quebec, Canada','CGI','s',CURRENT_TIMESTAMP) \n";
	$sql .= ",('4AN','IBM Markham','Markham, Ontario, Canada','IBM','t',CURRENT_TIMESTAMP) \n";
	$sql .= ",('5AW','IBM Viger','Montreal, Quebec, Canada','IBM','t',CURRENT_TIMESTAMP) \n";
	$sql .= "; \n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	}
	$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`location`;");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		$rowsOut += $refr[0];
	}
}

my $opsys_rows = 0;
$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`opsys`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	$opsys_rows = $refr[0];
}

if ($fNewDB || $opsys_rows == 0) {
	## OPERATING SYSTEMS DETAIL AND DISCOVERED EOL DATA
	$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`opsys` (name,platform,eol,eoxs,nminus2,riskfactor,lastupdate) VALUES \n";
	$sql .= "   ('Red Hat Enterprise Linux 5.5','Linux','1/8/2013','11/30/2020',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 5.6','Linux','1/8/2013','11/30/2020',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 5.7','Linux','1/8/2013','11/30/2020',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 5.8','Linux','1/8/2013','11/30/2020',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 5.9','Linux','1/8/2013','11/30/2020',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 5.10','Linux','1/8/2013','11/30/2020',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 5.11','Linux','1/8/2013','11/30/2020',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.1','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.2','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.3','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.4','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.5','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.6','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.7','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.8','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.9','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 6.10','Linux','5/10/2016','6/30/2024',1,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.1','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.2','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.3','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.4','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.5','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.6','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.7','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 7.8','Linux','8/6/2019','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 8.0','Linux','5/31/2024','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 8.1','Linux','5/31/2024','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 8.2','Linux','5/31/2024','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 8.3','Linux','5/31/2024','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Red Hat Enterprise Linux 8.4','Linux','5/31/2024','TBD',0,8,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Microsoft Windows Server 2003','Windows','7/13/2010','7/14/2015',1,100,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Microsoft Windows Server 2008','Windows','1/13/2015','1/14/2020',1,50,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Microsoft Windows Server 2008 R2','Windows','1/13/2015','1/14/2020',1,50,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Microsoft Windows Server 2012','Windows','10/9/2018','10/10/2023',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Microsoft Windows Server 2012 R2','Windows','10/9/2018','10/10/2023',1,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Microsoft Windows Server 2016','Windows','1/11/2022','1/12/2027',0,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Microsoft Windows Server 2019','Windows','1/9/2024','1/9/2029',0,10,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('IBM AIX 5.3','AIX','4/30/2012','4/30/2012',1,100,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('IBM AIX 6.1','AIX','4/30/2017','4/30/2017',1,50,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('IBM AIX 7.1','AIX','TL5 ends 4/30/2023','4/30/2023',0,30,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('IBM AIX 7.2','AIX','TL4 ends 11/30/2022','11/30/2022',0,20,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Oracle Linux 5.8','Linux','6/2017','6/2020',1,100,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Solaris 10','Solaris','1/2018','1/2024',0,100,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Solaris 11','Solaris','11/2031','11/2034',0,50,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('CentOS 6.3','Linux','11/30/2020','11/30/2020',50,0,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('SUSE Linux Enterprise 11','Linux','3/31/2022','3/31/2022',1,50,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('IBM z/OS 2.2','Mainframe','9/2020','9/2020',1,50,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('IBM VIOS 2.2.5.10','AIX','9/30/2019','9/30/2019',1,50,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Linux - Customized','Linux',NULL,NULL,NULL,200,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('N/A','Other',NULL,NULL,NULL,200,CURRENT_TIMESTAMP),\n";
	$sql .= "   ('Unavailable','Other',NULL,NULL,NULL,200,CURRENT_TIMESTAMP);\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	}

	$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`opsys`;");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		$rowsOut += $refr[0];
	}
}
## 6/23/20 -- REMOVED EVENT INSERTS AND REPLACED WITH LOAD SCRIPT

## DBMS values
my $dbms_rows = 0;
$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`dbms`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	$dbms_rows = $refr[0];
}
if ($fNewDB || $dbms_rows == 0) {
#	$sql = "INSERT INTO i_wsib.dbms (shortname, dbtype, edition, version, eol, supported, lastupdate) VALUES \n";
#	$sql .= "('', '', '', '', '', 0, CURRENT_TIMESTAMP), \n";
#	$sql .= "('', '', '', '', '', 0, CURRENT_TIMESTAMP); \n";
}

my $tracking_rows = 0;
$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`dsattrack`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	$tracking_rows = $refr[0];
}
if ($fNewDB || $tracking_rows == 0) {
	$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`dsattrack` (script_seq, datasrcscript, datasrcname, datasrcdesc, datasrcconst, lastrun, rows_in, rows_out) \n";
	$sql .= "  VALUES \n";
	$sql .= "  (1, 'ibm-db-primer.pl', 'DB Primer', 'Creates a new database and populates key tables with initial data.', 'No data source is read.', CURRENT_TIMESTAMP, NULL, NULL),\n";
	$sql .= "  (2, 'ibm-vlan-load.pl', 'VLAN Sheet Load', 'Reads the IBM/CGI VLAN xlsx workbook and loads all subnets in scope.', 'CGI must notify IBM of any changes to subnets/VLANs. VLAN sheet must be updated regularly by IBM to reflect those changes.', NULL, NULL, NULL),\n";
	$sql .= "  (3, 'ibm-lb-load.pl', 'Load Balanced IP Load', 'Reads an F5 details xlsx workbook and loads all load balancer VIPs and pool IPs in scope.', 'F5 load balancer detail files must be updated regularly to reflect any load balancer changes.', NULL, NULL, NULL),\n";
	$sql .= "  (4, 'ibm-addm-load.pl', 'ADDM Operations Inventory Load', 'Reads the ADDM export xlsx workbook and loads specific rows for key operational data.', 'Primary IP Addresses are not discerned by ADDM. Only IPs in range specified in VLAN sheet are loaded.', NULL, NULL, NULL),\n";
	$sql .= "  (5, 'ibm-ops-load.pl', 'CGI Operations Inventory Load', 'Reads the basic CGI Operations Inventory xlsx workbook and loads all rows for key operational data.', 'Inventory only contains active VMs, AIX LPARs and Solaris containers. Virtual Appliances are excluded.', NULL, NULL, NULL),\n";
	$sql .= "  (6, 'ibm-rvt-load.pl', 'CGI RVTools Export Load', 'Reads the CGI RVTools export xlsx files and inserts rows with key operational data.', 'RVTools must be manually run on a CGI system that has access to all VCenters in scope.', NULL, NULL, NULL),\n";
	$sql .= "  (7, 'ibm-csasset-load.pl', 'CGI Cloudscape Asset Export Load', 'Reads the Cloudscape Assets csv export and inserts rows with key operational data.', 'Cloudscape scans are run weekly. CS data must be updated by CGI and discrepancies resolved for clean data.', NULL, NULL, NULL),\n";
	$sql .= "  (8, 'ibm-csdep-load.pl', 'CGI Cloudscape Detailed Application Dependencies Load', 'Reads the Cloudscape Detailed Application Dependencies csv export files and inserts rows with key operational data.', 'Cloudscape scans are run weekly. CS data must be updated by CGI and discrepancies resolved for clean data.', NULL, NULL, NULL),\n";
	$sql .= "  (9, 'ibm-sami-load.pl', 'WSIB SAMI Legacy Data Load', 'Reads the SAMI xlsx file and inserts rows into a table for legacy reference lookups.', 'SAMI is obsolete and is no longer updated by WSIB. Data may be stale and outdated. Use sparingly.', NULL, NULL, NULL),\n";
	$sql .= "  (10, 'ibm-events-load.pl', 'IBM Migration Events Data Load', 'Reads the Events xlsx file and loads the database with migration event details.', 'IBM USE ONLY.', NULL, NULL, NULL),\n";
	$sql .= "  (11, 'ibm-master-load.pl', 'IBM Master System Inventory Data Load', 'Reads the IBM Master System Inventory xlsx file and reloads the database with any key updates.', 'IBM USE ONLY. Database updates are triggered only if valid data ranges are provided.', NULL, NULL, NULL),\n";
	$sql .= "  (12, 'ibm-storage-load.pl', 'IBM Storage Data Load', 'Reads the IBM Storage xlsx file and reloads the database with any key updates for SAN and NAS specifications.', 'IBM USE ONLY. Database updates are triggered only if valid data ranges are provided.', NULL, NULL, NULL),\n";
	$sql .= "  (13, 'ibm-dbms-load.pl', 'IBM DBMS Data Load', 'Reads the IBM Database xlsx file and reloads the database with any key updates for DBMS and DB Instances.', 'IBM USE ONLY. Database updates are triggered only if valid data ranges are provided.', NULL, NULL, NULL),\n";
	$sql .= "  (14, 'ibm-appstack-load.pl', 'IBM Application Stack Load', 'Loads application stack name, owner name and contact and business criticality from an xlsx file.', 'IBM USE ONLY. This is optional once the spreadsheet is completed.', NULL, NULL, NULL),\n";
	$sql .= "  (15, 'ibm-targetvm-load.pl', 'IBM Target VMware Cluster Load', 'Loads VM target information for VPG automation from an xlsx file.', 'IBM USE ONLY. This is optional once the spreadsheet is completed.', NULL, NULL, NULL),\n";
	$sql .= "  (16, 'ibm-master-gen.pl', 'IBM Master Inventory Generator', 'Creates a new Master Inventory Workbook.', 'IBM USE ONLY. Other scripts above must be run prior to this one.', NULL, NULL, NULL);\n";

	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	}
	$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`dsattrack`;");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		$rowsOut += $refr[0];
	}
}

my $redflag_rows = 0;
$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`redflag`;");
if (!$sth) {
	die "Error:" . $dbh->errstr . "\n";
}
if (!$sth->execute) {
	die "Error:" . $sth->errstr . "\n";
}
while (my @refr = $sth->fetchrow_array) {
	$redflag_rows = $refr[0];
}

if ($fNewDB || $redflag_rows == 0) {
	## SOURCE DATA CENTER LOCATIONS
	$sql = "INSERT INTO `" . $main::IDB_NAME . "`.`redflag` (shortkey,notify,resolution,lastupdate) VALUES  \n";
	$sql .= "('vmrvtnotfound',1,'VM was not found in RVTools on any vCenter. Client must locate the system or it will not be migrated. Alternatively, Client must provide decommission strategy in writing.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('sysnotfound',1,'Client must locate the system or it will not be migrated. Alternatively, client must provide decommission strategy in writing.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('rdssolution',1,'Must have a tested RAS/RDS core services solution in operation at the target location prior to this migration event. Must also have written confirmation of the disposition strategy for this system.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('adsolution',1,'Must have a tested Active Directory core services solution in operation at the target location prior to this migration event. Must also have written confirmation of the disposition strategy for this system.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('stayback',1,'Must obtain formal confirmation of Stay Back and associated decommission strategy in writing as an audit trail.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('sysdecomm',1,'Must obtain formal confirmation of decommission in writing as an audit trail.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('drdecomm',1,'Must obtain formal confirmation of decommission in writing as an audit trail. This system is a DR system being replaced by SRM in lieu of migration.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('confirmscope',1,'Migration scope must be confirmed and a clear disposition strategy documented in writing as an audit trail.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('rvtprimaryapipa',1,'RVTools primary IP address is automatically assigned (APIPA), indicating an improperly configured VM. This issue must be resolved on the source VM prior to the migration event or it will not be migrated.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('sysprimaryapipa',1,'Primary IP address is automatically assigned (APIPA), indicating an improperly configured system. This issue must be resolved on the source VM prior to the migration event or it will not be migrated.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('pvtvlannotmigrating',1,'VLAN containing this private IP address is not associated to any wave and must be built new in the target data center.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('sysprimaryipprivate',1,'Class C Primary IP address is private and non-routable.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('rvtprimaryipprivate',1,'Class C RVTools Primary IP address is private and non-routable.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('resolvepriormigration',1,'This issue must be resolved prior to the migration event or system will not be migrated.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('virtualappliance',1,'Virtual Appliance which must be built new in the target location. Must have formal, documented disposition strategy from the steady state owner supporting this Virtual Appliance as an audit trail.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('sysremoved',1,'System removed from migration scope and/or the migration pattern was undetermined. Please see Migration Notes for further details.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('sysosunsupported',1,'This system is shown as running an unsupported operating system. If still targeted for migration, IBM Steady State teams must confirm that the OS can and will be supported in the target, or the system will not be migrated.',CURRENT_TIMESTAMP) \n";
	$sql .= ",('vmwithserialnum',1,'This VM is showing a serial number in ADDM, indicating a physical server. Physical servers will not be migrated as P2V is not supported in this migration program.',CURRENT_TIMESTAMP) \n";
	$sql .= "; \n";
	print $sql . "\n" if ($DEBUGSQL); # debug sql
	$dbh->do($sql);
	if (!defined($dbh) ) {
		print "Error while executing SQL:\n";
		print $sql . "\n";
		print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
		$iSqlErr++;
	}
	$sth = $dbh->prepare("SELECT COUNT(*) FROM `" . $main::IDB_NAME . "`.`redflag`;");
	if (!$sth) {
		die "Error:" . $dbh->errstr . "\n";
	}
	if (!$sth->execute) {
		die "Error:" . $sth->errstr . "\n";
	}
	while (my @refr = $sth->fetchrow_array) {
		$rowsOut += $refr[0];
	}
}

$sql = "UPDATE `" . $main::IDB_NAME . "`.`dsattrack` SET \n";
$sql .= "   lastrun = CURRENT_TIMESTAMP,\n";
$sql .= "   rows_out = " . $rowsOut . "\n";
$sql .= "   WHERE datasrcscript='ibm-db-primer.pl';\n";
print $sql . "\n" if ($DEBUGSQL); # debug sql
$dbh->do($sql);
if (!defined($dbh) ) {
	print "Error while executing SQL:\n";
	print $sql . "\n";
	print "*** SQL ERROR:  $DBI::errstr\n";         # $DBI::errstr is the error
	$iSqlErr++;
}

print "\n************************\n";
print "SQL Errors\t\t:" . $iSqlErr . "\n";
print "************************\n";

# Disconnect from the database.
$dbh->disconnect();
exit;
