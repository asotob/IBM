############################################################################
### Program by:	Joseph Blaty, IBM Global Services
### Purpose:	Application Global Defines
### Date:		August 6, 2020
############################################################################
### ---- ORDER OF SCRIPTS: -----
### SEE ibm-db-primer.pl FOR THE ORDER OF SCRIPTS
### ---- HISTORY: -----
### 2/19/20 - Business decision to remove SAMI from trusted sources
############################################################################
## database variables ----------------------------------------------------
our $IDB_NAME = 'i_wsib';
our $IDB_HOST = 'localhost';
our $IDB_USER = 'root';
our $IDB_PWD = 'QN3fANeq79BsJM6j2o';
our $IDB_DBI = 'DBI:mysql:';
#our $IDB_DBI = 'DBI:MariaDB:';
our $CUST_NAME = 'WSIB';

our $DB_CREATE_SCRIPT = 'ibm-db-primer.pl'; # name of the script that creates and primes the database
our $SCRIPT_VER = "4.5";
our $SCRIPT_TAG = "IBM";

our %hashRVTPowerSt = (
	"poweredoff"  => 0,
	"poweredon" => 1,
	"suspended"  => 2,
);

our %txtRVTPowerSt = (
	0 => "poweredOff",
	1 => "poweredOn",
	2 => "suspended",
);

our %hashRVTGuestSt = (
	"notrunning"  => 0,
	"running" => 1,
	"standby"  => 2,
	"resetting"  => 3,
	"shuttingdown"  => 4,
	"unknown"  => 5,
);

our %hashRVTConnectSt = (
	"disconnected"  => 0,
	"connected" => 1,
	"inaccessible"  => 2,
	"invalid"  => 3,
	"orphaned"  => 4,
);

our %hashRVTLatencySensitivity = (
	"normal"  => 0,
	"low" => 1,
	"high"  => 2,
);

our %hashDiscoveryStatus = (
	"unknown"  => 0,
	"inprogress" => 1,
	"validating"  => 2,
	"confirmed"  => 3,
	"notfound"  => 4,
	"removed"  => 9,
	"override"  => 255,
);

our %txtDiscoveryStatus = (
	0 => "Unknown",
	1 => "In Progress",
	2 => "Validating",
	3 => "Confirmed",
	4 => "Not Found",
	9 => "Removed",
	255 => "Override",
);

our %hashSYSDisposition = (
	"notmigrating"  => 0,
	"migrating"  => 2,
	"confirmscope"  => 3,
	"decomm"  => 4,
	"removed"  => 9,
);

our %txtSYSDisposition = (
	0 => "Not Migrating",
	2 => "Migrating",
	3 => "Confirm Scope",
	4 => "Decommission",
	9 => "Removed",
);

our %hashIPDisposition = (
	"change"  => 0,
	"retain" => 1,
	"notfound"  => 2,
	"decomm"  => 3,
	"notmigrating"  => 9,
);

our %txtIPDisposition = (
	0 => "Change",
	1 => "Retain",
	2 => "Not Found",
	3 => "Decommission",
	9 => "Not Migrating",
);

our %hashAppDisposition = (
	"remove"  => 0,
	"retain" => 1,
	"decomm"  => 2,
);

our %txtAppDisposition = (
	0 => "Remove",
	1 => "Retain",
	2 => "Decommission",
);

our %hashMigrationStatus = (
	"notstarted"  => 0,
	"failback"  => 1,
	"completed"  => 3,
	"standdown"  => 5,
	"failed"  => 9,
);

our %txtMigrationStatus = (
	0 => "Not Started",
	1 => "Failback",
	3 => "Completed",
	5 => "Stand Down",
	9 => "Failed",
);

our %hashAppCriticality = (
	"low"  => 0,
	"high"  => 1,
);

our %txtAppCriticality = (
	0 => "Low",
	1 => "High",
);

our %hashDRScope = (
	"none"  => 0,
	"primary" => 1,
	"failover"  => 2,
);

our %txtDRScope = (
	0 => "None",
	1 => "Primary",
	2 => "Failover",
);

our %hashLBScope = (
	"none"  => 0,
	"pool" => 1,
	"vip"  => 2,
);

our %txtLBScope = (
	0 => "None",
	1 => "Pool",
	2 => "VIP",
);

our %hashSubnetScope = (
	"notmigrating"  => 'n',
	"migrating"  => 'y',
	"hnas"  => 'h',
	"networkonly"  => 'r',
	"cgi"  => 'c',
	"wsib"  => 'w',
);

our %txtSubnetScope = (
	'n' => "Not Migrating",
	'y' => "Migrating",
	'h' => "HNAS",
	'r' => "Network Only",
	'c' => "CGI",
	'w' => "WSIB",
);

our %hashVMEnv = (
	"nonprod"  => 'n',
	"prod"  => 'p',
	"sql"  => 'q',
	"test"  => 't',
);

our %txtVMEnv = (
	'n' => "NONPROD",
	'p' => "PROD",
	'q' => "SQL",
	't' => "TEST",
);

our %hashVMPlat = (
	"linux"  => 'l',
	"windows"  => 'w',
	"other"  => 'o',
);

our %txtVMPlat = (
	'l' => "Linux",
	'w' => "Windows",
	'o' => "Other",
);

#our %hashWSIBEnv = (
#	"p"  => "Production",
#	"n"  => "Pre-Production",
#	"a"  => "Business Acceptance Testing",
#	"i"  => "Development Integration Testing",
#	"d"  => "Development",
#	"r"  => "Training",
#	"e"  => "Disaster Recovery",
#	"c"  => "Conversion",
#	"s"  => "System Integration Testing",
#	"t"  => "Proof of Concept/Sandbox",
#);

our %hashWSIBEnv = (
	"a"  => "BAT",
	"c"  => "CONV",
	"d"  => "DEV",
	"e"  => "DR",
	"i"  => "DIT",
	"n"  => "PPD",
	"p"  => "PRD",
	"q"  => "QA",
	"r"  => "TRN",
	"s"  => "SIT",
	"t"  => "TEST",
);

our %hashADDMtype = (
	"hw"  => 1,
	"ucs"  => 2,
	"sunfire"  => 3,
	"sparc"  => 4,
	"dell"  => 6,
	"xseries"  => 7,
	"power"  => 8,
	"switch"  => 10,
	"router"  => 11,
	"controller"  => 12,
	"vm" => 21,
	"partition"  => 22,
	"container"  => 23,
	"ucsvm"  => 24,
);

our %txtADDMtype = (
	1 => "hw",
	2 => "ucs",
	3 => "sunfire",
	4 => "sparc",
	6 => "dell",
	7 => "xseries",
	8 => "power",
	10 => "switch",
	11 => "router",
	12 => "controller",
	21 => "vm",
	22 => "partition",
	23 => "container",
	24 => "ucsvm",
);

our %hashADDMswtype = (
	"os"  => 1,
	"networkos"  => 2,
	"appdeploy"  => 9,
	"appserver"  => 10,
	"assetmgt"  => 11,
	"backup"  => 12,
	"busintel"  => 13,
	"changemgt"  => 14,
	"cluster"  => 15,
	"contentmgt"  => 16,
	"dataaccess"  => 17,
	"dataintegration"  => 18,
	"dataprotection"  => 19,
	"dbmgt"  => 20,
	"devlanguage"  => 21,
	"email"  => 22,
	"enduserquery"  => 23,
	"entportal"  => 24,
	"entresmgt"  => 25,
	"entresplan"  => 26,
	"evtmgt"  => 27,
	"evtdrvmw"  => 28,
	"extact"  => 29,
	"filesys"  => 30,
	"idmgt"  => 31,
	"instantcom"  => 32,
	"integrationserver"  => 33,
	"linux"  => 34,
	"middleware"  => 35,
	"monitoring"  => 36,
	"network"  => 37,
	"networkmgt"  => 38,
	"nonreldb"  => 39,
	"officeapp"  => 40,
	"otherappmw"  => 41,
	"otherdeploy"  => 42,
	"performmgt"  => 43,
	"processauto"  => 44,
	"programmingtool"  => 45,
	"projectmgt"  => 46,
	"qualtools"  => 47,
	"reporting"  => 49,
	"scheduling"  => 50,
	"searchdiscover"  => 51,
	"securecontent"  => 52,
	"security"  => 53,
	"storagemgt"  => 54,
	"sysmgt"  => 55,
	"teamcollab"  => 56,
	"transactionproc"  => 57,
	"unix"  => 58,
	"vmsoftware"  => 59,
	"webserver"  => 60,
	"windows"  => 61,
	"workloadsched"  => 62,
);

our $MINMIGRATIONBANDWIDTHGbps = 7.0; # minimum migration bandwidth in Gbps
our $MINMIGRATIONBANDWIDTHBITSPERSEC = $main::MINMIGRATIONBANDWIDTHGbps * 1073741824; # convert Gbps to bits per second
our $TRANSFEROVERHEADPCT = 10; # total percentage of data transfer overhead (latency + encryption)

############################################################################
sub Display_Pgm_Banner
############################################################################
{
	# Localize the variables used in this subroutine.
	my($strin) = @_;
	my $pgm = "";
	$pgm = uc($strin) if ( defined($strin) );
	print "\n" . '----- ' . $main::SCRIPT_TAG . " DISCOVERY SOURCE AGGREGATION SCRIPT v" . $main::SCRIPT_VER . "\n";
	if ($pgm ne "") {
		print '----- ' . uc($strin) ."\n\n";
	}
	return;
}	## Display_Pgm_Banner

############################################################################
sub ipfmt
############################################################################
{
	# Localize the variables used in this subroutine.
	my($strin) = @_;
	my $strout = "";
	return "" if ( !defined($strin) );
	my @octet = split (/\./, $strin); # IPv4 split into hopefully 4 octets
	if (scalar @octet != 4) {
		return "";
	} else {
		$strout = sprintf ("%d.%d.%d.%d", @octet); # format the output
	}
	return($strout);
}	##ipfmt

############################################################################
sub trim
############################################################################
{
	# Localize the variables used in this subroutine.
	my($strin) = @_;
	return "" if ( !defined($strin) );
	my $strout = $strin;
	$strout =~ s/^\s+|\s+$//g; # remove the whitespace at beginning and end of the string
	return($strout);
}	##trim

############################################################################
sub stripchr
############################################################################
{
	# Localize the variables used in this subroutine.
	my($strin) = @_;
	my $strout = "";
	return "" if ( !defined($strin) );
	$strout = $strin;
	$strout =~ s/[#%&\$*+\',]//g;
	return($strout);
}	##stripchr

############################################################################
sub reorder
############################################################################
{
	# Localize the variables used in this subroutine.
	my($strin) = @_;
	my $strout = "";
	return "" if ( !defined($strin) );
	$strin =~ s/\r\n//g; # remove the carriage returns and line feeds
	my @inarray = split(/;\s*/,$strin); # split out to an array
	$strout = join ', ' , sort @inarray;
	$strout =~ s/\,\s*$//; # remove the last ';'
	return($strout);
}	##reorder
############################################################################
sub num_commify
############################################################################
{
    my $text = reverse $_[0];
    $text =~ s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
    return scalar reverse $text;
}
