# CMM-Anthem-FWrequests
1. Install Strawberry PERL: http://strawberryperl.com/
2. Download the CMM-Anthem-FWrequests-master.zip file by selecting "Clone or download" and Download ZIP
3. Extract FWRequest to C:\
