#fwrequest-anthem-net.pl v1
#authors: Marcos Sylos (sylos@br.ibm.com)
#         Patrick King (paking@us.ibm.com)
#Only runs in Windows
#Install Strawberry PERL: http://strawberryperl.com/
#Configured to run in C:\FWRequest

use strict;
use warnings;
use Win32::OLE;
use Win32::OLE qw(in with);
$Win32::OLE::Warn = 3;

my $templatefolder = "C:/FWRequest/";
my $reportfolder = 'C:\FWRequest\Report_Output\\';
my $templatefile = "Firewall Request - Template.xlsx";
my $numrows=2000;
my $outbound="outbo";
my $inbound="inbo";
my $defNet="Anthem";

my $csfiles = $templatefolder."CSfiles";
my $targetips = $templatefolder."TargetIP";
my $logdir = $templatefolder."Report_Output";
my $fwimplemented = $templatefolder."FW_Implemented";

#Non-prod subnet block in VCS is 10.152.0.0/17. Any comms with source & dest in that range don’t require firewall rules.
#161.69.226.0/24 - NETWORK-ASSOCIATES-INC - McAfee, Inc.
my %networks = (
"30.A.B.0/24" => "Anthem",
"161.69.226.0/24" => "Anthem",
"10.152.0.0/17" => "IBM-WDC",
"10.152.136.0/22" => "IBM-WDC",
"10.152.140.0/22" => "IBM-WDC",
"10.152.128.0/22" => "IBM-WDC",
"10.152.132.0/22" => "IBM-WDC"
);
#my %networks = ("30.A.B.0/24" => "Anthem", "10.152.8.0/22" => "IBM-WDC", "10.152.12.0/22" => "IBM-WDC", "10.152.0.0/22" => "IBM-WDC", "10.152.4.0/22" => "IBM-WDC" );

my %ip;
my %checkdup;
my %checkdupnet;
my %FWrules;
my %Environments;
my %FW30nets;
my %FWimplemented;

my $debug=1;
$debug=$ARGV[1] if ($ARGV[1]);
my $wave=0;

#read .30 FW nets behind FW (Anthem specific)
my $fw30file = $templatefolder."30FWsubnets.txt";
open(FH, '<', $fw30file) or die $!;
while(<FH>){
	s/\r//gm;
	s/\n//gm;
	my $fw30net=$_;
	$FW30nets{$fw30net}=1;
}
close(FH);
if ($debug == 2){
	print ".30 FW nets\n";
	foreach my $fw30net (sort keys %FW30nets){print $fw30net."\n"};
}

#network handling perl stuff
sub FWkey{
	(my ($FWenv,$FWtype,$FWsrc,$FWdst,$FWport)) = @_;
	my $FWkey=$FWenv."|".$FWtype."|".$FWsrc."|".$FWdst."|".$FWport;
	return $FWkey;
}

sub getFWkey{
	(my $FWkey) = @_;
	(my ($FWenv,$FWtype,$FWsrc,$FWdst,$FWport)) = split /\|/,$FWkey;
	return $FWenv,$FWtype,$FWsrc,$FWdst,$FWport;
}

sub getIp {
	return ($_[0]*256*256*256) + ($_[1]*256*256) + ($_[2]*256) + $_[3];
}

sub getNetwork {
	my @a = split(/[\/|\.]/, +shift);
	return (getIp(@a[0 .. 3]), (getIp(@a[0 .. 3]) + (2 ** (32 - $a[4]))));
}

sub getSubnet{
	my ($ip) = @_;
	my @a = split /\./, $ip;
	my $ia=$a[1];
	my $ib=$a[2];
	my $di = getIp(@a);
	foreach my $subnet (keys %networks){
		$subnet =~ s/A/$ia/g;
		$subnet =~ s/B/$ib/g;
		my ($a, $b) = getNetwork($subnet);
		if(($di >= $a) && ($di <= $b)){return $subnet}
	}
	return $ip;
}

sub testNetwork {
	my ($srcip,$tgtip,$previous) = @_;
	my $subnsrc=getSubnet($srcip);
	my $subntgt=getSubnet($tgtip);
	my $myNet=$previous;
	if ($subnsrc eq $subntgt){
		$myNet="Same Network";
	}elsif ($subnsrc and $subntgt){
		if ($networks{$subnsrc} and $networks{$subntgt}){
			if ($networks{$subnsrc} ne $defNet){
				$myNet=$networks{$subntgt} if ($networks{$subntgt} ne $myNet);
			}
		}
	}
	return $myNet;
}

sub ignorelocal{
	my ($ip1,$ip2) = @_;
	my $ipvalid=1;
	$ipvalid=0 if ($ip1 eq "127.0.0.1" or $ip2 eq "127.0.0.1");
	$ipvalid=0 if ($ip1 eq "127.0.0.2" or $ip2 eq "127.0.0.2");
	return $ipvalid;
}

sub ignore30fw{
	(my ($subna,$subnb)) = @_;
	my $fw30result=0;
	$fw30result=1 if (($subna=~/^30\./) or ($subnb=~/^30\./));
	$fw30result=0 if ($FW30nets{$subna} or $FW30nets{$subnb});
	print "($subna,$subnb) - $fw30result\n" if ($debug == 2);
	return $fw30result;
}

sub splitPath {
    if ($_[0] =~ m|(.*/)(.*)|) { return ($1, $2); }
    return ('', $_[0]);
}

#get the wave number
$wave=$ARGV[0] if ($ARGV[0]);
if (not $wave){
	print "\nWhat Migration Event is this part of ? : ";
	chomp($wave = <>);
	print "\n";
}
exit if (not $wave or $wave eq "");

my ($sec, $min, $hour, $mday, $mon, $year) = gmtime();
my $random = sprintf "%4u%02u%02u-%02u%02u%02u", $year+1900, $mon+1, $mday, $hour, $min, $sec;
my $log_name = $logdir."/Firewall-NET-Request-Summary-ME".$wave."-".$random.".csv";

open (LOG, "> $log_name") or die "Error opening log file!" if ($debug);

#start excel
my $Excel = Win32::OLE->new('Excel.Application', 'Quit');

#read Previous implemented FW requests
my $dirfwimp = $fwimplemented."/*.xlsx";
my @impfiles = glob( $dirfwimp );
foreach my $file (@impfiles){
	printf("Reading Previous FW implemented file: %s\n",$file);
	my $Book = $Excel->Workbooks->Open($file);
	$Excel->Workbooks->Item(1)->Close(0) if ($Excel->Workbooks->Count() > 1);
	my ($fwisrc,$fwidst,$fwiport,$imppath,$impfile);
	my $sheet = $Book->Worksheets(1);
	foreach my $row (2..$numrows){
		next unless $sheet->Range("A".$row)->{Text};
		$fwisrc=$sheet->Range("A".$row)->{Text};
		$fwidst=$sheet->Range("B".$row)->{Text};
		$fwiport=$sheet->Range("D".$row)->{Text};
		($imppath,$impfile)=splitPath($file);
		print "FWimplemented{$fwisrc}{$fwidst}{$fwiport}=$impfile\n" if ($debug == 2);
		$FWimplemented{$fwisrc}{$fwidst}{$fwiport}=$impfile;
	}
	$Book->Close(0);
}

#read source/target ips at $targetips dir
my $dirglob = $targetips."/*.xlsx";
my @files = glob( $dirglob );
foreach my $file (@files){
	my $std=$targetips."/[A-za-z0-9]";
	if ($file =~ $std){
		#if ($file =~ $wave){
			printf("Reading Target IP file: %s\n",$file);
			my $Book = $Excel->Workbooks->Open($file);
			#get rid of any automatically opened new books
			$Excel->Workbooks->Item(1)->Close(0) if ($Excel->Workbooks->Count() > 1);
			my ($src,$dst);
			foreach my $idx (1..$Book->Worksheets->Count()){
				my $sheet = $Book->Worksheets($idx);
					foreach my $col ('A'..'Z'){
						next unless $sheet->Range($col.'1')->{Text};
						if ($sheet->Range($col.'1')->{Text} =~ /source.*ip/i){
							#source IP column
							$src = $col;
							print "src: ".$src."\n" if ($debug == 2);
						}elsif ($sheet->Range($col.'1')->{Text} =~ /target.*ip/i){
							#source IP column
							$dst = $col;
							print "dst: ".$dst."\n" if ($debug == 2);
						}
					}
				foreach my $row (2..$numrows){
					next unless $sheet->Range($src.$row)->{Text};
					next unless $sheet->Range($dst.$row)->{Text};
					my $srcip=$sheet->Range($src.$row)->{Text};
					my $tgtip=$sheet->Range($dst.$row)->{Text};
					print $srcip."\t~\t".$tgtip."\n" if ($debug == 2);
					$ip{$srcip}=$tgtip;
				}
			}
			$Book->Close(0);
			unlink $file;
		#}
	}
}

print LOG "Source IP, Target IP\n" if ($debug);
foreach my $srcip (sort keys %ip){
	print $srcip."\t~\t".$ip{$srcip}."\n";
	print LOG $srcip.",".$ip{$srcip}."\n" if ($debug);
}
print LOG "\nEnvironment,Type,Source NET IP,Source IP,Target NET,Target IP,Target port,Group,CS File,Rule,Comment\n" if ($debug);

#read CLOUDSCAPE files
$dirglob = $csfiles."/*.xlsx";
@files = glob( $dirglob );
foreach my $file (@files){
  my $std=$csfiles."/[A-za-z0-9]";
  if ($file =~ $std){
	printf("Reading Cloudscape file: %s\n",$file);
	my $Book = $Excel->Workbooks->Open($file);
	if ($Excel->Workbooks->Count() > 1){
		$Excel->Workbooks->Item(1)->Close(0);
	}
	foreach my $idx (1..$Book->Worksheets->Count()){
		my $sheet = $Book->Worksheets($idx);
		my ($srcaddr,$srcport,$dstaddr,$dstport,$protoname,$srcgroup,$dstgroup);
		my ($srcserver,$srcp,$dstserver,$dstp,$proto,$srcgrp,$dstgrp,$subnetsrc,$subnettgt);
		my $flowtype=0;
		#process outbound
		$flowtype="Outbound" if($sheet->Name() =~ /$outbound/i);
		$flowtype="Inbound" if($sheet->Name() =~ /$inbound/i);
		if($flowtype){
			my $flowgrp;
			foreach my $col ('A'..'AO'){
				my $cellv = $sheet->Range($col."1")->{Text};
				if ($cellv =~ /srcaddr/){$srcaddr = $col;}
				# elsif ($cellv =~ /srcport/){$srcport = $col;}
				elsif ($cellv =~ /destaddr/){$dstaddr = $col;}
				elsif ($cellv =~ /destport/){$dstport = $col;}
				# elsif ($cellv =~ /protocolname/){$protoname = $col;}
				elsif ($cellv =~ /srcgroup/){$srcgroup = $col;}
				elsif ($cellv =~ /destgroup/){$dstgroup = $col;}
			}
			my ($rowsread,$rowsproc,$rowspnet)=(0,0,0);
			foreach my $row (2..$numrows){
				next unless $sheet->Range($srcaddr.$row)->{Text};
				$srcserver = $sheet->Range($srcaddr.$row)->{Text};
				#$srcp = $sheet->Range($srcport.$row)->{Text};
				$dstserver = $sheet->Range($dstaddr.$row)->{Text};
				$dstp = $sheet->Range($dstport.$row)->{Text};
				#$proto = $sheet->Range($protoname.$row)->{Text};
				$srcgrp = $sheet->Range($srcgroup.$row)->{Text};
				$dstgrp = $sheet->Range($dstgroup.$row)->{Text};
				if ($flowtype eq "Outbound"){$flowgrp=$srcgrp}else{$flowgrp=$dstgrp};
				$rowsread++;
				if ($srcserver ne $dstserver){
					if(ignorelocal($srcserver,$dstserver)){
						$srcserver=$ip{$srcserver} if ($ip{$srcserver});
						$dstserver=$ip{$dstserver} if ($ip{$dstserver});
						$subnetsrc=getSubnet($srcserver);
						$subnettgt=getSubnet($dstserver);
						if (not $checkdup{$srcserver}{$dstserver}{$dstp}){
							my $myNet=testNetwork($srcserver,$dstserver,$defNet);
							if ($myNet ne "Same Network"){
								if (not $checkdupnet{$subnetsrc}{$subnettgt}{$dstp}){
									$checkdupnet{$subnetsrc}{$subnettgt}{$dstp}=1;
									#if (ignore30fw($subnetsrc,$subnettgt)){
									#	print LOG "30.x outside FW,$flowtype,$subnetsrc,$srcserver,$subnettgt,$dstserver,$dstp,$flowgrp,".$sheet->Name().",NO\n" if ($debug);
									#}else{
										if ($FWimplemented{$subnetsrc}{$subnettgt}{$dstp}){
		print LOG "FW implemented,$flowtype,$subnetsrc,$srcserver,$subnettgt,$dstserver,$dstp,$flowgrp,".$sheet->Name().",NO,".$FWimplemented{$subnetsrc}{$subnettgt}{$dstp}."\n" if ($debug);
										}else{
											my $fwkey=FWkey($myNet,$flowtype,$subnetsrc,$subnettgt,$dstp);
											$FWrules{$fwkey}=$flowgrp;
											$Environments{$myNet}=1;
											$rowspnet++;
											print LOG $myNet.",".$flowtype.",".$subnetsrc.",".$srcserver.",".$subnettgt.",".$dstserver.",".$dstp.",".$flowgrp.",".$sheet->Name().",YES\n" if ($debug);
										}
									#}
								}else{print LOG $myNet.",".$flowtype.",".$subnetsrc.",".$srcserver.",".$subnettgt.",".$dstserver.",".$dstp.",".$flowgrp.",".$sheet->Name().",DUP\n" if ($debug);}
								$rowsproc++;
							}else{print LOG $myNet.",".$flowtype.",".$subnetsrc.",".$srcserver.",".$subnettgt.",".$dstserver.",".$dstp.",".$flowgrp.",".$sheet->Name().",NO\n" if ($debug);}
							$checkdup{$srcserver}{$dstserver}{$dstp}=1;
						}else{ print LOG "DUP ignored,".$flowtype.",,".$srcserver.",,".$dstserver.",".$dstp.",".$flowgrp.",".$sheet->Name().",NO\n" if ($debug == 2); }
					}else{ print LOG "Local IP ignored,".$flowtype.",,".$srcserver.",,".$dstserver.",".$dstp.",".$flowgrp.",".$sheet->Name().",NO\n" if ($debug); }
				}else{ print LOG "Same IP ignored,".$flowtype.",,".$srcserver.",,".$dstserver.",".$dstp.",".$flowgrp.",".$sheet->Name().",NO\n" if ($debug); }
			}
			print "  ".$sheet->Name().": read $rowsread , proc $rowsproc , net $rowspnet rows \n";
		}
	}
	$Book->Close(0);
	unlink $file;
  }
}

sub openTemplate{
	(my $Excel) = @_;
	#open template
	my $FWbook = $Excel->Workbooks->Open($templatefolder.$templatefile,0,0);
	my $fwform = $FWbook->Worksheets("FW Rules");
	#$fwform->Range("A21:A25")->EntireRow->Delete;
	return $FWbook,$fwform;	
}
sub closeFWform{
	(my ($FWbook,$wave,$direction,$rowT)) = @_;
	my $new_folder = $reportfolder.$wave.'\\';
	mkdir $new_folder;
	#my $random = time(); or localtime();
	my ($sec, $min, $hour, $mday, $mon, $year) = gmtime();
	my $random = sprintf "%4u%02u%02u-%02u%02u%02u", $year+1900, $mon+1, $mday, $hour, $min, $sec;
	my $fw_change_name = "Firewall-NET-Request-".$direction."-ME".$wave."-".$random.".xlsx";
	$rowT--;
	print "\nSaved FW rules as ".$new_folder.$fw_change_name." - rows: $rowT\n\n";
	$FWbook->SaveAs($new_folder. $fw_change_name);
	$FWbook->Close(0);
}

foreach my $env (sort keys %Environments){
	my ($fwBook,$rulesout) = openTemplate($Excel);
	my $rowC=1;
	foreach my $fwkey (sort keys %FWrules){
		my ($fwenv,$fwtype,$fwsrc,$fwdst,$fwport)=getFWkey($fwkey);
		if ($env eq $fwenv){
			my $fwgrp=$FWrules{$fwkey};
			$rowC++;
			print $rowC."\t~ ".$fwenv."\t~ ".$fwsrc."\t~ ".$fwdst."\t~ ".$fwport."\t~ ".$fwtype."\t~ ".$fwgrp."\n" if ($debug == 2);
			$rulesout->Range("A".$rowC)->{Value} = $fwsrc;
			$rulesout->Range("B".$rowC)->{Value} = $fwdst;
			$rulesout->Range("C".$rowC)->{Value} = "TCP";
			$rulesout->Range("D".$rowC)->{Value} = $fwport;
			$rulesout->Range("E".$rowC)->{Value} = $fwtype;
			$rulesout->Range("F".$rowC)->{Value} = $fwgrp;
			$rulesout->Range("G".$rowC)->{Value} = "Allow";
			$rulesout->Range("H".$rowC)->{Value} = "Uni-directional";
			$rulesout->Range("I".$rowC)->{Value} = "Cloudscape";
			$rulesout->Range("J".$rowC)->{Value} = $fwenv;
			#$rulesout->Range("K".$rowC)->{Value} = "";	
		}
	}
	closeFWform($fwBook,$wave,$env,$rowC);
}

# clean up 
close(LOG) if ($debug);
$Excel->Quit();
