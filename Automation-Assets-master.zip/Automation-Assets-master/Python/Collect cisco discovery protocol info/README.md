# CollectCDPInfo #

This script collects the Cisco Discovery Protocol(CDP) information from a Cisco device using SSH. These information are converted to a JSON data structure that is used within a HTML page to create a simple network diagram.

It uses netmiko, TextFSM and vis.js.
