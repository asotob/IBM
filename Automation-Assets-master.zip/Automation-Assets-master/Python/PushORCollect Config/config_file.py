host_conf = ['show version', 'show inventory', 'show run','exit']

# To implement config changes your config would be implemented in list format
# host_conf = ['config t', 'interface lo10', 'description TEST-CONFIG-SCRIPT-3', 'end', 'show run int loop 10']