# Push or Collect Config #

Various Python scripts to automate connecting to Cisco devices via SSH and collecting show commands or pushing some commands.
