import pxssh
import pexpect

#import getpass

#try:
    s = pxssh.pxssh()
    #hostname = raw_input('hostname: ')
    #username = raw_input('username: ')
    #password = getpass.getpass('password: ')

    hostname = '192.168.254.129'
    username = 'admin'
    password = 'Cisco_123'

    s.login(hostname, username, password)
    s.sendline('show version')   # run a command
    s.prompt()             # match the prompt
    print(s.before)        # print everything before the prompt.
    s.sendline('ls -l')
    s.prompt()
    print(s.before)
    s.sendline('df')
    s.prompt()
    print(s.before)
    s.logout()
#except pxssh.ExceptionPxssh as e:
#    print("pxssh failed on login.")
#    print(e)