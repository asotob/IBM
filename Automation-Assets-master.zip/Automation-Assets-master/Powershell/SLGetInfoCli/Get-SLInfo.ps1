<#PSScriptInfo

      .VERSION 0.5

      .GUID 0d04fc80-d661-41f5-b442-22c722726a04

      .AUTHOR Amr Momtaz - amomtaz@ibm.com or amr.momtaz@gmail.com

      .COMPANYNAME IBM

      .COPYRIGHT 2021

      .TAGS ibmcloud

      .LICENSEURI

      .PROJECTURI https://github.ibm.com/cmm-automation-guild-americas/Automation-Assets/tree/master/Powershell/SLGetInfoCli

      .ICONURI

      .EXTERNALMODULEDEPENDENCIES

      .REQUIREDSCRIPTS

      .EXTERNALSCRIPTDEPENDENCIES

      .PRIVATEDATA

      .ReleaseNotes "Added pre-requisits check for ibmcloud cli and Import-Excel module"

#>

# Requires -Module IBMCloudcli
# Install steps for the different OS can be found @ https://cloud.ibm.com/docs/cli?topic=cli-getting-started
# Requires -Module ImportExcel

<#
     .SYNOPSIS
          This powershell Script scraps an IBM Cloud account and collects Classic Infrastructure (SoftLayer) Information related on that account
          - Retrives Account Information
          - Retrieves Users assigned on the account
          - Retrive VSI Information
          - Retrive Baremetal Information      
          - Retrive Network Information (Vlans and Subnets)
          - Retrive Secrutiy Groups Information
          - Retrive File Storage Information
          - Retrive Block Storage Information
          - Retrive Tags Information
          - Optional Switch to retrive VSIs & Baremetals OS & KVM Credenials (-ShowCred)
          - Output can be exported as 
            = Excel output is multi-sheet with everysheet as its own table that can later be used as inputs for other docs via PowerQuery Imports or used in PivotTables/PivotCharts.
            = CSV where each section is its own CSV document
          
     .DESCRIPTION
          Upon execution, this script does the following:
          - Verifies Powershell 5.0 or higher.
          - Check if IBMCloud Cli is installed
          - Imports non-proprietory, open source EXCEL MODULES if required.
          - Retreives Information from Cloud Account
          - Exports invnetory Excel/CSV depending on the switches passed during command execution
          
          UPDATES:
          2021-02-22 Version 0.5
     
     .PARAMETER ExportExcel
          Enabled by default.
          Enables the data colledcted to be exported to Excel documents. The Excel Document name can be passed using the -FileName Switch
          -ExportExcel:$False  #disables
     
    .PARAMETER ExportCsv
          Disabled by default.
          Enables the data colledcted to be exported to CSV documents 

    .PARAMETER FileName
          Filename prefix for Excel & CSV File
          Default set to: SL-Info_Export-
          File is saved in the current working folder that the script is executed from.
    
    .PARAMETER GetAccountInfo
          Get Account Information for Account on IBM Cloud Classic      

    .PARAMETER GetUsersInfo
          Get Users Information for Account on IBM Cloud Classic
     
     .PARAMETER GetVsInfo
          Get Virtual Server Information for Account on IBM Cloud Classic.

     .PARAMETER GetHwInfo
          Get Baremetal/Hardware Information for Account on IBM Cloud Classic.
          
     .PARAMETER GetNetworkInfo
          Get Vlan & Subnet information for Account on IBM Cloud Classic.

     .PARAMETER GetSecurityGroupInfo
          Get Security Group information for Account on IBM Cloud Classic.
    
     .PARAMETER GetFileStorageInfo
          Get FileStorage/NFS Volumes information for Account on IBM Cloud Classic.
     
    .PARAMETER GetBlockStorageInfo
          Get FileStorage/NFS Volumes information for Account on IBM Cloud Classic.
     
    .PARAMETER GetTagsInfo
          Get Resource Tags information for Account on IBM Cloud Classic.

    .PARAMETER GetAllInfo
          Get All Information (All Switches)information for Account on IBM Cloud Classic.

     .PARAMETER ShowCred
          Disabled by default
          Switch to enabled script to collect and display KVM & OS Credentials for the Hw/Baremetal & VSIs
     
     .PARAMETER Help
          Displays help info.
     
     .EXAMPLE
          Get-SLInfo.ps1 -ExportExcel -GetAllInfo -ShowCred
          -- Get all Info and export to excel with default file name SL-Info_Export- Date.
     
     .EXAMPLE
          Get-SLInfo.ps1 -GetVsInfo -ExportExcel
          -- Get VirtualServer Information without showing credentials as the -ShowCred switch is not passed and export data as excel.
        
     .EXAMPLE
          Get-SLInfo.ps1  -GetHwInfo -ExportCsv
          -- Get Hardware/Baremetal Information without showing credentials as the -ShowCred switch is not passed and export data as Csv.
     
     .OUTPUTS
          Excel or CSV files.
          
     .Inputs
     No command line inputs required for export to EXCEL, but parameters are available for convenice for additional optoins.
     
     .Link
     https://github.ibm.com/cmm-automation-guild-americas/Automation-Assets/tree/master/Powershell/SLGetInfoCli
     https://www.powershellgallery.com/packages/ImportExcel/
     https://cloud.ibm.com/docs/cli?topic=cli-getting-started

     .NOTES
          
         RoadMap Items:
          - Modify Get-BlockStorage Function to work like Get-FileStorage Function
          - Power BI for Q&A Type Questions
          - Portal, Dashboard Ideas
            Top 10 Hardware
            Top 10 VSI
            Top 10 FileStorage
            Top 10 BlockStorage



#>
param
(
    [String]$getfunc,
    [Switch]$ExportExcel = $True,
    [Switch]$ExportCsv = $False,
    [String]$FileName = "SL-Info_Export-",   
    [Switch]$GetUsersInfo = $False,
    [Switch]$GetVsInfo = $False,
    [Switch]$GetHwInfo = $False,
    [Switch]$GetNetworkInfo = $False,
    [Switch]$GetSecurityGroupInfo = $False,
    [Switch]$GetFileStorageInfo = $False,
    [Switch]$GetBlockStorageInfo = $False,
    [Switch]$GetAccountInfo = $False,
    [Switch]$GetTagsInfo = $False,
    [Switch]$GetAllInfo,
    [Switch]$ShowCred = $False,
    [Switch]$Help
)

Function InstallImportExcel {    
    param ( $zipfile )

    ##### Install ImportExcel Modules ##### 
    $allPSmodule = $env:PSModulePath.Split(";") | Where-Object { $_ -match "program files" } 
    $UserPSMODULE = $env:PSModulePath.Split(";") | Where-Object { $_ -match "\\user" } 

    $ModulePath = $UserPSMODULE 

    if (test-path $allPSmodule) {
        $ModulePath = $allPSmodule
    }
    else {
        #Create user directory if not exist
        New-Item -Path $ModulePath -Type:Directory -ErrorAction:SilentlyContinue
    }

    $ModulePath = Get-Item $ModulePath 
    $zipfile = $zipfile | dir | ForEach-Objec { $_.Fullname }
    Expand-Archive $zipfile -DestinationPath $ModulePath -verbose
}

function Get-FileStorageInfoFunc ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    #write-host "ExportExcel Value:" $ExportExcel -BackgroundColor Cyan
    #write-host "ExportCsv Value:" $ExportCsv -BackgroundColor Cyan

    $command_json = "ibmcloud sl file volume-list --output json"
    $command = "ibmcloud sl file volume-list"
    $command = Invoke-Expression $command

    Write-host "INFO: Executing command:" $command_json "..." -foreground Yellow
    $volList = Invoke-Expression $command_json | ConvertFrom-Json
    
    #Show output collected
    $command
         
    $volDetailList = @()
    
    Write-host "INFO: Geting Volume Details..." -foreground Yellow
    Write-host "INFO: Found File Volume(s) on account:" $volList.Count -foreground Yellow

    $Seq = 1

    Foreach ($volId in $volList) {
        
        #ibmcloud sl file volume-detail 86323830 --output json
        $volDet = ibmcloud sl file volume-detail $volId.id --output json | ConvertFrom-Json
       
        #$volDet = ibmcloud sl file volume-detail 86323830 --output json | ConvertFrom-Json


        Write-host "INFO: Geting Volume Details for file-volume" $Seq "/" $volList.Count ":" $volDet.username  -foreground Yellow
        $volObj = New-Object -TypeName PSObject
        $volObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq
        $volObj | Add-Member -MemberType NoteProperty -Name Cloud_File_ID -Value $volDet.id
        $volObj | Add-Member -MemberType NoteProperty -Name UserName -Value $volDet.username
        $volObj | Add-Member -MemberType NoteProperty -Name Type -Value $volDet.storageType.keyName
        $volObj | Add-Member -MemberType NoteProperty -Name storageTierLevel -Value $volDet.storageTierLevel

        #Determine IOPS from Storage Level Tier
        if ($volObj.storageTierLevel -eq "LOW_INTENSITY_TIER") {
            $volObj | Add-Member -MemberType NoteProperty -Name IOPS -Value 0.25
        }
        elseif ($volObj.storageTierLevel -eq "READHEAVY_TIER") {
            $volObj | Add-Member -MemberType NoteProperty -Name IOPS -Value 2
        }
        elseif ($volObj.storageTierLevel -eq "WRITEHEAVY_TIER") {
            $volObj | Add-Member -MemberType NoteProperty -Name IOPS -Value 4
        }
        else {
            $volObj | Add-Member -MemberType NoteProperty -Name IOPS -Value 10
        }

        $volObj | Add-Member -MemberType NoteProperty -Name SizeGB -Value $volDet.capacityGb
        try {
            $capUsedGB = [math]::Round($volDet.bytesUsed / 1GB, 2)
        }
        catch {
            $capUsedGB = 0
        }        

        $volObj | Add-Member -MemberType NoteProperty -Name SizeUsedGB -Value $capUsedGB
        #Get Percent of Utilization (Try & Catch for the Div by Zero)
        try {
            $capUsedPercent = $volObj.SizeUsedGB / $volObj.SizeGB
            $capUsedPercent = $capUsedPercent.ToString("P")
        }
        catch {
            $capUsedPercent = 0
        }
        $volObj | Add-Member -MemberType NoteProperty -Name SizeUsedPercent -Value $capUsedPercent


        $volObj | Add-Member -MemberType NoteProperty -Name Datacenter -Value $volDet.serviceResource.datacenter.name
        $volObj | Add-Member -MemberType NoteProperty -Name TargetIP -Value $volDet.serviceResourceBackendIpAddress
        $volObj | Add-Member -MemberType NoteProperty -Name MountAddress -Value $volDet.fileNetworkMountAddress

        $volObj | Add-Member -MemberType NoteProperty -Name ReplicantCount -Value $volDet.replicationPartnerCount
        
        #Getting Device authorization per VolId
        #
        $volAccess = ibmcloud sl file access-list $volId.id --output json | ConvertFrom-Json
        #$volAccess = ibmcloud sl file access-list 79447263 --output json | ConvertFrom-Json
           
        #looping through the authentited device list and adding them to a list as strings and then adding this list to the volObj as a new membertype
        $authDeviceList = @()
        Foreach ($authDevice in $volAccess) {  
            $authDeviceList += $authDevice.name
        }
        #put the contents authDeviceList to a Strvariable so it can be exported to CSV
        $authDeviceListString = $authDeviceList -join ', '
    
        $volObj | Add-Member -MemberType NoteProperty -Name AuthenticatedDevices -Value $authDeviceListString

        #Adding the volObj to the volDetailList
        $volDetailList += $volObj
        $Seq = $Seq + 1
        
    }

       
    #Export volDetailList to CSV
    if ($ExportCsv) {
        $CsvFname = $fname + ".csv"
        $volDetailList | Export-Csv -Path $CsvFname -NoTypeInformation
        Write-host "INFO: Finished Exporting" $volDetailList "to" $CsvFname "to current working folder." -foreground Yellow
    } 

    #Export volDetailList to Excel
    if ($ExportExcel) {     
        $workSheetName = "FileStorage_Info"
        $fname = $fname + ".xlsx"
        $volDetailList | Export-Excel -WorksheetName $workSheetName -Path $fname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "to" $fname "to current working folder." -foreground Yellow
    }
    
    #Display $VolDetail List
    $volDetailList | Format-Table -AutoSize
}

function Get-FileStorageInfoTrans ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    #write-host "ExportExcel Value:" $ExportExcel -BackgroundColor Cyan
    #write-host "ExportCsv Value:" $ExportCsv -BackgroundColor Cyan

    $command = "ibmcloud sl file volume-list"

    Write-host "INFO: Executing command:" $command "..." -foreground Yellow
    $tmp = Invoke-Expression $command
    
    #Show output collected
    $tmp
    
    #replace multiple spaces with comma
    $tmp = $tmp -replace '\s+', ','
    #replace comma at the end of the line with nothing
    $tmp = $tmp -replace ',$', ''
    
    #save file as txt
    $tmp | Out-file tmp.txt
    
    #import file as txt and then export as csv
    import-csv .\tmp.txt | Export-Csv .\volList.csv -NoTypeInformation
    $volList = import-csv .\volList.csv
      
    $volDetailList = @()
    
    Write-host "INFO: Geting Volume Details..." -foreground Yellow
    Write-host "INFO: Found File Volume(s) on account:" $volList.Count -foreground Yellow

    
    $Seq = 1

    Foreach ($volId in $volList) {
        
        #ibmcloud sl file volume-detail 152444704
        $volDet = ibmcloud sl file volume-detail $volId.id
        $volDet = $volDet -replace '\s{2,}', ','
        $volDet = $volDet -replace ',$', ''
        $volDet | Out-file tmp.txt
        import-csv .\tmp.txt | Export-Csv volDet.csv -NoTypeInformation
        $volDet = .\Transpose.ps1 -InputFile .\volDet.csv
        
        $volDet = ibmcloud sl file volume-detail $volId.id --output json | ConvertFrom-Json
        
        Write-host "INFO: Geting Volume Details for:" $volDet.'User name'  -foreground Yellow
        $volObj = New-Object -TypeName PSObject
        $volObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq
        $volObj | Add-Member -MemberType NoteProperty -Name VolId -Value $volDet.id
        $volObj | Add-Member -MemberType NoteProperty -Name UserName -Value $volDet.'User name'
        $volObj | Add-Member -MemberType NoteProperty -Name Type -Value $volDet.Type
        $volObj | Add-Member -MemberType NoteProperty -Name CapacityGB -Value $volDet.'Capacity (GB)'
        $volObj | Add-Member -MemberType NoteProperty -Name EnduranceTier -Value $volDet.'Endurance Tier'
        $volObj | Add-Member -MemberType NoteProperty -Name IOPS -Value $volDet.'Endurance Tier Per IOPS'
        $volObj | Add-Member -MemberType NoteProperty -Name Datacenter -Value $volDet.Datacenter
        $volObj | Add-Member -MemberType NoteProperty -Name TargetIP -Value $volDet.'Target IP'
        $volObj | Add-Member -MemberType NoteProperty -Name MountAddress -Value $volDet.'Mount Address'
        
        #Getting Device authorization per VolId
        #
        $volAccess = ibmcloud sl file access-list $volId.id
        #$volAccess = ibmcloud sl file access-list 152444704
        $volAccess = $volAccess -replace '\s{2,}', ','
        $volAccess = $volAccess -replace ',$', ''
        $volAccess | Out-file volAccess.txt
        import-csv .\volAccess.txt | Export-Csv .\volAccess.csv -NoTypeInformation
        $volAccess = import-csv .\volAccess.csv
    
        #looping through the authentited device list and adding them to a list as strings and then adding this list to the volObj as a new membertype
        $authDeviceList = @()
        Foreach ($authDevice in $volAccess) {  
            $authDeviceList += $authDevice.name
        }
        #put the contents authDeviceList to a Strvariable so it can be exported to CSV
        $authDeviceListString = $authDeviceList -join ', '
    
        $volObj | Add-Member -MemberType NoteProperty -Name AuthenticatedDevices -Value $authDeviceListString
        $volObj | Add-Member -MemberType NoteProperty -Name ReplicantCount -Value $volDet.'Replicant Count'
        #Adding the volObj to the volDetailList
        $volDetailList += $volObj
        $Seq = $Seq + 1
        
    }
    
    #Export volDetailList to CSV
    if ($ExportCsv) {
        $CsvFname = $fname + ".csv"
        $volDetailList | Export-Csv -Path $CsvFname -NoTypeInformation
        Write-host "INFO: Finished Exporting" $volDetailList "to" $CsvFname "to current working folder." -foreground Yellow
    } 

    #Export volDetailList to Excel
    if ($ExportExcel) {     
        $workSheetName = "FileStorage_Info"
        $fname = $fname + ".xlsx"
        $volDetailList | Export-Excel -WorksheetName $workSheetName -Path $fname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "to" $fname "to current working folder." -foreground Yellow
    }
    
    #Display $VolDetail List
    $volDetailList | Format-Table -AutoSize
       
    
    #Remove Temp Files used during the Function run
    Remove-Item .\tmp.txt
    Remove-Item .\volAccess.csv
    Remove-Item .\volAccess.txt
    Remove-Item .\volDet.csv
    Remove-Item .\volList.csv
    #Remove-Item .\volDetailList.csv
}

function Get-VsInfoFunc([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv, [boolean]$ShowCred) {
    $command = 'ibmcloud sl vs list'
    $csvFileName = "vsList.csv"

    Write-host ("INFO: Executing command: " + $command) -foreground Yellow

    $tmp = Invoke-Expression $command

    #String Manipulation to convert String to CSV Compatible
    $tmp = $tmp -replace 'action', ''
    $tmp = $tmp -replace '\s+', ','
    #replace comma at the end of the line with nothing
    $tmp = $tmp -replace ',$', ''

    #convert $tmp string to csv 
    $tmp = $tmp | ConvertFrom-Csv -Delimiter ","

    #Show output collected
    $tmp | Format-Table

    #export $tmp to csv
    $tmp | Export-Csv $csvFileName -NoTypeInformation
    #Write-host ("INFO: Finished export-csv" + $csvFileName + "to current working folder") -foreground Yellow


    $cList = import-csv $csvFileName
    Write-host "INFO: Found VSI(s) on account:" $cList.Count -foreground Yellow
    
    $seq = 1

    #Empty Array/List
    $cDetailList = @()

    ForEach ($cID in $cList) {
    
        #Loop over every VSI ID collected in cLIST and put the details in json variable
            
        $json = ibmcloud sl vs detail $cID.id --output json | ConvertFrom-Json

        Write-host "INFO: Geting Details for VSI" $Seq "/" $cList.Count ":"  $json.fullyQualifiedDomainName -foreground Yellow
        #$json = ibmcloud sl vs detail 83921925 --output json >> camcollector.json | ConvertFrom-Json
        #ibmcloud sl vs detail 64561509 --output json >> Tivoli.json
        #$json = ibmcloud sl vs detail 83921925 --output json | ConvertFrom-Json

        #Create cObj to put all VSI info collected from json
        $cObj = $cObj = New-Object -TypeName PSObject
        $cObj | Add-Member -MemberType NoteProperty -Name Seq -Value $seq
        $cObj | Add-Member -MemberType NoteProperty -Name Cloud_VSI_ID -Value $json.id
        $cObj | Add-Member -MemberType NoteProperty -Name Hostname -Value $json.hostname
        $cObj | Add-Member -MemberType NoteProperty -Name Domain -Value $json.domain
        $cObj | Add-Member -MemberType NoteProperty -Name FQDN -Value $json.fullyQualifiedDomainName
        $cObj | Add-Member -MemberType NoteProperty -Name DC -Value $json.datacenter.name
        $cObj | Add-Member -MemberType NoteProperty -Name Notes -Value $json.notes
        $cObj | Add-Member -MemberType NoteProperty -Name CPU -Value $json.maxCpu
        
        #Convert Memory to GigaByte
        $maxMemoryGB = $json.maxMemory / 1024
        $cObj | Add-Member -MemberType NoteProperty -Name MemoryGB -Value $maxMemoryGB
        $cObj | Add-Member -MemberType NoteProperty -Name PrivateIP -Value $json.primaryBackendIpAddress
        $cObj | Add-Member -MemberType NoteProperty -Name PublicIP -Value $json.primaryIpAddress

        #Count Num of Nics
        $numofnics = $json.networkComponents | Measure-Object
        $cObj | Add-Member -MemberType NoteProperty -Name "Num of Nics" -Value $numofnics.Count
    
        #Get Nic information
        $nicNum = 0
        foreach ($nic in $json.networkComponents) {
            $nicName = "Nic" + $nicNum + " Name"
            $nicN = $nic.name + $nic.port
            $cObj | Add-Member -MemberType NoteProperty -Name $nicName -Value $nicN
            $nicStatus = "Nic" + $nicNum + " Status"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicStatus -Value $nic.status
            $nicSpeed = "Nic" + $nicNum + " Speed"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicSpeed -Value $nic.maxSpeed
            $nicMac = "Nic" + $nicNum + " Mac Address"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicMac -Value $nic.macAddress
            $nicIpAddr = "Nic" + $nicNum + " IP Addr"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicIpAddr -Value $nic.primaryIpAddress
            $nicIpMaskS = "Nic" + $nicNum + " IP MaskS"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicIpMaskS -Value $nic.primarySubnet.netmask
            $nicIpMask = "Nic" + $nicNum + " IP Mask"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicIpMask -Value $nic.primarySubnet.cidr
            $nicIpGw = "Nic" + $nicNum + " IP Gw"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicIpGw -Value $nic.primarySubnet.gateway
            $nicIpSubnet = "Nic" + $nicNum + " IP Subnet"
            $cObj | Add-Member -MemberType NoteProperty -Name $nicIpSubnet -Value $nic.primarySubnet.networkIdentifier
        
            #Cross check Vlan ID to Vlan List to get Vlan Number
            ForEach ($vlan in $json.networkVlans) {
                if ($nic.primarySubnet.networkVlanId -eq $vlan.id) {
                    $nicVlan = "Nic" + $nicnum + " Vlan"
                    $cObj | Add-Member -MemberType NoteProperty -Name $nicVlan -Value $vlan.vlanNumber
                    $nicVlanType = "Nic" + $nicNum + " Vlan Type"
                    $cObj | Add-Member -MemberType NoteProperty -Name $nicVlanType -Value $vlan.networkSpace
                }
            }
            $nicNum = $nicNum + 1
        }

        #Get additional VSI properties
        $cObj | Add-Member -MemberType NoteProperty -Name ProvisionDate -Value $json.provisionDate
        $cObj | Add-Member -MemberType NoteProperty -Name PowerState -Value $json.powerState.name
        $cObj | Add-Member -MemberType NoteProperty -Name OS -Value $json.operatingSystem.softwareLicense.softwareDescription.referenceCode
        $cObj | Add-Member -MemberType NoteProperty -Name Owner -Value $json.billingItem.orderItem.order.userRecord.username

        #Get OS Credentials | Checks if $ShowCred Switch is True before collecting OS Credentials
        if ($ShowCred) {
            $credList = @()
            Foreach ($credEntry in $json.operatingSystem.passwords) {
        
                $userpass = ""
                $username = $credEntry.username -join ""
                $password = $credEntry.password -join ""
                $userpass = $username + "|" + $password
                $credList += $userpass
            }
            $credList = $credList -join ', '
            $cObj | Add-Member -MemberType NoteProperty -Name Credentials -Value $credList
        }
        ######

        $cDetailList += $cObj
        $seq = $seq + 1 
    }

    #$newVar = $cDetailList
    #Export cDetailList to CSV
    if ($ExportCsv) {
        $Csvfname = $fname + "-GetVsInfo" + ".csv"
        $cDetailList | Select-Object "Seq", "ID", "Hostname", "Domain", "FQDN", "Notes", "CPU", "Memory", "PrivateIP", "PublicIP", "Num of Nics", "Nic0 Name", "Nic0 Status", "Nic0 Speed", "Nic0 Mac Address", "Nic0 IP Addr", "Nic0 IP MaskS", "Nic0 IP Mask", "Nic0 IP Gw", "Nic0 IP Subnet", "Nic0 Vlan", "Nic0 Vlan Type", "Nic1 Name", "Nic1 Status", "Nic1 Speed", "Nic1 Mac Address", "Nic1 IP Addr", "Nic1 IP MaskS", "Nic1 IP Mask", "Nic1 IP Gw", "Nic1 IP Subnet", "Nic1 Vlan", "Nic1 Vlan Type", "ProvisionDate", "PowerState", "OS", "Owner", "Credentials" | Export-Csv -Path $Csvfname -NoTypeInformation
        Write-host ("INFO: Finished Exporting " + $CsvFname + " to current working folder.") -foreground Yellow
    }
    #Export cDetailList to Excel
    if ($ExportExcel) {
        $workSheetName = "VSI_Info"
        $Excelfname = $fname + ".xlsx"
        $cDetailList | Export-Excel -WorksheetName $workSheetName -Path $Excelfname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $Excelfname "to current working folder." -foreground Yellow

    }
    #Displays output     
    $cDetailList | format-table -AutoSize
    
    #Remove Temp Files used during the Function run
    Remove-Item $csvFileName
    #Remove-Item .\tmp.txt
    #Remove-Item .\cDetailList.csv.csv

}


Function Get-HwInfoFunc ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv, [boolean]$ShowCred) {
    
    $command = 'ibmcloud sl hardware list'

    Write-host ("INFO: Executing command: " + $command) -foreground Yellow
    $command = ibmcloud sl hardware list --output json | ConvertFrom-Json
    $cList = $command

    #Create an Empty Array
    $cDetailList = @()

    $Seq = 1
    Foreach ($cID in $cList) {
        $cObj = New-Object -TypeName PSObject
        $cObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq
        $cObj | Add-Member -MemberType NoteProperty -Name Cloud_HW_ID -Value $cID.id
        $cObj | Add-Member -MemberType NoteProperty -Name Hostname -Value $cID.hostname
        $cObj | Add-Member -MemberType NoteProperty -Name Domain -Value $cID.domain
        $cObj | Add-Member -MemberType NoteProperty -Name Status -Value $cID.hardwareStatus.status
        $cObj | Add-Member -MemberType NoteProperty -Name PrivateIP -Value $cID.primaryBackendIpAddress
        $cObj | Add-Member -MemberType NoteProperty -Name PublicIP -Value $cID.primaryIpAddress
        $cObj | Add-Member -MemberType NoteProperty -Name DC -Value $cID.datacenter.name

        #$cDetailList = $cDetailList + $cObj
        $cDetailList += $cObj
        $Seq += 1
    }
    
    $cDetailList | Format-Table -AutoSize
    
    $cList = $cDetailList

    $cDetailList = @()

    Write-host "INFO: Found HW(s) on account:" $cList.Count -foreground Yellow

    $Seq = 1
    Foreach ($cID in $cList) {
    
        $cDet = ibmcloud sl hardware detail $cID.Cloud_HW_ID --output json | ConvertFrom-Json
        #$cDet = ibmcloud sl hardware detail 1891014 --output json | ConvertFrom-Json

        Write-host "INFO: Geting Details for Hardware" $Seq "/" $cList.Count ":"  $cDet.'fullyQualifiedDomainName' -foreground Yellow
    
        $cObj = New-Object -TypeName PSObject
        $cObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq
        $cObj | Add-Member -MemberType NoteProperty -Name ID -Value $cDet.id
        $cObj | Add-Member -MemberType NoteProperty -Name Hostname -Value $cDet.'hostname'
        $cObj | Add-Member -MemberType NoteProperty -Name Domain -Value $cDet.'domain'
        $cObj | Add-Member -MemberType NoteProperty -Name FQDN -Value $cDet.'fullyQualifiedDomainName'
        $cObj | Add-Member -MemberType NoteProperty -Name Datacenter -Value $cDet.datacenter.name
        $cObj | Add-Member -MemberType NoteProperty -Name Status -Value $cDet.hardwareStatus.status
        #$cObj | Add-Member -MemberType NoteProperty -Name Notes -Value $cDet.notes
        $cObj | Add-Member -MemberType NoteProperty -Name CpuModel -Value $cDet.billingItem.orderItem.description
        $cObj | Add-Member -MemberType NoteProperty -Name CpuCores -Value $cDet.processorPhysicalCoreAmount
        $cObj | Add-Member -MemberType NoteProperty -Name MemoryGB -Value $cDet.memoryCapacity
        
        $cObj | Add-Member -MemberType NoteProperty -Name PrivateIP -Value $cDet.primaryBackendIpAddress
        $cObj | Add-Member -MemberType NoteProperty -Name PublicIP -Value $cDet.primaryIpAddress

        $cObj | Add-Member -MemberType NoteProperty -Name PrivateVlan -Value ""
        $cObj | Add-Member -MemberType NoteProperty -Name PublicVlan -Value ""

        #Vlans Info
        ForEach ($vlan in $cDet.networkVlans) {
            if ($vlan.networkSpace -eq "PRIVATE") {               
                $cObj.PrivateVlan = $vlan.vlanNumber
            }
            elseif ($vlan.networkSpace -eq "PUBLIC") {
                $cObj.PublicVlan = $vlan.vlanNumber
            }
        } 
        
        #KVM Cred Info
        if ($ShowCred) {
            $cObj | Add-Member -MemberType NoteProperty -Name KVM-IP -Value $cDet.networkManagementIpAddress
        
            $credList = @()
            Foreach ($credEntry in $cDet.remoteManagementAccounts) {
        
                $userpass = ""
                $username = $credEntry.username -join ""
                $password = $credEntry.password -join ""
                $userpass = $username + "|" + $password
                $credList += $userpass
            }
            $credList = $credList -join ', '
            $cObj | Add-Member -MemberType NoteProperty -Name KVM-Cred -Value $credList
        }
        
        #OS Info
        $cObj | Add-Member -MemberType NoteProperty -Name OS -Value $cDet.operatingSystem.softwareLicense.softwareDescription.name
        $cObj | Add-Member -MemberType NoteProperty -Name OS-Version -Value $cDet.operatingSystem.softwareLicense.softwareDescription.referenceCode

        
        #OS Credentials
        if ($ShowCred) {
            $cObj | Add-Member -MemberType NoteProperty -Name OS-Cred -Value ""
            $credList = @()
            Foreach ($credEntry in $cDet.operatingSystem.passwords) {
        
                $userpass = ""
                $username = $credEntry.username -join ""
                $password = $credEntry.password -join ""
                $userpass = $username + "|" + $password
                $credList += $userpass
            }
            $credList = $credList -join ', '
            $cObj."OS-Cred" = $credList
        }

        #Order Info
        $cObj | Add-Member -MemberType NoteProperty -Name Created -Value $cDet.provisionDate
        $cObj | Add-Member -MemberType NoteProperty -Name Owner -Value $cDet.billingItem.orderItem.order.userRecord.username
                        
        #Adding the cObj to the cDetailList & Increment Seq
        $cDetailList += $cObj
        $Seq += 1    
    }

    #Export cDetailList to CSV
    if ($ExportCsv) {
        $CsvFname = $fname + "-GetHwInfo" + ".csv"
        $cDetailList | Export-Csv $CsvFname -NoTypeInformation
        Write-host ("INFO: Finished Exporting " + $CsvFname + " to current working folder.") -foreground Yellow
    }

    #Export to Excel
    if ($ExportExcel) {
        $workSheetName = "HW_Info"
        $Excelfname = $fname + ".xlsx"
        $cDetailList | Export-Excel -WorksheetName $workSheetName -Path $Excelfname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $Excelfname " in working folder..." -foreground Yellow
    }
    #Display Output
    $cDetailList | format-table -AutoSize
}

Function Get-BlockStorageInfoFunc ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    $command = 'ibmcloud sl block volume-list'
    
    Write-host ("INFO: Executing command: " + $command) -foreground Yellow
    $command = ibmcloud sl block volume-list --output json | ConvertFrom-Json
    $cList = $command

    $cDetailList = @()

    $Seq = 1
    Foreach ($cID in $cList) {
        $cObj = New-Object -TypeName PSObject
        $cObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq
        $cObj | Add-Member -MemberType NoteProperty -Name Cloud_Block_ID -Value $cID.id
        $cObj | Add-Member -MemberType NoteProperty -Name Username -Value $cID.username
        $cObj | Add-Member -MemberType NoteProperty -Name CapacityGB -Value $cID.capacityGb
        $cObj | Add-Member -MemberType NoteProperty -Name StorageType -Value $cID.storageType.keyName
        $cObj | Add-Member -MemberType NoteProperty -Name DataCenter -Value $cID.serviceResource.datacenter.name
        $cObj | Add-Member -MemberType NoteProperty -Name LunId -Value $cID.lunId

        $cDetailList += $cObj
        $Seq += 1
    }
    
    #Export to CSV
    if ($ExportCsv) {
        $Csvfname = $fname + "-GetBlockStorageInfo" + ".csv"
        $cDetailList | Export-Csv $Csvfname -NoTypeInformation
        Write-host ("INFO: Finished Exporting" + $Csvfname + "to current working folder") -foreground Yellow
    }
    
    #Export to Excel
    if ($ExportExcel) {
        $workSheetName = "BlockStorage_Info"
        $Excelfname = $fname + ".xlsx"
        $cDetailList | Export-Excel -WorksheetName $workSheetName -Path $Excelfname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $Excelfname "to current working folder..." -foreground Yellow
    }

    #Displays output
    $cDetailList | Format-Table -AutoSize
    
}

Function Get-SecurityGroupInfoFunc ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    $command = 'ibmcloud sl securitygroup list'
    
    Write-host ("INFO: Executing command: " + $command) -foreground Yellow
    $command = ibmcloud sl securitygroup list --output json | ConvertFrom-Json
    $cList = $command

    $cDetailList = @()
    
    $Seq = 1
    Foreach ($cID in $cList) {
        $cObj = New-Object -TypeName PSObject
        $cObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq
        $cObj | Add-Member -MemberType NoteProperty -Name Cloud_SG_ID -Value $cID.id
        $cObj | Add-Member -MemberType NoteProperty -Name Name -Value $cID.name
        $cObj | Add-Member -MemberType NoteProperty -Name Description -Value $cID.description
        $cObj | Add-Member -MemberType NoteProperty -Name Created -Value $cID.createDate

        $cDetailList += $cObj
        $Seq += 1
    }
    
    #Export file as txt and then export as csv
    $cDetailList | Format-Table -AutoSize

    if ($ExportCsv) {
        $Csvfname = $fname + "-GetSecurityGroupInfo" + ".csv"
        $cDetailList | Export-Csv $Csvfname -NoTypeInformation
        Write-host ("INFO: Finished export-csv " + $Csvfname + " to current working folder") -foreground Yellow
    }
    
    if ($ExportExcel) {
        $workSheetName = "SecurityGroup_Info"
        $Excelfname = $fname + ".xlsx"
        $cDetailList | Export-Excel -WorksheetName $workSheetName -Path $Excelfname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $Excelfname "in working folder..." -foreground Yellow
    }
        
}


Function Get-NetworkInfoFunc([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    $command = 'ibmcloud sl vlan list'
    
    Write-host ("INFO: Executing command: " + $command) -foreground Yellow

    $tmp = Invoke-Expression $command

    #Show output collected
    $tmp
    #replace multiple spaces with semi-colon
    $tmp = $tmp -replace '\s+', ';'
    #replace semi-colon at the end of the line with nothing
    $tmp = $tmp -replace ';$', ''
    #convert $tmp string to csv 
    $tmp = $tmp | ConvertFrom-Csv -Delimiter ";"

    #export VlansInfo to Csv
    if ($ExportCsv) {
        $CsvFname = $fname + "-VlansInfo" + ".csv"
        $tmp | Export-Csv $CsvFname -NoTypeInformation
        Write-host "INFO: Finished Exporting" $CsvFname "to current working folder." -foreground Yellow
    }

    #$tmp = Import-Csv $csvFileName

    #Export VlanInfo to Excel
    if ($ExportExcel) {
        $workSheetName = "Vlans_Info"
        $ExcelFname = $fname + ".xlsx"
        $tmp | Export-Excel -WorksheetName $workSheetName -Path $ExcelFname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $fname " in current working folder." -foreground Yellow
    }

    $cList = $tmp

    Write-host "INFO: Found Vlan(s) on account:" $cList.Count -foreground Yellow

    $Seq = 1
    $Seq2 = 1
    $cDetailList = @()

    Foreach ($cID in $cList) {
    
        $json = ibmcloud sl vlan detail $cID.id --output json | ConvertFrom-Json
    
        #$json = ibmcloud sl vlan detail 2975764 --output json | ConvertFrom-Json 
        #Write-host "INFO: Geting Subnets in Vlan:" $json.vlanNumber  -foreground Yellow
        Write-host "INFO: Geting Details for Vlan" $Seq "/" $cList.Count ": Vlan#"  $json.vlanNumber -foreground Yellow 
    
        
        foreach ($subnet in $json.subnets) {
        
            $cObj = $subnet
            $cObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq2
            $cObj | Add-Member -MemberType NoteProperty -Name vlanId -Value $json.vlanNumber
            #Remove Object with property name "id"
            $cObj.PSObject.Properties.Remove('id')
            #$cObj | Add-Member -MemberType AliasProperty -Name Subnet -Value networkIdentifier
            $cObj | Add-Member -MemberType NoteProperty -Name subnet -Value $cObj.networkIdentifier
            $cObj.PSObject.Properties.Remove('networkIdentifier')
            $cObj | Add-Member -MemberType NoteProperty -Name vlanName -Value $cID.name
            $cObj | Add-Member -MemberType NoteProperty -Name primaryRouter -Value $json.primaryRouter.fullyQualifiedDomainName
            
            #Check Vlan Type based on gateway name
            if ($json.primaryRouter.fullyQualifiedDomainName.Contains("fcr")) {
                $cObj | Add-Member -MemberType NoteProperty -Name VlanType -Value "PUBLIC"
            }
            else {
                $cObj | Add-Member -MemberType NoteProperty -Name VlanType -Value "PRIVATE"
            }
            
            $cObj | Add-Member -MemberType NoteProperty -Name datacenter -Value $json.primaryRouter.datacenterName
            #$cObj | Add-Member -MemberType NoteProperty -Name network_space -Value $json.network_space

            $cDetailList += $cObj
            $Seq2 = $Seq2 + 1
    
        }
        $Seq = $Seq + 1
    }

    $fDetailList = $cDetailList | Select-Object Seq , subnet, netmask, gateway, subnetType, vlanId, vlanName, VlanType, datacenter, primaryRouter

    #Export cDetailList to CSV
    if ($ExportCsv) {
        $CsvFname = $fname + "-SubnetsInfo" + ".csv"
        $fDetailList | Export-csv -Path $CsvFname -NoTypeInformation
        Write-host "INFO: Finished Exporting" $CsvFname "to current working folder." -foreground Yellow
    }

    if ($ExportExcel) {
        $workSheetName = "Subnets_Info"
        $ExcelFname = $fname + ".xlsx"
        $fDetailList | Export-Excel -WorksheetName $workSheetName -Path $ExcelFname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $fname " in current working folder." -foreground Yellow
    }

    #Display Output
    $fDetailList | format-table -AutoSize
}


Function Get-UsersInfoFunc ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    $command = 'ibmcloud sl user list'
    
    Write-host ("INFO: Executing command: " + $command) -foreground Yellow
    $command = ibmcloud sl user list --output json | ConvertFrom-Json
    $cList = $command

    $cDetailList = @()

    $Seq = 1
    Foreach ($cID in $cList) {
        $cObj = New-Object -TypeName PSObject
        $cObj | Add-Member -MemberType NoteProperty -Name Seq -Value $Seq
        $cObj | Add-Member -MemberType NoteProperty -Name id -Value $cID.id
        $cObj | Add-Member -MemberType NoteProperty -Name Username -Value $cID.username
        $cObj | Add-Member -MemberType NoteProperty -Name DisplayName -Value $cID.displayName
        $cObj | Add-Member -MemberType NoteProperty -Name Email -Value $cID.email

        $cDetailList += $cObj
        $Seq += 1
    }
    
    #Export to CSV
    if ($ExportCsv) {
        $Csvfname = $fname + "-GetUsersInfo" + ".csv"
        $cDetailList | Export-Csv $fname -NoTypeInformation
        Write-host ("INFO: Finished Exporting " + $Csvfname + " to current working folder.") -foreground Yellow
    }
    
    #Export to Excel
    if ($ExportExcel) {
        $workSheetName = "Users_Info"
        $Excelfname = $fname + ".xlsx"
        $cDetailList | Export-Excel -WorksheetName $workSheetName -Path $Excelfname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $fname "to current working folder." -foreground Yellow
    }
    #Displays output
    $cDetailList | format-table -AutoSize
    
}


Function Get-AccountInfoFunc ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    $command = 'ibmcloud account show'
    
    Write-host ("INFO: Executing command: " + $command) -foreground Yellow
    $command = ibmcloud account show --output json | ConvertFrom-Json
    
    $cObj = New-Object -TypeName PSObject
    $cObj | Add-Member -MemberType NoteProperty -Name AccountName -Value $command.name
    $cObj | Add-Member -MemberType NoteProperty -Name AccountId -Value $command.account_id
    $cObj | Add-Member -MemberType NoteProperty -Name AccountOwner -Value $command.onwer
    $cObj | Add-Member -MemberType NoteProperty -Name AccountType -Value $command.type
    $cObj | Add-Member -MemberType NoteProperty -Name 'IMS AccountID' -Value $command.ims_account_id
    $cObj | Add-Member -MemberType NoteProperty -Name AccountStatus -Value $command.status
    $cObj | Add-Member -MemberType NoteProperty -Name 'VRF Enabled' -Value $command.service_endpoint_status.VRF_Enabled
    $cObj | Add-Member -MemberType NoteProperty -Name 'Service Endpoint Enabled' -Value $command.service_endpoint_status.Service_Endpoint_Connected
    $cObj | Add-Member -MemberType NoteProperty -Name 'EU Supported' -Value $command.traits.eu_supported
    $cObj | Add-Member -MemberType NoteProperty -Name 'PoC Account' -Value $command.traits.poc
    $cObj | Add-Member -MemberType NoteProperty -Name 'HIPPA Accepted' -Value $command.traits.hippa_accepted
           
    
    #Export to CSV
    if ($ExportCsv) {
        $Csvfname = $fname + "-GetAccountInfo" + ".csv"
        $cObj | Export-Csv $fname -NoTypeInformation
        Write-host ("INFO: Finished Exporting " + $Csvfname + " to current working folder.") -foreground Yellow
    }
    
    #Export to Excel
    if ($ExportExcel) {
        $workSheetName = "Account_Info"
        $Excelfname = $fname + ".xlsx"
        $cObj | Export-Excel -WorksheetName $workSheetName -Path $Excelfname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $fname "to current working folder." -foreground Yellow
    }
    #Displays output
    $cObj | format-table -AutoSize
    
}

Function Get-TagsInfoFunc ([string]$fname, [boolean]$ExportExcel, [boolean]$ExportCsv) {
    
    $command = 'ibmcloud resource tags'
    
    Write-host ("INFO: Executing command: " + $command) -foreground Yellow
    $command = ibmcloud resource tags
    $cObj = $command
    
    #Export to CSV
    if ($ExportCsv) {
        $Csvfname = $fname + "-TagsInfoFunc" + ".csv"
        $cObj | Export-Csv $fname -NoTypeInformation
        Write-host ("INFO: Finished Exporting " + $Csvfname + " to current working folder.") -foreground Yellow
    }
    
    #Export to Excel
    if ($ExportExcel) {
        $workSheetName = "Tags_Info"
        $Excelfname = $fname + ".xlsx"
        $cObj | Export-Excel -WorksheetName $workSheetName -Path $Excelfname -AutoSize -TableName $workSheetName -TableStyle Medium20
        Write-host "INFO: Finished adding" $workSheetName "Worksheet to" $fname "to current working folder." -foreground Yellow
    }
    #Displays output
    $cObj | format-table -AutoSize
    
}


#######################################################################################
#Parameters
#######################################################################################

#This is a copy of the parameters section for easy to read instead of scrolling all the way up
#[String]$getfunc,
#[Switch]$ExportExcel,
#[Switch]$ExportCsv = $False,
#[String]$FileName = "SL-Info_Export-",   
#[Switch]$Help
#    [String]$getfunc,
#    [Switch]$ExportExcel,
#    [Switch]$ExportCsv = $False,
#    [String]$FileName = "SL-Info_Export-",   
#    [Switch]$GetUsersInfo = $False,
#    [Switch]$GetVsInfo = $False,
#    [Switch]$GetHwInfo = $False,
#    [Switch]$GetNetworkInfo = $False,
#    [Switch]$GetSecurityGroupInfo = $False,
#    [Switch]$GetFileStorageInfo = $False,
#    [Switch]$GetBlockStorageInfo = $False,
#    [Switch]$GetAllInfo,
#    [Switch]$Help





#######################################################################################
#Main
#######################################################################################
$timestamp = get-date -f yyyy-MM-dd_HH.mm.ss
$FileName = $FileName + $timestamp
$currentfolder = Get-Location
$currentfolder = $currentfolder.ToString()
$ExportExcelBol = $ExportExcel.ToBool()
$ExportCsvBol = $ExportCsv.ToBool()
$ShowCredBol = $ShowCred.ToBool()
$StartTime = $(get-date)
#Get screen width for text
$wWidth = (Get-Host).UI.RawUI.MaxWindowSize.Width - 5

Write-Host "Switches Passed during command:" -ForegroundColor Yellow
Write-Host "CurrentFolder": $currentfolder -ForegroundColor Cyan
Write-Host "FileName:" $FileName -ForegroundColor Cyan
Write-Host "ExportExcel:" $ExportExcelBol -ForegroundColor Cyan
Write-Host "ExportCsv:" $ExportCsvBol -ForegroundColor Cyan
Write-Host "ShowCred:" $ShowCredBol -ForegroundColor Cyan

#Check if IBMCloud CLI is installed
If ((Get-command ibmcloud -ErrorAction:SilentlyContinue).count -lt 1) {
    Write-Host -ForegroundColor Red {
        IBMCloud CLI is not installed. Check the link below for installation steps.
        https://cloud.ibm.com/docs/cli?topic=cli-install-ibmcloud-cli 
    }
    #Exit from Script
    exit
}

##### Import ImportExcel Module #####
#Check if ImportExcel Module is installed & If ExportExcel Switch is enabled. If Yes, it will attempt to install locally from Zip file. 
#It will check again, if still not found, it will display warning and give directions to get from Internet & switch ExportExcel to false & ExportCSV to True
If ((Get-Command Export-Excel -ErrorAction:SilentlyContinue).count -lt 1 -AND ($ExportExcelBol) ) {
    
    #If no ImportExcelModulePath is passed during command execution, Set $path for the following
    if (! $ImportExcelModulePath ) {
        $paths = $env:path.split(";"), "$ENV:USERPROFILE\downloads", "C:\temp", "$ENV:USERPROFILE\Desktop", "$ENV:USERPROFILE\Documents", $ENV:USERPROFILE, ".\" | ForEach-Object { $_ }
        $ImportExcelModulePath = Get-ChildItem ImportExcel.zip -Path $paths | select-object -First 1
    }

    # Attempt Install of ImportModule with local zip archive file
    if ( $ImportExcelModulePath | Test-Path  ) {
        InstallImportExcel $ImportExcelModulePath
    }

    #Check again if Export-Excel is present, if present, skip the if statement
    if ((Get-Command Export-Excel -ErrorAction:SilentlyContinue).count -lt 1 ) {
        #print freeform text
        WRITE-HOST -foreground yellow {
            "
            --------------------------------------------------------------------------------------
            To Export Output in Excel, you need the ImportExcel Module that can be downloaded from 
            the Interet by executing the command below: 

            Find-Module -Name ImportExcel | Install-Module -Name ImportExcel;
            
            Set-ExecutionPolicy to Bypass or Unrestricted (requires powershell Administrator mode)
            Set-ExecutionPolicy Bypass -Force

            Powershell TLS Version may not match Microsoft

            See: https://www.powershellgallery.com/packages/ImportExcel/
            --------------------------------------------------------------------------------------
            "
        } #end WRITE-HOST


        WRITE-HOST ("X" * $wWidth) "`nImporting Module: ImportExcel. Press CTRL-C to stop.`n" ("X" * $wWidth)
        $null = Set-PowerCLIConfiguration -ProxyPolicy NoProxy -InvalidCertificateAction Ignore -Confirm:$false -DefaultVIServerMode Multiple -Scope User
        $null = Set-ExecutionPolicy Bypass -Confirm:$false -Force
        Find-Module -Name ImportExcel | Install-Module -Verbose:$True
    }
          
} #endif ImportExcel
     
     
If ((Get-Command Export-Excel -ErrorAction:SilentlyContinue).count -lt 1) {
    #ImportExcel Module missing, export to CSV
    Write-Host "WARNING: ImportExcel Module not present & could not be installed locally or from the Internet." -ForegroundColor DarkMagenta
    Write-Host "WARNING: Switching DataExport to CSV..." -ForegroundColor DarkMagenta
          
    ## ImportExcel not installed
    $ExportExcelBol = $False
    $ExportCsvBol = $True
    Write-Host "ExportExcel:" $ExportExcelBol -ForegroundColor Cyan
    Write-Host "ExportCsv:" $ExportCsvBol -ForegroundColor Cyan          
          
}

#############

if ($GetAccountInfo.ToBool()) {
    Write-Host "Getting Account Info..." -ForegroundColor Yellow
    Get-AccountInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
}

if ($GetVsInfo.ToBool()) {
    Write-Host "Getting VSI Info..." -ForegroundColor Yellow
    Get-VsInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol -ShowCred $ShowCredBol
}

if ($GetHwInfo.ToBool()) {
    Write-Host "Getting Hareware Info..." -ForegroundColor Yellow
    Get-HwInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol -ShowCred $ShowCredBol
}

if ($GetNetworkInfo.ToBool()) {
    Write-Host "Getting Network Info..." -ForegroundColor Yellow
    Get-NetworkInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
}

if ($GetSecurityGroupInfo.ToBool()) {
    Write-Host "Getting SecurityGroup Info..." -ForegroundColor Yellow
    Get-SecurityGroupInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
}

if ($GetFileStorageInfo.ToBool()) {
    Write-Host "Getting File Storage Info..." -ForegroundColor Yellow
    Get-FileStorageInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
}

if ($GetBlockStorageInfo.ToBool()) {
    Write-Host "Getting Block Storage Info..." -ForegroundColor Yellow
    Get-BlockStorageInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
}

if ($GetUsersInfo.ToBool()) {
    Write-Host "Getting Account Users Info..." -ForegroundColor Yellow
    Get-UsersInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
}

if ($GetTagsInfo.ToBool()) {
    Write-Host "Getting Account Tags Info..." -ForegroundColor Yellow
    Get-TagsInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
}

if ($GetAllInfo.ToBool()) {
    
    Write-Host "Getting Account Info..." -ForegroundColor Yellow
    Get-AccountInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol
    
    Write-Host "Getting VSI Info..." -ForegroundColor Yellow
    Get-VsInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol -ShowCred $ShowCredBol

    Write-Host "Getting Hareware Info..." -ForegroundColor Yellow
    Get-HwInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol -ShowCred $ShowCredBol

    Write-Host "Getting Network Info..." -ForegroundColor Yellow
    Get-NetworkInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol

    Write-Host "Getting SecurityGroup Info..." -ForegroundColor Yellow
    Get-SecurityGroupInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol

    Write-Host "Getting File Storage Info..." -ForegroundColor Yellow
    Get-FileStorageInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol

    Write-Host "Getting Block Storage Info..." -ForegroundColor Yellow
    Get-BlockStorageInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol

    Write-Host "Getting Account Users Info..." -ForegroundColor Yellow
    Get-UsersInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol

    Write-Host "Getting Account Tags Info..." -ForegroundColor Yellow
    Get-TagsInfoFunc -fname $FileName -ExportExcel $ExportExcelBol -ExportCsv $ExportCsvBol

    Write-Host "INFO: Script Completed" -ForegroundColor Yellow
    if ($ExportExcelBol) {
        Write-Host "INFO: Data have been exported to Excel File with multiple tabs in folder " $currentfolder -ForegroundColor Yellow
    }
    if ($ExportCsvBol) {
        Write-Host "INFO: Data have been exported to multiple CSV Files in the current folder " $currentfolder -ForegroundColor Yellow
    }

}

$elapsedTime = $(get-date) - $StartTime

$totalTime = "{0:HH:mm:ss}" -f ([datetime]$elapsedTime.Ticks)
Write-host "INFO: Script Execution Time:" $totalTime -ForegroundColor Yellow