<#PSScriptInfo

      .VERSION 0.5

      .GUID 0d04fc80-d661-41f5-b442-22c722726a04

      .AUTHOR Amr Momtaz - amomtaz@ibm.com or amr.momtaz@gmail.com

      .COMPANYNAME IBM

      .COPYRIGHT 2021

      .TAGS ibmcloud

      .LICENSEURI

      .PROJECTURI https://github.ibm.com/cmm-automation-guild-americas/Automation-Assets/tree/master/Powershell/SLGetInfoCli

      .ICONURI

      .EXTERNALMODULEDEPENDENCIES

      .REQUIREDSCRIPTS

      .EXTERNALSCRIPTDEPENDENCIES

      .PRIVATEDATA

      .ReleaseNotes "Added pre-requisits check for ibmcloud cli and Import-Excel module"

#>

# Requires -Module IBMCloudcli
# Install steps for the different OS can be found @ https://cloud.ibm.com/docs/cli?topic=cli-getting-started
# Requires -Module ImportExcel

<#
     .SYNOPSIS
          This powershell Script scraps an IBM Cloud account and collects Classic Infrastructure (SoftLayer) Information related on that account
          - Retrives Account Information
          - Retrieves Users assigned on the account
          - Retrive VSI Information
          - Retrive Baremetal Information      
          - Retrive Network Information (Vlans and Subnets)
          - Retrive Secrutiy Groups Information
          - Retrive File Storage Information
          - Retrive Block Storage Information
          - Retrive Tags Information
          - Optional Switch to retrive VSIs & Baremetals OS & KVM Credenials (-ShowCred)
          - Output can be exported as 
            = Excel output is multi-sheet with everysheet as its own table that can later be used as inputs for other docs via PowerQuery Imports or used in PivotTables/PivotCharts.
            = CSV where each section is its own CSV document
          
     .DESCRIPTION
          Upon execution, this script does the following:
          - Verifies Powershell 5.0 or higher.
          - Check if IBMCloud Cli is installed
          - Imports non-proprietory, open source EXCEL MODULES if required.
          - Retreives Information from Cloud Account
          - Exports invnetory Excel/CSV depending on the switches passed during command execution
          
          UPDATES:
          2021-02-22 Version 0.5
     
     .PARAMETER ExportExcel
          Enabled by default.
          Enables the data colledcted to be exported to Excel documents. The Excel Document name can be passed using the -FileName Switch
          -ExportExcel:$False  #disables
     
    .PARAMETER ExportCsv
          Disabled by default.
          Enables the data colledcted to be exported to CSV documents 

    .PARAMETER FileName
          Filename prefix for Excel & CSV File
          Default set to: SL-Info_Export-
          File is saved in the current working folder that the script is executed from.
    
    .PARAMETER GetAccountInfo
          Get Account Information for Account on IBM Cloud Classic      

    .PARAMETER GetUsersInfo
          Get Users Information for Account on IBM Cloud Classic
     
     .PARAMETER GetVsInfo
          Get Virtual Server Information for Account on IBM Cloud Classic.

     .PARAMETER GetHwInfo
          Get Baremetal/Hardware Information for Account on IBM Cloud Classic.
          
     .PARAMETER GetNetworkInfo
          Get Vlan & Subnet information for Account on IBM Cloud Classic.

     .PARAMETER GetSecurityGroupInfo
          Get Security Group information for Account on IBM Cloud Classic.
    
     .PARAMETER GetFileStorageInfo
          Get FileStorage/NFS Volumes information for Account on IBM Cloud Classic.
     
    .PARAMETER GetBlockStorageInfo
          Get FileStorage/NFS Volumes information for Account on IBM Cloud Classic.
     
    .PARAMETER GetTagsInfo
          Get Resource Tags information for Account on IBM Cloud Classic.

    .PARAMETER GetAllInfo
          Get All Information (All Switches)information for Account on IBM Cloud Classic.

     .PARAMETER ShowCred
          Disabled by default
          Switch to enabled script to collect and display KVM & OS Credentials for the Hw/Baremetal & VSIs
     
     .PARAMETER Help
          Displays help info.
     
     .EXAMPLE
          Get-SLInfo.ps1 -ExportExcel -GetAllInfo -ShowCred
          -- Get all Info and export to excel with default file name SL-Info_Export- Date.
     
     .EXAMPLE
          Get-SLInfo.ps1 -GetVsInfo -ExportExcel
          -- Get VirtualServer Information without showing credentials as the -ShowCred switch is not passed and export data as excel.
        
     .EXAMPLE
          Get-SLInfo.ps1  -GetHwInfo -ExportCsv
          -- Get Hardware/Baremetal Information without showing credentials as the -ShowCred switch is not passed and export data as Csv.
     
     .OUTPUTS
          Excel or CSV files.
          
     .Inputs
     No command line inputs required for export to EXCEL, but parameters are available for convenice for additional optoins.
     
     .Link
     https://github.ibm.com/cmm-automation-guild-americas/Automation-Assets/tree/master/Powershell/SLGetInfoCli
     https://www.powershellgallery.com/packages/ImportExcel/
     https://cloud.ibm.com/docs/cli?topic=cli-getting-started

     .NOTES
          
         RoadMap Items:
          - Modify Get-BlockStorage Function to work like Get-FileStorage Function
          - Power BI for Q&A Type Questions
          - Portal, Dashboard Ideas
            Top 10 Hardware
            Top 10 VSI
            Top 10 FileStorage
            Top 10 BlockStorage



#>
