# Virtual machine management #
A set of PowerCLI/Powershell scripts to handle general tasks like collecting logs, reconfiguring VMs or shutting down VMs.
