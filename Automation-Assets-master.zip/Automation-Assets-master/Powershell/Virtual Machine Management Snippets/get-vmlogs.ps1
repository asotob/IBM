# script is used to pull the vm operational logs from the vCenter's vm storage location for problem analysis. creates a local directory on the hard drive
# of location running the script and dumps the .log text file in a directory named for the vm. 

param (

    [parameter(Mandatory=$true)]
    [string]
    $name,

    [parameter()]
    [string]
    $targetvcenter

)

# This Script export virtual machine logs from a Datastore to local computer.
# Script Author: Haim Cohen 2017
# Version 1.0

$location = get-location
$vm = get-vm $name -server $targetvcenter
$target = New-Item -ItemType Directory -Force -Path .\VM_Logs\$vm
$datastore = get-vm $vm -server $targetvcenter | Get-Datastore
New-PSDrive -Location $datastore -Name ds -PSProvider VimDatastore -Root "\"
Set-Location ds:\
cd $vm
Copy-DatastoreItem -Item vmware.log -Destination $target
set-Location $location
Remove-PSDrive -Name ds -Confirm:$false