# does a controlled shutdown of a target VM and disconnects the network interface

param (

    [parameter(mandatory=$true)]
    [string]
    $file,

    [parameter()]
    [string]
    $sourcevcenter,

    [parameter()]
    [string]
    $server,

    [parameter()]
    [string]
    $fcuser

)

if (!$domaincred){
    write-host "Input name of domain admin account."
    $fcuser = read-host
    write-host ""
    write-host "Input your domain admin password."
    write-host ""
    $fcpasswd = read-host -AsSecureString
    $domaincred = new-object system.management.automation.pscredential($fcuser, $fcpasswd)
   
}
    
        

# if not $targetvcconn, force input for establishing the vCenter IP or name, username and password required for connecting. Setting $vccred = 
# get-credential username@vcenter.local will establish the user credentials for all connections to vCenter. Setting $targetvcconn = connect-viserver

if (!$sourcevcconnold){
    #if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
        if (!$sourcevcenter){
        write-host "input name or IP of source vCenter."
        $sourcevcenter = (read-host)
        write-host ""
            }
        write-host "input name of source vCenter Username in name@domain format."
        $fcuser = (read-host)
        write-host ""
        
        write-host ""
        write-host "input the vCenter password."
        $sourcevcpasswd = (read-host -AsSecureString) 
    
    #$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
        $vCcred = new-object system.management.automation.pscredential ($fcuser, $sourcevcpasswd)
        $sourcevCConn = Connect-VIServer -server $sourcevcenter -Credential $vCcred -port 443
        Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
    
    }

if (!$sourcevcconnew){
#if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
    if (!$sourcevcenter){
    write-host "input name or IP of source vCenter."
    $sourcevcenter = (read-host)
    write-host ""
        }
    write-host "input name of source vCenter Username in name@domain format."
    $fcuser = (read-host)
    write-host ""
        
    write-host ""
    write-host "input the vCenter password."
    $sourcevcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcred = new-object system.management.automation.pscredential ($fcuser, $sourcevcpasswd)
    $sourcevCConn = Connect-VIServer -server $sourcevcenter -Credential $vCcred -port 443
    Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false

}

# input file required for this process, refer to sample template file new-bnsvm-##.csv for example
$servers = import-csv -Delimiter "`," $($file) | where-object {$_.hostname -like $server}


# start the scripted process

foreach ($computer in $servers){
$computername = $computer.hostname

$vm = get-vm $computername -server $sourcevCConn
write-host ""
write-host "Server has been shutdown."
$network = get-vm $vm | get-networkadapter
Set-NetworkAdapter -NetworkAdapter $network -StartConnected:$false -Connected:$false  -confirm:$false -ErrorAction SilentlyContinue | Select-Object parent, NetworkName
Shutdown-VMGuest $vm -server $sourcevCConn -Confirm:$false
start-sleep 10

write-host ""
write-host "$computername has been shutdown and network disconnected."
    #scripts

write-host ""
write-host "Process complete on $computername."


}