# script takes imports a vm from an attached storage device and requires an input file to function. Checks vm after successful import and boot. Useful if
# storage replication is the primary means of migration of a workload. Script will find vm files matching folder name and import the .vmx file. 

param (

    [parameter(mandatory=$true)]
    [string]
    $file,

    [parameter()]
    [string]
    $targetvcenter,

    [parameter()]
    [string]
    $server,

    [parameter()]
    [string]
    $fcuser,

    [parameter()]
    [string]
    $fclocal,

    [parameter()]
    [switch]
    $tests


)

if (!$domaincred){
    write-host "Input name of domain admin account."
    $fcuser = read-host
    write-host ""
    write-host "Input your domain admin password."
    write-host ""
    $fcpasswd = read-host -AsSecureString
    $domaincred = new-object system.management.automation.pscredential($fcuser, $fcpasswd)
   
}
 
if ($fcuser){
write-host ""
write-host "Enter your Fircall domain account's password:"
$domaincred = get-credential $fcuser
}
        

# if not $targetvcconn, force input for establishing the vCenter IP or name, username and password required for connecting. Setting $vccred = 
# get-credential username@vcenter.local will establish the user credentials for all connections to vCenter. Setting $targetvcconn = connect-viserver

if (!$targetvcconn){
#if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
    if (!$targetvcenter){
    write-host "input name or IP of source vCenter."
    $targetvcenter = (read-host)
    write-host ""
        }
    if (!$targetvcusername){
    write-host "input name of source vCenter Username in name@domain format."
    $targetVCUsername = (read-host)
    write-host ""
        }
    write-host ""
    write-host "input the vCenter password."
    $targetvcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcred = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)
    $targetvCConn = Connect-VIServer -server $targetvcenter -Credential $vCcred -port 443
    Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false

}    

#local passwords that exist in environment, for use with the password guessing process
$servers = import-csv -Delimiter "`," $($file) | where-object {$_.hostname -like $server}

#if ($fclocal){
#$localcred = new-object system.management.automation.pscredential($servers.fclocalaccount, $servers.fclocalpasswd)
#}
    $fcpasswd = $servers.fclocalpasswd
    


# start the scripted process

foreach ($computer in $servers){

write-host ""
write-host "Collecting vCenter vLAN, vSAN, folder, and compute cluster objects. This will take a few moments."
write-host ""

# section requires an input file, pulls column headers from file to fill in variables, source vCenter and target vCenter are delineated. 
$vlanbr = get-vdportgroup -name $computer.portgroupbarrie -server $targetvCConn
$clusterBr = get-cluster $computer.computecluster -server $targetvcconn
$wave = $computer.jumpfolder
$sourcedatastorefr = get-datastore $computer.sourcedatastorefront -Server $sourcevcconn
$destinationfr = Get-VMHost $computer.sourceESXIFront -server $sourcevcconn
$jumpdatastorefr = get-datastore $computer.JumpDataStoreFront -server $sourcevCConn
$location = get-folder $computer.jumpfolder -server $sourcevcconn

$targetdatastorebr = get-datastore ("*" + $computer.targetdatastorebarrie) -Server $targetvcconn

$jumpdatastorebr = get-datastore ("*" + $computer.JumpDataStoreBarrie) -server $targetvcconn #-VMHost $computer.TargetESXIBarrie

$location = get-folder $computer.jumpfolder -server $targetvcconn
$computername = $computer.hostname
$vmdir = dir $jumpdatastorebr.DatastoreBrowserPath -filter $computername
$vmxpath = get-childitem $vmdir -recurse | where-object {$_.name -like $vmdir.name + ".vmx"}

#create new vm
write-host ""
write-host "A new vm with name $computername will now be created on $($computer.jumpdatastoreBarrie) datastore running on $($computer.TargetESXIBarrie)."
if (!$tests){
new-vm -name $computername -resourcepool $clusterbr -location $location -server $targetvcconn -VMFilePath $vmxpath.datastorefullpath `
 -description $computer.TargetESXIBarrie -HARestartPriority $computer.HARestartPriority -VMHost ($computer.TargetESXIBarrie + ".bns.bns")
start-sleep 20 
}
$vm = get-vm $computername -server $targetvcconn
write-host ""
write-host "Server $computername has been added to $targetesxibarrie."
$vm   
start-sleep 10
if (!$tests){
write-host ""
write-host "Networking will now be changed to $($computer.portgroupbarrie) and network adapter connected."
$network = get-vm $vm | get-networkadapter
Set-NetworkAdapter -NetworkAdapter $network -portgroup $vlanbr -confirm:$false -ErrorAction SilentlyContinue | Select-Object parent, NetworkName
Set-NetworkAdapter -NetworkAdapter $network -StartConnected:$true -Confirm:$false -ErrorAction SilentlyContinue | out-null
#set-vm $computername -memorygb $computer.memorygb -numcpu $computer.numcpu -Confirm:$false  | Select-Object guest, memorygb, numcpu
#get-HardDisk $computername | set-harddisk -CapacityGB $computer.diskgb -Confirm:$false  | Select-Object parent, name, CapacityGB
start-sleep 10

write-host ""
write-host "$computername will now storage vMotion to $($computer.targetdatastorebarrie)."
move-vm $vm -Datastore $computer.targetdatastorebarrie -Confirm:$false -Location $computer.targetfolder
write-host ""
write-host "Please wait to until the storage vMotion has completed for $computername."


write-host ""
write-host "$computername will now be booted up."
start-vm $vm -confirm:$false -server $targetvcconn  -ErrorAction SilentlyContinue | Select-Object name, powerstate

start-sleep 70
}
    if ($vm.guest -like "*Windows *"){
    try {
    $running = get-vmguest -vm $computername -ErrorAction stop -server $targetvcconn | where {$_.state -like "running"}
        }

    catch {
    write-host "$($computer.hostname) vmtools not running."
    write-host "$($computer.hostname) another 30 second wait for tools to start."
    
    start-sleep 30
    $running = get-vmguest -vm $computername -ErrorAction stop -server $targetvcconn | where {$_.state -like "running"}

        }
    
    $current = get-vmguest $computername -Server $targetvcconn | Where-Object {$_.state -like "running" -and $_.ToolsVersion -like "10.3.*"}

    if (!$current){
    
    Update-Tools -VM $computername -Server $targetvcconn -ErrorVariable noupdate -NoReboot:$true

    if (!$noupdate){
    write-host ""
    write-host "VMtools updating, no reboot set."

    start-sleep 50
        }
    else { 
        write-host ""
        write-host "A pause will be initiated so that the vmware tools can be manually installed."
        pause
    }
    }
}
$evidencedir = $wave -replace (' ', '')
$evidencepath = ".\wavefiles\($evidencedir)_evidencefiles\"


    if ($vm.guest -like "*Windows *"){
    # command list for each invoke-vmscript commands

    # sets the IP configuration IP, mask, GW, and DNS for selected server and requires an input file with the column headings of ip-address, dns1, dns2
    # default gateway and subnet mask
    $getnetip = $computer."ip-address"

    # commands to display needed information on the screen
    $getid = 'netsh interface ipv4 show interfaces'
    $checkIP = 'ipconfig /all'
    $date = 'date'
    $nettest = 'ping TOCBVCTR1PV.bns.bns /n 1
    ping TOCGVCTR1PV.bns.bns /n 1
    ping tocfvctr1pv.bns.bns'
    
    # simple command to test use of domain credentials to execute command
    $testdomain = 'hostname'

    $setEULA = 'reg.exe ADD HKCU\Software\Sysinternals /v EulaAccepted /t REG_DWORD /d 1 /f
    reg.exe ADD HKCU\DEFAULT\Software\Sysinternals /v EulaAccepted /t REG_DWORD /d 1 /f'

    $runbatch = 'c:\temp\"source script.bat"'
    $renamereport = "move c:\temp\$evidencedir c:\temp\post-migration-$evidencedir
    remove-item -path 'c:\temp\source script.bat'"
    $checkIP = 'ipconfig /all'
    $nettest = 'ping TOCBVCTR1PV.bns.bns /n 1
    ping TOCGVCTR1PV.bns.bns /n 1'
    # test for successful network swing
    $checkipres = 'nslookup google.com'
    $moveevidence = "move c:\temp\post-migration-$evidencedir c:\temp\to_delete_after_move\"
    $evidence2003 = "systeminfo.exe >> c:\temp\postmigration_($computername).txt"
    $mcaffeeupdate = '"c:\Program Files (x86)\McAfee\VirusScan Enterprise\mcupdate.exe" /update'
    $mcaffeecheck = '"C:\Program Files (x86)\common files\mcaffee\csscan.exe" -versions'
    $tivolibackup = 'cd "C:\Program Files\Tivoli\TSM\baclient\"
    .\dsmc archive c:\ibm\tsm'

    write-host ""
    # test domain join with execution of command using $domaincred variable information
    write-host "$($computer.name) will now be tested for domain logon."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $testdomain -GuestCredential $domaincred -Server $targetvcconn -ErrorVariable errordomain

    if ($errordomain){
    write-host ""
    write-host "error with domain logon test, vm cannot see domain controller. Verify networking is correct."
    Invoke-VMScript -vm $computername -ScriptText $checkip -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn 
    }

    
    if ($vm.Guestid -notlike '*2003*'){
    # prep to run the pre-migration check on vm

    write-host ""
    write-host "Copying source script.bat, du.exe to $computername"
    Copy-VMGuestFile -vm $computername -source "./DU/du.exe" -LocalToGuest -GuestUser $fclocal -GuestPassword $fcpasswd -Destination "c:\temp\bin\" -force -ErrorAction stop -Server $targetvCConn
    Copy-VMGuestFile -vm $computername -source "./source script.bat" -LocalToGuest -GuestUser $fclocal -GuestPassword $fcpasswd -Destination c:\temp -force -ErrorAction stop -server $targetvCConn

    # execute the source script.bat report and rename folder to post-migration and copy report folders to local machine
    write-host ""
    write-host "Run the c:\temp\source script.bat and renaming directory."
    Invoke-VMScript -vm $computername -ScriptText $setEULA -Server $targetvcconn -GuestUser $fclocal -GuestPassword $fcpasswd -ErrorAction stop -ScriptType bat
    invoke-vmscript -vm $computername -ScriptText $runbatch -Server $targetvcconn -ScriptType bat -GuestUser $fclocal -GuestPassword $fcpasswd 
    invoke-vmscript -vm $computername -ScriptText $renamereport -Server $targetvcconn  -GuestUser $fclocal -GuestPassword $fcpasswd -ScriptType powershell
    write-host ""
    write-host "copying evidence files to jump server directory c:\ibm\cmf\wavefiles"
    Copy-VMGuestFile -vm $computername -source c:\temp\post-migration-$evidencedir\ -GuestUser $fclocal -GuestPassword $fcpasswd -GuestToLocal -destination $evidencepath\$coputername -force -server $targetvcconn 
    Invoke-VMScript -vm $computername -ScriptText $moveevidence -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn
    }
    else {
    #run evidence gathering on 2003 servers
    write-host ""
    write-host "Running evidence gathering on $computername"
    invoke-vmscript -vm $computername -ScriptText $evidence2003 -GuestUser $fclocal -GuestPassword $fcpasswd -ScriptType bat -server $targetvcconn
    Copy-VMGuestFile -vm $computername -source c:\temp\($computername)_migration.txt -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn -GuestToLocal -Destination $evidencepath\$computername -force
    invoke-vmscript -vm $computername -ScriptText "del c:\temp\postmigration_($computername).txt" -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn -ScriptType bat   
    }
        

    # test for successful network swing
    $checkipres = "nslookup google.com"


    # commands to set then verify timezone change
    $timezone = "TZUTIL /s 'Eastern Standard Time'"
    $timezoneck = "TZUTIL /g"

    write-host ""
    write-host "A series of checks will now be run to verify IP communication, address, domain logon test, and Timezone."
    # display the changes to the screen
    write-host "Checking IP settings, should be IP $($computer.'IP-address')."
    Invoke-VMScript -vm $computername -ScriptText $checkip -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvCConn
    start-sleep 10
    
    #run a check on resolving google.com
    write-host ""
    write-host "Testing IP resolution."
    invoke-vmscript -ScriptText $checkipres -vm $computername -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn -ScriptType Powershell
    write-host ""
    start-sleep 10

    # test communications to Front Street, Gough, Barrie hosts
    write-host ""
    write-host "Testing routing to Front Street, Gough, and Barrie DC."
    invoke-vmscript -ScriptText $nettest -vm $computername -GuestUser $fclocal -GuestPassword $fcpasswd  -server $targetvcconn -ScriptType Powershell
    start-sleep 10

    write-host ""
    write-host "Updating McAffee Virus scanner, will display current settings then run update"
    Invoke-VMScript -ScriptText $mcaffeecheck -vm $computername -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn -ScriptType bat
    Invoke-VMScript -ScriptText $mcaffeeupdate -vm $computername -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn -ScriptType bat
    write-host ""
    write-host "Another check will be run to confirm update."
    Invoke-VMScript -ScriptText $mcaffeecheck -vm $computername -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn -ScriptType bat
    start-sleep 10

    write-host ""
    write-host "A Tivoli backup will be tested on $computername of the c:\ibm\tsm directory."
    Invoke-VMScript -ScriptText $tivolibackup -vm $computername -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn -ScriptType bat

    # test date/time settings
    write-host ""
    write-host "Checking current date/time on vm."
    Invoke-VMScript -ScriptText $date -vm $computername -GuestUser $fclocal -GuestPassword $fcpasswd -server $targetvcconn
    start-sleep 10


    # set different command set for OS version, one for 2008R2 and one for 2012R2. 
    if ($vm.guest -like "*2012*"){
    write-host "Timezone to be set to Eastern Standard time."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $timezone -GuestUser $fclocal -GuestPassword $fcpasswd -Server $targetvcconn 
    write-host "Time zone will be verified."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $timezoneck -GuestUser $fclocal -GuestPassword $fcpasswd -Server $targetvcconn 
        }
    
    #scripts

    write-host ""
    write-host "Testing complete on $computername."
    
    if (!$tests){
    $sourcevm = get-vm $computername -server $sourcevcconn
    $renamevm = $($sourcevm.name + " - migrated to Barrie")
    write-host ""
    write-host "VM on $sourcevcconn will now be renamed and vMotioned to original $sourcedatastorefr"
    #move-vm $sourcevm.name -Datastore $computer.sourcedatastorefr -Confirm:$false  -ErrorAction SilentlyContinue -RunAsync | Select-Object name, folder
    set-vm -vm $sourcevm.name -server $sourcevcconn -name $renamevm -Confirm:$false
    }

        }
else {
        $ramcpu = $vm | Select-Object numcpu, corespersocket, memorygb
        write-host ""
        $ramcpu
        $vlanbr | Select-Object Name
        write-host ""
        write-host "target VLAN information"
        $vlanbr
        write-host ""
        $ipdisks = Get-vmguest $computername 
        $harddisks = $ipdisks | select -ExpandProperty disks | out-string
        write-host ""
        write-host "Hard disk information"
        $harddisks | Out-String
        $ipadd = $ipdisks | Select-Object -ExpandProperty ipaddress | out-string
        write-host ""
        write-host "IP address"
        $ipadd 
        write-host ""
        write-host "Source datastore information"
        $targetdatastorebr | select name, CapacityGB
        write-host ""
        write-host "Jump datastore information"
        $jumpdatastorebr | select name, CapacityGB
    
        $checkIP = 'ipconfig /all'
        $testlocal = 'hostname'
    
        $snapshot = get-snapshot $computername
        if ($snapshot){
            write-host ""
            write-host "Snapshot detected."
        }
        else {write-host ""
        write-host "No snapshots detected"}
        
        write-host ""
    
        $report = New-Object psobject -Property @{
            "hostname" = $computername
            "targetdatastore" = $targetdatastorebr.name
            "targetVLAN" = $vlanbr.name
            "Ipaddress" = $ipadd
            "RAM" = $ramcpu.memorygb
            "CPU" = $ramcpu.numcpu
            "Cores" = $ramcpu.corespersocket
    
        } | Select-Object hostname, ram, cpu, cores, ipaddress, targetvlan, targetdatastore
    
        $testpath = test-path "$evidenepath\$evidencedir"
        if (!$testpath){
        mkdir .\wavefiles\$evidencedir
        }
        $report | export-csv -Delimiter "`," .\wavefiles\$evidencedir\postmigration_evidence.csv -NoTypeInformation -force -append
        
    
        $diskreport = New-Object psobject -property @{
            "hostname" = $computername
            "localstorage" = $harddisks | out-string
        } | Select-Object hostname, localstorage
        $diskreport | export-csv -Delimiter "`," .\wavefiles\$evidencedir\postmigration_storage.csv -NoTypeInformation -force -append
        continue
    }
    

if ($errordomain){
write-host ""
write-host "Something went wrong with the domain logon test, you may need to investigate this further on the vm with local firecall ID."}
}
