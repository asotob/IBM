<#PSScriptInfo

.VERSION 2.0

.GUID 18745d5b-8102-4448-bd43-09254ec2b367

.AUTHOR Mark McInturff mark.mcinturff@ibm.com mmcint@gmail.com

.COMPANYNAME IBM

.COPYRIGHT

.TAGS

.LICENSEURI

.PROJECTURI https://github.ibm.com/cmm-automation-guild-americas/Automation-Assets/tree/master/Powershell/NewLinkedClone

.ICONURI

.EXTERNALMODULEDEPENDENCIES 

.REQUIREDSCRIPTS

.EXTERNALSCRIPTDEPENDENCIES

.RELEASENOTES
See -help

.PRIVATEDATA

#>

#Requires -Module VMware.VimAutomation.Core, VMware.VimAutomation.Common

<#
     .SYNOPSIS
       Author: Mark.Mcinturff@ibm.com mmcint@gmail.com
       

    .DESCRIPTION
      Creates Instant Linked Clone of Specified VM by assuming all the properties of the Source VM for the Destination VM. All parmeters optional except VM and Source_VM_Templ_or_Snap. 
      This is much faster than 
        Cloning 
        vSphere Client Clone
        Web Client Clone

      Does not prompt you for cpu, memory, disk Size, vhardware version, folder/location, storage, network, vswitch, datacenter, cluster, and host

      Once a linked clone is created, Storage Vmotion of the VM creates an unlinked copy of the clone and the source snapshot is no longer referenced.


     .PARAMETER TargetVmName
          Name of NEW VM linked clone. Autocreated when not present
     
     .PARAMETER Source_VM_Templ_or_Snap
          The only Mandatory paramter.
          May be a VM, Template, or Snapshot. This script will create a Snapshot of the current state for cloning. The Snapshot is what the Vm 
          
     .Parameter UseLastSnapshot
     Use Existing snapshot, otherwise new snapshot is created at runtime.
     
     .PARAMETER NumCPU
      Inherits Source when not specified.
      
      .PARAMETER MemoryGB
      Inherits Source when not specified.
      
      .PARAMETER vHardware
      Inherits Source when not specified.
      
      .PARAMETER vHardware
      Inherits Source when not specified.
      
      .PARAMETER OsCustomizationSpec
      Unused if not specificifed. Customization Spec is use to change properties of the OS. 
      
      .PARAMETER Datastore
      Inherits Source when not specified.
      
      .PARAMETER PowerON
      Switch to PowerON Cloned VM after creation. Default is PoweredOFF.
      
      .PARAMETER Whatif
      Simulates running of this script but performs no action. VM Snapshot is created if not exists.
      
      .PARAMETER RunAsync
      Runs Clone job as a Task completing script without waiting for clone-task completion.
      
      .PARAMETER Verbose
      Provides detailed output of Script.
     
      .Example
      Minimal Parameters
      NewLinkedClone.ps1 -TargetVmName -Source_VM_Templ_or_Snap MyVM
      
      .Example
      
      NewLinkedClone.ps1 -TargetVmName myvm000 -Source_VM_Templ_or_Snap myvm
      #### output ####
      
                   VM: win10-bfs-CLONE 2021-01-28 17:31
             SourceVM: Win10-BFS [VirtualMachineImpl]
             Snapshot: 2021-01-28Linked Clone Snapshot (01/28/2021 17:50:25)
               VMhost: bm3.priv
            Datastore: vmfs1fc1
  OsCustomizationSpec:
                  Cpu: 2
             MemoryGB: 4
             UserName: cornpop@vsphere.local
    
      Name    PowerState Num CPUs MemoryGB
      ----    ---------- -------- --------
      myvm000 PoweredOff 1        0.098
      
      
   .Example
   ### Exmaple using Cpu and Memory paramters
   NewLinkedClone.ps1 -TargetVmName myvm003 -Source_VM_Templ_or_Snap myvm -NumCPU 4 -MemoryGB 8
   
          VM: myvm003
    SourceVM: MyVM [VirtualMachineImpl]
    Snapshot: 2020-09-25Linked Clone Snapshot (09/25/2020 01:08:42)
      VMhost: baremetal02.priv
   Datastore: nfs1
        Spec:
     Cpu/Mem: 4x8
    UserName: mark
   VERBOSE: Creates a new virtual machine with the specified parameters.
   VERBOSE: 12/10/2020 11:08:38 AM New-VM Finished execution
   
   Name                 PowerState Num CPUs MemoryGB
   ----                 ---------- -------- --------
   myvm003              PoweredOff 4        8.000
   
   

#>


#begin
#{
   param(

        #[Parameter(Mandatory=$true)]
        $Source_VM_Templ_or_Snap,
        $TargetVmName,
        [switch]$UseLastSnapshot,
        [int]$NumCPU,
        [single]$MemoryGB,
        [switch]$vHardware,
        [switch]$OSCustomizationSpec,
        $Datastore,
        [Switch]$PowerOn ,
        [Switch]$WhatIf = $False,
        [Switch]$Verbose = $False,
        [Switch]$Help,
        [Switch]$RunAsync
   )


   if ($Help ) {
     HELP $MyInvocation.MyCommand.Name -Detail
     exit 
   }
   
   if (-not $DefaultVIServers)
   {
      Write-Host -Foreground:White -Back:Red  " ViServerConnectionException: You are not currently connected to any vCenter or ESXi servers."
      exit
   }

   $Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
#}

#Process 
#{
   Function WriteError {
        param($Msg)
        write-host -Foreg White -Backg DarkGreen "[" (Get-Date) "]" $Msg"
   "
   }

   #load Snappins/Modules
   #Get-PSSnapin VMware* | Add-PSSnapin -ErrorAction SilentlyContinue


   #Verify the the Source_VM_Templ_or_Snap 
   if ( $Source_VM_Templ_or_Snap ) {

        #Check first if $Snapshot
        If ( $Source_VM_Templ_or_Snap.GetType().Name -eq "SnapshotImpl" ) {

              $VM_Source = $Source_VM_Templ_or_Snap.VM
              $Snapshot_Source = $Source_VM_Templ_or_Snap

        }else{
             #if not $snapshot, check for Vm or template

             #Get VM/Template Inventory
             $VM_Source = Get-Inventory "$Source_VM_Templ_or_Snap" -ErrorAction SilentlyContinue | ? { $_.ID -match "VirtualMachine" }

             ## Check if Get-Inventory returned result
             if (!($VM_Source )){

                  WriteError "-Source_VM_Templ_or_Snap $Source_VM_Templ_or_Snap doesn't exist. "
                  Exit

             }elseIf ( ( $VM_Source ).Count -gt 1 ) 
             {

                  write-host -Foregr White -Backgr Blue "More than 1 Source_VM_Templ_or_Snap exists. Choose VirtualMachine:"
         
                  $i = 1; $choice = 0;
                  $VM_Source.Name | % { "  " + $i++ + ") " + $_  } ;

                  do #choice 
                  {
                     $choice = [int]$(Read-Host " Type number")
                  } Until ( $choice.GetType().name -match "int" -AND ($choice -GT 0 -AND $choice -lt $i  ) )

                  $VM_Source = $VM_Source[$choice -1 ]
             }
             
             
             ############ Begin Check SourceName
                #Check if -TargetVmName Supplied
                If (!($TargetVmName)){
                   $srcname = $Source_VM_Templ_or_Snap
                    
                   if ($srcname -match "\*") 
                   { 
                     $srcname = $VM_Source.name
                   }

                   $TargetVmName = $srcname + "-CLONE " + (get-date -Format "yyyy-MM-dd HH:ss")
                   #WriteError "-TargetVmName and -Source_VM_Templ_or_Snap required."
             
                }
             
                #Check if new -TargetVmName exists.
                if ( 
                     #Get-View is the fastest with -Property option and -Filter
                     Get-View -ViewType VirtualMachine -Property Name -Filter @{Name = "$TargetVmName" } | ? { $_.Name -eq $TargetVmName } 
                     ) {
             
                     WriteError "VM exists: $TargetVmName"
                     Exit
                }

             ############ END Check SourceName

             ## Assign the VM Variable and convert Template to VM for Linked Clone
             $VM = $VM_Source  

             If   ( $VM_Source.GetType().Name -match "Template" ){

                  $VM = $VM_Source | Set-Template -ToVM -Confirm:0 -ErrorAction Stop

             }
        }


        if (!($Snapshot_Source)) { 

                  $Snapshot_Source = Get-VM $VM | Get-Snapshot | Select -Last 1
             }

   }

        if ( -NOT $Snapshot_Source -OR  -NOT $UseLastSnapshot ) {

             #WriteError "Creating Instant Snapshot"
             
             $Snapshot_Source = $VM | New-Snapshot -Name ((get-date).tostring("yyyy-MM-dd") + "Linked Clone Snapshot") -Description "This snapshot created to clone by $($MyInvocation.MyCommand.Name)script." -ErrorAction Stop -Verbose:$Verbose
             #Work Around next 2 lines
             IF (!($Snapshot_Source)){
                  Start-Sleep 2
                  $Snapshot_Source = $VM | Get-Snapshot | Select -L 1 
             }

             $SnapshotToRemove = $Snapshot_Source 

        }else{

             $VM = $Snapshot_Source.VM

        }


   if (!($Datastore)){
        $Datastore = Get-datastore -ID $VM.DatastoreIdList 
        #Next line required because streaming Get-view to Select sometimes fails
        $Datastore = $Datastore | Select -f 1
   }




   #changed 
   #$VMhost = $VM.VMhost
   $VMhost = $VM.VMhost

   if ($OSCustomizationSpec){

        $spec = Get-OSCustomizationSpec $OSCustomizationSpec  -ErrorAction SilentlyContinue 

        if ( -Not $spec )
        {
             write-host -Foregr White -Backgr Blue  "No OsCusomization spec '$OSCustomizationSpec' exists. Choose OSCustomizationSpec:"

            #show numbered vCenter Connection List
            $i = 1; $choice = 0;
            
            $spec = (Get-OSCustomizationSpec | Sort Name )

            #Number output
            $spec.Name | % { "  " + $i++ + ") " + $_  } ;
            
            do #choice 
            {
               $choice = [int]$(Read-Host " Type number")
            } Until ( $choice.GetType().name -match "int" -AND ($choice -GT 0 -AND $choice -lt $i  ) )
            
            $spec = $spec[$choice -1 ]
        }
   }

   #Assign CPU
   if (! $NumCPU){ $NumCPU = $VM.NumCPU }
   if (! $MemoryGB ){ $MemoryGB = $VM.MemoryGB }


   #Assign Variables
   ### Assign Description
   $Description = "
                   VM: $TargetVmName 
             SourceVM: $VM [" + $VM.GetType().Name + "]
             Snapshot: $Snapshot_Source (" + $Snapshot_Source.Created + ")
               VMhost: $VMhost 
            Datastore: $Datastore
  OsCustomizationSpec: $Spec
                  Cpu: $NumCPU 
             MemoryGB: $MemoryGB
             UserName: " + [Environment]::UserName 

   ##Print Description
   Write-host  -Background DarkGreen $Description 
   $Description = $Description -replace "\n\s+"


   ### LinkClones require VM's with Snapshots... Just an FYI
   $NewVM = New-Vm -LINKEDCLONE -VM $VM -ReferenceSnapshot $Snapshot_Source  -Name $TargetVmName -VMHost $VMhost -Datastore $Datastore -Location $VM.Folder  -Confirm:0  -ResourcePool $VM.ResourcePool -WhatIf:$WhatIf  -Verbose:$Verbose -ErrorAction Stop

   if ($SnapshotToRemove ){
        #The SNapshot is needed for linked clones
        ###$SnapshotToRemove | Remove-Snapshot  -Confirm:0 -RunAsync  -Verbose:$Verbose | out-null

   }

   if ($Vm_Source.GetType().Name -Match "Template" ){
        WriteError "$VM converting back to template."
        $VM | Set-VM -ToTemplate -Confirm:0 -RunAsync -Verbose:$Verbose | Out-Null
   }


   ### Stop the Script if WHATIF
   if ($WhatIf ){
        writeError "-WhatIf End" #Nothing else to see
        exit
   }


   if (!($NewVM ) ){

        WriteError "Aborting: " $Error[0]

        If ($Error[0] -match "Operation is not valid due to the current state of the object"){
             WriteError "This error usually means your Powershell session is corrupt and needs to be closed and restarted."
        }

        exit
   }


   if ($Spec){ 

        WriteError "Applying OsCustomizationSpec $Spec"
        $NewVM | Set-VM -OSCustomizationSpec $Spec -Confirm:0 -Verbose:$Verbose | Out-Null


   }

   if ( $vHardware ){
        $NewVM | Set-VM -Version v10 -Confirm:0 -RunAsync:0 | Out-Null
   }


   $NewVM | Set-VM -NumCPU $NumCPU -MemoryGB $MemoryGB -Description $Description -Confirm:$False  -RunAsync:$RunAsync | Out-Null
   $NewVM | Get-NetworkAdapter | Set-NetworkAdapter -StartConnected:$False -Confirm:0  -RunAsync:$RunAsync | Out-null
   #Get-VM $NewVM | Select Name, Powerstate, NumCPU, MemoryGB, @{N="SrcVM" ; E={$VM_Source}}

   if ($PowerOn ){ 
        $NewVM | Start-VM  
   }

#}

write-verbose "$($Stopwatch.Elapsed.TotalSeconds) Elapsed Seconds"
#End {}