﻿#script for disjoinging and rejoining domains using invoke-vmscript Powercli commandlet. 
#script will also guess passwords if environment contains numerous local admin passwords.
#the -nic switch will run a process to swap out e1000 network adapters for the vmxnet3, e1000
#being the default for Hyper-V VMs. 
#other tasks peformed are vmware tools version checks, tools running, update of tools if older
#versions, local admin password changes, and domain join testing.

# parameters assume some of the following: input files are in use, one for isolation networks and one
# for production, usernames for vCenter and domain account being given per script run, a wave designator
# to ensure the right server is being targeted, and means to bypass the password guessing for local admin
# accounts by specifying the user and the password on the command line and finally a test parameter to use
# a separate input file for test vms that can be moved through the process in the live environment. 

param (
    [parameter(Mandatory=$true)]
    [string]
    $server,

    [parameter()]
    [string]
    $wave,

    [parameter()]
    [switch]
    $iso,

    [parameter()]
    [switch]
    $prd,

    [parameter()]
    [string]
    $targetvcusername,

    [parameter()]
    [string]
    $targetvcenter,

    [parameter()]
    [string]
    $targetvcpasswd,

    [parameter()]
    [switch]
    $test,

    [parameter()]
    [switch]
    $nic,

    [parameter()]
    [string]
    $userO,

    [parameter()]
    [string]
    $passwordO


    )

#set path for input files, if not -test, then use the root of the script directory to find the input files
if (!$test){
    $path = ".\"
}
else {
    $path = ".\input\"
}
# if -iso or -prd used, substitute the correct name for the input file required.
if ($iso -or $prd){
#verify path/name
try {
$errorcsv = get-content "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -ErrorAction Stop
    }
#if $errorcsv = False, notify user of need to re-input path/file of csv
catch {
write-host "incorrect path or file name."
write-host "input path and filename of csv file."
write-host ""
$file = read-host
$servers = import-csv -Delimiter "`," -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" | Where-Object {$_.hostname -like "$server" -and $_.wave -like $wave}
    }

#if $errorcsv test = true, import csv file. 
if ($errorcsv){
$servers = import-csv -Delimiter "`," -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" | Where-Object {$_.hostname -like "$server" -and $_.wave -like $wave}
if ($server -like "*,*"){
    $multi = $server -split (",")
    foreach ($vm in $multi){
        $numerous = @()
        $servers = import-csv -Delimiter "`," -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" | Where-Object {$_.hostname -like "$vm" -and $_.wave -like $wave}
        
    }
}    
    }
}

# if not -domaincred, then take input for the username and password before continuing. Use $domaincred = get-credential ****@domain.com to establish
# credentials for domain joining and domain logon testing.
if (!$domaincred){
write-host "Input name of domain admin account."
$userD = read-host
write-host ""
write-host "Input your domain admin password."
$passwordD = read-host -AsSecureString
$domaincred = new-object system.management.automation.pscredential($userD, $passwordD)

    }

# if not $targetvcconn, force input for establishing the vCenter IP or name, username and password required for connecting. Setting $vccred = 
# get-credential username@vcenter.local will establish the user credentials for all connections to vCenter. Setting $targetvcconn = connect-viserver
# -server IPaddress -credential $vccred will bypass this step and set the current vCenter connection in memory.
if (!$targetvcconn){
#if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
    if (!$targetvcenter){
    write-host "input name or IP of source vCenter."
    $targetvcenter = (read-host)
    write-host ""
        }
    if (!$targetvcusername){
    write-host "input name of source vCenter Username in name@domain format."
    $targetVCUsername = (read-host)
    write-host ""
        }
    write-host ""
    write-host "input the vCenter password."
    $targetvcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcred = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)

}

#get source vCenter, if not already set, set the variable $targetvcconn
    if (!$targetvCConn){
$targetvCConn = Connect-VIServer -server $targetvcenter -Credential $vCcred -port 443

# if not already set, establish the bypass for ignoring the unverified server certificate or that workstation does not have a certificate
# that matches what is set in vcenter. 
Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
    }
    # if $targetvcconn is set, connect to vCenter.
    else {connect-viserver -server $targetvcenter -session $targetvcconn.sessionid }

#local passwords that exist in environment, for use with the password guessing process
$wincred1 = 'Allyourbasearebelongtous....'
$wincred2 = 'Letmein2'
$wincred3 = 'g0T!gersg0'
$wincred4 = 'P@ssw0rd!'
$localpass = '9s4&**#rpT=M'


# start the scripted process
write-host ""
foreach ($computer in $servers){
    #reset test variables
    $testadmin1 = $null
    $testadmin2 = $null
    $testadmin3 = $null
    $testadmin4 = $null
    $testadmin5 = $null

#test domain account credentials file, if not present halt the script.
    try {
        $credck = get-content .\creds.txt -ErrorAction stop
    }
    catch {
        write-host "Credentials file not found, script requires a file called creds.txt with the domain account password only."
        write-host ""
        write-host "Please create a file in the root of the directory where the script is executed."
        break
    }

    $adpater = $null

    # if -usero switch is not used, attempt to set known local admin accounts per domain (if different). 
    if (!$usero){
    $userO = $(if ($computer."domain name" -like 'extapp.local') {'extrootacct'} else {'administrator'})
        }
    
    # reset the testadmin
    $testadmin = $null
    $computername = -join($computer.hostname + "-*ssign*")
    $testdomain = 'hostname'
    if ($passwordo -and $usero){
        $passwordo = $passwordo
    try {
        Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $passwordO -vm $computername -Server $targetvcconn -ErrorAction stop | Select-Object -ExpandProperty scriptoutput
    }
    catch {
        write-host "Admin account or password incorrect."
        break
    }
        }
    try {
    $vm = get-vm $computername -Server $targetvcconn -ErrorAction stop
    }
    catch {
    $vm = get-vm $server -server $targetvcconn
    $computername = $vm
    }
    $toolsver = $vm | get-vmguest
    $running = $toolsver | where {$_.state -like "running"}
    
        
    Write-host "$($computer.hostname) will be checked for VM tools version."
    write-host ""

    # pull adapter information, used for checking if the e1000 adapter is present or not
    $adapter = get-vm $computername -Server $targetvcconn  | Get-networkadapter 
    if ($adatper.type -like "E100*"){
        write-host ""
        write-host "E1000 network adapter detected. Process halting. Run script with the -nic switch to remediate."
        break
    }

    # check vmtools version and if in running state. if not in running state halt script. Script requires vmtools to be installed and running.
    $current = get-vmguest $computername -Server $targetvcconn | where {$_.state -like "running" -and $_.ToolsVersion -like "10.1.*"}

    if (!$running){
        write-host "Tools not running on $($computer.hostname). Process halting."
        break
    }

# is server powered on?
if ($running -and !$current){
    write-host "Updating VMtools version."
    $cdcheck = Get-CDDrive $computername -Server $targetvcconn

    # if vm does not have a CD/DVD device installed, shut down VM and set device, halt script. 
    if (!$cdcheck){
        Shutdown-VMGuest -vm $computername -Server $targetvcconn -confirm:$false
        start-sleep 90
        get-vm $computername | new-CDDrive -confirm:$false -StartConnected:$true
        start-sleep 5
        write-host ""
        write-host "Starting $($computername) after CDDrive addition."
        start-vm -vm $computername -Server $targetvcconn
        start-sleep 90
        write-host "$($computer.hostname) cd device installed, will need manual install of tools."
        break
    }
    # if running but not correct version, update tools with no reboot
    write-host "Tools version out of date, updating version."

    Update-Tools -VM $computername -Server $targetvcconn -ErrorAction SilentlyContinue -NoReboot:$false
    write-host ""
    start-sleep 50
    Restart-VMGuest $computername -Server $targetvcconn -confirm:$false 
    start-sleep 40
    }

    else {write-host "$($computer.hostname) version up to date."}

# reboot VM to start fresh and avoid any vmtools client issues at start.
    if ($current){
    write-host "$($computer.hostname) will be rebooted before start of process."
    get-vm $computername -Server $targetvcconn | Restart-VMGuest -Confirm:$false
    start-sleep 50
        }

# Begin process for establishing local admin password for the particular system this script is running on. 
    write-host "Determining local admin password for logon."
    write-host ""

    # if not -passwordo, then run each command in turn. Process of elimination, once found universal variables of $passwordo and $usero are set for each 
    # subsequent command.
        if (!$passwordo) {
        $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred1 -vm $computername -ErrorAction SilentlyContinue | Select-Object -ExpandProperty scriptoutput
         if ($testadmin1){
            $passwordO = $wincred1
            write-host ""
            write-host "$usero and $wincred1 in use"
           
        }

         $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred2 -vm $computername -server $Targetvcconn -ErrorAction silentlyContinue | Select-Object -ExpandProperty scriptoutput
         if ($testadmin2){
            $passwordO = $wincred2
            write-host ""
            write-host "$usero and $wincred2 in use"
            
        }

         $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred3 -vm $computername -ErrorAction silentlyContinue | Select-Object -ExpandProperty scriptoutput
         if ($testadmin3){
            $passwordO = $wincred3
            write-host ""
            write-host "$usero and $wincred3 in use"
            
        }

         $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred4 -vm $computername -ErrorAction silentlyContinue | Select-Object -ExpandProperty scriptoutput
         if ($testadmin4) {
            $passwordO = $wincred4
            write-host ""
            write-host "$usero and $wincred4 in use"
            
        }

         $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $localpass -vm $computername -ErrorAction SilentlyContinue | Select-Object -ExpandProperty scriptoutput

        if ($testadmin5) {
           $passwordO = $localpass
           write-host ""
           write-host "$usero and $localpass in use"
           
        }

# If all of the above fail, use the following sequence to guess the password using the alternate local admin username for each password again.
# this accounts for the machines that used to be members of one domain but are now in another thus breaking the mold. 
           if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
            write-host ""
            write-host "$($computer.hostname) unable to determine admin account password."
            write-host "Trying with alternative Accretivehealth username extrootacct."
            $userO = "extrootacct"

            $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred1 -vm $computername -ErrorAction SilentlyContinue | Select-Object -ExpandProperty scriptoutput
            if ($testadmin1){
               $passwordO = $wincred1
               write-host ""
               write-host "$usero and $wincred1 in use"
              
           }
   
            $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred2 -vm $computername -ErrorAction silentlyContinue | Select-Object -ExpandProperty scriptoutput
            if ($testadmin2){
               $passwordO = $wincred2
               write-host ""
               write-host "$usero and $wincred2 in use"
               
           }
   
            $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred3 -vm $computername -ErrorAction silentlyContinue | Select-Object -ExpandProperty scriptoutput
            if ($testadmin3){
               $passwordO = $wincred3
               write-host ""
               write-host "$usero and $wincred3 in use"
               
           }
   
            $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred4 -vm $computername -ErrorAction silentlyContinue | Select-Object -ExpandProperty scriptoutput
            if ($testadmin4) {
               $passwordO = $wincred4
               write-host ""
               write-host "$usero and $wincred4 in use"
               
           }
   
            $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $localpass -vm $computername -ErrorAction SilentlyContinue | Select-Object -ExpandProperty scriptoutput
   
           if ($testadmin5) {
              $passwordO = $localpass
              write-host ""
              write-host "$usero and $localpass in use"
              
           }
           # if all of the above attempts fail, break the script. 
           if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
            write-host ""
            write-host "$($computer.hostname) unable to determine admin account password. Server needs SSH process."
            break
           }
    
           }
        }

# once the password has been guessed, log the account name and password to a file for later reference
    $accounts = new-object psobject -Property @{
        "computer" = $computername
        "admin" = $usero
        "password" = $passwordo

    } | select computer, admin, password
    $accounts | export-csv -Delimiter "`," -NoTypeInformation -Append .\cutover_auth.csv


    # command list for each invoke-vmscript command, checks for the variability of domain membership and establishes the right command

    # changes the local admin password to something known for the second scripted process to run on to bypass the password guessing process if possible
    $changeadmin = $(if ($usero -like "ahrootacct") {'net user "ahrootacct" P@ssw0rd!'} elseif ($usero -like "extrootacct") `
    {'net user "extrootacct" P@ssw0rd!'} else {'net user "administrator" P@ssw0rd!'})
    $changeadminext = 'net user "extrootacct" P@ssw0rd!'

    # disjoin commands, the /reboot switch is critical as any change to the VMs underlying logon state will bring a VIX error from the vmware tools service
    # running on the VM necessitating a restart of that service. Leave this switch in its current state. 
    $netdomdisjoinAH = 'netdom.exe remove localhost /domain:accretivehealth.local /reboot /force'
    $netdomdisjoinEX = 'netdom.exe remove localhost /domain:extapp.local /reboot /force'

    # domain join command, uses the established $domaincred for the permissions to join to the specified domain (input file). 
    $netdomjoinAH = "netdom.exe join localhost /Domain:accretivehealth.local /UserD:$($domaincred.username) /PasswordD:$(get-content ./creds.txt) /ReBoot"
    $netdomjoinEX = "netdom.exe join localhost /Domain:extapp.local /UserD:$($domaincred.username) /PasswordD:$(get-content ./creds.txt) /ReBoot"

    # disables IPv6
    $disableipv6 = "netsh interface 6to4 set state disabled"

    # run this section only if -nic switch is used and the $adapter type check is e100*
    if ($adapter.type -like "e100*" -and $nic){
        write-host "E1000 network adapter detected, will be removed."
        write-host ""

        #set DNS1 and DNS2 to input file for the DNS1 and DNS2 columns
        $colldns1 = $computer.dns1
        $colldns2 = $computer.dns2

        # displays the current interfaces
        $getid = 'netsh interface ipv4 show interfaces'
        $registerdns = 'ipconfig /registerdns'
        $checkIP = 'ipconfig /all'

        # sets the DNS1 using the output from screen for the IDX value ($setidx) of the network interface getting the change for Windows 2008R2 vms
        $resetDNS1 = "netsh interface ipv4 set dnsserver $setidx static $colldns1 primary"
        $resetdns2 = "netsh interface ipv4 add dnsserver $setidx $colldns2 index=2"

        # sets the above but for Windows 2012R2 vms, will require checking for OS version in vCenter to differentiate
        $resetDNS12012 = "netsh interface ipv4 set dnsservers $setidx static $colldns1 primary validate=no"
        $resetdns22012 = "netsh interface ipv4 add dnsservers $setidx $colldns2 index=2 validate=no"
    
        $disableipv6 = "netsh interface 6to4 set state disabled"

        # tests the completed IP, GW, and DNS changes by looking up local domain information
        $checkipres = "nslookup accretivehealth.local"

        # begin scripted process
        write-host "Collectiong current IP information from machine before change."
        write-host ""
        write-host "An ipconfig will be run on $($computername) to verify single or multiple IP addresses."
        write-host ""

        # runs the $checkip command to display so operator can verify current IP settings against record (input file). 
        invoke-vmscript -ScriptText $checkIP -vm $computername -GuestUser $usero -GuestPassword $passwordo -Server $targetvcconn | select -ExpandProperty scriptoutput
        write-host "A pause is in effect, hit any key to continue after you validate the number of IP addresses assigned."
        pause
    
        # set IP, GW, and Mask based on columns from the input file, ip-address, default gateway, and subnet mask. 
        $collip = $computer."ip-address"
        $colldfgw = $computer."Default Gateway"
        $collmask = $computer.'Subnet Mask'

        # add the new vmxnet3 adapter while vm is still powered on, prevents reboot from long delays due to no network adapters being found that are connected
        # and issues with services dependent upon an adapter with driver being loaded. 
        New-NetworkAdapter -Confirm:$false -VM $computername -Portgroup $computer."network long name" -Type vmxnet3 -Server $targetvcconn -StartConnected 
        write-host "new vmxnet3 adapter added."
        write-host ""
        start-sleep 10
        write-host "disabling the E1000 adapter."
        write-host "" 

        # disconnects the detected $adapter and disables from connecting at next poweron. 
        Set-NetworkAdapter $adapter -Connected:$false -StartConnected:$false -confirm:$false
        start-sleep 10

        # after power down of vm, remove the $adapter detected earlier
        write-host "Initiating the removal of the E1000 network adatper, adding a vmxnet3 adapter and re-applying the IP information."
        write-host ""
        Get-VM $computername -Server $targetvcconn  | shutdown-VMguest -Confirm:$false
        write-host "shutdown initiated, a wait of 60 seconds to next task."
        start-sleep 60
            try {
                get-vm $computername -server $targetvcconn | where {$_.powerstate -eq "poweredoff"}
            }
            catch {
                start-sleep 10
            }
        Remove-NetworkAdapter -Confirm:$false -NetworkAdapter $adapter
        get-vm $computername -Server $targetvcconn | Start-VM
        write-host "starting vm. A wait of a minute before next step."
        write-host ""
        start-sleep 40
        
        # check for reboot being completed and vmtools running on vm, if not, add an additional delay.
        $state = get-vm $computername -server $targetvCConn | get-vmguest | where {$_.state -eq "running"}
        if (!$state){
            write-host "Tools not yet in running state, a further 15 seconds will be added before next task."
            start-sleep 15
        }
    
        # collects the current network adapter information and operator chooses which IDX value to act on and sets that value for the command. 
        [string]$collidx = Invoke-VMScript -ScriptText $getid -vm $computername -GuestUser $userO -GuestPassword $passwordO -server $targetvcconn | Select-Object -ExpandProperty scriptoutput
        write-host "Choose the correct index ID of the local area connection that needs to be reset."
        $collidx
        $setidx = Read-Host
        write-host ""
        write-host "Resetting IP, Mask, and Default Gateway."
        write-host ""

        # establishes the command to run next based on the $setidx value entered from keyboard and displays it to the screen.
        $resetip = "netsh interface ipv4 set address $setidx static $collip $collmask $colldfgw 1"
        $resetip
    
        # run the command set by the variables above, display what is being run to screen and then run. 
        Invoke-VMScript -ScriptText $resetip -VM $computername -GuestUser $userO -GuestPassword $passwordO -server $targetvCConn | Select-Object -ExpandProperty scriptoutput
        write-host ""
        start-sleep 10
        write-host "Resetting Primary and Secondary DNS server."
        write-host ""

        # based on type of OS, run one or the other command set.
        $(if ($vm.guest -like "*2008*") {$resetdns1} else {$resetDNS12012})
        Invoke-VMScript -ScriptText $(if ($vm.guest -like "*2008*") {$resetdns1} else {$resetdns12012}) -vm $computername -GuestUser $userO -GuestPassword $passwordO -Server $targetvcconn -ScriptType Powershell | Select-Object -ExpandProperty scriptoutput
        write-host ""
        $(if ($vm.guest -like "*2008*") {$resetdns2} else {$resetDNS22012})
        Invoke-VMScript -ScriptText $(if ($vm.guest -like "*2008*") {$resetdns2} else {$resetdns22012}) -vm $computername -GuestUser $userO -GuestPassword $passwordO -Server $targetvcconn -ScriptType powershell | Select-Object -ExpandProperty scriptoutput
        
        # begin verification section commands for testing IP and routing settings. 
        write-host "Registering DNS."
        Invoke-VMScript -ScriptText $registerdns -vm $computername -guestuser $userO -GuestPassword $passwordO -server $targetvcconn -ScriptType powershell | Select-Object -ExpandProperty scriptoutput
        write-host "Checking IP information on the $($computer.hostname)."
        Invoke-VMScript -ScriptText $checkIP -vm $computername -GuestUser $userO -GuestPassword $passwordO -server $targetvcconn -ScriptType powershell | Select-Object -ExpandProperty scriptoutput
        write-host ""
        write-host "Disabling IPv6."
        Invoke-VMScript -ScriptText $disableipv6 -vm $computername -GuestUser $usero -GuestPassword $passwordo -server $targetvcconn -ScriptType powershell | Select-Object -ExpandProperty scriptoutput
        write-host ""
        write-host "Checking for IP resolution to accretivehealth.local"
        invoke-vmscript -ScriptText $checkipres -vm $computername -GuestUser $usero -GuestPassword $passwordo -server $targetvcconn -ScriptType Powershell | Select-Object -ExpandProperty scriptoutput
        }
        
    

    # if not -nic used, run this section
    if (!$nic){
                    
    # disjoin the domain, this section is used for when the synchronization has completed and the vm can no longer communicate with the isolation domain        
    write-host ""
    write-host "$($computer.hostname) will now be disjoined from the $($computer."domain name")."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer."domain name" -like "extapp.local") {$netdomdisjoinEX} else {$netdomdisjoinAH}) -GuestUser $userO -GuestPassword $passwordO  -server $targetvCConn -ErrorAction SilentlyContinue #| Select-Object -ExpandProperty scriptoutput
    write-host ""
    start-sleep 90
    $state = ""

    # check for vmtools running on vm, if not add additional delay
    $state = get-vm $computername -server $targetvCConn | get-vmguest | where {$_.state -eq "running"}
    if (!$state){
        write-host "Tools not yet in running state, a further 30 seconds will be added before next task."
        start-sleep 30
    }


    # if either the -iso or the -prd and not -nic, run this section.
    if ($ISO -or $prd -and !$nic){
    
    write-host ""

    write-host "$($computer.hostname) will now be re-joined to the $($computer."domain name")."

    # Add vm to the isolation domain, if attempt fails, flag the error and inform operator in the try catch statement and then retry the command.
    try {
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer."domain name" -like "extapp.local") {$netdomjoinEX} else {$netdomjoinAH}) `
    -GuestUser $userO -GuestPassword $passwordO -server $targetvCConn -ErrorAction stop #| Select-Object -ExpandProperty scriptoutput
    write-host ""
    start-sleep 90
    }
    catch {
    write-host "Error in completing command, $($computer.hostname) may not have been joined to $($computer."domain name")."
    write-host ""
    $state = ""
    $state = get-vm $computername -server $targetvCConn | get-vmguest | where {$_.state -eq "running"}
    if (!$state){
        write-host "Tools not yet in running state, a further 30 seconds will be added before next task."
        start-sleep 30
    }
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer."domain name" -like "extapp.local") {$netdomjoinEX} else {$netdomjoinAH}) `
    -GuestUser $userO -GuestPassword $passwordO -server $targetvCConn -ErrorAction stop 
    start-sleep 90
    }
    $state = ""
    $state = get-vm $computername -server $targetvCConn | get-vmguest | where {$_.state -eq "running"}
    if (!$state){
        write-host "Tools not yet in running state, a further 20 seconds will be added before next task."
        start-sleep 30
    }

# test the vm for domain membership after delay for reboot, use the $domaincred variable to run command using domain credentials. 
try {
    write-host "$($computer.hostname) will now be tested for domain logon."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $testdomain -GuestCredential $domaincred -Server $targetvcenter -ErrorAction stop #| Select-Object -ExpandProperty scriptoutput
        }

    catch {
    write-host "Cannot connect to $($computer.hostname), domain logon test failed, another 10 second wait will be initiated."
    start-sleep 10
    Invoke-VMScript -vm $computername -ScriptText $testdomain -GuestCredential $domaincred -Server $targetvcenter -ErrorAction stop #| Select-Object -ExpandProperty scriptoutput
    write-host "Second attempt failed, the password saved to the $domaincred variable is incorrect. Please redo the variable."
        }
    
    write-host ""
    write-host "$($computer.hostname) domain disjoin/join and logon test completed."
    write-host ""
    write-host "--------------------------------------------------------------------"
        }


    }

    # if password detected not P@ssw0rd!, change password of local admin account
    if ($passwordO -notlike $wincred4 -and !$nic){
    
        write-host "Changing local admin password."
        invoke-vmscript -vm $computername -ScriptText $( if($computer."domain name" -like "extapp.local") {$changeadminext} else {$changeadmin}) `
        -GuestCredential $domaincred -server $targetvCConn #| select-object -ExpandProperty scriptoutput
        $passwordO = $wincred4

            }
    
write-host "Process for $($computer.hostname) complete."
}


