# used to craete a new vCenter VM with use of an input file that sets all required parameters, clones the template, and powers on the new vm, sets the IP
#addressing, joins the domain. 

param (

    [parameter(mandatory=$true)]
    [string]
    $file,

    [parameter(mandatory=$true)]
    [string]
    $targetvcenter

)

# will prompt if $domaincred has not previously been established, required for domain join section
if (!$domaincred){
    write-host "Input name of domain admin account."
    $userD = read-host
    write-host ""
    write-host "Input your domain admin password."
    $passwordD = read-host -AsSecureString
    $domaincred = new-object system.management.automation.pscredential($userD, $passwordD)
    
        }

# if not $targetvcconn, force input for establishing the vCenter IP or name, username and password required for connecting. Setting $vccred = 
# get-credential username@vcenter.local will establish the user credentials for all connections to vCenter. Setting $targetvcconn = connect-viserver

if (!$targetvcconn){
#if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
    if (!$targetvcenter){
    write-host "input name or IP of source vCenter."
    $targetvcenter = (read-host)
    write-host ""
        }
    if (!$targetvcusername){
    write-host "input name of source vCenter Username in name@domain format."
    $targetVCUsername = (read-host)
    write-host ""
        }
    write-host ""
    write-host "input the vCenter password."
    $targetvcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcred = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)
    $targetvCConn = Connect-VIServer -server $targetvcenter -Credential $vCcred -port 443
    Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false

}
# input file section, will require a template .csv file using the following column headers:
# hostname	vmhost	resourcepool	location	diskgb	memorygb	numcpu	networkname	ip-address	defaultgw	mask	dns1	dns2	domain	template	ddrive	edrive	kdrive	ldrive	datastore
# the drive section, d,e,k,l can be modified per need. script does not map any disks, it just adds them to the VM. 
$servers = import-csv -Delimiter "`," $($file)


# start the scripted process

foreach ($computer in $servers){

#reset variables

# get environment variables for each vm creation

write-host ""
write-host "Collecting vCenter vLAN, vSAN, folder, and compute cluster objects. This will take a few moments."
write-host ""
$vlan = get-vdportgroup -vdswitch sddc-dswitch-private -name ("*" + $computer.networkname + "*") -server $targetvcenter
$cluster = get-cluster $($computer.resourcepool) -server $targetvcenter
$datastore = get-datastore $computer.datastore -server $targetvcenter
$location = get-folder $computer.location -server $targetvcenter
$passwordo = ''
$usero = 'administrator'
$computername = $computer.hostname


    
    #test domain account credentials file, if not present halt the script.
    try {
        $credck = get-content .\creds.txt -ErrorAction stop
    }
    catch {
        write-host "Credentials file not found, script requires a file called creds.txt with the domain account password only."
        write-host ""
        write-host "Please create a file in the root of the directory where the script is executed."
        break
    }
#create new vm

new-vm -name $computername -template $($computer.template) -resourcepool $cluster -location $location -datastore $datastore -server $targetvcenter `
-OSCustomizationSpec scripted-win-custom-nonetwork -RunAsync
start-sleep 120

Pause
write-host "Once clone is complete, hit enter."
$vm = get-vm $computername -server $targetvcenter

$network = get-vm $computername -server $targetvcenter| get-networkadapter
Set-NetworkAdapter -NetworkAdapter $network -portgroup $vlan -confirm:$false -ErrorAction SilentlyContinue | Select-Object parent, NetworkName
set-vm $computername -memorygb $computer.memorygb -numcpu $computer.numcpu -Confirm:$false -ErrorAction SilentlyContinue -server $targetvcenter | Select-Object guest, memorygb, numcpu

if ($diskgb){
get-HardDisk $computername -server $targetvcenter | set-harddisk -CapacityGB $computer.diskgb -Confirm:$false -ErrorAction SilentlyContinue -server $targetvcenter | Select-Object parent, name, CapacityGB
}
start-sleep 10

# add additional disks if any requested
if ($computer.ddrive){
    write-host ""
    write-host "Ddrive being created."
    New-HardDisk -vm $vm -StorageFormat Thin -CapacityGB $computer.ddrive -Confirm:$false  -ErrorAction SilentlyContinue -server $targetvcenter | select-object parent, name, CapacityGB
    start-sleep 10 
    }
    
# add additional disks if any requested

if ($computer.edrive){
write-host ""
write-host "Edrive being created."
New-HardDisk -vm $vm -StorageFormat Thin -CapacityGB $computer.edrive -Confirm:$false  -ErrorAction SilentlyContinue -server $targetvcenter | select-object parent, name, CapacityGB
start-sleep 10 
}

if ($computer.kdrive){
write-host ""
write-host "Kdrive being created."
New-HardDisk -vm $vm -StorageFormat Thin -CapacityGB $computer.kdrive -Confirm:$false  -ErrorAction SilentlyContinue -server $targetvcenter | select-object parent, name, CapacityGB
start-sleep 10 
}

if ($computer.ldrive){
write-host ""
write-host "Ldrive being created."
New-HardDisk -vm $vm -StorageFormat Thin -CapacityGB $computer.ldrive -Confirm:$false   -ErrorAction SilentlyContinue -server $targetvcenter | select-object parent, name, CapacityGB
start-sleep 10
}
   
# power on the VM after cloning has completed
start-vm $computername -confirm:$false -server $targetvcenter | Select-Object name, powerstate

write-host ""
write-host "There will be a 5 minute wait as the sysprep process initiates several reboots before the next phase can start."
start-sleep 300

    try {
    $running = get-vmguest -vm $computername -ErrorAction stop -server $targetvcenter | where {$_.state -like "running" -and $_.toolsversion -like "10.*"}
        }

    catch {
    write-host "$($computer.hostname) vmtools not running."
    write-host "$($computer.hostname) will be skipped."
    $skipped += $computer.hostname
    break
        }

    #$vm = get-vm $computername -server $targetvcenter
    # command list for each invoke-vmscript commands

    # sets the IP configuration IP, mask, GW, and DNS for selected server and requires an input file with the column headings of ip-address, dns1, dns2
    # default gateway and subnet mask
    $getnetip = $computer."ip-address"
    $getnetdns1 = $computer.dns1
    $getnetdns2 = $computer.dns2
    $getdfgw = $computer.defaultgw
    $getmask = $computer.mask
    $getnetname = $computer.networkname

    # commands to display needed information on the screen
    $getid = 'netsh interface ipv4 show interfaces'
    $checkIP = 'ipconfig /all'

    # disjoin and join domain based on domain membership from input file, will need to be modified for different domain names
    $netdomjoinAH = 'netdom.exe join localhost /Domain:accretivehealth.local /UserD:accretivehealth\adm-us26735 /PasswordD:C8an53m3n0w! /ReBoot'
    $netdomjoinEX = 'netdom.exe join localhost /Domain:extapp.local /UserD:accretivehealth\adm-us26735 /PasswordD:C8an53m3n0w! /ReBoot'

    # disable IPv6

    # test for successful network swing
    $checkipres = "nslookup google.com"

    # simple command to test use of domain credentials to execute command
    $testdomain = 'hostname'

    # commands to set then verify timezone change
    $timezone = "TZUTIL /s 'Eastern Standard Time'"
    $timezoneck = "TZUTIL /g"

    # change the local admin password


    # pull the current network adapter information and diplay to screen, operator will choose the correct IDX value and input to screen
    # next commands then will set the correct change commands based on the $setidx value input. 
    [string]$collidx = Invoke-VMScript -ScriptText $getid -vm $computername -GuestUser $userO -GuestPassword $passwordO -server $targetvcenter | select -ExpandProperty scriptoutput
    write-host "Choose the correct index ID of the local area connection that needs to be reset."
    $collidx
    $setidx = Read-Host
    write-host "Resetting IP, Mask, and Default Gateway."
    write-host ""

    # commands based on the detected operating system of the vm
    $setDNS12008 = "netsh interface ipv4 set dnsserver $setidx static $getnetdns1 primary"
    $setdns22008 = "netsh interface ipv4 add dnsserver $setidx $getnetdns2 index=2"
    $setDNS12012 = "netsh interface ipv4 set dnsservers $setidx static $getnetdns1 primary validate=no"
    $setdns22012 = "netsh interface ipv4 add dnsservers $setidx $getnetdns2 index=2 validate=no"

    # display the command that is being sent to the vm
    $setip = "netsh interface ipv4 set address $setidx static $getnetip $getmask $getdfgw 1"
    $setip

    # sets the IP value, mask, and GW selected interface
    Invoke-VMScript -vm $computername -ScriptText $setip -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter
    start-sleep 20
    write-host ""
    # setting the primary and secondary DNS
    write-host "Changing Primary DNS $($getnetdns1) $(if ($vm.guest -like "*2008*") {$setdns12008} else {$setdns12012})."
    Invoke-VMScript -vm $computername -ScriptText $(if ($vm.guest -like "*2008*") {$setdns12008} else {$setdns12012}) -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter
    write-host ""
    write-host "Changing Secondary DNS $($getnetdns2) $(if ($vm.guest -like "*2008*") {$setdns22008} else {$setdns22012})."
    Invoke-VMScript -vm $computername -ScriptText $(if ($vm.guest -like "*2008*") {$setdns22008} else {$setdns22012}) -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter
    write-host ""

    # display the changes to the screen
    write-host "Checking IP settings."
    Invoke-VMScript -vm $computername -ScriptText $checkip -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter

    # check the changes to GW and VXLAN with an nslookup command to an outside FQDN, in this case google.com
    write-host ""
    write-host "Testing IP resolution."
    invoke-vmscript -ScriptText $checkipres -vm $computername -GuestUser $usero -GuestPassword $passwordo -server $targetvcenter -ScriptType Powershell

    # join the domain
    write-host "$($computer.hostname) will now be joined to the $($computer.domain)."

    # try the domain join, if not verified or an error occurs, restart VM and retry command. 
    try {
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer.domain -like "extapp.local") {$netdomjoinEX} else {$netdomjoinAH}) `
    -GuestUser $userO -GuestPassword $passwordO -ErrorAction stop -server $targetvcenter 
    write-host ""
    start-sleep 70
    }
    catch {
    write-host "Error in completing command, $($computer.hostname) may not have been joined to $($computer.domain)."
    write-host ""
    write-host "Restarting guest tools and retrying command."
    Restart-VMGuest -Guest $computername -confirm:$false -server $targetvcenter
    write-host ""
    start-sleep 50
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer.domain -like "extapp.local") {$netdomjoinEX} else {$netdomjoinAH}) `
    -GuestUser $userO -GuestPassword $passwordO -ErrorAction stop -server $targetvcenter 
        }


    # test domain join with execution of command using $domaincred variable information
    write-host "$($computer.name) will now be tested for domain logon."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $testdomain -GuestCredential $domaincred -Server $targetvcenter -ErrorAction SilentlyContinue

    # set different command set for OS version, one for 2008R2 and one for 2012R2. 
    if ($vm.guest -like "*2012*"){
    write-host "Timezone to be set to Eastern Standard time."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $timezone -GuestUser $usero -GuestPassword $passwordo -server $targetvcenter
    write-host "Time zone will be verified."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $timezoneck -GuestUser $usero -GuestPassword $passwordo -server $targetvcenter 
        }




}