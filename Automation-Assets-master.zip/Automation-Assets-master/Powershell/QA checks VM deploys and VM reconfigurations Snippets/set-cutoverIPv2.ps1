﻿#script for conducting either a network swing or a full domain disjoin and join after the IP, GW, mask, and DNS settings have been set for
#a production network from an isolation network. Takes parameters that depend upon input files setting isolation and production IP settings
#and takes usernames for vcenter and domain credentials if not established in a universal variable $domaincred and $vccred. Test switch 
#tells script where to look for the input files, special test files can be used without having to mess with production level files. Uses
#wave parameter to ensure the right server is being acted upon. 

# parameters assume some of the following: input files are in use, one for isolation networks and one
# for production, usernames for vCenter and domain account being given per script run, a wave designator
# to ensure the right server is being targeted, and means to bypass the password guessing for local admin
# accounts by specifying the user and the password on the command line and finally a test parameter to use
# a separate input file for test vms that can be moved through the process in the live environment. 
[cmdletbinding()]
param (
    [parameter(mandatory=$true)]
    [string[]]
    $server,

    [parameter()]
    [string]
    $wave,

    [parameter()]
    [switch]
    $iso,

    [parameter()]
    [switch]
    $prd,

    [parameter()]
    [string]
    $targetvcusername,

    [parameter()]
    [string]
    $targetvcenter,

    [parameter()]
    [string]
    $targetvcpasswd,

    [parameter()]
    [switch]
    $test,

    [parameter()]
    [string]
    $userO,

    [parameter()]
    [string]
    $passwordO,

    [parameter()]
    [switch]
    $swing,

    [parameter()]
    [string]
    $type,

    [parameter()]
    [switch]
    $rename,

    [parameter()]
    [string]
    $source


    )


#set path for input files, if not -test, then use the root of the script directory to find the input files

if (!$test){
    $path = ".\"
}
else {
    $path = ".\input\"
}
# if -iso or -prd used, substitute the correct name for the input file required.

if ($iso -or $prd){
#verify path/name
try {
$errorcsv = get-content "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -ErrorAction Stop
    }
#if $errorcsv = False, notify user of need to re-input path/file of csv
catch {
write-host "incorrect path or file name."
write-host "input path and filename of csv file."
write-host ""
$file = read-host
$servers = import-csv -Delimiter "`," -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" | Where-Object {$_.hostname -like "$server"}
    }

#if $errorcsv test = true, import csv file. 
if ($errorcsv){
$servers = import-csv -Delimiter "`," -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" | Where-Object {$_.hostname -like "$server"}
    }
}

# if not -domaincred, then take input for the username and password before continuing. Use $domaincred = get-credential ****@domain.com to establish
# credentials for domain joining and domain logon testing.

if (!$domaincred){
    write-host "Input name of domain admin account."
    $userD = read-host
    write-host ""
    write-host "Input your domain admin password."
    $passwordD = read-host -AsSecureString
    $domaincred = new-object system.management.automation.pscredential($userD, $passwordD)
    
        }

# if not $targetvcenter, force input for establishing the vCenter IP or name, username and password required for connecting. Setting $vccred = 
# get-credential username@vcenter.local will establish the user credentials for all connections to vCenter. Setting $targetvcenter = connect-viserver

if (!$targetvcconn){
#if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
    if (!$targetvcenter){
    write-host "input name or IP of source vCenter."
    $targetvcenter = (read-host)
    write-host ""
        }
    if (!$targetvcusername){
    write-host "input name of source vCenter Username in name@domain format."
    $targetVCUsername = (read-host)
    write-host ""
        }
    write-host ""
    write-host "input the vCenter password."
    $targetvcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcred = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)

}

#get source vCenter, if not already set, set the variable $targetvcconn
if (!$targetvCConn){
$targetvCConn = Connect-VIServer -server $targetvcenter -Credential $vCcred -port 443 -ErrorAction SilentlyContinue

# if not already set, establish the bypass for ignoring the unverified server certificate or that workstation does not have a certificate
# that matches what is set in vcenter. 

Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
    }
    #else {connect-viserver -server $targetvcenter -session $targetvcconn.sessionid }

#local passwords that exist in environment, for use with the password guessing process
$wincred1 = 'Allyourbasearebelongtous....'
$wincred2 = 'Letmein2'
$wincred3 = 'g0T!gersg0'
$wincred4 = 'P@ssw0rd!'
$localpass = '9s4&**#rpT=M'


# start the scripted process

foreach ($computer in $servers){
$computername = $null
#reset variables
$testadmin1 = $null
$testadmin2 = $null
$testadmin3 = $null
$testadmin4 = $null
$testadmin5 = $null

    if (!$usero){
        $usero = $(if ($computer."domain name" -like 'extapp.local') {'extrootacct'} else {'administrator'})
            }
    else {$usero = $usero}

    $testadmin = $null
    $testdomain = 'hostname'
    $computername1 = -join($computer.hostname + "-*ssign*")
    $computername2 = -join($computer.hostname + "$type")
    $computername3 = $computer.hostname
    
$rackware = $null
$newpx = $null
$repx = $null
    
    $vm = get-vm $computername1 -Server $targetvcenter -ErrorAction SilentlyContinue
    if ($vm){
    $computername = $vm.name
    $rackware = $true
    
        }
    if (!$vm){
    $vm = get-vm $computername3 -server $targetvcenter -ErrorAction silentlycontinue
    $computername = $vm.name
    $newpx = $true
    }

    else {
    $vm = get-vm $computername2 -server $targetvcenter -ErrorAction SilentlyContinue
    if ($vm){
        $computername = $vm.name
        $repx = $true
    }
    if (!$computername) {
    write-host ""
    write-host "VM not found, process halted."
    break
        }
    }
$vm = get-vm $computername -server $targetvcenter

    write-host ""
    write-host "Starting process on $computername."
    start-sleep 5

    #check for adapter type
    $adapter = get-vm $computername -Server $targetvcenter  | Get-networkadapter 

    #test domain account credentials file, if not present halt the script.
    try {
        $credck = get-content .\creds.txt -ErrorAction stop
    }
    catch {
        write-host "Credentials file not found, script requires a file called creds.txt with the domain account password only."
        write-host ""
        write-host "Please create a file in the root of the directory where the script is executed."
        break
    }



# Begin process for establishing local admin password for the particular system this script is running on. 

    write-host "Determining local admin password for logon."
    write-host ""

# reboot VM to start fresh and avoid any vmtools client issues at start.

    # if not -passwordo, then run each command in turn. Process of elimination, once found universal variables of $passwordo and $usero are set for each 
    # subsequent command.
        if (!$passwordo) {
        $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred1 -vm $computername -server $targetvcenter -ErrorAction SilentlyContinue #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin1){
            $passwordO = $wincred1
            write-host ""
            write-host "$usero and $wincred1 in use"
           
        }

         $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred2 -vm $computername -server $targetvcenter -ErrorAction silentlyContinue #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin2){
            $passwordO = $wincred2
            write-host ""
            write-host "$usero and $wincred2 in use"
            
        }

         $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred3 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin3){
            $passwordO = $wincred3
            write-host ""
            write-host "$usero and $wincred3 in use"
            
        }

         $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred4 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin4) {
            $passwordO = $wincred4
            write-host ""
            write-host "$usero and $wincred4 in use"
            
        }

         $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $localpass -vm $computername -ErrorAction SilentlyContinue -server $targetvcenter #|  Select-Object -ExpandProperty scriptoutput

        if ($testadmin5) {
           $passwordO = $localpass
           write-host ""
           write-host "$usero and $localpass in use"
           
        }

        # If all of the above fail, use the following sequence to guess the password using the alternate local admin username for each password again.
        # this accounts for the machines that used to be members of one domain but are now in another thus breaking the mold. 

           if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
            write-host ""
            write-host "$($computer.hostname) unable to determine admin account password."
            write-host "Trying with alternative Accretivehealth username extrootacct."
            $userO = "extrootacct"

            $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred1 -vm $computername -ErrorAction SilentlyContinue -server $targetvcenter  #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin1){
               $passwordO = $wincred1
               write-host ""
               write-host "$usero and $wincred1 in use"
              
           }
   
            $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred2 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin2){
               $passwordO = $wincred2
               write-host ""
               write-host "$usero and $wincred2 in use"
               
           }
   
            $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred3 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin3){
               $passwordO = $wincred3
               write-host ""
               write-host "$usero and $wincred3 in use"
               
           }
   
            $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred4 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin4) {
               $passwordO = $wincred4
               write-host ""
               write-host "$usero and $wincred4 in use"
               
           }
   
            $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $localpass -vm $computername -ErrorAction SilentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
   
           if ($testadmin5) {
              $passwordO = $localpass
              write-host ""
              write-host "$usero and $localpass in use"
              
           }

        # if all of the above attempts fail, break the script. 
           if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
            write-host ""
            write-host "$($computer.hostname) unable to determine admin account password. Server needs SSH process."
            break
           }
    
           }
        }

    # check vmtools version and if in running state. if not in running state halt script. Script requires vmtools to be installed and running.

    try {
    $running = get-vmguest -vm $computername -ErrorAction stop -server $targetvcenter | where {$_.state -like "running" -and $_.toolsversion -like "10.*"}
        }

    catch {
    write-host "$($computername) vmtools not running."
    write-host "$($computername) will be skipped."
    $skipped += $computer.hostname
    break
        }
    if ($running){

    # begin change part of script
    write-host "Beginning IP change process."
    write-host ""

    # command list for each invoke-vmscript commands

    # sets the IP configuration IP, mask, GW, and DNS for selected server and requires an input file with the column headings of ip-address, dns1, dns2
    # default gateway and subnet mask
    $getnetip = $computer."ip-address"
    $getnetdns1 = $computer.dns1
    $getnetdns2 = $computer.dns2
    $getdfgw = $computer."default gateway"
    $getmask = $computer."subnet mask"
    $getnetname = $computer."network long name"

    # commands to display needed information on the screen
    $getid = 'netsh interface ipv4 show interfaces'
    $registerdns = 'ipconfig /registerdns'
    $checkIP = 'ipconfig /all'

    # commands to make the needed changes to the vm

    # change local admin password commands, dependent upon domain and detected $usero name
    $changeadmin = $(if ($usero -like "ahrootacct") {'net user "ahrootacct" 9s4"&"**#rpT=M'} elseif ($usero -like "extrootacct") `
    {'net user "extrootacct" P@ssw0rd!'} else {'net user "administrator" P@ssw0rd!'})
    $changeadminext = 'net user "extrootacct" P@ssw0rd!'

    # disjoin and join domain based on domain membership from input file
    $netdomdisjoinAH = 'netdom.exe remove localhost /domain:accretivehealth.local /reboot /force'
    $netdomdisjoinEX = 'netdom.exe remove localhost /domain:extapp.local /reboot /force'
    $netdomjoinAH = "netdom.exe join localhost /Domain:accretivehealth.local /UserD:$($domaincred.username) /PasswordD:$(get-content ./creds.txt) /ReBoot"
    $netdomjoinEX = "netdom.exe join localhost /Domain:extapp.local /UserD:$($domaincred.username) /PasswordD:$(get-content ./creds.txt) /ReBoot"

    # disable IPv6
    $disableipv6 = "netsh interface 6to4 set state disabled"

    # test for successful network swing
    $checkipres = "nslookup google.com"

    # simple command to test use of domain credentials to execute command
    $testdomain = 'hostname'

    # used for changing local admin account based on variable set during password guess process
    $changeadmin = $(if ($usero -like "ahrootacct") {'net user "ahrootacct" P@ssw0rd!'} elseif ($usero -like "extrootacct") `
    {'net user "extrootacct" P@ssw0rd!'} else {'net user "administrator" P@ssw0rd!'})
    $changeadminext = 'net user "extrootacct" P@ssw0rd!'

    # commands to set then verify timezone change
    $timezone = "TZUTIL /s 'Eastern Standard Time'"
    $timezoneck = "TZUTIL /g"

    # commands used for removal of persistent routes, if present in environment. One set for swinging to isolation domain and one for production. 
    $prdroutedb = "route delete 10.246.238.64
    route delete 10.246.238.128
    route delete 0.0.0.0 mask 0.0.0.0 10.25.158.1
    route delete 0.0.0.0 mask 0.0.0.0 10.25.152.1
    route delete 0.0.0.0 mask 0.0.0.0 10.15.*.*"
    $isoroutedb = "route delete 10.246.254.128
    route delete 0.0.0.0 mask 0.0.0.0 10.25.152.1
    route delete 0.0.0.0 mask 0.0.0.0 10.25.158.1
    route delete 0.0.0.0 mask 0.0.0.0 10.15.*.*"
    $checkroute = "route print -4"

    # if not -swing, run these commands
    $usero
    $passwordo


    if (!$swing){
    write-host ""
    write-host "$computername will now be disjoined from the $($computer."domain name")."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer."domain name" -like "extapp.local") {$netdomdisjoinEX} else {$netdomdisjoinAH}) -GuestUser $usero -GuestPassword $passwordo  -server $targetvcenter -ScriptType bat -ErrorAction silentlyContinue #| select-object -expandproperty scriptoutput
    write-host ""

    write-host ""
    start-sleep 90
    $state = ""

    # check for vmtools running on vm, if not add additional delay
    $state = get-vm $computername -server $targetvcenter | get-vmguest | where {$_.state -eq "running"}
    
    if (!$state){
        write-host "Tools not yet in running state, a further 30 seconds will be added before next task."
        start-sleep 30
    }
    write-host "Disjoin complete."
    }

    if ($rename){
        if ($newpx){
        #command to run a host rename on the system.
        $oldname = $computername -replace ".{3}$"
        $newname = $computer.hostname
        }
        elseif ($repx)
         {$oldname = $computer.hostname
        $newname = ($computername)}
        $newhostname = "netdom renamecomputer localhost /newname $newname /force /reboot"
        write-host ""
        write-host "Hostname will now be changed to $computername"
        invoke-vmscript -ScriptText $newhostname -vm $computername -server $targetvcenter -GuestUser $usero -GuestPassword $passwordo -ScriptType bat | select-object -ExpandProperty scriptoutput
        write-host ""
        write-host "A reboot is necessary after the hostname change."
        start-sleep 90
        # check for vmtools running on vm, if not add additional delay
        $state = $null
        $state = get-vm $computername -server $targetvcenter | get-vmguest | where {$_.state -eq "running"}

        $removereg = 'get-childitem hklm: -recurse -erroraction silentlycontinue | where {$_.pschilditem -eq "DNSRegisteredAdapters" -and $_.pschilditem -eq "CachedMachineNames"} | remove-item -confirm:$false'
        write-host ""
        write-host "Searching registery for source server hostname."
        Invoke-VMScript -vm $computername -ScriptText $removereg -server $targetvcenter -GuestUser $usero -GuestPassword $passwordo | Select-Object ScriptOutput
        if (!$state){
            write-host "Tools not yet in running state, a further 30 seconds will be added before next task."
            start-sleep 30
        }
        write-host ""
        write-host "A check on the hostname will now be executed to confirm change of hostname."
        invoke-vmscript -ScriptText $testdomain -vm $computername -GuestUser $usero -GuestPassword $passwordo -server $targetvcenter -ScriptType bat | select-object -ExpandProperty scriptoutput
        write-host ""
        write-host "did hostname change?"
        pause
        }



    # pull the current network adapter information and diplay to screen, operator will choose the correct IDX value and input to screen
    # next commands then will set the correct change commands based on the $setidx value input. 
    [string]$collidx = Invoke-VMScript -ScriptText $getid -vm $computername -GuestUser $userO -GuestPassword $passwordO -server $targetvcenter -ScriptType bat #| Select-Object -ExpandProperty scriptoutput
    write-host "Choose the correct index ID of the local area connection that needs to be reset."
    write-host "$collidx"
    $setidx = Read-Host
    write-host "Resetting IP, Mask, and Default Gateway."
    write-host ""

    # commands based on the detected operating system of the vm
    $setDNS12008 = "netsh interface ipv4 set dnsserver $setidx static $getnetdns1 primary"
    $setdns22008 = "netsh interface ipv4 add dnsserver $setidx $getnetdns2 index=2"
    $setDNS12012 = "netsh interface ipv4 set dnsservers $setidx static $getnetdns1 primary validate=no"
    $setdns22012 = "netsh interface ipv4 add dnsservers $setidx $getnetdns2 index=2 validate=no"
    $setdnsautoreg = "netsh interface ipv4 set dnsservers register=none"
    $registerdns = 'ipconfig /registerdns'

    # display the command that is being sent to the vm
    $setip = "netsh interface ipv4 set address $setidx static $getnetip $getmask $getdfgw 1"
    $setip

    # sets the IP value, mask, and GW selected interface
    Invoke-VMScript -vm $computername -ScriptText $setip -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter -ScriptType bat | Select-Object -ExpandProperty scriptoutput
    start-sleep 20
    write-host ""
    # setting the primary and secondary DNS
    write-host "Changing Primary DNS $($getnetdns1) $(if ($vm.guest -like "*2008*") {$setdns12008} else {$setdns12012})."
    Invoke-VMScript -vm $computername -ScriptText $(if ($vm.guest -like "*2008*") {$setdns12008} else {$setdns12012}) -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter -ScriptType bat
    write-host ""
    write-host "Changing Secondary DNS $($getnetdns2) $(if ($vm.guest -like "*2008*") {$setdns22008} else {$setdns22012})."
    Invoke-VMScript -vm $computername -ScriptText $(if ($vm.guest -like "*2008*") {$setdns22008} else {$setdns22012}) -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter -ScriptType bat
    write-host ""

    # display the changes to the screen
    write-host "Checking IP settings."
    Invoke-VMScript -vm $computername -ScriptText $checkip -Guestuser $userO -GuestPassword $passwordO -server $targetvcenter -ScriptType bat | select-object -ExpandProperty scriptoutput

    # change the VXLAN on the vm based on the input file
    write-host "Process will now change the vxlan of $($computer."hostname")."
    Set-NetworkAdapter -NetworkAdapter $adapter -portgroup $computer."network long name" -confirm:$false -ErrorAction SilentlyContinue
    start-sleep 70

    # remove the persistent legacy routes, removes those routes known, allows for removing any additional routes still present after the known routes
    # are removed. 
    write-host ""
    write-host "A check of the default routes on $($computername)."
    Invoke-VMScript -ScriptText $checkroute -vm $computername -GuestUser $userO -GuestPassword $passwordO -Server $targetvcenter -ScriptType bat
    write-host ""
    write-host "Default routes for ISO environment will be removed automatically."
    invoke-vmscript -ScriptText $(if ($iso) {$isoroutedb} else {$prdroutedb}) -vm $computername -GuestUser $userO -GuestPassword $passwordO -server $targetvcenter -ScriptType bat
    write-host ""
    write-host "The route table will be checked once again after the ISO default routes have been removed."
    Invoke-VMScript -ScriptText $checkroute -vm $computername -GuestUser $userO -GuestPassword $passwordO -Server $targetvcenter -ScriptType bat
    write-host "Do you need to remove more routes? Press y for Yes, Press n for No."
    $no = read-host
    if ($no -eq "y"){
        do {
        write-host ""
        write-host "Enter the reoute delete command required. If route is a default route, use the followign syntax: route delete 0.0.0.0 mask 0.0.0.0 df_gw address."
        write-host "If multiple routes need to be removed, separate the commands with a '|' symbol before hitting the 'enter' key."
        write-host "If these are addtional persistent routes, use the following syntax: route delete gw_addr. If multiple here, separate the commands with a '|' symbol."
        write-host ""
        $routedel = read-host
        Invoke-VMScript -ScriptText $routedel -vm $computername -GuestUser $usero -GuestPassword $passwordo -server $targetvcenter -ScriptType bat
        write-host ""
        write-host "An additional route print -4 command will be executed to confirm all needed routes have been removed."
        Invoke-VMScript -ScriptText $checkroute -vm $computername -GuestUser $userO -GuestPassword $passwordO -Server $targetvcenter -ScriptType bat
        write-host ""
        write-host "Are all routes with the 10.246.238.* removed? Hit y for Yes or n for No."
        $yes = read-host
        }
        until ($yes -eq "y") {
        write-host "All non production routes have been removed, process is moving on."
        continue
        }

    }

    
    # check the changes to GW and VXLAN with an nslookup command to an outside FQDN, in this case google.com
    write-host ""
    write-host "Testing IP resolution."
    invoke-vmscript -ScriptText $checkipres -vm $computername -GuestUser $usero -GuestPassword $passwordo -server $targetvcenter -ScriptType Powershell | select-object -expandproperty scriptoutput

    # rename the computer hostname if -rename switch used

        
    # if not -swing, execute this command set
    if (!$swing){
    write-host "$($computer.hostname) will now be re-joined to the $($computer."domain name")."

    # try the domain join, if not verified or an error occurs, restart VM and retry command. 
    try {
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer."domain name" -like "extapp.local") {$netdomjoinEX} else {$netdomjoinAH}) `
    -GuestUser $userO -GuestPassword $passwordO -server $targetvcenter -ErrorAction stop -ScriptType bat | select-object -expandproperty scriptoutput
    write-host ""
    start-sleep 80
    }
    catch {
    write-host "Error in completing command, $($computer.hostname) may not have been joined to $($computer."domain name")."
    write-host ""
    write-host "Restarting guest tools and retrying command."
    Restart-VMGuest -Guest $computername -server $targetvcenter -confirm:$false
    write-host ""
    start-sleep 30
    Invoke-VMScript -vm $computername -ScriptText $(if ($computer."domain name" -like "extapp.local") {$netdomjoinEX} else {$netdomjoinAH}) `
    -GuestUser $user0 -GuestPassword $passwordO -server $targetvcenter -ErrorAction stop  -ScriptType bat | select-object scriptoutput
        }

    }

    #start-sleep 
    if ($rename -and $source){

        $domcheck = get-vmguest $source -server $targetvcconn
            $user1 = $(if ($domcheck.hostname -like '*.extapp.local') {'extrootacct'} else {'administrator'})
                
    write-host ""
    write-host "A password guess will be started for the $source server to do the ipconfig /registerdns step."
    if (!$password1) {
        $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred1 -vm $source -server $targetvcconn -ErrorAction SilentlyContinue #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin1){
            $password1 = $wincred1
            write-host ""
            write-host "$user1 and $wincred1 in use"
            
        }

            $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred2 -vm $source -server $targetvcconn -ErrorAction silentlyContinue #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin2){
            $password1 = $wincred2
            write-host ""
            write-host "$user1 and $wincred2 in use"
            
        }

            $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred3 -vm $source -ErrorAction silentlyContinue -server $targetvcconn #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin3){
            $password1 = $wincred3
            write-host ""
            write-host "$user1 and $wincred3 in use"
            
        }

            $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred4 -vm $source -ErrorAction silentlyContinue -server $targetvcconn #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin4) {
            $password1 = $wincred4
            write-host ""
            write-host "$user1 and $wincred4 in use"
            
        }

            $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $localpass -vm $source -ErrorAction SilentlyContinue -server $targetvcconn #|  Select-Object -ExpandProperty scriptoutput

        if ($testadmin5) {
            $password1 = $localpass
            write-host ""
            write-host "$user1 and $localpass in use"
            
        }

    }

    if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
        write-host ""
        write-host "$($source) unable to determine admin account password."
        write-host "Trying with alternative Accretivehealth username extrootacct."
        $user1 = "extrootacct"

        $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred1 -vm $source -ErrorAction SilentlyContinue -server $targetvcconn  #| Select-Object -ExpandProperty scriptoutput
        if ($testadmin1){
            $password1 = $wincred1
            write-host ""
            write-host "$user1 and $wincred1 in use"
            
        }

        $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred2 -vm $source -ErrorAction silentlyContinue -server $targetvcconn #| Select-Object -ExpandProperty scriptoutput
        if ($testadmin2){
            $password1 = $wincred2
            write-host ""
            write-host "$user1 and $wincred2 in use"
            
        }

        $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred3 -vm $source -ErrorAction silentlyContinue -server $targetvcconn #| Select-Object -ExpandProperty scriptoutput
        if ($testadmin3){
            $password1 = $wincred3
            write-host ""
            write-host "$user1 and $wincred3 in use"
            
        }

        $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $wincred4 -vm $source -ErrorAction silentlyContinue -server $targetvcconn #| Select-Object -ExpandProperty scriptoutput
        if ($testadmin4) {
            $password1 = $wincred4
            write-host ""
            write-host "$user1 and $wincred4 in use"
            
        }

        $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $user1 -GuestPassword $localpass -vm $source -ErrorAction SilentlyContinue -server $targetvcconn #| Select-Object -ExpandProperty scriptoutput

        if ($testadmin5) {
            $password1 = $localpass
            write-host ""
            write-host "$user1 and $localpass in use"
            
        }

    # if all of the above attempts fail, break the script. 
        if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
        write-host ""
        write-host "$($source) unable to determine admin account password. Server needs SSH process."
        
        }

        }
    
    $dnssuffix = "`$network = get-wmiobject win32_networkadapterconfiguration -filter `"ipenabled = 'true'`"
    `$network.setdynamicdnsregistration(`$true,`$true)"

    if ($testadmin1 -or $testadmin2 -or $testadmin3 -or $testadmin4 -or $testadmin5){
    Invoke-VMScript -ScriptText $dnssuffix -vm $source -server $targetvcconn -ErrorAction stop -GuestUser $user1 -GuestPassword $password1
    Invoke-VMScript -ScriptText $registerdns -VM $source -Server $targetvcconn -ErrorAction stop -ScriptType bat -guestuser $user1 -GuestPassword $password1  | select-object -ExpandProperty ScriptOutput
    }
    }
    # test domain join with execution of command using $domaincred variable information
    write-host "$($computer.hostname) will now be tested for domain logon."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $testdomain -GuestCredential $domaincred -Server $targetvcenter -ErrorAction stop -ScriptType bat | select-object -expandproperty scriptoutput

    # set different command set for OS version, one for 2008R2 and one for 2012R2. 
    if ($vm.guest -like "*2012*"){
    write-host "Timezone to be set to Eastern Standard time."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $timezone -GuestCredential $domaincred -Server $targetvcenter -ScriptType bat | select-object -expandproperty scriptoutput
    write-host "Time zone will be verified."
    write-host ""
    Invoke-VMScript -vm $computername -ScriptText $timezoneck -GuestCredential $domaincred -Server $targetvcenter -ScriptType bat | select-object -expandproperty scriptoutput
        }

if ($rename){
    $adgroups = "([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/release management team,group`")
    ([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/etl_prod_support,group`")
    ([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/dba-adm,group`")
    ([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/ach-dba,group`")
    ([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/prodmonty-adm,group`")
    ([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/middleware admin_ad,group`")"
    
Invoke-VMScript -vm $computername -ScriptText $adgroups -GuestCredential $domaincred -server $targetvcenter | select -expandproperty ScriptOutput
}
    

# change the local admin password to the new local password agreed upon by the customer for the end state. 
if ($passwordO -notlike $wincred4 -and !$nic){
    $changeadmin = $(if ($usero -like "ahrootacct") {'net user "ahrootacct" 9s4"&"**#rpT=M'} elseif ($usero -like "extrootacct") `
    {'net user "extrootacct" P@ssw0rd!'} else {'net user "administrator" P@ssw0rd!'})
    $changeadminext = 'net user "extrootacct" P@ssw0rd!'

    write-host "Changing local admin password."
    invoke-vmscript -vm $computername -ScriptText $( if($computer."domain name" -like "extapp.local") {$changeadminext} else {$changeadmin}) `
    -GuestCredential $domaincred -server $targetvcenter #| select-object -ExpandProperty scriptoutput
    $passwordO = $wincred4

        }
    



    # if local admin password already set to the agreed upon end state, do nothing. 
    else {
    write-host "password change for $($computer.hostname) will be skipped."
    $skipped += $computer.hostname
        }
    write-host ""
    write-host "Process for $($computer.hostname) complete."


    $toolsver = $vm | get-vmguest -server $targetvcenter
    $running = $toolsver | where {$_.state -like "running"}

    $current = get-vmguest $computername -Server $targetvcenter | Where-Object {$_.state -like "running" -and $_.ToolsVersion -like $(if ($targetvcenter -eq $drptargetvcconn) {"10.3.*"} else {"10.1.*"})}

    if (!$running){
        write-host "Tools not running on $($computer.hostname). Process halting."
        break
    }

# is server powered on?
if ($running -and !$current){
    write-host "Updating VMtools version."

    # if vm does not have a CD/DVD device installed, shut down VM and set device, halt script. 
    # if running but not correct version, update tools with no reboot
    write-host "Tools version out of date, updating version."

    Update-Tools -VM $computername -Server $targetvcenter -ErrorAction SilentlyContinue -NoReboot:$true
    write-host ""
    start-sleep 50
    Restart-VMGuest $computername -Server $targetvcenter -confirm:$false 
    start-sleep 40
    }

    else {write-host "$($computer.hostname) version up to date."}

    }
    

}
