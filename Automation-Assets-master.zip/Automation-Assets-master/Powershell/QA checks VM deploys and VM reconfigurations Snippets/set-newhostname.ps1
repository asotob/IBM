#script will rename a vCenter object and then rename the hostname on the server in Active directory. Valid permissions required for both AD and vCenter

param (
    [parameter(mandatory=$true)]
    [string[]]
    $server,

    [parameter()]
    [string]
    $targetvcusername,

    [parameter()]
    [string]
    $targetvcenter,

    [parameter()]
    [string]
    $targetvcpasswd,

    [parameter()]
    [string[]]
    $newname


    )

    if (!$domaincred){
    write-host "Input name of domain admin account."
    $userD = read-host
    write-host ""
    write-host "Input your domain admin password."
    $passwordD = read-host -AsSecureString
    $domaincred = new-object system.management.automation.pscredential($userD, $passwordD)
    
        }

# if not $targetvcenter, force input for establishing the vCenter IP or name, username and password required for connecting. Setting $vccred = 
# get-credential username@vcenter.local will establish the user credentials for all connections to vCenter. Setting $targetvcenter = connect-viserver

if (!$targetvcconn){
#if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
    if (!$targetvcenter){
    write-host "input name or IP of source vCenter."
    $targetvcenter = (read-host)
    write-host ""
        }
    if (!$targetvcusername){
    write-host "input name of source vCenter Username in name@domain format."
    $targetVCUsername = (read-host)
    write-host ""
        }
    write-host ""
    write-host "input the vCenter password."
    $targetvcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcred = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)

}

#get source vCenter, if not already set, set the variable $targetvcconn
if (!$targetvCConn){
$targetvCConn = Connect-VIServer -server $targetvcenter -Credential $vCcred -port 443 -ErrorAction SilentlyContinue

# if not already set, establish the bypass for ignoring the unverified server certificate or that workstation does not have a certificate
# that matches what is set in vcenter. 

Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
    }
    #else {connect-viserver -server $targetvcenter -session $targetvcconn.sessionid }


#begin execution portion of script, loop can take multiple targets for -server and -newname as long as they are in order of execution

foreach ($computer in $server){

$computername = get-vm $server -server $drptargetvcconn 

$newhostname = "netdom renamecomputer localhost /newname $newname /force /reboot"
$testdomain = 'hostname'
$newhostnameEX = "netdom.exe renamecomputer localhost /newname $newname /UserD:accretivehealth\$($domaincred.username) /PasswordD:$(get-content ./creds.txt) /ReBoot /force"


$rename = set-vm -vm $computername -name $newname -server $targetvcenter -Confirm:$false
start-sleep 5
$domain = get-vm $rename -server $targetvcenter | Get-VMGuest
write-host ""
write-host "$server renamed to $rename"
start-sleep 10
write-host ""
write-host "$rename hostname property will now be changed and a reboot executed."

if ($domain.hostname -like '*.accretivehealth.local'){
Invoke-VMScript -ScriptText $newhostname -server $targetvcenter -vm $rename -GuestCredential $domaincred -scripttype bat -ErrorAction SilentlyContinue | select-object -ExpandProperty scriptoutput
}

else {
Invoke-VMScript -ScriptText $newhostnameEX -server $targetvcenter -vm $rename -GuestUser 'extrootacct' -GuestPassword 'Allyourbasearebelongtous....' -ErrorAction SilentlyContinue | select-object -ExpandProperty scriptoutput
}

start-sleep 140

invoke-vmscript -ScriptText $testdomain -vm $rename -GuestCredential $domaincred -server $targetvcenter -ScriptType bat | select-object -ExpandProperty scriptoutput


}
