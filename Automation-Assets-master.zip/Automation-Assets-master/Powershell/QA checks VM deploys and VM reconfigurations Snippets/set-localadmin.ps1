#script is for setting the local admin to any windows server, an edit will need to be made to the command section for the appropriate AD groups required

param (

    [parameter()]
    [string]
    $targetvcusername,

    [parameter()]
    [string]
    $targetvcenter,

    [parameter()]
    [string]
    $targetvcpasswd,

    [parameter()]
    [string]
    $usero,

    [parameter()]
    [string]
    $passwordo,

    [parameter()]
    [string[]]
    $server,

    [parameter()]
    [string]
    $folder

    )
  
  
   if (!$targetvcconn){
#if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
    if (!$targetvcenter){
    write-host "input name or IP of source vCenter."
    $targetvcenter = (read-host)
    write-host ""
        }
    if (!$targetvcusername){
    write-host "input name of source vCenter Username in name@domain format."
    $targetVCUsername = (read-host)
    write-host ""
        }
    write-host ""
    write-host "input the vCenter password."
    $targetvcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcred = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)

}

#get source vCenter, if not already set, set the variable $targetvcconn
if (!$targetvCConn){
$targetvCConn = Connect-VIServer -server $targetvcenter -Credential $vCcred -port 443 -ErrorAction SilentlyContinue

# if not already set, establish the bypass for ignoring the unverified server certificate or that workstation does not have a certificate
# that matches what is set in vcenter. 

Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
    }
    #else {connect-viserver -server $targetvcenter -session $targetvcconn.sessionid }

#local passwords that exist in environment, for use with the password guessing process. These will need to reflect current useage in environment
$wincred1 = 'Allyourbasearebelongtous....'
$wincred2 = 'Letmein2'
$wincred3 = 'g0T!gersg0'
$wincred4 = 'P@ssw0rd!'
$localpass = '9s4&**#rpT=M'


# start the scripted process

if ($folder){
$servers = get-vm -location $folder -server $targetvcenter -NoRecursion | select name
}
else {$servers = get-vm $server -server $targetvcenter | select name}


foreach ($computer in $servers.name){
$computername = $computer
#reset variables
$testadmin1 = $null
$testadmin2 = $null
$testadmin3 = $null
$testadmin4 = $null
$testadmin5 = $null
if (!$usero){
$usero = $null
}
if (!$passwordo){
$passwordo = $null
}
    $testadmin = $null
    $testdomain = 'hostname'

   
        # if there is a difference between local admin between multiple domains, this section defines what to set $usero to. if not required, it can be commented out
        $domcheck = get-vmguest $computername -server $targetvcenter
            if (!$usero) {$usero = $(if ($domcheck.hostname -like '*.extapp.local') {'extrootacct'} else {'administrator'})
            }
            else {$usero = $usero}

    write-host ""
    write-host "A password guess will be started for the $computername server to add the domain groups."

    #begin password guessing process, this will try each password one at a time until a match is found, then sets $passwordo to the discovered password
    if (!$passwordo) {
        $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred1 -vm $computername -server $targetvcenter -ErrorAction SilentlyContinue #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin1){
            $passwordO = $wincred1
            write-host ""
            write-host "$usero and $wincred1 in use"
           
        }

         $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred2 -vm $computername -server $targetvcenter -ErrorAction silentlyContinue #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin2){
            $passwordO = $wincred2
            write-host ""
            write-host "$usero and $wincred2 in use"
            
        }

         $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred3 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin3){
            $passwordO = $wincred3
            write-host ""
            write-host "$usero and $wincred3 in use"
            
        }

         $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred4 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
         if ($testadmin4) {
            $passwordO = $wincred4
            write-host ""
            write-host "$usero and $wincred4 in use"
            
        }

         $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $localpass -vm $computername -ErrorAction SilentlyContinue -server $targetvcenter #|  Select-Object -ExpandProperty scriptoutput

        if ($testadmin5) {
           $passwordO = $localpass
           write-host ""
           write-host "$usero and $localpass in use"
           
        }

        # If all of the above fail, use the following sequence to guess the password using the alternate local admin username for each password again.
        # this accounts for the machines that used to be members of one domain but are now in another thus breaking the mold. 

           if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
            write-host ""
            write-host "$($computer.hostname) unable to determine admin account password."
            write-host "Trying with alternative Accretivehealth username extrootacct."
            $userO = "extrootacct"

            $testadmin1 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred1 -vm $computername -ErrorAction SilentlyContinue -server $targetvcenter  #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin1){
               $passwordO = $wincred1
               write-host ""
               write-host "$usero and $wincred1 in use"
              
           }
   
            $testadmin2 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred2 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin2){
               $passwordO = $wincred2
               write-host ""
               write-host "$usero and $wincred2 in use"
               
           }
   
            $testadmin3 =    Invoke-VMScript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred3 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin3){
               $passwordO = $wincred3
               write-host ""
               write-host "$usero and $wincred3 in use"
               
           }
   
            $testadmin4 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $wincred4 -vm $computername -ErrorAction silentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
            if ($testadmin4) {
               $passwordO = $wincred4
               write-host ""
               write-host "$usero and $wincred4 in use"
               
           }
   
            $testadmin5 =    Invoke-vmscript -ScriptText $testdomain -GuestUser $userO -GuestPassword $localpass -vm $computername -ErrorAction SilentlyContinue -server $targetvcenter #| Select-Object -ExpandProperty scriptoutput
   
           if ($testadmin5) {
              $passwordO = $localpass
              write-host ""
              write-host "$usero and $localpass in use"
              
           }

        # if all of the above attempts fail, break the script. 
           if (!$testadmin1 -and !$testadmin2 -and !$testadmin3 -and !$testadmin4 -and !$testadmin5) {
            write-host ""
            write-host "$($computer.hostname) unable to determine admin account password. Server needs SSH process."
            continue
           }
    
           }
        }
    else {$passwordo = $passwordo}

# set the AD groups required on the server's local admin group. Change the desired ://domainname/AD group name

$adgroups = "([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/release management team,group`")
([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/etl_prod_support,group`")
([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/dba-adm,group`")
([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/ach-dba,group`")
([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/prodmonty-adm,group`")
([adsi]`"WinNT://./administrators,group`").Add(`"WinNT://accretivehealth/middleware admin_ad,group`")"

Invoke-VMScript -vm $computername -ScriptText $adgroups -guestuser $usero -GuestPassword $passwordo -server $targetvcenter 
        
continue
}