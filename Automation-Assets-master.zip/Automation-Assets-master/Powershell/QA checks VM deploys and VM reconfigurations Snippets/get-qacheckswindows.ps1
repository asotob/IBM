﻿##########################################################
#
# QA script, windows workload verification Post migration
#
# Author: Phillip Bryant, Mike Martorano IBM
# Date : 7/19/2018
#
##########################################################

##########################################################
#
# Help and information section
#
##########################################################
<#
.SYNOPSIS
This version 1 script executes all tests as well as the data evaluations in serial (i.e. one server at a time), one server at a time. 
Author: Phillip Bryant, written for IBM R1 project activities for Quality Assurance of migrated workloads, August 2018.
Designer: tests designed by Steve Jackson, July 2018. 

.DESCRIPTION
get-qacheckswindows.ps1 executes a series of individual windows server checks to validate proper synchronization of VM workloads from a source environment
to a target VMware environment. In the case of R1 (see case study at URL) the source was a Microsoft System Center Virtual Machine Manager hypervisor and the 
-hyperv switch was to designate a data scan on the produciton VMs, that switch identification can be modified for other uses, just make sure you modify all of 
the instances in this script. Script automatically creates a folder structure with the day's date to ensure a consistent area for report generation.

The script uses a definition of the following syntax: type of test, meaning OS, or VM, or Network and a number to designate which OS test. The full guide to
these definitions can be found here (URL). Each test is documented in the script comments sections. There are a total of 36 VM, OSI, OSD, ST (storage) and Net 
tests configured here. Each will either output to a report file or evaluate pass/fail based on test logic in the script. Each test either has a pass, fail, inventory,
or skipped result dependent upon the specific parameters executed. See the examples section for further information. 

Script needs to be executed, dependent upon network design and workstation access, either three times or twice. If vCenter and target (where workloads are being
migrated to) are on the same segment and no firewall prevents access, the -vcenter and -inventory switches can be used in the same session. vCenter tests will 
execute first and then the -inventory second. Both will output an individual report file. The -hyperv run should be executed last as it is dependent upon output
from both the -vcenter and the -inventory runs. 

These can be further modified by using the -critical or the -net switches. Switches are documented in the parameter help and how they should be used. Once all runs
are complete, the report files can be collated into one for overall reporting purposes. Each run will either return a pass, fail, skipped, or invetory result. Inventory
is denoted for those tests that will not be evaluated that run, i.e. on the -inventory run. They are dumped to a file for evaluation for the -hyperv run. Pass and Fail
results in the -inventory run are final results and only meant to judge the fitness of the VMs in the target environment and do not require evaluation with the machine 
state in the source or -hyperv environment. 

This script is intended to aid in the troubleshooting and evaluation of a migration program and overall state of each VM as it is spun up in the target. Some tests will
only rely upon certain markers in the OS while others will require input of specific data, i.e. IP address, DNS server search order, default gateway etc. to be able to
render a pass/fail verdict. Tests are to be used to diagnose issues for remediation prior to a big cut over weekend (-net tests geared for this type of activity) whereas
the full battery of tests are to help ID problems prior to cut over activities. 

.PARAMETER
-File. When used, the -file will require a FQDN path or a .\ path to a .csv file name with tab delimeter. This file, at a minimum must contain the following column headers:
name ip-address domain. For further use of tests, these additional columns should be present: raid_drive dns_servers routing backup_server app_pool_servers load_balancer 
lb_vip_addr firewall_subnet other_subnet. 

.PARAMETER
-vCenter. This iniates a request for logon iformation for the target vCenter server and then takes either the server names from the input file or a dynamic collection of
workloads on the vCenter server and begins looking at each in turn to either gather information for a dump file or checking for a pass/fail state on tools version, guest 
tools installed, running state, etc. This can be run in conjunction with the -inventory switch if both the vCenter and the individual servers running on the VMware hosts can
be connected to from the same network segment. This switch produces its own report. 

.PARAMETER
-Inventory. This initiates a request for logon information for the source System Center Virtual Machine Managment server and for remote powershell logon to the source servers. 
If utlized (current state of the SCVMM checks are commented out in this script) the script will connect to the SCVMM and check each named server, comparing data dumped from
the vCenter run with present state in SCVMM and render a pass or fail result if the two environments differ and then it will attempt connections with each running server
in the source environment to begin the simultaneous checks and then the data analysis and individual network checks. Tbis switch produces its own report.

.PARAMETER
-Compare. This initiates a request for logon information for an account with rights to make remote powershell connections to windows workloads in the target environment. 
This will start the simultaneous server tests and then move on to the one at a time data analysis from data gathered during the simultaneous tests and either render a 
pass or fail or, if the data was written to a dump file, inventory result. This run can be modified by wither the -critical switch, or the -net switch which run a smaller
subset of tests as required. This switch produces its own report. 

.PARAMETER
-Critical. This switch initiates a subset of the tests in both the -inventory and -hyperv tests. Please see README file that accompanied this script for test definitions.
This -switch can only be run when accompanied by the -inventory or the -hyperv switches. This does not produce its own report but produces either the target report to be
found in the target folder or the source report to be found in the source folder. This test can be modified to add/remove other elements using the $critical variable and 
adding additional named elements to the report section at the bottom of the script. 

.PARAMETER
-Net. This swtich initates just two of the network tests as deemed by the R1 project to be most critical to cut over activities. This test can be altered by adding additional 
tests to the $net parameter and variable setting as well as additional named output in the report section at the bottom of the script. 

.PARAMETER
-test. This switch is used to run any test but with additional connectivity requirements like unique subnet, IP, or machine name information if development of the script differs
from the target or source environment. For instance, if testing on stand alone VMs without domain controllers and FQDNs that do not conform to the production environment, the -test
switch can be used to validate the results of the tests without undue modification later for deployment. All tests are set to look for the -test switch before modifying what is checked.
All variable sections have a $test sequence that can be modified for differing subnets and IPs or server names. The same reports are generated and all tests run based upon either the
-inventory, -hyperv, -critical, or -net switches. 

.EXAMPLE
Run a full spread of the tests on a vCenter and target environment. Will generate two report files, one in the vcenter folder and one in the target folder, additional data dump files
will also be generated in each for use in running a compare against the source environment. Adding the -test switch here will allow for the use of unique

get-qawindowschecks.ps1 -file .\pathtofile.csv -vcenter -inventory

.EXAMPLE
Run a smaller set of tests on a target or source environment. Each will produce a report and dump files in either the source or target directories. 

get-qawindowschecks.ps1 -file .\pathtofile.csv -(inventory or -compare) -critical 

.EXAMPLE
Run a network only set of tests that are geared for basic checking of migrated workloads in the target environment. The -net switch is only meant for use with the -inventory switch. 
Optional switch is -test with this, for development off network purposes only. 

get-qawindowschecks.ps1 -file .\pathtofile.csv -inventory -net 

.EXAMPLE
Run a vCenter only report. This will only check vCenter in the target environment for VM settings and then report the findings. Two dump files will be generated for comparison later
when the -hyperv run is initiated. 

get-qawindowschecks.ps1 -file .\pathtofile.csv -vcenter

.EXAMPLE
Run a vCenter only report where every VM is inspected without an input file. This will generate a report in the vcenter folder and two dump files. 

get-qawindowschecks.ps1 -vcenter

.EXAMPLE
Run a Hyperv only report using an input file. Will generate a source report and utilize dump reports from the previous -vcenter and -inventory runs to do a final comparison between
source VMs and target VMs. This report should only be run when the full -inventory report has been run (i.e. no use of -net or -critical) as the reports will append and the dump files
will only generate the selected data. Trying to mix runs will generate errors to appending and to evaluating the tests when certain files do not exist. 

get-qawindowschecks.ps1 -file .\pathtofile.csv -compare

.NOTES
This script was developed with a specific set of required quality assurance checks requested by the R1 migration project. Steve Jackson developed the battery of tests that would
check OS operability, the cloning and configuration of the target VMs, domain and network operability and load balancer tests. Script in its current state was made production for
project use and went through several iterations leading to this second version that would execute most tests simultaneously for data gathering. The -net set of tests was a request for
just certain checks. 

#>

##########################################################
#
# Parameters section
#
##########################################################
param (
    [parameter()]
    [switch]
    $file,

    #optional parameters for automation use
    [parameter()]
    [string]
    $winuser,

    [parameter()]
    [string]
    $winpasswd,

    [parameter()]
    [string]
    $targetvcusername,

    [parameter()]
    [string]
    $targetvcpasswd,

    [parameter()]
    [string]
    $targetvCenter,

    [parameter()]
    [switch]
    $vcenter,

    [parameter()]
    [switch]
    $compare,

    [parameter()]
    [switch]
    $inventory,

    [parameter()]
    [switch]
    $critical,

    [parameter()]
    [switch]
    $test,

    [parameter()]
    [switch]
    $net,

    [parameter()]
    [string]
    $serverck,

    [parameter()]
    [string]
    $wave,

    [parameter()]
    [switch]
    $iso,

    [parameter()]
    [switch]
    $prd,

    [parameter()]
    [switch]
    $full
    
    )


##########################################################
#
# Functions Section
#
##########################################################

function Get-winGroupMember {
<#
.SYNOPSIS   
Retrieves the members of a local group
    
.DESCRIPTION 
The script can use a remote of local ComputerName as input and will list the group members

.PARAMETER ComputerName
The name of the computer(s) that will be queried their respective group members
	
.PARAMETER LocalGroup
The name of the local group

.NOTES   
Name       : Get-GroupMember.ps1
Author     : Jaap Brasser
Version    : 1.0.1
DateCreated: 2016-08-02
DateUpdated: 2016-08-15

.LINK
http://www.jaapbrasser.com

.EXAMPLE
. .\Get-GroupMember.ps1

Description
-----------
This command dot sources the script to ensure the Get-GroupMember function is available in your current PowerShell session

.EXAMPLE   
Get-GroupMember Administrators

Description
-----------
Gets the group members of the Administrators group on the local system

.EXAMPLE   
Get-GroupMember -ComputerName 'Server01','Server02' -LocalGroup Administrators

Description
-----------
Gets the group members of the Administrators group on both Server01 and Server02

.EXAMPLE   
Get-GroupMember -ComputerName 'Server01','Server02' -LocalGroup Administrators,Users

Description
-----------
Gets the group members of the Administrators and the Users groups on both Server01 and Server02
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, position = 0)]
        [Alias('Group')]
        [string[]]
            $LocalGroup,
        [parameter(position = 1)]
        [Alias('CN','Computer')]
        [string[]]
            $ComputerName = '.'
    )

    foreach ($Computer in $ComputerName) {
        Write-Verbose "Checking membership of localgroup: '$LocalGroup' on $Computer"
	    try {
            foreach ($Group in $LocalGroup) {
                ([adsi]"WinNT://$Computer/$Group,group").psbase.Invoke('Members') | ForEach-Object {
                    New-Object -TypeName PSCustomObject -Property @{
                        ComputerName = $Computer
                        LocalGroup   = $Group
                        Member       = $_.GetType().InvokeMember('Name', 'GetProperty', $null, $_, $null)
                    }
                }
                Write-Verbose "Successfully checked membership of local group: '$LocalGroup' on $Computer"
            }
	    } catch {
		    Write-Warning $_
	    }
    }	
}

function Get-NetworkStatistics { 
    $properties = ‘Protocol’,’LocalAddress’,’LocalPort’ 
    $properties += ‘RemoteAddress’,’RemotePort’,’State’,’ProcessName’,’PID’ 

    netstat -ano | Select-String -Pattern ‘\s+(TCP|UDP)’ | ForEach-Object { 

        $item = $_.line.split(” “,[System.StringSplitOptions]::RemoveEmptyEntries) 

        if($item[1] -notmatch ‘^\[::’) 
        {            
            if (($la = $item[1] -as [ipaddress]).AddressFamily -eq ‘InterNetworkV6’) 
            { 
               $localAddress = $la.IPAddressToString 
               $localPort = $item[1].split(‘\]:’)[-1] 
            } 
            else 
            { 
                $localAddress = $item[1].split(‘:’)[0] 
                $localPort = $item[1].split(‘:’)[-1] 
            }  

            if (($ra = $item[2] -as [ipaddress]).AddressFamily -eq ‘InterNetworkV6’) 
            { 
               $remoteAddress = $ra.IPAddressToString 
               $remotePort = $item[2].split(‘\]:’)[-1] 
            } 
            else 
            { 
               $remoteAddress = $item[2].split(‘:’)[0] 
               $remotePort = $item[2].split(‘:’)[-1] 
            }  

            New-Object PSObject -Property @{ 
                PID = $item[-1] 
                ProcessName = (Get-Process -Id $item[-1] -ErrorAction SilentlyContinue).Name 
                Protocol = $item[0] 
                LocalAddress = $localAddress 
                LocalPort = $localPort 
                RemoteAddress =$remoteAddress 
                RemotePort = $remotePort 
                State = if($item[0] -eq ‘tcp’) {$item[3]} else {$null} 
            } | Select-Object -Property $properties 
        } 
    } 
} 

function Resolve-DnsName {
    Param
    (
        [Parameter(Mandatory=$true)]
        [string]$Name,
        [string]$Server = '127.0.0.1'
    )
    Try
    {
        $nslookup = &nslookup.exe $Name $Server
        $regexipv4 = "^(?:(?:0?0?\d|0?[1-9]\d|1\d\d|2[0-5][0-5]|2[0-4]\d)\.){3}(?:0?0?\d|0?[1-9]\d|1\d\d|2[0-5][0-5]|2[0-4]\d)$"

        $name = @($nslookup | Where-Object { ( $_ -match "^(?:Name:*)") }).replace('Name:','').trim()

        $deladdresstext = $nslookup -replace "^(?:^Address:|^Addresses:)",""
        $Addresses = $deladdresstext.trim() | Where-Object { ( $_ -match "$regexipv4" ) }

        $total = $Addresses.count
        $AddressList = @()
        for($i=1;$i -lt $total;$i++)
        {
            $AddressList += $Addresses[$i].trim()
        }

        $AddressList | %{

        new-object -typename psobject -Property @{
            Name = $name
            IPAddress = $_
            }
        }
    }
    catch 
    { }
}


##########################################################
#
# Variables section
#
##########################################################
# link http:\\psgallery

#testing only variables
#$file = '\\vmware-host\Shared Folders\Documents\Powershell scripts\input\new-inputfile.txt'
#$vcenter = $false
#$compare = $false
#$inventory = $true

#for local admin check, this array needs to have names of admins who need to be present in the local admin group
#if not present, test will fail
#$whitelist = 'phillip.bryant', 'administrator'

##########################################################
#
# import server list, requires an input file with the 
# following columns in tab delimited format: 
# name, ip-address, domain, dns_servers (if not using 
# more dynamic means second variable section below)
# if -file is set, import the .csv but first check for valid 
# file path or name

if (!$test){
    $path = ".\"
}
else {
    $path = ".\input\"
}

if ($full){
#verify path/name
try {
    $errorcsv = get-content "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -ErrorAction Stop
}
#if $errorcsv = False, notify user of need to re-input path/file of csv
catch {
write-host "incorrect path or file name."
write-host "input path and filename of csv file."
write-host ""
$filep = read-host
if ($test){
$servers1 = import-csv -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -Delimiter "`," | where {$_.wave -like $wave}
}
    
else { $servers1 = import-csv -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -Delimiter "`," | where {$_.wave -like $wave}}
    }
#if $errorcsv test = true, import csv file. 
if ($errorcsv){
    if ($test){
        $servers1 = import-csv -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -Delimiter "`," | where {$_.wave -like $wave}
    }
    
else {
$servers1 = import-csv -path "$path\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -Delimiter "`," | where {$_.wave -like $wave}
    
}}}

if ($serverck){
    try {
        $errorcsv = get-content ".\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" -ErrorAction Stop
            }
        #if $errorcsv = False, notify user of need to re-input path/file of csv
        catch {
        write-host "incorrect path or file name."
        write-host "input path and filename of csv file."
        write-host ""
        $file = read-host
        $servers1 = import-csv -Delimiter "`," -path ".\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" | Where-Object {$_.hostname -like "$serverck"}
            }
        
        #if $errorcsv test = true, import csv file. 
        if ($errorcsv){
        $servers1 = import-csv -Delimiter "`," -path ".\all-columns-$(if ($iso) {"iso"} else {"prd"}).csv" | Where-Object {$_.hostname -like "$serverck"}
            }
        }
        



#########################################################
#
# is there a current source vCenter connection? Uses 
# custom function above to delineate target vCenter from 
# a source vCenter. This is used exclusively for the 
# -vcenter switch.

if (!$targetvcconn -and $vcenter){
    #if no current, get sourcevc name or IP and credentials, check for valid server 2x then terminate
        if (!$targetvcenter){
        write-host "input name or IP of source vCenter."
        $targetvcenter = (read-host)
        write-host ""
            }
        if (!$targetvcusername){
        write-host "input name of source vCenter Username in name@domain format."
        $targetVCUsername = (read-host)
        write-host ""
            }
        write-host ""
        write-host "input the vCenter password."
        $targetvcpasswd = (read-host -AsSecureString) 
    
    #$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    #$vCcred = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)

    }
 
    #get source vCenter
        if (!$targetvCConn -and $vcenter){
    $targetvCConn = Connect-VIServer -server $targetvcenter -User $targetvcusername -password $targetvcpasswd -port 443
    
    Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
    #$servers = get-vm | where {$_.name -like "*-assigned"} | select-object @{Name='Name'; Expression={$_.name.substring(0,$_.name.lastindexof('-'))}}
        }
       elseif ($targetvcconn -and $vcenter) {connect-viserver -server $targetvcconn -session $targetvcconn.sessionid }
    
    

#########################################################
#
# If not using an input file, this command will pull all 
# hosted vms off of the vCenter server. In this instance, 
# filtered by a common nomenclature "-*ssigne*".
# The $servers array is what feeds all other parts of this 
# script and must have machine host names before moving on 
# to other parts. This swtich can be used in conjunction 
# with the -inventory switch to collect information from 
# vCenter and then from the target environment VMs. If 
# you do not use -file and the path
# for the input file, this will build the list of VMs 
# to run checks against. 

<#if ($vCenter){
$servers = vmware.vimautomation.core\get-vm | where {$_.name -like "*-assigned"} 
    }#>

#########################################################
#
# Set connection credentials for windows servers
# if there are mulitple domains this requires that the 
# account has trusted access to all domains were VMs 
# reside in both the target and source environmnet.

if ($winpasswd -and $winuser){
$Winpass = convertto-securestring $winpasswd -asplaintext -force
$wincred = new-object system.management.automation.pscredential($winuser, $winpass)
    }

elseif (!$wincred -and ($inventory -or $compare)){
write-host ""
write-host "Input name of account for Windows Administration."
$username = read-host

$wincred = (get-credential $username -Message "Windows Server Admin")

<#write-host ""
write-host "Input name of account for AccretiveHealth domain."
$username2 = read-host

$wincred2 = (get-credential $username2 -Message "Windows Server Admin Logon AccretiveHealth")
#>
    }
if ($wincred) {}
#########################################################
#
# this is for setting up the connection to the System Center 
# Virtual Machine Manager server, if present in the source 
# environment.
     
<#if ($compare){
    if (!$svcmm){
        write-host "Input name of SCVMM server."
        $scvmm = read-host
        write-host ""
    }

get-scvmmserver -computername $scvmm -credential $wincred
}#>

#########################################################
#
# Path where the reports will be generated and previous 
# runs read from, needs to be consistent throughout. These 
# are created in the root directory from where the script 
# is run. It checks for presence, and if not present creates 
# the root folder and child folders and sets the variable 
# that each export section will use to dump data. 
if (!$test){
    $path = ".\"
}

$testpath = test-path ".\QA_run"

if (!$testpath){
$1stlvl = ""
$target = ""
$source = ""
$vcntr = ""
       $1stlvl = new-item -ItemType directory ".\QA_run"
       $target = new-item -ItemType directory "$1stlvl\target_rpts"
       $source = new-item -ItemType directory "$1stlvl\source_rpts"
       $vcntr = new-item -ItemType directory  "$1stlvl\vcenter_rpts"
        }
else {
$1stlvl =  ".\QA_run"
$target =  "$1stlvl\target_rpts"
$source = "$1stlvl\source_rpts"
$vcntr = "$1stlvl\vcenter_rpts"

$src_files = get-childitem $source
$tgt_files = get-childitem $target
$vtr_files = get-childitem $vcntr

if ($src_files -and $inventory){
    rm $source\*.*
    }
if ($tgt_files -and $compare){
   
    }
if ($vtr_files -and $vcenter){
    rm $vcntr\*.*
    }
    }
    
    

##########################################################
#
# Script execution section
#
##########################################################

#########################################################
#
# these variables set what is displayed in the $report section
# created at the end of this script. These values can be anything
# that you want to show. 

$pass = 'Pass'
$fail = 'Fail'
$skipped = 'Skipped'
$inv = 'Inventory'

#########################################################
#
# begin server by server analysis on data collected either
# by the parallel process or data written to file if -inventory
# switch used. 
#
#########################################################



foreach ($workload in $servers1){

$service_ck = ''
#clear variables
        $vcguest = ""
        $vCstate = ""
        $vCPURAM = ""
        $invc = ""
        $vcguestcl = ""
        $vcguestNIC = ""
        $hostname = ""
        $Domainname = ""
        $Hypervsvc = ""
        $remoteacc = ""
        $login = ""
        $services = ""
        $packages = ""
        $keyapps = ""
        $localsrv = ""
        $runningproc = ""
        $runningsrv = ""
        $localgroups = ""
        $basic_ops = ""
        $crash = ""
        $localdisks = ""
        $raid = ""
        $volume = ""
        $freeapce = ""
        $tcpaddr = ""
        $tcpport = ""
        $tcpsub = ""
        $tcpbkup = ""
        $lbpool = ""
        $lbal = ""
        $LBalVIP = ""
        $errors = ""
        $freespace = ""
        $tcproute = ""
        $tcpdns = ""
        $tcpdnsres = ""
        $tcpres = ""
        $tcpsub = ""
        $fwsub = ""

    if ($vCenter){

    write-host ""
    write-host "Beginning vCenter checks $($workload.hostname)."

        ####################################################
        #
        # collect information from VMware vCenter connection

        #does VM exist in vC? 
        $assignedname = -join($workload.hostname + "-*ssign*")
        $invC_ck = vmware.vimautomation.core\get-vm $assignedname -ErrorAction SilentlyContinue -Server $targetvcconn
        $invC_vmNIC = get-vm $assignedname | get-networkadapter
        $invC_vmCl = get-vm $assignedname | get-cluster
        

        #VMD01 move on through reset of checks if workload is found in vCenter
        if ($invC_ck -and !$critical){
        write-host ""
        write-host "Starting VMD01 test."
        $invC = $pass
            }
        else {$invc = $fail}    

        #VMD02 check for running state
        if (!$critical){
        write-host ""
        write-host "Starting VMD02 Test."
        $invCstate_ck = ""
        $invCstate_ck = $invC_ck | where {$_.powerstate -eq "PoweredOn"}            
            if ($invCstate_ck){
            $vCstate = $Pass
                }
            else {$vCstate = $fail}
            }

        #VMD03 check that vmware tools are updated
        $vCguest_ck = ""
        write-host ""
        write-host "Starting VMD03 Test."
        $vCguest_ck = get-vmguest -vm $assignedname -ErrorAction SilentlyContinue| where {$_.state -like "running" -and $_.toolsversion -like "10.1.*"}
        if ($vCguest_ck){
        $vCGuest = $Pass
            }
        else {$vCGuest = $fail}

        #VMD04 check for assigned CPU/RAM, fail if below threshhold less than 2 cpus and 4 Gb RAM
        $vCPURAM_ck = ""
        write-host ""
        write-host "Starting VMD04 Test."
        $vCPURAM_ck = $invC_ck | select name, numcpu, memorygb
        if ($vcpuram_ck){
        $vCPURAM_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$vcntr\QAreportraw_VMD04.csv" -Encoding Unicode
        $vcpuram = $Inv
            }
        else {$vcpuram = $fail}

        #VMD05 check for guest heartbeat status
        if (!$critical){
        write-host ""
        write-host "Starting VMD05 Test."
        $vCGuestHB_ck = ""
        $vCGuestHB_ck = $invC_ck.ExtensionData | where {$_.guestheartbeatstatus -eq "green"}
            if ($vCGuestHB_ck){
            $vCGuestHB = $pass
                }
            else {$vCGuestHB = $fail}

        #VMD06, check for E1000 Network adapters
        write-host ""
        write-host "Starting VMD06 Test."
        $vcGuestNIC_ck = ""
        $VcGuestNIC_ck = $invC_vmNIC | where {$_.type -notlike "E100*"}
                if ($vcguestNIC_ck){
                    $VcGuestNIC = $pass
                }
                else {$vCGuestNIC = $fail}

        #VMD07, check for cluster
        write-host ""
        write-host "Starting VMD07 Test."
        $vcGuestCl_ck = ""
        $vcguestCl_ck = $invC_vmCL | where {$_.name -like "prd0*"}
                if ($vcguestCl_ck){
                    $vcguestcl = $pass
                }
                else {$vcguestcl = $fail}

            }

        #OSI01 check guest OS information
        if (!$critical){
        write-host ""
        write-host "Starting OSI01 Test."
        $vCGuestOS_ck = ""
        $vCGuestOS_ck = $invC_ck | select name, guestid         
            if ($vCGuestOS_ck){
            $vCGuestOS = $inv
            $vcGuestOS_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$vcntr\QAreportraw_OSI01.csv" -Encoding Unicode            
                }
            else {$vCguestOS = $fail}
            }
                

        #skip other tests on the report
        $hostname = $skipped
        $Domainname = $skipped
        $Hypervsvc = $skipped
        $remoteacc = $skipped
        $login = $skipped
        $services = $skipped
        $packages = $skipped
        $keyapps = $skipped
        $localsrv = $skipped
        $runningproc = $skipped
        $runningsrv = $skipped
        $localgroups = $skipped
        $basic_ops = $skipped
        $crash = $skipped
        $localdisks = $skipped
        $raid = $skipped
        $volume = $skipped
        $freeapce = $skipped
        $tcpaddr = $skipped
        $tcpport = $skipped
        $tcpsub = $skipped
        $tcpbkup = $skipped
        $lbpool = $skipped
        $lbal = $skipped
        $LBalVIP = $skipped
        $errors = $skipped
        $freespace = $skipped
        $tcproute = $skipped
        $tcpdns = $skipped
        $tcpdnsres = $skipped
        $tcpres = $skipped
        $tcpsub = $skipped
        $fwsub = $skipped



    }       


        ####################################################
        #
        # collect information from SCVMM connection   

    if ($compare){

    write-host ""
    write-host "Skipping SCVMM checks on $($workload.name)."

    #skip non-inventory tests
    $invC = $skipped
    $vCState = $skipped
    $vCGuest = $skipped
    $vCGuestHB = $skipped
    $vcGuestOS = $skipped
    $vCPURAM = $skipped

<#

    #connect and collect SCVMM data on supplied list of VMs from -file
    $inHV_ck = get-scvirtualmachine -name $workload.name -vmmserver $svcmm
    if ($inHV_ck){
        

    #check attached CPU and RAM compared to vCenter if previous inventory report exists   
    $vCPURAM_rpt = test-path -Path "$path\$vcntr\QAreportraw_VMD04.csv" 
        if (!$vCPURAM_rpt){
            write-host "Error reading VMD04 inventory file. Halting this check."
            $vCPURAM = $fail
            }
        else {
            $vCPURAM_rpt = import-csv -Delimiter "`t" -Path "$vcntr\QAreportraw_VMD04.csv" | where {$_.name -like $workload.name} `
            | select-object @{Name='Name'; Expression={$_.name.substring(0,$_.name.lastindexof('-'))}}
            $vCPU_cmpr = compare $vCPURAM_rpt.numcpu  $inHV_ck.cpucount -IncludeEqual | where {$_.sideindicator -like "<="}
            $vRAM_cmpr = compare $vCPURAM_ck.memorygb $inHV_ck.memory/1G -IncludeEqual | where {$_.sideindicator -like "<="}
                if ($vCPU_cmpr -or $vRAM_cmpr){
                $vCPURAM = $fail    
                    }
            }

    #check SCCM OS type and compare with vCenter
    $vGuestOS_rpt = test-path -path "$path\$vcntr\QAreportraw_OSI01.csv"
        if (!$vGuestOS_rpt){
            write-host "Error reading OSI01 inventory file. Test will be marked as Fail."
            $vGuestOS = $fail
            }
        else {
            $vGuestOS_rpt = import-csv -Delimiter "`t" -Path "$vcntr\QAreportraw_OSI01.csv" | where {$_.name -like $workload.name} `
            | select-object @{Name='Name'; Expression={$_.name.substring(0,$_.name.lastindexof('-'))}}
            $vGuestOS_cmpr = $vGuestOS_rpt | where {$_.guestid -like $inHV_ck.operatingsystem}
                if ($vGuestOS_cmpr){
                    $vGuestOS = $pass
                    }
                else {$vGuestOS = $fail}

                }



            }
        else {
            $vGuestOS = $fail
            $vCPURAM = $fail
            }
     #>         
    }

        ####################################################
        #
        # begin remote powershell checks


# collect information from the individual VM, if remote connection fails, fail all tests

if ($inventory -or $compare){

    #skip non-inventory tests
    $invC = $skipped
    $vCState = $skipped
    $vCGuest = $skipped
    $vCGuestHB = $skipped
    $vCPURAM = $skipped
    $vCGuestOS = $skipped
    $vCGuestnic = $skipped
    $vcGuestcl = $skipped

    
    foreach ($rps in $workload){
    
    #clearing variables in case there's an issue connecting to next in line server
        $hostname = ""
        $Domainname = ""
        $Hypervsvc = ""
        $remoteacc = ""
        $login = ""
        $services = ""
        $packages = ""
        $keyapps = ""
        $localsrv = ""
        $runningproc = ""
        $runningsrv = ""
        $localgroups = ""
        $basic_ops = ""
        $crash = ""
        $localdisks = ""
        $raid = ""
        $volume = ""
        $freeapce = ""
        $tcpaddr = ""
        $tcpport = ""
        $tcpsub = ""
        $tcpbkup = ""
        $lbpool = ""
        $lbal = ""
        $LBalVIP = ""
        $errors = ""
        $freespace = ""
        $tcproute = ""
        $tcpdns = ""
        $tcpdnsres = ""
        $tcpres = ""
        $tcproute = ""
        $fwsub = ""
        $pscheck = ""


    
    write-host ""
    write-host "Beginning OS and network checks on $($rps.hostname).$($rps."domain name")"

    #check for running services
   try {
  
   $pscheck = new-PSSession -ComputerName $(if (!$test) {"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname}) -Credential $wincred -name $rps.hostname -ErrorAction stop 
        }
   catch {
   #$pscheck = new-PSSession -ComputerName $rps.name -Credential $wincred2 -name $rps.name 
        write-host "Cannot connect to $($rps.hostname), all tests marked as fail."

        ####################################################################
        #
        # builds report for all failed remote powershell connections. 
        
        $hostname = $fail
        $Domainname = $fail
        $Hypervsvc = $fail
        $remoteacc = $fail
        $login = $fail
        $services = $fail
        $packages = $fail
        $keyapps = $fail
        $localsrv = $fail
        $runningproc = $fail
        $runningsrv = $fail
        $localgroups = $fail
        $basic_ops = $fail
        $crash = $fail
        $localdisks = $fail
        $raid = $fail
        $volume = $fail
        $freeapce = $fail
        $tcpaddr = $fail
        $tcpport = $fail
        $tcpsub = $fail
        $tcpbkup = $fail
        $lbpool = $fail
        $lbal = $fail
        $LBalVIP = $fail
        $errors = $fail
        $freespace = $fail
        $tcproute = $fail
        $tcpdns = $fail
        $tcpdnsres = $fail
        $tcpres = $fail
        $fwsub = $fail
       }


        #############################################################
        #
        #begin performing individual checks OS INformation section

        ##########################################################
        #
        #Variable section, set test specific IPs and other 
        #test options here

        #########################################################
        #
        # NET04 DNS server search order, edit the levels based on 
        # domain, the 'else' section is for off network testing
        # for the first section, only set for -inventory runs. 
        # Sets the IPs to check based on domain for the network 
        # bubble environment. The second section is for workloads 
        # moved to the production network and require different IP 
        # addresses to be verfied. These settings will be compared
        # with what has been collected from the parallel section.

        if ($compare -or $net){
        $tcpdnsips = ""
        if ($rps."domain name" -like 'extapp.local' -and !$test){
        $tcpdnsips = '10.246.238.4','10.246.238.5'
            }
        elseif ($rps."domain name" -like 'accretivehealth.local' -and !$test){
        $tcpdnsips = '10.246.238.2','10.246.238.3'
            }
        else {
        $tcpdnsips = '172.16.98.190','172.16.98.2'
            }
        }

        #########################################################
        # 
        # NET05 IP address ranges per domain for local hosts test, 
        # chooses DNS servers in this instance. Use different IPs
        # for -inventory use vs. when -net is used. -inventory is
        # used for the bubble network, -net for the production 
        # migration. This test is one at a time per server. The else
        # sections are used with -test for off network development.

        if ($compare -or $net){
        $tcpresips = ""
        if ($rps."domain name" -like 'extapp.local' -and !$test){
        $tcpresips = '10.246.238.2','10.246.238.3'
            }
        elseif ($rps."domain name" -like 'accretivehealth.local' -and !$test){
        $tcpresips = '10.246.238.4','10.246.238.5'
            }
        else {
        $tcpresips = '172.16.98.190','172.16.98.193'
            }
        }


        #########################################################
        #
        # NET09 route subnet tests. Sets the additional subnets for
        # each vm to test for firewall access through. Can have any
        # number of IPs set, this test is one at a time per server.
        # else sections for use with -test and off network development

        if ($compare -or $net){
        $tcpsubnets = ""
        if ($rps."domain name" -like 'extapp.local' -or $rps."domain name" -like 'accretivehealth.local' -and !$test){
        $tcpsubnets = '10.246.230.1','10.246.236.291','10.246.238.2','10.246.228.1'
            }
        else {
        $tcpsubnets = '172.16.98.2','10.0.0.1'}
        }
        

    #OSI08 check for remote access services and listeners
    if ($pscheck){
    if (!$net){
    write-host ""
    write-host "Starting OSI08 Test"
    $remoteacc = $pass
    }
        

        #############################################################
        # begin performing individual checks OS INformation section

        #########################################################
        #
        # VMD04 RAM and CPU checks, compares the values gathered
        # in the -vcenter collection written to the QAreportraw_vmd04
        # output with what was collected during the paralell data
        # gathered in the above section. Runs only with the -inventory
        # and -file switches. 

        if ($compare){
        write-host ""
        write-host "Starting VMD04 Test."
        $vCPURAM_rpt = import-csv  -Delimiter "`t" -path "$vcntr\QAreportraw_VMD04.csv" |
        where {($_.name -like $(-join($rps.hostname + "-*ssign*")))} | select numcpu,memorygb
        if ($compare -and $vCPURAM_rpt){
            $vram_ck = invoke-command -session $pscheck -command {(get-wmiobject -class win32_physicalmemory | measure capacity  -sum).sum/1Gb}
            $vCPU_ck = invoke-command -session $pscheck -command {get-wmiobject -class win32_processor | select deviceid }
            $vCPURAM_ck = New-Object psobject -property @{
                NumCPU = $($vCpu_ck.deviceid).count
                MemoryGB = $vRAM_ck
                } | select numcpu, memorygb 
            $vRAM_cmpr = compare $vCPURAM_rpt.memorygb $vCPURAM_ck.memorygb -IncludeEqual | where {$_.sideindicator -eq "<="}
            $vCPU_cmpr = compare $vCPURAM_rpt.NumCpu $vCPURAM_ck.numcpu -IncludeEqual | where {$_.sideindicator -eq "<="} 
                if ($vCpu_cmpr -or $vRAM_cmpr){
                $vCPURAM = $fail
                    }
                else {$vCPURAM = $pass}   
                }
            }
        else {$vCPURAM = $skipped}
        



        #########################################################
        #
        # OSI02 does local hostname equal input file? If hostname
        # gathered in the -inventory portion does not match what was
        # written to file in the -inventory run, mark test as a fail
        # only run in the -inventory and -file switches

            if (!$net){
                write-host ""
                write-host "Starting OSI02 Test."
                $hostname_ck = ""
                $hostname_ck = invoke-command -Session $pscheck -command { hostname }
            if ($compare){
                $hostname_rpt = test-path -path "$source\QAreportraw_OSI02.csv" 
                 if ($hostname_rpt){
                 $hostname_rpt = import-csv -Delimiter "`t" "$source\QAreportraw_OSI02.csv" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}
                 $hostname_cmpr = compare $hostname_rpt.hostname $hostname_ck -IncludeEqual | where {$_.sideindicator -like "<="}
                        if ($hostname_cmpr){
                        $hostname = $fail
                        }
                        else {$hostname = $Pass} 
                        }
                else {write-host "Error reading OSI02 inventory file. Test will be marked as Fail."
                      $hostname = $fail }
                       }
            else {
        $hostname = $inv
        $hostname_ck | select pscomputername,@{name='hostname';expression={$_}} | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_OSI02.csv" -Encoding Unicode
            }
        }
        

        #########################################################
        #
       <# OSI03 does currently reported domain name equal input file?
        # this test not in use by R1 project, requires the AD powershell
        # module be installed on servers in the bubble domain and was
        # disabled.

        $domainname_ck = ""
        if ($rps."domain name"){
        $domainname_ck = invoke-command -session $pscheck -command {get-addomain -current LocalComputer -ErrorAction SilentlyContinue | out-null}
           if ($domainname_ck -ne $rps.domain_name){
            $domainname = $fail
                }
            else {$domainname = $Pass}
               }
        else {
        $domainname_ck = invoke-command -session $pscheck -command {get-addomain -current LocalComputer -ErrorAction SilentlyContinue | out-null}
        $domainname_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$path\QAreportraw_OSI03.csv" -Encoding Unicode
        $domainname = $inv
            }#>

        #########################################################
        # 
        # OSI04 are hyper-V services running? If hyper-v service is 
        # status running, this test is a fail. Looks for pccomputername
        # match on the gathered services array with the current vm
        # being tested. Only run for the -inventory switch, not run
        # for the -net switch.

        if ($compare -and !$net){
        write-host ""
        write-host "Starting OSI04 Test."
        $hyperv_ck = ""
        $hyperv_ck = invoke-command -session $pscheck -command {Get-Service | where {$_.displayname -like 'Hyper-V*' -and $_.status -like 'running'}}
            if (!$hyperv_ck){
            $hypervsvc = $Pass
                }
            else {
            $hypervsvc = $fail
                }
            }
        else {$hypervsvc = $skipped}

        #gather all services installed
        if (!$net){
        write-host ""
        write-host "Collecting services list."
        $services = invoke-command -session $pscheck -command {get-service}
        }

        #########################################################
        #
        # OSI06 check for IIS and SQL installation and other key 
        # services for running state. Compare current vm with
        # pscomputername in the output file and verify state, fail
        # if no match found. Do not run for -critical or -net tests.

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting OSI06 Test."
        $services_ck = ""
        $services_ck = $services | where {$_.displayname -like "World Wide Web*" -or $_.DisplayName -like "SQL*" -and $_.status -eq "running"} | select displayname,status,pscomputername         
            if ($compare){
                $services_rpt = test-path -path "$source\QAreportraw_OSI06.csv"
                    if ($services_rpt){
                        $services_rpt = import-csv -Delimiter "`t" "$source\QAreportraw_OSI06.csv" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})} |
                         select displayname,status,pscomputername
                        $services_cmpr = compare $services_rpt.displayname $services_ck.displayname -IncludeEqual | where {$_.sideindicator -like "<="}
                            if (!$services_cmpr){
                                $packages = $Pass
                                    }
                            else { $packages = $fail }
                                }
                    else {                      
                    write-host "Error reading OSI06 inventory file. Test will be marked as Fail."
                    $packages = $fail }
                        }
            else {  
                $packages = $inv
                $services_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_OSI06.csv" -Encoding Unicode
                }
            }

        #########################################################
        #
        # OSI07 check for feature installs or application presence.
        # Find pscomputername in from current check ($rps.name) in
        # output file and compare with settings in source domain. If
        # different, test is a fail. Does not run with -critical or
        # -net swtiches. 

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting OSI07 Test."
        $keyapps_ck = ""
        $keyapps_ck2 = ""
        $keyapps_ck = invoke-command -session $pscheck -command {Get-WindowsFeature | where {$_.installstate -eq "installed" -and $_.name -like "web-server" `
        -or $_.name -like "File-services"} | select pscomputername, @{name='name'; expression = {$_.name}}, @{name='status'; expression = {$_.installstate}}} 
        $keyapps_ck2 = $services | where {$_.displayname -like "SQL*" -and $_.status -eq "running"} | select pscomputername, @{name='name'; expression = {$_.displayname}}, status, runspaceid
        if ($compare){
            $keyapps_rpt = test-path -path "$source\QAreportraw_OSI07.csv"
            $keyapps_rpt1 = test-path -path "$source\QAreportraw_OSI07.2.csv"
                if ($keyapps_rpt -and $keyapps_rpt1){
                    $keyapps_rpt = import-csv -Delimiter "`t" -Path "$source\QAreportraw_OSI07.csv" -Encoding Unicode | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}                      
                    $keyapps_rpt1 = import-csv -Delimiter "`t" -Path "$source\QAreportraw_OSI07.2.csv" -Encoding Unicode | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}                     
                    $keyapps_cmpr = compare $keyapps_rpt.name $keyapps_ck.name -IncludeEqual | where {$_.sideindicator -eq "<="}
                    if ($keyapps_rpt1){
                    $keyapps_cmpr2 = compare $keyapps_rpt1.name $keyapps_ck2.name -includeequal | where {$_.sideindicator -eq "<="}
                        }
                        if ($keyapps_cmpr -or $keyapps_cmpr2){
                        $keyapps = $fail
                            }                        
                        else {$keyapps = $pass}
                        }
                else {$keyapps = $fail
                     write-host "Error reading OSI07 inventory files. Test will be marked as Fail."
                    }
                }
        else {
        $keyapps_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_OSI07.csv" -Encoding Unicode
        if ($keyapps_ck2){
        $keyapps_ck2 | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_OSI07.2.csv" -Encoding Unicode
            }
        $keyapps = $inv}
        }
            
        ####################################################################
        #
        # begin checks for OS settings   
        
        #########################################################
        #
        # OSD01 if $pscheck then this is a pass. If remote session
        # has been successful, this test is a pass. Do not run with 
        # -net swtich. 

        if (!$net){
        $login = ""
        write-host ""
        write-host "Starting OSD01 Test."
        if ($pscheck){
            $Login = $pass
            } 
        else {$login = $fail}
        
        #########################################################
        #
        # OSD02 check for accounts in local admin group
        # compare target report with members of local admin group, 
        # if different test fails. Only run with the -inventory switch.

        if (!$net){
        $localgroups_ck = ""
        $localgroups_cmpr = ""
        write-host ""
        write-host "Starting OSD02 Test."
        $localgroups_ck = invoke-command -session $pscheck -ScriptBlock ${function:Get-winGroupMember} -ArgumentList 'administrators'| select member, pscomputername
        #compare target report with members of local admin group, if different test fails
        if ($compare){
            $localgroups_rpt = test-path -path "$source\QAreportraw_OSD02.csv" 
                if ($localgroups_rpt){
                   $localgroups_rpt = import-csv -Delimiter "`t" -path "$source\QAreportraw_OSD02.csv" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}
                   $localgroups_cmpr = compare $localgroups_rpt.member $localgroups_ck.member -IncludeEqual | where {$_.sideindicator -like '=>'}
                    if ($localgroups_cmpr){
                    $localgroups = $fail
                    }
                    else {$localgroups = $pass}
                    }
                else {write-host "Error reading OSD02 inventory file. Test will be marked as Fail."
                $localgroups = $fail }
                    }
        else {$localgroups_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_OSD02.csv" -Encoding Unicode
            $localgroups = $inv}
        }

        #########################################################
        #
        # OSD03 check event viewer for critical errors, fail test 
        # if present for schannel errors or DCOM update errors. 
        # looks at data gathered in the parallel section and if
        # pscomputername matches current machine, test is a fail.
        # If -inventory or -net swtich used, do not run test.

        if (!$inventory -and !$net){
        write-host ""
        write-host "Starting OSD03 Test."
        $events_ck = ""
        $events_ck = invoke-command -Session $pscheck -command { Get-EventLog -LogName system -After ((get-date).AddHours(-12)) | where {$_.InstanceId -eq '36887' -or $_.InstanceId -eq '3221232498' `
        -or $_.InstanceId -eq '2147489656'}}
            if ($events_ck){
            $errors = $fail
                }
            else {$errors = $Pass}
                } 
        else {
            $errors = $skipped
        }
        
        #########################################################
        #
        # OSD04 checks for application event log errors for 
        # anything SQL or IIS related, if any fails check. if
        # pscomputername matches that of current machine, test is
        # a fail. Does not run with the -inventory, -critical, or -net
        # switch. 

        if (!$inventory -and !$critical -and !$net){
        write-host ""
        write-host "Starting OSD04 Test."
        $basic_ops_ck = ""
        $basic_ops_ck = invoke-command -Session $pscheck -command { Get-EventLog -LogName Application -after ((get-date).AddHours(-12)) -EntryType error |
         where {$_.source -like 'ASP.Net*' -or $_.source -like 'SQL*'}}
            if ($basic_ops_ck) {
            $basic_ops = $fail
            $basic_ops_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$target\QAreportraw_OSD04.csv" -Encoding Unicode
                }
            else {$basic_ops = $Pass}
                }
        else {
            $basic_ops = $skipped
            }

        #########################################################
        # 
        # OSD05 check for any OS crashes logged to the system log
        # if pscomputername matches that of the current server then
        # test is a fail. Does not run with -inventory, -critical, or 
        # -net switch. 

        if (!$inventory -and !$critical -and !$net){
        write-host ""
        write-host "Starting OSD05 Test."
        $crash_ck = ""
        $crash_ck = $events_ck | where {$_.InstanceId -eq '2147489656'}
            if ($crash_ck) {
            $crash = $fail
                }
            else {$crash = $pass}
                }
        else {
            $crash = $skipped
            }

        #########################################################
        #
        # OSD06 check for key running processes, if svchost, system
        # winlogon, and vmtoolsd are not all running, test is a fail.
        # current server is compared with pscomputername from data
        # gathered in parallel section, any mismatches in the 
        # $runningproc_vrf and $runningproc_ck, test is a fail. 

        if (!$inventory -and !$critical -and !$net){
        write-host ""
        write-host "Starting OSD06 Test."
        $runningproc_vrf = 'svchost','system', 'winlogon','vmtoolsd', 'vmicguestinterface' -split ","
        $runningproc_ck = ""
        $runningproc_ck = invoke-command -Session $pscheck -command  {Get-Process  | where {$_.processname -like 'svchost' -or $_.processname -like 'system' `
         -or $_.processname -like 'winlogon' -or $_.processname -like 'vmtoolsd' -or $_.processname -like 'vmicguestinterface'}}
            $runningproc_cmpr = compare $runningproc_vrf $runningproc_ck.processname -includeequal | where {$_.sideindicator -eq "<="}
            if (!$runningproc_cmpr){
            $runningproc = $fail
                }
            else {$runningproc = $pass}
                }
        else {
            $runningproc = $skipped
        }

        #########################################################
        #
        # OSD07 check running services, data from paralell section
        # must match that of the $runningsrv_vrf and all must be
        # marked as running if any difference test is a fail. Matches
        # pscomputername with current server of that in gathered
        # data. Does not run with -critical, -inventory, or -net switches

        if (!$inventory -and !$critical -and !$net){
        write-host ""
        write-host "Starting OSD07 Test."
        $runningsrv_vrf = 'workstation','server','windows time','vmware tools'
        $runningsrv_ck = ""
        $runningsrv_ck = $services | where {$_.displayname -like 'workstation' -or $_.displayname -like 'server' -or $_.displayname -like 'windows time' -or `
        $_.DisplayName -like 'VMware tools' -and $_.status -eq 'running'}
            $running_cmpr = compare $runningsrv_vrf $runningsrv_ck.displayname -IncludeEqual | where {$_.sideindicator -eq "<="}
            if ($running_cmpr){
            $runningsrv = $fail
                }
            else {$runningsrv = $pass}
                }
        else {
            $runningsrv = $skipped
        }

        #########################################################
        #
        # OSD08 check for key services IIS and SQL present and running
        # if services captured in current -inventory scan do not match 
        # that from the pscomputername that matches the current server
        # then test is a fail. Does not run with the -critical switch
        # nor the -net swtich. 

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting OSD08 Test."
        $localsrv_ck = ""
        $localsrv_ck = $services | where {$_.name -like 'w3svc' -or $_.displayname -like 'SQL*' -or $_.displayname -like 'server' -and $_.status -eq 'running'} | select status,displayname,pscomputername
            if ($compare){
                $localsrv_rpt = test-path -path "$source\QAreportraw_OSD08.csv"                    
                if ($localsrv_rpt){
                    $localsrv_rpt = import-csv -Delimiter "`t" -path "$source\QAreportraw_OSD08.csv" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}
                    $localsrv_cmpr = compare $localsrv_rpt $localsrv_ck -IncludeEqual | where {$_.sideindicator -eq "<="}                        
                    if ($localsrv_cmpr){                        
                        $localsrv = $fail
                            }
                    else {$localsrv = $pass}
                        }
                else {write-host "Error reading OSD08 inventory file. Test will be marked as Fail."
                     $localsrv = $fail }
                    }
            else {$localsrv_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_OSD08.csv" -Encoding Unicode
                $localsrv = $inv}
                }


        #########################################################
        #
        # STO01 check local volumes, scan from -inventory switch is
        # compared with scan from the -inventory switch, if not
        # matching, test is a fail. Matches pscomputername with 
        # the current server. Does not run with the -inventory or
        # -net switch. 

        if (!$net){
        $localdisks_ck = ""
        $localdisks_cmpr = "" 
        write-host ""
        write-host "Starting STO01 Test."       
        $localdisks_ck = invoke-command -Session $pscheck -command { get-wmiobject -class win32_logicaldisk | where {$_.drivetype -eq 3 } | select deviceid,freespace,size,volumename}
            if ($compare){
                $localdisks_rpt = test-path -path "$source\QAreportraw_STO01.csv"  
                if ($localdisks_rpt){
                    $localdisks_rpt = import-csv -path "$source\QAreportraw_STO01.csv" -Delimiter "`t" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})} 
                    $localdisks_cmpr = compare $localdisks_rpt.deviceid $localdisks_ck.deviceid -IncludeEqual | where {$_.sideindicator -eq "<="}
                    if ($localdisks_cmpr) {
                    $localdisks = $fail
                        }
                    else {$localdisks = $Pass}
                        }
                else {write-host "Error reading STO01 inventory file. Test will be marked as Fail."
                $localgroups = $fail }                
                    }
        else {$localdisks_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_STO01.csv" -Encoding Unicode
              $localdisks = $inv}
        }

        #########################################################
        #
        # STO02 check any RAID volumes for health, if raid_drive
        # column set for a drive letter, and the volume check reveals
        # an unhealthy volume or not present, test is a fail. 
        # pscomputername match the current server before comparison
        # is run. Does not run with -critical or -net switches. 

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting STO02 Test."
        $raid_ck = ""
        if ($rps.raid -and !$compare){
        $raid_ck = invoke-command -session $pscheck -command {get-volume | where {$_.driveletter -eq $rps.raid -or $_.filesystemlabel -eq $rps.raid -and $_.healthstatus -eq 'healthy'}}
            if ($raid_ck){
            $raid = $Pass
                }
            else {$raid = $fail}
            }
        if (!$rps.raid){
            $raid = $skipped
                }
        if ($compare){
            $raid = $skipped
            }
            }

        #########################################################
        #            
        # STO03 check for empty or unhealthy volumes, data from the
        # -inventory run is compared with what was written to the output
        # file, anything showing with a dirtybitset is a fail. Any 
        # differences between the drive sizes between the two is a fail. 
        # does not run with the -inventory or the -net switch.

        if (!$net){
        $healthy_vol_ck = ""
        $empty_vol_ck = ""
        write-host ""
        write-host "Starting STO03 Test."
        $health_vol_ck = invoke-command -session $pscheck -command {get-wmiobject -class win32_volume | where {$_.dirtybitset -eq "true" -and $_.drivetype -eq "3"}}
        $empty_vol_ck = invoke-command -session $pscheck -command {get-wmiobject -class win32_logicaldisk | where {$_.drivetype -eq 3} | select deviceid,freespace, size}
        if ($compare){
            $empty_vol_rpt = test-path -path "$source\QAreportraw_STO03.csv"
                if ($empty_vol_rpt){
                    $empty_vol_rpt = import-csv -Delimiter "`t" -path "$source\QAreportraw_STO03.csv" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}
                    $empty_vol_cmpr = compare $empty_vol_rpt $empty_vol_ck -Property size -IncludeEqual | where {$_.sideindicator -eq "<="}
                        if ($empty_vol_cmpr){
                        $volume = $fail
                        }
                        else {$volume = $pass } 
                            }
                else {write-host "Error reading STO03 inventory file. Test will be marked as Fail."
                $Volume = $fail }                
                    }
        else {
            if ($health_vol_ck){
                $volume = $fail
                $empty_vol_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_STO03.csv" -Encoding Unicode
                }
            else {$volume = $inv}                
            $empty_vol_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_STO03.csv" -Encoding Unicode
                }
        }

        #########################################################
        #
        # STO04 check for available disk space, if under 20Gb free 
        # fail test, data from inventory gathering is checked here
        # for percentage free, if below 20Gb the test is a fail. Looks
        # for a match in the pscomputername and the current server. Does
        # not run with -inventory or -the -net switches. 

        if (!$inventory -and !$net){
        write-host ""
        write-host "Starting STO04 Test."
        $freespace_vol_ck = ""
        $freespace_vol_ck = invoke-command -session $pscheck -command {get-wmiobject -class win32_logicaldisk | where {$_.size -ne $null -and $_.drivetype -eq 3} |
        select deviceid,drivetype,freespace,size,@{name='%free';expression={[Math]::round((($_.freespace/$_.size) * 100))}}}
            if ($freespace_vol_ck.'%free' -lt 20){
            $freespace = $fail
                }
            else {$freespace = $pass}
                }
        else {
            $freespace = $skipped
            }


        ####################################################################
        #
        # begin checks for network settings   

        
        ####################################################################
        #
        # NET01 check IP addresses assigned to NICs, requries that the input
        # from the input file be present for this check to function. If not
        # present, output will be dumped to file instead. 

        if (!$net){
        $tcpaddr_ck = ""
        write-host ""
        write-host "Starting NET01 Test."
        $tcpaddr_ck = invoke-command -Session $pscheck -command { get-wmiobject -Class win32_networkadapterconfiguration -filter ipenabled=True | select pscomputername, ipaddress}
        if ($rps."IP-address" -and !$inventory){
            $tcpaddr_cmpr = compare $rps."IP-address" $tcpaddr_ck.ipaddress -IncludeEqual | where {$_.sideindicator -like "<="}            
            if ($tcpaddr_cmpr){
                $tcpaddr = $fail
                    }                
            else {$tcpaddr = $pass}
                }
        if (!$rps."IP-address" -and $compare){
        $tcpaddr = $Inv
        $tcpaddr_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_NET01.csv" -Encoding Unicode
            }
        if ($inventory){
            $tcpaddr = $inv
            }
        }
        
        ####################################################################
        # 
        # NET02 check for tcp/udp port listeners and compare if -inventory switch
        # is used. Do not run if -critical or -net switch is used. 

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting NET02 Test."
        $tcpport_ck = ""
        $tcpport_ck = invoke-command -Session $pscheck -ScriptBlock ${function:Get-NetworkStatistics} | where {$_.state -eq "listening"} | select protocol,localaddress,localport,pscomputername
            if ($compare){
                $tcpport_rpt = test-path -path "$source\QAreportraw_NET02.csv"
                    if ($tcpport_rpt){
                        $tcpport_rpt = import-csv -Delimiter "`t" "$source\QAreportraw_NET02.csv" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}
                        $tcpport_cmpr = compare $tcpport_rpt.localport $tcpport_ck.localport -IncludeEqual | where {$_.sideindicator -eq "<="}
                            if ($tcpport_cmpr){
                            $tcpport = $fail
                                }
                            else {$tcpport = $pass}
                            }
                    else {write-host "Error reading NET02 inventory file. Test will be marked as Fail."
                        $Volume = $fail }                
                    }
            else {
            $tcpport_ck| export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_NET02.csv" -Encoding Unicode
            $tcpport = $inv}
            }

        ####################################################################
        #
        # NET03 check default route per vm, factor out IPv6 routes, routes 
        # from $routes must exist or check fails. This test is less useful
        # unless manual routes have been set per server. If landing pad is
        # a bubble network using the same IP scheme, this will work as a 
        # compare of the source with the target environmnet. If not using the
        # same IP subnets this test will not be as useful. Does not work with
        # -net switch. 

        if (!$net){
        $tcproute_ck = ""
        write-host ""
        write-host "Starting NET03 Test."
        $tcproute_ck = invoke-command -session $pscheck -command {Get-WmiObject -Class win32_ip4routetable | select description, destination, mask, name, pscomputername -ExcludeProperty runspaceid, psshowcomputername |
        where {$_.name -notlike "224.*" -and $_.name -notlike "0.0.0.0" -and $_.name -notlike "127.*"} }
        if ($compare){
            $tcproute_rpt =  test-path -path "$source\QAreportraw_NET03.csv"
                if ($tcproute_rpt){
                    $tcproute_rpt = import-csv -Delimiter "`t" "$source\QAreportraw_NET03.csv" | where {$_.pscomputername -like $(if (!$test){"$($rps.hostname).$($rps."domain name")"} else {$rps.hostname})}
                    $tcproute_cmpr = compare $tcproute_rpt.destination $tcproute_ck.destination -IncludeEqual | where {$_.sideindicator -eq "<="}
                    }
                    if (!$tcproute_cmpr){
                        $tcproute = $pass
                        }
                    else {$tcproute = $fail}
                }                
        else {
            $tcproute_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\QAreportraw_NET03.csv" -Encoding Unicode
            $tcproute = $inv
            }
        }

        ####################################################################
        #
        # NET04 check dns server settings requires either: input in the file
        # per server for 'dns_servers' correct IP addresses or adding information to the 
        # Net04 variable section at line 1014 in this script. This test works for
        # either the -net or the -inventory swtich. 
         
        if ($compare){
            write-host ""
            write-host "Starting NET04 Test."
            $tcpdns_ck = ""
            $tcpdns_ck = invoke-command -session $pscheck -command {Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter IPEnabled=TRUE | Select-Object pscomputername,dnsserversearchorder}
            $tcpdns_vrf = $tcpdnsips -split "," #$(if ($rps.domain -eq 'extapp.local' -and !$rps.DNS_Servers) {'10.246.238.4,10.246.238.5'} elseif ($rps."domain name" -eq 'accretivehealth.local' -and !$rps.DNS_Servers) {'10.246.238.2,10.246.238.3'} else {$rps.DNS_Servers}) -split ","
            $tcpdns_cmpr = compare $tcpdns_ck.dnsserversearchorder $tcpdns_vrf -IncludeEqual | where{$_.sideindicator -eq "<="}
                if ($tcpdns_cmpr){
                    $tcpdns = $fail
                    }
                else {$tcpdns = $pass}
                }
        else {
            $tcpdns = $skipped} 

        ####################################################################
        #
        # NET05 check hostname resolution for local hosts, this requires that
        # the NET05 variable section starting at line 1044 be filled in for
        # the valid subnets needing to be tested against and a list of IPs of
        # hosts belonging to that subnet. Only two will be tested but any number
        # of IPs can be utlized. Test does not work if the -inventory switch is
        # used. 

        if (!$inventory){
        $tcpdnsres_cmpr = ""
        write-host ""
        write-host "Starting NET05 Test."
        $tcpdnsres_ck = ""
        $tcpdnsres_ck = invoke-command -session $pscheck -scriptblock {foreach ($www in $using:tcpresips) {[System.Net.Dns]::GetHostEntry($www)[0]}} 2>$null
        $tcpdnsres_cmpr = compare ($tcpresips[0,1]).count ($tcpdnsres_ck.hostname).count -IncludeEqual | where {$_.sideindicator -eq "<="}           
            if ($tcpdnsres_cmpr){
                $tcpdnsres = $fail
                }
            else {$tcpdnsres = $pass}
                }
        else {$tcpdnsres = $skipped }

        <#NET06 check for latency issues in internet communications
        if (!$compare){
        $tcplatency_ck = invoke-command -session $pscheck -command {Test-Connection www.google.com | measure-object -Property responsetime -average | select property, average}
            }
        $tcplatency_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$target\QAreportraw_NET11.csv" -Encoding Unicode #>

        ####################################################################
        #
        # NET08 check for ping connections to default GW, DNS servers. Takes
        # the $iprestests required output of two successful entries and compares
        # that to the actual successful replies, any deviation is a fail. Does
        # not run with the -inventory or the -net switches. 

        if (!$inventory -and !$net){
        write-host ""
        write-host "Starting NET08 Test."
        $tcpset_ck = ""
        $tcpgw_ck = ""
        $tcpgw = ""
        $iprestests = ""
        $tcpres_ck = ""
        $tcpset_ck = $tcpdns_ck.dnsserversearchorder
        $tcpgw_ck = invoke-command -session $pscheck -command {Get-WmiObject -Class Win32_NetworkAdapterConfiguration -Filter IPEnabled=TRUE | Select-Object pscomputername,defaultipgateway}
        $tcpgw = $tcpgw_ck.defaultipgateway
        $iprestests = $tcpset_ck += $tcpgw
        $tcpres_ck = invoke-command -session $pscheck -scriptblock {foreach ($ip in $using:iprestests) {Test-Connection $ip  -count 1 -ErrorAction SilentlyContinue}}
        $tcpres_cmpr = compare $iprestests $tcpres_ck.protocoladdress -IncludeEqual | where {$_.sideindicator -eq "=>"}
            if ($tcpres_cmpr){
                $tcpres = $fail
                }
            else {$tcpres = $pass}
                }
        else {$tcpres = $skipped}
            

        ####################################################################
        #
        # NET09 check for ping into other routable subnets. Requires that the
        # Net09 variable section starting at line 1080 have default gateway
        # IPs input in order to test connectivity. Does not run with the -inventory
        # or -net switches. 

        if (!$net){
        write-host ""
        write-host "Starting NET09 Test."
        $tcpsubnet_ck = ""
        $tcpsub_vrfy = ""
        if (!$inventory){
        $tcpsubnet_ck = invoke-command -Session $pscheck -scriptblock {
        $subnetset = $using:tcpsubnets | sort {get-random}
        foreach ($subn in $subnetset[0,1]) {
        test-connection $subn -count 1 -ErrorAction SilentlyContinue | select protocoladdress,responsetime}}
        if ($tcpsubnet_ck){
        $tcpsub_vrfy = compare $tcpsubnets $tcpsubnet_ck.protocoladdress -IncludeEqual | where {$_.sideindicator -eq "<="}
            if (!$tcpsub_vrfy){
            $tcpsub = $pass
                    }
            else {$tcpsub = $fail}
                }
            }
        else {$tcpsub = $skipped}
        }
        
        ####################################################################
        #
        # NET10 check for ping into non-routable subnets (backup servers).
        # Requires that the input file have a column header called backup_servers.
        # This tests connectivity to VCS backup services. Does not run if
        # backup_servers is blank in input file or -critical or -net switch 
        # is used. 

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting NET10 Test."
        $tcpbkupsvrs = ""
        $tcpbkup_ck = ""
        $tcpbkup_vrfy = ""
        if ($rps.backup_servers -and $compare){
        $tcpbkupsvrs = ($rps.backup_servers) -split ","
        $tcpbkup_ck = invoke-command -Session $pscheck -scriptblock { foreach ($bkup in $using:tcpbkupsvrs) {test-connection $bkup -Count 1 -ErrorAction SilentlyContinue| select protocoladdress,responsetime}}
            if ($tcpbkup_ck){
        $tcpbkup_vrfy = compare $tcpbkupsvrs $tcpbkup_ck.protocoladdress -IncludeEqual | where {$_.sideindicator -eq "=="}   
            if ($tcpbkup_vrfy) {
            $tcpbkup = $pass
                    }
                }
            else {$tcpbkup = $fail}
            }
        else {$tcpbkup = $skipped}
        }


        ####################################################################
        #
        # begin checks for load balancer settings   

        ####################################################################
        #
        # BAL01 check pooled LB workloads for connectivity to one another,
        # requires that IP addresses of all pooled servers be added to the
        # input file under the app_pool_servers column header. If not present
        # test is skipped as well as if -net, -inventory, or -critical switches
        # are used.

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting BAL01 Test."
        $lbpooled = ""
        $lbpooled_ck = ""
        $lbpooled_vrfy = ""
        if ($rps.app_pool_servers -and !$inventory){
        $LBpooled = ($rps.App_pool_servers) -split ","
        $LBpooled_ck = invoke-command -session $pscheck -ScriptBlock {foreach ($lbpool in $using:lbpooled) {Test-Connection $lbpool -ErrorAction silentlycontinue -Count 1 | select protocoladdress}}
        if (!$LBpooled_ck){
            $lbpool = $fail
            }
        else {
        $LBpool_vrfy = compare $LBpooled $LBpooled_ck.protocoladdress -IncludeEqual | where {$_.sideindicator -eq "<="}
            if ($LBpool_vrfy){
            $LBPool = $fail
                    }                
            else {$LBPool = $pass}
            }
        }
        else {$LBPool = $skipped}
        }

        ####################################################################
        #
        # BAL02 check LB pool workloads for LB connectivity. Requires that the
        # load_balancer column heading be used in the input file. tests for 
        # communication to the LB IP address. Does not run with the -net or
        # the -critical switch.

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting BAL02 Test."
        $lbal_ck = ""
        if ($rps.Load_Balancer -and !$inventory){
        $LBal_ck = invoke-command -Session $pscheck -command {Test-Connection $using:rps.load_balancer -ErrorAction SilentlyContinue | select protocoladdress,responsetime}
            if ($LBal_ck){
            $LBal = $pass
                }
            else {$LBal = $fail}
            }
        else {$LBAl = $skipped}
        }

        ####################################################################
        #
        # BAL04 check LB is allowing access through the VIP. test only works
        # if the lb_vip_addr column header is in the input file and has the 
        # application VIP identified. does not run with the -net or the -critical
        # switches. 

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting BAL04 Test."
        $lbalvip_ck = ""
        if ($rps.lB_VIP_addr){
        $LBalvip_ck = invoke-command -Session $pscheck -command {test-connection $using:rps.lb_vip_addr -ErrorAction SilentlyContinue| select protocoladdress, responsetime}
            if ($LBalvip_ck){
            $LBalVIP = $pass
                }
            else {$LBalVIP = $fail}
            }
        else {$LBalVIP = $skipped}
        }
        

        ####################################################################
        #
        # FIR01 check if workload can communicate with firewalled subnets.
        # requires that the firewall_subnet column be present in the input
        # file and returns a fail if there's a successful connection across
        # the subnets. Does not run with -critical or -net switches. 

        if (!$critical -and !$net){
        write-host ""
        write-host "Starting FIR01 Test."
        $fwsubs = ""
        $fwsubs_ck = ""
        if ($rps.firewall_subnet -and !$inventory){
        $FWsubs = ($rps.firewall_subnet) -split ","
        $FWsubs_ck = invoke-command -Session $pscheck -ScriptBlock { foreach ($FW in $using:fwsubs) {Test-Connection $fw -count 1 -ErrorAction SilentlyContinue | select protocoladdress, responsetime}}
            if ($fwsubs_ck){
            $fwsubs_ck | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$target\QAreportraw_FIR01.csv" -Encoding Unicode 
            $FWsub = $fail
                }
            else {$FWsub = $pass}
            }
        else {$FWsub = $skipped}
        }


        ####################################################################
        #
        # End checks begin reporting
 
         ####################################################################
        #
        # remove the remote powershell connection for each server in turn after
        # checks are complete       

        if ($pscheck){
        Remove-PSSession -Session $pscheck
                }
            }
    
    } 
    }  
    
 write-host ""
 write-host "$($workload.hostname) checks completed."
 write-host "" 
   

####################################################################
#
# build report for default test, ignored for -net or -critical

if (!$critical){
$report = New-Object psobject -Property @{
    "Server" = $workload.hostname
    "VMD01" = $invC
    "VMD02" = $vCState
    "VMD03" = $vCGuest
    "VMD04" = $vCPURAM
    "VMD05" = $vCGuestHB
    "VMD06" = $vcGuestNIC
    "VMD07" = $vcGuestCl
    "OSI01" = $vCguestOS
    "OSI02" = $hostname
    "OSI03" = $domainname
    "OSI04" = $hypervsvc
    "OSI06" = $packages
    "OSI07" = $keyapps
    "OSI08" = $remoteacc
    "OSD01" = $login
    "OSD02" = $localgroups
    "OSD03" = $errors
    "OSD04" = $basic_ops
    "OSD05" = $crash
    "OSD06" = $runningproc
    "OSD07" = $runningsrv
    "OSD08" = $localsrv
    "STO01" = $localdisks
    "STO02" = $raid
    "STO03" = $volume
    "STO04" = $freespace
    "NET01" = $tcpaddr
    "NET02" = $tcpport
    "NET03" = $tcproute
    "NET04" = $tcpdns
    "NET05" = $tcpdnsres
    "NET08" = $tcpres
    "NET09" = $tcpsub
    "NET10" = $tcpbkup
    "BAL01" = $lbpool
    "BAL02" = $lbal
    "BAL04" = $lbalvip
    "FIR01" = $fwsub


    } | select 'server', 'VMD01', 'VMD02', 'VMD03', 'VMD04', 'VMD05', 'VMD06', 'VMD07', 'OSI01','OSI02', <#'OSI03',#> 'OSI04', 'OSI06',  `
        'OSI07', 'OSI08', 'OSD01', 'OSD02', 'OSD03', 'OSD04', 'OSD05', 'OSD06', `
        'OSD07','OSD08', 'STO01', 'STO02', 'STO03', 'STO04', 'NET01', 'NET02', 'NET03', 'NET04', 'NET05', 'NET08','NET09', 'NET10', 'BAL01', 'BAL02', 'BAL04', 'FIR01'
        }

####################################################################
#
# build report for all tests with the -critical switch applied

if ($critical){
$report = New-Object psobject -Property @{
    "Server" = $workload.hostname
    "VMD03" = $vCGuest
    "VMD04" = $vCPURAM
    "OSI02" = $hostname
    "OSI04" = $hypervsvc
    "OSI08" = $remoteacc
    "OSD01" = $login
    "OSD02" = $localgroups
    "OSD03" = $errors
    "STO01" = $localdisks
    "STO03" = $volume
    "STO04" = $freespace
    "NET01" = $tcpaddr
    "NET03" = $tcproute
    "NET04" = $tcpdns
    "NET05" = $tcpdnsres
    "NET08" = $tcpres
    "NET09" = $tcpsub


    } | select 'server', 'VMD03', 'VMD04','OSI02', 'OSI04',  `
        'OSI08', 'OSD01', 'OSD02', 'OSD03', `
        'STO01','STO03', 'STO04', 'NET01','NET03', 'NET04', 'NET05', 'NET08','NET09'
    }

####################################################################
#
# build report with the -net switch applied

if ($net){
$report = New-Object psobject -Property @{
    "Server" = $workload.hostname
    "NET04" = $tcpdns
    "NET05" = $tcpdnsres


    } | select 'server', 'NET04', 'NET05'
}

####################################################################
#
# export report for just the -vcenter switch
                        
if ($vcenter){
$report  
$report | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$vcntr\vc_TargetQAreport.csv" -Encoding Unicode
       }

####################################################################
#
# export report for either the -inventory or the -net switch
              
if ($inventory) {
$report
$report | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$source\SourceQAreport.csv" -Encoding Unicode
    }

####################################################################
#
# export report for just the -net swtich

if ($net) {
$report | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$target\TargetQAreport.csv" -Encoding Unicode
$report | ft
    }

####################################################################
#
# export report for just the -inventory switch

if ($compare -and !$net) {
$report
$report | export-csv -Delimiter "`t" -NoTypeInformation -Append -Path "$target\TargetQAreport.csv" -Encoding Unicode
    
         
import-csv -delimiter "`t" $source\So*.csv | export-csv -delimiter "`t" dashboard-input.csv
import-csv -delimiter "`t" $target\ta*csv | export-csv -delimiter "`t" -append dashboard-input.csv
import-csv -delimiter "`t" $vcntr\vc*csv | export-csv -delimiter "`t" -append dashboard-input.csv
    }

if ($critical){
$Results = Import-CSV -delimiter "`t" "Dashboard-input.csv"
$Servers = ($Results | Sort-Object Server -Unique).Server
$Scores = Foreach($Server in $Servers){
    $Records = $Results | where{$_.Server -eq $Server}
    [PSCUSTOMOBJECT]@{
        Server = $Server
        VMD03 = $(IF($Records.VMD03 -notcontains "Pass"){""}ELSE{"Pass"})
        VMD04 = $(IF($Records.VMD04 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI02 = $(IF($Records.OSI02 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI04 = $(IF($Records.OSI04 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI08 = $(IF($Records.OSI08 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD01 = $(IF($Records.OSD01 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD02 = $(IF($Records.OSD02 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD03 = $(IF($Records.OSD03 -notcontains "Pass"){""}ELSE{"Pass"})
        STO01 = $(IF($Records.STO01 -notcontains "Pass"){""}ELSE{"Pass"})
        STO03 = $(IF($Records.STO03 -notcontains "Pass"){""}ELSE{"Pass"})
        STO04 = $(IF($Records.STO04 -notcontains "Pass"){""}ELSE{"Pass"})
        NET01 = $(IF($Records.NET01 -notcontains "Pass"){""}ELSE{"Pass"})
        NET03 = $(IF($Records.NET03 -notcontains "Pass"){""}ELSE{"Pass"})
        NET04 = $(IF($Records.NET04 -notcontains "Pass"){""}ELSE{"Pass"})
        NET05 = $(IF($Records.NET05 -notcontains "Pass"){""}ELSE{"Pass"})
        NET08 = $(IF($Records.NET08 -notcontains "Pass"){""}ELSE{"Pass"})
        NET09 = $(IF($Records.NET09 -notcontains "Pass"){""}ELSE{"Pass"})
    }
}
$Scores | Select Server,VMD03,VMD04,OSI02,OSI04,OSI08,OSD01,OSD02,OSD03,STO01,STO03,STO04,NET01,NET03,NET04,NET05,NET08,NET09 | Export-CSV -path Dashboard.csv -NoType

    }
elseif (!$inventory) {
$Results = Import-CSV -delimiter "`t" "Dashboard-input.csv"
$Servers = ($Results | Sort-Object Server -Unique).Server
$Scores = Foreach($Server in $Servers){
    $Records = $Results | where{$_.Server -eq $Server}
    [PSCUSTOMOBJECT]@{
        Server = $Server
        VMD01 = $(IF($Records.VMD01 -notcontains "Pass"){""}ELSE{"Pass"})
        VMD02 = $(IF($Records.VMD02 -notcontains "Pass"){""}ELSE{"Pass"})
        VMD03 = $(IF($Records.VMD03 -notcontains "Pass"){""}ELSE{"Pass"})
        VMD04 = $(IF($Records.VMD04 -notcontains "Pass"){""}ELSE{"Pass"})
        VMD05 = $(IF($Records.VMD05 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI01 = $(IF($Records.OSI01 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI02 = $(IF($Records.OSI02 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI04 = $(IF($Records.OSI04 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI06 = $(IF($Records.OSI06 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI07 = $(IF($Records.OSI07 -notcontains "Pass"){""}ELSE{"Pass"})
        OSI08 = $(IF($Records.OSI08 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD01 = $(IF($Records.OSD01 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD02 = $(IF($Records.OSD02 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD03 = $(IF($Records.OSD03 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD04 = $(IF($Records.OSD04 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD05 = $(IF($Records.OSD05 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD06 = $(IF($Records.OSD06 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD07 = $(IF($Records.OSD07 -notcontains "Pass"){""}ELSE{"Pass"})
        OSD08 = $(IF($Records.OSD08 -notcontains "Pass"){""}ELSE{"Pass"})
        STO01 = $(IF($Records.STO01 -notcontains "Pass"){""}ELSE{"Pass"})
        STO02 = $(IF($Records.STO02 -notcontains "Pass"){""}ELSE{"Pass"})
        STO03 = $(IF($Records.STO03 -notcontains "Pass"){""}ELSE{"Pass"})
        STO04 = $(IF($Records.STO04 -notcontains "Pass"){""}ELSE{"Pass"})
        NET01 = $(IF($Records.NET01 -notcontains "Pass"){""}ELSE{"Pass"})
        NET02 = $(IF($Records.NET02 -notcontains "Pass"){""}ELSE{"Pass"})
        NET03 = $(IF($Records.NET03 -notcontains "Pass"){""}ELSE{"Pass"})
        NET04 = $(IF($Records.NET04 -notcontains "Pass"){""}ELSE{"Pass"})
        NET05 = $(IF($Records.NET05 -notcontains "Pass"){""}ELSE{"Pass"})
        NET08 = $(IF($Records.NET08 -notcontains "Pass"){""}ELSE{"Pass"})
        NET09 = $(IF($Records.NET09 -notcontains "Pass"){""}ELSE{"Pass"})
        NET10 = $(IF($Records.NET10 -notcontains "Pass"){""}ELSE{"Pass"})
        BAL01 = $(IF($Records.BAL01 -notcontains "Pass"){""}ELSE{"Pass"})
        BAL02 = $(IF($Records.BAL02 -notcontains "Pass"){""}ELSE{"Pass"})
        BAL04 = $(IF($Records.BAL04 -notcontains "Pass"){""}ELSE{"Pass"})
        FIR01 = $(IF($Records.FIR01 -notcontains "Pass"){""}ELSE{"Pass"})
    }
}
$Scores | Select Server,VMD01,VMD02,VMD03,VMD04,VMD05,OSI01,OSI02,OSI04,OSI06,OSI07,OSI08,OSD01,OSD02,OSD03,OSD04,OSD05,OSD06,OSD07,OSD08 `
,STO01,STO02,STO03,STO04,NET01,NET02,NET03,NET04,NET05,NET08,NET09,NET10,BAL01,BAL02,BAL04,FIR01 | Export-CSV -path Dashboard.csv -NoType

    }    
    }
    
    
