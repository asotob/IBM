<#PSScriptInfo

      .VERSION 1.69

      .GUID 0d04fc80-d661-41f5-b442-22c722726a04

      .AUTHOR Mark McInturff - mark.mcinturff@ibm.com or mmcint@gmail.com

      .COMPANYNAME IBM

      .COPYRIGHT 2021

      .TAGS vcenter vmware

      .LICENSEURI

      .PROJECTURI https://github.ibm.com/cmm-automation-guild-americas/Automation-Assets/blob/master/vInfoTools.ps1

      .ICONURI

      .EXTERNALMODULEDEPENDENCIES

      .REQUIREDSCRIPTS

      .EXTERNALSCRIPTDEPENDENCIES

      .PRIVATEDATA

      .ReleaseNotes "Added additionals sheets with charts"

# Requires -Module VMware.PowerCLI
# Requires -Module ImportExcel


#>

#line space required

<#
     .SYNOPSIS
          This powershell Script is a replacement for RVtools. Here are the highlights:
          - Gathers inventory and quicly performs (seconds to minutes) analysis that previously took hours to days with rvtools
          - Retrieves VMware vCenter inventory and EXPORTS TO AN EXCEL spreadsheet on your Desktop or to CSV 
          - Excel output is multi-sheet with column autowidth.
          - Excel sheets Freeze first row and column for easy viewing.
          - Joins CDP (Cisco Discover Protocol) data on the PNIC (physical nic) tab.
          - Flags VM as candidate for HCX, vmotion, or sVmotoin migration in the vmInfo worksheet
          - vmInfo (VM) sheet Snapshot count and Size.
          - vmInfo tab combines to one tab VM inventory with vCPU and Memory data.
          - creates graphs and charts to quickly view vm host and os relationship
          - provides massive discovery and diagnostic data rvTools does not provide 
     
     .DESCRIPTION
          Upon execution, this script does the following:
          - Verifies Powershell 5.0 or higher.
          - Imports Vmware Powercli Modules if required.
          - Imports non-proprietory, open source EXCEL MODULES if required.
          - Connects to vCenter using your credentials if not already connected.
          Note: Credentials use Microsoft Credential manager and passwords are not visible to this script.h
          - Retreives vCenter inventory.
          - Exports invnetory Excel.
          - Exports vmInfo (VM Inventory) to CSV if EXCEL MODULES not avalable.
          
          UPDATES:
          2021-06-08 fixed *bug* with portgroup labels, switch names, and vlanid. Thank you vmware for making this so confusing.
          2021-06-07 vmotion eligible fixed for not showing when FALSE. Made performance improvovements for remote vcenters
          2021-06-03 Repaired missing portgroup labels due to previous optimiations
          2021-06-02 Cleaned up exit/break debugs
          2021-05-27 Added vCenter Extension Worksheeet. Changed ESXi Version bar chart to Pie chart.
          2021-05-24 Added DVdFloppy sheet vm
          2021-05-20 Added FilesOnVm Worksheet to show exact files for VM and usagesac
          2021-05-18 Fixed vNetworkadapter sheet, Portgroup to show string instead of array object
          2021-05-12 Speed improvements; fixed conditions that cause duplicates
          2021-04-19 Major performance increase using -VM parameter which filters are supporting inventory to that which -VM is using.
          2021-04-06 Enhanced ConcurrentVmotion to evaluate all nic speeds in a cluster. 
                     Added HA_HeartbeatDatastores column to Cluster worksheet. 
                     Modularized Export proecudure.
                     Added Switch - VM_Export_Only to export only vmInfo.
          2021-04-14 Added Folders Tab with vm count and disk usage.
          2021-04-09 Added columns to vDisk worksheet: DeltaDiskFormat, ParentDiskUuid , IsClone
          2021-04-08 Fixed DiskGB on vminfo and vDisk to show actual disk usage 
          2021-04-02 Added createDate to vminfo sheet. Is supported only 6.5 and above
          2021-03-31 Added vmtools_GuestOS column to viminfo.
          2021-03-23 Added Cluster HA configurations to Cluster worksheet. Fixed some bugs. 
          2021-03-19 Added PrimarIP to vmInfo worksheet. Changed vmIP worksheet where IP is primary key instead of MacAddress (therefore, one to many is IP to VM-MacAddress) 
          2021-03-16 Added vdisk TYPE column to specify Thick or Thin disk type. Left THIN column in place.
          2021-03-10 Added sVmotion eligibility to vmInfo tab
          2021-02-12 Added Four worksheets with Charts: GuestOS VmPerVMhost VmPerCluster VMhostVersion
          2021-01-25 Added Check update for script version. Added version numbering.
          2021-01-21 Added three sheets for: DrsRule, DrsClusterGroup, DrsVMHostRule
          2021-01-13 Added installation for ImportExcel module by Zip File 
          2021-01-13 Added "MemUsed%" and "MemUsedGB" to vmHost tab
          2021-01-06 Added EvcMode field to Cluster Tab, re-ordered tabs
          2020-09-30 Added Dashboard for HcxEligible VM Count 
          Added CSV Export as 1 file per Inventory Collection
          2020-10-12 added tab for ResourcePools which includes vAPP
          2020-10-14 added vCenter column to all sheets as a cross reference of vcenters objects in case connected to multiple vCenters.
          2020-10-14 added vmIP section to provide Ip to VM listing
     
     .PARAMETER VM
          Virtual Machine name
     
     .PARAMETER ExportExcel
          Enabled by default..
          True False parameter to export to excel.
          -ExportExcel:$False  #disables
     
     .PARAMETER CsvExport
          A description of the CsvExport parameter.
     
     .PARAMETER FilenamePath
          Path of a file. Exampe C:\temp\myoutput.xlsx
          Default path output is your $ENV:\User\Desktop.
     
     .PARAMETER vCenter
          vCenter FQDN name or IP address.
     
     .PARAMETER Credential
          A description of the Credential parameter.
     
     .PARAMETER Raw
          Outputs the VM data in raw format to the console. No export to file.
     
     .PARAMETER ScrubLicenseKey
          Switch to remove last part of license key
     
     .PARAMETER ImportExcelModulePath
          The path\filename to the ImportExcel module
          Use this for manual installation of supporting ImportExcel Module
          ImportExcel.zip module will automatically import if it is in the same directory as this script.
     
     .PARAMETER Help
          Displays help info.
     
     .EXAMPLE
          vmInfoTools.ps1
          -- Exports vCenter Inventory to Excel file located on your desktop.
     
     .EXAMPLE
          vmInfoTools.ps1  -ExportExcel
          -- Exports vCenter Inventory toExcel file . -ExportExcel defaults to TRUE and is the same as vmInfotools.ps1 with no parameter.
          -- the ExportExcel disables with the -VM parameter but can be over ridden by selecting th -ExportExcel parameter.
     
     .EXAMPLE
          vmInfoTools.ps1  -VM MyVM
          -- Prints vmInfo content to screen and DOES NOT create Excel file.
     
     .EXAMPLE
          vmInfoTools.ps1  -VM MyVM  -ExportExcel
          -- Prints vmInfo content to screen AND creates Excel file .
     
     .EXAMPLE
          vmInfoTools.ps1  -VM MyVM  -ExportExcel  -FileName
          -- Prints vmInfo content to screen AND creates Excel file as specified by parameter -FileName
     
     .EXAMPLE
          vmInfoTools.ps1  -FilenamePath C:\myfolder\myfile.xlsx
          -- Creates Excel file as specified by parameter -FilenamePath
     
     .OUTPUTS
          Excel or CSV files.
          
     .Inputs
     No command line inputs required for export to EXCEL, but parameters are available for convenice for additional optoins.
     
     .Link
     https://www.powershellgallery.com/packages/ImportExcel/

     .NOTES
          
          HCX Verification:
          PhysicalRDM,Shared VMDK,Virtual Media,ESXi version -lt 5.0,ESXi version -lt 5.5,HW version -lt 9,Standard vSwitch,HCX vMotion,HCX Eligible
          PhysicalRDM,Shared VMDK,VirtualMedia,ESXi version -lt 5.0,ESXi version -lt 5.5,HW version -lt 9,Standard vSwitch,HCX vMotion,HCX Eligible,Environment,Have DR?,Physical?,Simple Workload
          Check for SRM Visibility
          
          Roadmap:
          tags
          fix folderpath resourcepath
          

#>

Param 
(
     [Parameter(Mandatory = $false,
         ValueFromPipeline = $true,
         Position = 1,
         HelpMessage = 'Virtual Machine Name')]
     [Alias('vmName', 'VirtualMachine', 'Name')]
     $VM,
     [switch]$ExactMatch,
     [SWITCH]$VM_Export_Only = $False,
     [SWITCH]$ExportExcel =  $True,
     [SWITCH]$CsvExport = $False,
     [STRING]$FilenamePath,
     [string]$vCenter,
     [PsCredential]$Credential,
     [SWITCH]$Raw,
     [SWITCH]$ScrubLicenseKey,
     [ValidateScript({Test-Path $_ })]
      $ImportExcelModulePath ,
     [SWITCH]$NoLaunch,
     [SWITCH]$NoChartExport,
     [SWITCH]$Help
)


begin
{
   $ErrorActionPreference = "Continue"

     if ($Help)
     {
          HELP $MyInvocation.MyCommand.Name -Detail
          break
     }
     

     ##### BEGIN Error Collection ENABLE
     $error.Clear()
     $ErrorActionPreference = "SilentlyContinue" #disable errors for null expressions
     $ErrorStart = $Error.Count - 1

     #### BEGIN Check for latest script version
     #$scriptURL = "https://raw.github.ibm.com/cmm-automation-guild-americas/Automation-Assets/master/Powershell/vInfoTools/vInfoTools.ps1?token=AABHUOXL2HLOOWFLRCWATI3ADBDCO"
     #$scriptDownloaded = echo $env:TEMP\$(get-Random).ps1
     #(Invoke-WebRequest $scriptURL).Content  > $scriptDownloaded
     #$scriptThisVersion = Test-ScriptFileInfo $MyInvocation.MyCommand.Source
     #$scriptDownloadedVersion = Test-ScriptFileInfo $scriptDownloaded
     
     if ( [double]$scriptThisVersion.Version -LT [double]$scriptDownloadedVersion.Version )
     {
         write-host -Foreground Green "`n There's a more recent version of this script:`n 
         Current Version: $($scriptThisVersion.Version)
             New Version: $($scriptDownloadedVersion.Version) "
         
         Release Notes:
         $($scriptDownloadedVersion.ReleaseNotes )

         $ans = Read-host  "   Y/N " 

         if ($ans -match "y")
         {
            Copy-Item $scriptDownloaded $MyInvocation.MyCommand.Source -Verbose
            write-host -Foreground Green "You must re-run the script"
            break
         } #end If
     } #end If
     #### END Check for latest script version


     
     Function InstallImportExcel 
     {    
          param ( $zipfile )

          ##### Install ImportExcel Modules ##### 
          $allPSmodule = $env:PSModulePath.Split(";") | ? { $_ -match "program files" } 
          $UserPSMODULE = $env:PSModulePath.Split(";") | ? { $_ -match "\\user" } 

          $ModulePath = $UserPSMODULE 

          if (test-path $allPSmodule)
          { $ModulePath = $allPSmodule
          }
          else
          {    #Create user directory if not exist
               New-Item -Path $ModulePath -Type:Directory -ErrorAction:SilentlyContinue
          }

          $ModulePath = gi $ModulePath 
          $zipfile  = $zipfile |dir | % { $_.Fullname }
          Expand-Archive $zipfile -DestinationPath $ModulePath -verbose
     }


     #Default No ExportCSV 
     $ExportCsvIfNoExcel = $False
     if ($CsvExport) { $ExportCsvIfNoExcel = $True }
     
     #Default as ExcelExport but not if vm name specified 
     $ExportExcelDEFAULT = $TRUE ;
     if ((! $ExportExcel )) { $ExportExcelDEFAULT = $FALSE } ;
     


     ##### Import ImportExcel Module #####
     # Get screen width for text
     $wWidth = (Get-Host).UI.RawUI.MaxWindowSize.Width - 5
     If ((gcm Export-Excel -ErrorAction:SilentlyContinue).count -lt 1 -AND (! $CsvExport) )
     {
          if(! $ImportExcelModulePath )
          {
               $paths = $env:path.split(";"), "$ENV:USERPROFILE\downloads", "C:\temp", "$ENV:USERPROFILE\Desktop", "$ENV:USERPROFILE\Documents", $ENV:USERPROFILE, ".\" | % { $_ }
               $ImportExcelModulePath = Get-ChildItem ImportExcel.zip -Path $paths | select-object -First 1
          }

          # Atempt Install of ImportModule with local zip archive file
          if ( $ImportExcelModulePath | test-path  )
          {
               InstallImportExcel $ImportExcelModulePath
          }

          if((gcm Export-Excel -ErrorAction:SilentlyContinue).count -lt 1 )
          {
               #print freeform text
               WRITE-HOST -foreground yellow {
                    Requirements:
                    ImportExcel Module. Oneliner installation:
                    Find-Module -Name ImportExcel | Install-Module -Name ImportExcel;

                    Set-ExecutionPolicy to Bypass or Unrestricted (requires powershell Administrator mode)
                    Set-ExecutionPolicy Bypass -Force

                    VMware VMware.PowerCLI Modules
                    Find-Module VMware.PowerCLI; Install-Module VMware.PowerCLI

                    Powershell TLS Version may not match Microsoft

                    See: https://www.powershellgallery.com/packages/ImportExcel/
               } #end WRITE-HOST


               WRITE-HOST ("X" * $wWidth) "`nImporting Module: ImportExcel. Press CTRL-C to stop.`n" ("X" * $wWidth)
               $null = Set-PowerCLIConfiguration -ProxyPolicy NoProxy -InvalidCertificateAction Ignore -Confirm:$false -DefaultVIServerMode Multiple -Scope User
               $null = Set-ExecutionPolicy Bypass -Confirm:$false -Force
               Find-Module -Name ImportExcel | Install-Module -Verbose:$True
          }
          
     } #endif ImportExcel
     
     
     If ((gcm Export-Excel -ErrorAction:SilentlyContinue).count -lt 1)
     {
          #ImportExcel Module missing, export to CSV
          Write-Host ImportExcel Module not present.
          
          ## ImportExcel not installed
          $ExportCsvIfNoExcel = $True
          
          
     }
     
     ##### Import VMware Powercli Module #####     
     #Include VMware modules exist
     If ((gcm Get-VmHost -ErrorAction:SilentlyContinue).count -eq 0)
     {
          WRITE-HOST ("X" * $wWidth) "`nImporting Module : VMware.PowerCLI. Press CTRL-C to stop.`n" ("X" * $wWidth)
          Find-Module -Name VMware.PowerCLI -ErrorAction:SilentlyContinue | Install-Module -Force -Verbose
          
     }
     

     if ($vCenter){
          #$null = 
          $DefaultVIServers | ? { $_.Name -ne $vCenter } | Disconnect-ViServer -Force -Confirm:0 #-ErrorAction:Ignore
     }


     IF ( ( $DefaultVIServers.Count -gt 1 ) )
     {
          WRITE-HOST "` "  Choose which vCenter to use. "`n"
          

          #show numbered vCenter Connection List
          $i=$null; $i++ ; 
          $DefaultVIServers.Name | % { "  " + $i++ + ") " + $_  } ; 

           "  $i) NONE" 

          $choiceVc = 0
          do 
          { 
               [int]$choiceVc = (Read-Host " Type number")
          } Until ( $choiceVc.GetType().name -match "int"  -and $choiceVc -gt 0 -and $choiceVc -lt ($i + 1 ) )

          $vCenter = $DefaultVIServers[$choiceVc -1]
          
          if (! $vCenter  ){
               $null = $DefaultVIServers | Disconnect-ViServer -Force -Confirm:0 #-ErrorAction:Ignore
          }else {
               $null = $DefaultVIServers | ? { $_.name -ne $vCenter } | Disconnect-ViServer -Force -Confirm:0 #-ErrorAction:Ignore
          }
     }#end if


     if ( ! $DefaultVIServers) 
     {
          WRITE-HOST "`n Connection required. Using Get-VC";
          WRITE-HOST " If required, You'll be prompted for ""$vCenter"" credentials in a moment."
          
          if (! $vCenter){
               $vCenter = Read-Host " Type vCenter FQDN or IP address"
          }     

          if (! $Credential -OR ($Credential.GetType().name -notmatch "Credential") )
          {
               If (! $Credential) { 
               [string]$Credential = "Administrator@vsphere.local" 
               }

               [PsCredential]$Credential = Get-Credential -Message "VMware vCenter Credentials" -Username $Credential

          }

          WRITE-HOST " Connecting to $vCenter "   
          if ($vCenter -OR $Credential )
          {
               Connect-VIServer -Server $vcenter -Credential $Credential -Force  -verbose:$true | out-null
          }

     } #end if
     #END Connect to vCenter
     
     
     #vcenter connection doesn't exist
     if (! $DefaultVIServers)
     {
          WRITE-HOST -foreground:yellow "NO CONNECTION TO vCENTER."
          break #exit script because there are no vcenters
     }

    $MsgWriteProgressActivity = "Getting data once from vCenter: $DefaultVIServers"
    Write-Progress $MsgWriteProgressActivity  -Status (Get-Date)
     
     #WRITE-HOST "`n vCENTER: $( $DefaultVIServers.name -Join ", ") `n";
     write-host -foreground green " vCenter:      " $DefaultVIServer
     #GLOBAL VARIABLES for File output
     $vmInfo_OUTPUT = @()
     $FilesOnVm_OUTPUT = @()
     $DvdFloppy_OUTPUT = @()
     $Folders_OUTPUT = @()
     $Snapshots_OUTPUT = @()
     $vNetworkAdapter_OUTPUT = @()
     $vDisk_OUTPUT = @()
     $vmHost_OUTPUT = @()
     $VMKernelAdapters_OUTPUT = @()
     $vHBA_OUTPUT = @()
     $pNIC_CDP_OUTPUT = @()
     $Cluster_OUTPUT = @()
     $ResourcePool_vApp_OUTPUT = @()
     $Datastore_OUTPUT = @()
     $vLicense_OUTPUT = @()
     $vCenterExtensions_OUTPUT = @()
     $vSwitch_OUTPUT = @()
     $vPortgroup_OUTPUT = @()
     $vdSwitch_OUTPUT = @()
     $vdPortgroup_OUTPUT = @()
     $Datacenters_OUTPUT = @()
     $vmIP_OUTPUT = @()
     $DebugLOG_OUTPUT = @()
     
     $DrsRule_OUTPUT = @()
     $DrsClusterGroup_OUTPUT = @()
     $DrsVMHostRule_OUTPUT = @()
     
     $PIPELINEVM = @() #variable for vm's pipled to script
     
}

process
{
     #build array from Pipeline
     if ($_)
     {
          $PIPELINEVM += $_
          $Raw = $False
     }
     
} #end process


END
{

   Function ExportData
   {
     #############################
     ###### BEGIN Dashboard ######
     #This array contains list of variables to output to Dashboard and Excel Sheets.
     $OUTPUT_Variables = "Dashboard_OUTPUT
                         vmInfo_OUTPUT
                         HcxEligible_OUTPUT
                         Snapshots_OUTPUT
                         vDisk_OUTPUT
                         DvdFloppy_OUTPUT
                         FilesOnVm_OUTPUT
                         vNetworkadapter_OUTPUT
                         vmIP_OUTPUT
                         vSwitch_OUTPUT
                         vPortgroup_OUTPUT
                         vdSwitch_OUTPUT
                         vdportgroup_OUTPUT
                         ResourcePool_vApp_OUTPUT
                         Datacenters_OUTPUT
                         Cluster_OUTPUT
                         Datastore_OUTPUT
                         VMhost_OUTPUT
                         pNIC_CDP_OUTPUT
                         VMKernelAdapters_OUTPUT
                         vHba_OUTPUT
                         Folders_OUTPUT
                         DrsVMHostRule_OUTPUT
                         DrsRule_OUTPUT
                         DrsClusterGroup_OUTPUT
                         vLicense_OUTPUT
                         vCenterExtensions_OUTPUT
                         DebugLOG_OUTPUT".Split("`n").trim()
     
     #add HcxEligible count to Dashboard
     $hcxVMcount = ($vmInfo_OUTPUT | ? { $_.HcxEligible -eq $TRUE } | Measure).Count
     $row_Dashboard = "" | Select Collection, Count
     $row_Dashboard.Collection = "HcxEligible"
     #$row_Dashboard.Count = [string]$hcxVMcount + " of " + $vmInfo_OUTPUT.Count
     $row_Dashboard.Count = $hcxVMcount
     $HcxEligible_OUTPUT = $row_Dashboard
     
     if($vm_export_only) { $OUTPUT_Variables = "vmInfo_OUTPUT"  }
     
     $Dashboard_OUTPUT = @()
     Foreach ($var in $OUTPUT_Variables[1 .. 999]) #skip first two OUTPUT because it is the dashboard.
     {
          $row_Dashboard = "" | Select Collection, Count
          
          $row_dashboard.Collection = $var -replace "_OUTPUT"
          $row_dashboard.Count = (gv -name $var).Value.Count
          $Dashboard_OUTPUT += $row_Dashboard
     }
     
     #Remove HcxEligible_OUTPUT from Excel output because it is a dashboard only item
     $OUTPUT_Variables = $OUTPUT_Variables | ? { $_ -ne "HcxEligible_OUTPUT" }
     
     ###### END DASHBOARD ######
     
     
     ###############################################
     ###### BEGIN output file to excel or CSV ######
     #assign parameter $FilenamePath if provided

      #date string for generated filename for win/linux
      $date = get-date -Format yyyy-MM-dd_hh-mm-ss


     If ( $FilenamePath )
     {
     
          #if exists $FilenamePath
          if (Test-Path $FilenamePath)
          { 
            #Create new file with date
            $filename = (Split-Path $FilenamePath -Leaf ).split(".")[(Split-Path $FilenamePath -Leaf ).split(".").count -2] + ".$date." + (Split-Path $FilenamePath -Leaf ).split(".")[(Split-Path $FilenamePath -Leaf ).split(".").count -1]
            $Path = (Split-Path $FilenamePath -Parent ) + "\" +  $filename
          }else{
            #do not create new filename and use existing $FilenamePath
            $Path  = $FilenamePath
          }
          
     } else {
     
          #auto generate desktop filename
          $Path = "$env:USERPROFILE\Desktop\$date - $($row_dc.vCenter) - vInventory`.xlsx"
     }
     
     WRITE-HOST -Foreground Green "`n EXPORTING TO FILE $FilenamePath `n This could take a few moments. Exporting ..."
     #Export CSV  all data
     if ($ExportCsvIfNoExcel -OR $CsvExport  )
     {
          #Disable ExportExcel
          $ExportExcelDEFAULT = $False
          
          $Output_Dir = $Path -replace ".xlsx"
          New-Item -Path $Output_Dir -ItemType:Directory -Force -ErrorAction:SilentlyContinue | Out-Null
          WRITE-HOST -FOREGROUND WHITE $Output_Dir
          
          $i = $null

          #Export only $OUTPUT_Variables 

          foreach ($OUTPUT in $OUTPUT_Variables)
          {
               $i++

               if ((gv $OUTPUT).Value.count -lt 1){ continue }
               write-host -foreg yell $i $OUTPUT.count and (gv $OUTPUT).Value.count = $OUTPUT
               $Sheetname = ([string]$i).PadLeft(2,'0') + "-" + ((gv -Name $output).Name -replace "_OUTPUT") + ".csv"
               $Path = $Output_Dir + "\$Sheetname"
               
               (gv $OUTPUT).Value | Export-CSV $Path -NoTypeInformation
          }
          
          if(! $NoLaunch) { start $Output_Dir }
          
          
     }else{
         if ( $Path -notmatch "xlsx" ) { $Path = "$Path.xlsx" }
         
     }# end if $ExportCsvIfNoExcel


     if ($ExportExcelDEFAULT)
     {
          Write-Verbose -Message "`n STOPWATCH LAPSED SECONDS: $($Stopwatch.Elapsed.TotalSeconds)"

          $i = $null
          Foreach ($OUTPUT in $OUTPUT_Variables)
          {
               $i++

               if($vm_export_only)
               {
                  if ((gv $OUTPUT).Value.count -lt 2){ continue }
               }
               $Status = "$($i)/$($OUTPUT_Variables.Count) " + $($OUTPUT -replace "_.*" ) 
               WRITE-PROGRESS -Activity "PHASE 3/3: EXCEL: Exporting Sheets " -Status "$Status"  -PercentComplete ( (($i) / $OUTPUT_Variables.Count )*100 )
               #Insert Icons to Dashboard
               #$ConditionalFormatIconSet  = New-ConditionalFormattingIconSet -Range B2:B23 -ConditionalFormat:ThreeIconSet -IconType:Rating 
               #if (-not $DASHBOARD_OUTPUT){ $ConditionalFormatIconSet = $null }
               
               $sheetname = (gv -Name $output).Name -replace "_OUTPUT"
   
               (gv $OUTPUT).Value | Export-Excel -Path $Path -WorksheetName $sheetname -TableName $sheetname -AutoSize -FreezeTopRow -AutoFilter -BoldTopRow -FreezeFirstColumn -Verbose:$False
          
          }#end Foreach
          
         ###### BEGIN ADD CHARTS
         $Chart_GuestOS          = $vmInfo_OUTPUT | Group GuestOs | select Name, Count | sort-object name
         $Chart_VmPerVMhost      = $vmInfo_OUTPUT | Group VmHost | Select-Object Name, Count | Sort-object Count 
         $Chart_PowerState       = $vmInfo_OUTPUT | Group PowerState | Select-Object Name, Count | Sort-object Count 
         $Chart_VmPerCluster     = $vmInfo_OUTPUT | Group Cluster | Select-Object Name, Count | Sort-object Count 
         $Chart_VMhostVersion    = $VmHost_OUTPUT  | Group Product | Select-Object Name, Count | Sort-object Count

         # create hash table to refernce variables above with chart types. could have done [ordered]@{ 'name'='value'}
         $CHART_Variables_HASH = New-Object System.Collections.Specialized.OrderedDictionary
         $CHART_Variables_HASH.Add("GuestOS" , "PieExploded" )
         $CHART_Variables_HASH.Add("PowerState" , "PieExploded" )
         $CHART_Variables_HASH.Add("VMperVmhost" , "BarStacked" )
         $CHART_Variables_HASH.Add("VMperCluster" , "BarStacked" )
         $CHART_Variables_HASH.Add("VMHostVersion" , "PieExploded" )

         #no charts if vm_export_only
         if($vm_export_only)
         { 
            $CHART_Variables_HASH = $null 
         }

         #output Charts to sheets
         Write-Host -Foreground Green " Generating Charts."

         #append extension to file name
         $i=0;
         
         Foreach ($CHART in $CHART_Variables_HASH.Keys)
         {  
            if ($NoChartExport){ continue }
            
            $i++
            $Status = "$($i)/$($CHART_Variables_HASH.Count) " + $( $CHART -replace "_.*" ) 
            WRITE-PROGRESS "PHASE 3/3: EXCEL: Creating Charts " -Status $Status -PercentComplete  ( ($i/$CHART_Variables_HASH.Keys.Count )*100 )
            $data = ( Gv "CHART_$CHART" ).Value ;
            $sheetname = "CHART_$CHART" 
            $ChartType = $CHART_Variables_HASH[ $chart ]

            $data  | Export-Excel -Path  $Path -AutoFilter -WorksheetName $sheetname -AutoNameRange -AutoSize -TableName $CHART -TitleBackgroundColor BLUE
            $excel = Open-ExcelPackage $Path  ;
            Add-ExcelChart -Worksheet $excel."$sheetname" -ChartType $ChartType -Title $CHART -XRange Name -YRange Count  -ShowPercent ; #-ShowCategory removed to reduce cluster
            Close-ExcelPackage $excel ;
         }
        ###### END ADD CHARTS

     }else{
         #exit #if no export-excel 
     } #end if $ExportExcelDEFAULT
     
     RETURN $Path
     
     ###### END output  #####
   }# Function ExportData 
   


   Function Get-Snapshotinfo
   { 
      [cmdletBinding(SupportsShouldProcess=$false,DefaultParameterSetName="VM")]
       Param(
      [parameter(Mandatory=$true,ValueFromPipeline=$true, ParameterSetName="VM")]
      [VMware.Vim.VirtualMachine[]]
      $VM,

      [parameter(Mandatory=$true,ValueFromPipeline=$true, ParameterSetName="Snaptree")]
      [VMware.Vim.VirtualMachineSnapshotTree[]]
      $VirtualMachineSnapshotTree,

      [parameter(ParameterSetName="VM")] 
      [parameter(ParameterSetName="Snaptree")]
      [string] $Filter
       )

       Process {
      switch ($PScmdlet.ParameterSetName) 
      {
          "Snaptree"
             {
            Foreach ($Snapshot in $VirtualMachineSnapshotTree) 
            {
                Foreach ($ChildSnap in $Snapshot.ChildSnapshotList) 
                {
                  if ($ChildSnap) 
                  {
                  Get-Snapshotinfo -VirtualMachineSnapshotTree $ChildSnap -Filter $Filter
                  }
                }#Foreach $Snapshot.ChildSnapshotList

                If ($Snapshot.Name -match $Filter ) { $Snapshot | Select * }

            } #Foreach $VirtualMachineSnapshotTree
             }
          "VM"
               {
               Foreach ($v in $VM) {
                   $sDate = Get-Date
                   Get-Snapshotinfo -VirtualMachineSnapshotTree $v.Snapshot.RootSnapshotList -Filter $Filter | select @{N="VM" ; E= {$v.name} }, 
                   @{"N"="DaysOld"; E = { (($sDate - $_.CreateTime ).TotalDays) | % { [math]::Round($_,1) }  } }, 
                   Snapshot, 
                   Vm, 
                   Name, 
                   Id, 
                   CreateTime, 
                   @{ N="SS_State" ; E = { $_.State } } , 
                   Quiesced, 
                   @{"N"="SizeGB"; E= {
                   $v.LayoutEx | % { $_.File } | ? { $_.type -match "snap" } | % { $_.Size } | Measure-Object -sum | % { [Math]::Round($($_.sum / 1gb),2) } }}, 
                   @{"N"="Description"; E= { $_.Description.trim() }}, 
                   @{N="vCenter" ; E = {$v.Client.ServiceUrl.Split("/")[2].split(":")[0]  }}
               }#Foreach 
                }
         }#switch
       }#process
     }# Function Get-Snapshotinfo
    
     ##### function to recurse path of root to VM
     Function GetvCenterFolderPath
     {
          param ($obj)
          $PATH_TO_RETURN = @()
          $PATH_TO_RETURN += $obj.Name
          switch -regex ($obj.Parent)
          {
               'ResourcePool' { $PATH_TO_RETURN += GetvCenterFolderPath ($ResourcePools | ? { $_.Moref -eq $obj.parent }) }
               'Folder'       { $PATH_TO_RETURN += GetvCenterFolderPath ($Folders | ? { $_.Moref -eq $obj.parent }) }
               'Datacenter'   { $PATH_TO_RETURN += GetvCenterFolderPath ($Datacenters | ? { $_.Moref -eq $obj.parent }) }
               'Cluster'      { $PATH_TO_RETURN += GetvCenterFolderPath ($Clusters | ? { $_.Moref -eq $obj.parent }) }
               'Host'         { $PATH_TO_RETURN += GetvCenterFolderPath ($VmHosts | ? { $_.Moref -eq $obj.parent }) }
          }
          [array]::Reverse($PATH_TO_RETURN)
          $PATH_TO_RETURN = ($PATH_TO_RETURN -join "\") ###-replace "^Datacenters\\|\\host\\|\\Resources\\" , "\"
          if (! $o.Parent)
          { 
               $PATH_TO_RETURN = $obj.Client.ServiceUrl.Split("/")[2] + "\" + $PATH_TO_RETURN
          }
          RETURN $PATH_TO_RETURN
          
     } ### Function GetvCenterFolderPath
     
     
     ##### function to recurse path of root to VM
     Function GetvCenterResourcePath
     {
          param ($obj)
          $PATH_TO_RETURN = @()
          $PATH_TO_RETURN += $obj.Name
          $o = $obj
          if ($obj.gettype().Name -match "VirtualMachine|Host")
          {
               $o = $ResourcePools | ? { $_.Moref -eq $obj.ResourcePool };
               $PATH_TO_RETURN += $o.Name;
          }
          
          switch -regex ($o.Parent)
          {
               'ResourcePool' { $PATH_TO_RETURN += GetvCenterResourcePath ($ResourcePools | ? { $_.Moref -eq $o.parent }) }
               'Folder'       { $PATH_TO_RETURN += GetvCenterResourcePath ($Folders | ? { $_.Moref -eq $o.parent }) }
               'Datacenter'   { $PATH_TO_RETURN += GetvCenterResourcePath ($Datacenters | ? { $_.Moref -eq $o.parent }) }
               'Cluster'      { $PATH_TO_RETURN += GetvCenterResourcePath ($Clusters | ? { $_.Moref -eq $o.parent }) }
               'Host'         { $PATH_TO_RETURN += GetvCenterResourcePath ($VmHosts | ? { $_.Moref -eq $o.parent }) }
          }
          [array]::Reverse($PATH_TO_RETURN)
          $PATH_TO_RETURN = ($PATH_TO_RETURN -join "\") ###-replace "^Datacenters\\|\\host\\|\\Resources\\" , "\"
          
          if (! $o.Parent)
          {
               $PATH_TO_RETURN = $obj.Client.ServiceUrl.Split("/")[2] + "\" + $PATH_TO_RETURN
          }
          
          RETURN $PATH_TO_RETURN
     } ### End Function GetvCenterResourcePath
     
     
     #choose -VM or pipeline
     if ($PIPELINEVM.count -gt 0)
     {
          $vmList = $PIPELINEVM
     }
     
     $vmList = $VM -replace "\*", ".*" #replace * with .* for regex
     
     #convert paramater ary to filter string (regex)
     $vmlist = $vmlist -join "|"
     
     #otuput raw data onlye
     if ($Raw)
     {
          GET-VIEW -ViewType VirtualMachine -Filter @{ "Name" = $vmlist }
          break #after output raw data to screent
     }
     
     $Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
     
     #$viewtypes = "VirtualMachine,ComputeResource,Datacenter,Datastore,DistributedVirtualPortgroup,DistributedVirtualSwitch,Folder,HostSystem,Network,OpaqueNetwork,ResourcePool,StoragePod,VirtualApp,VmwareDistributedVirtualSwitch".Split(",") | % { $_.trim() }
     
     #######################################################
     ##### Get vCenter Inventory Data in this section
     #Get Virtual Machines from vmware.core.automation api 
     $VMViews = GET-VIEW -ViewType VirtualMachine -Filter @{ "Name" = $vmlist; } -Property Datastore, Name, Network, Layout, LayoutEx, RootSnapshot, Snapshot, ResourceConfig, ResourcePool, Parent, Storage, Guest, Config, Summary, Storage, Runtime | ? { $_.Config.FtInfo.Role -ne 2  } | Sort-Object Name

     if($ExactMatch){
      $VMViews = $VMViews | ? { $_.Name -in $vmlist.split("|") }
     }
     
     #stop if no VMs
     if ($VMViews.count -lt 1){ break }
     
     #Get all vcenter Extensions - 1 line
     $vCenterExtensions_OUTPUT = ( Get-View ExtensionManager -Property ExtensionList ).ExtensionList | select @{N='Extension';E={$_.Description.Label}}, Version, Company, @{N="vCenter"; E={ $x.Client.ServiceUrl.Split("/")[2] }}  | Sort-Object Extension, version

     WRITE-PROGRESS -Activity $MsgWriteProgressActivity - Status $([string]$vmviews.count + " vm's found ") 

     if($vmlist)
     { 
      #-filter and Get-View Moref are the same speed. But -Filter seems faster for remote vcenters
      $VmHosts =        GET-VIEW -ViewType HostSystem -Property Name, Config, ConfigManager, Network, Hardware.PciDevice, Datastore, Runtime, VM, Summary, Parent, Capability -Filter @{"Summary.Host"=($VMviews.Runtime.Host.value|group).Name -join "|" } | Sort-Object Name   
      $Folders =        GET-VIEW ( $vmviews.Parent | group  ).Name
      #$Clusters =      GET-VIEW -ViewType ClusterComputeResource -Property Name, Parent, Summary, Configuration, ConfigurationEx, Datastore, ResourcePool, Host | ? { $_.Moref -in $vmhosts.parent }  |  Sort-Object Name
      $Clusters =       GET-VIEW ( $vmhosts.parent | group ).Name -Property Name, Parent, Summary, Configuration, ConfigurationEx, Datastore, ResourcePool, Host | Sort-Object Name
      $Datastores =     GET-VIEW ($VMviews.Datastore|group).Name -Property Name, Info, Host, Summary, VM
      $Datacenters =    GET-VIEW -ViewType Datacenter | ? { $_.Datastore -match ($Datastores.Moref -join "|" ) }
      $vdSwitches =     GET-VIEW -ViewType VmwareDistributedVirtualSwitch -Filter @{"Name" = ($vmhosts.Config.Network.ProxySwitch | group Dvsname ).Name -Join "|" }
      $vdPortgroups =  (GET-VIEW ( $vmviews.Network | select -unique) | ? { ! $_.Config.Uplink } | Group Moref ) | % { $_.Group | select -Unique }
      $ResourcePools =  GET-VIEW ($vmviews.ResourcePool | Group).Name

     }else{

      $VmHosts =        GET-VIEW -ViewType HostSystem -Property Name, Config, ConfigManager, Network, Hardware.PciDevice, Datastore, Runtime, VM, Summary, Parent, Capability | ? { $_.Moref -in $VMviews.Runtime.Host} | Sort-Object Name
      $Folders =        GET-VIEW -ViewType Folder #-Property Name, Parent, Parent, Child
      $Clusters =       GET-VIEW -ViewType ClusterComputeResource -Property Name, Parent, Summary, Configuration, ConfigurationEx, Datastore, ResourcePool, Host | Sort-Object Name
      $Datastores =     GET-VIEW -ViewType Datastore -Property Name, Info, Host, Summary, VM
      $Datacenters =    GET-VIEW -ViewType Datacenter
      $vdSwitches =     GET-VIEW -ViewType VmwareDistributedVirtualSwitch
      $vdPortgroups =   GET-VIEW -ViewType Network | ? { ! $_.Config.Uplink } | sort-object name
      $ResourcePools =  GET-VIEW -ViewType ResourcePool #-Property Name, Parent
      
     }



     ###########################################
     
     WRITE-HOST -foreground:Green " VM Count:     " $VMViews.Count
     WRITE-HOST -foreground:Green " Folders:      " $Folders.Count
     WRITE-HOST -foreground:Green " Clusters:     " $Clusters.Count
     WRITE-HOST -foreground:Green " VmHost:       " $VmHosts.Count
     WRITE-HOST -foreground:Green " vSwitches:    " $VmHosts.Config.Network.Vswitch.Count
     WRITE-HOST -foreground:Green " Portgroup:    " $($VmHosts.Network | ? { $_.Type -Match "network" } | select -Unique ).Count
     WRITE-HOST -foreground:Green " Datacenters:  " $Datacenters.Count
     WRITE-HOST -foreground:Green " Datastores:   " $Datastores.Count
     WRITE-HOST -foreground:Green " ResourcePool: " $ResourcePools.Count
     WRITE-HOST -foreground:Green " vdSwitch:     " $vdSwitches.Count
     WRITE-HOST -foreground:Green " dvPortgroups: " $($VmHosts.Network | ? { $_.Type -Match "Dist" } | group Value | measure | % { $_.count })
     WRITE-HOST -foreground:Green " Portgroups :  " ( $vmhosts | % { $_.config.Network.Portgroup } ).COUNT
     Write-Verbose -Message "`n STOPWATCH LAPSED SECONDS: $($Stopwatch.Elapsed.TotalSeconds)"
     
     ######################################
     ####### BEGIN Resource Pools #########
     
     Foreach ($rp in $ResourcePools)
     {
          $row_rp = "" | Select ResourcePool, ResourceType, vAppState, ResourcePath, Status, VMs, vCPUs, CpuLimit, CpuReservation, vMemMB, MemLimit, MemReservation, OverallCpuUsage, OverallCpuDemand, GuestMemoryUsage, HostMemoryUsage, DistributedCpuEntitlement, DistributedMemoryEntitlement, StaticCpuEntitlement, StaticMemoryEntitlement, PrivateMemory, SharedMemory, SwappedMemory, BalloonedMemory, OverheadMemory, ConsumedOverheadMemory, CompressedMemory, MoRef, vCenter
          
          $VMviews_this = $VMViews | ? { $Rp.vm -contains $_.MoRef }
          
          $row_rp.ResourcePool = $rp.Name
          $row_rp.ResourceType = ($rp | gm -Type:Properties | select -f 1).TypeName.split(".")[2]
          #$row_rp.ResourcePath = GetvCenterResourcePath $rp
          $row_rp.vAppState = $rp.Summary.VAppState
          #$row_rp.ResourcePath = GetvCenterFolderPath $rp
          $row_rp.VMs = $rp.Vm.Count
          $row_rp.Status = $rp.OverallStatus
          $row_rp.vCPUs = $VMviews_this.Config.Hardware | Measure-Object -sum NumCPU | % { $_.Sum }
          $row_rp.vMemMB = $VMviews_this.Config.Hardware | Measure-Object -sum MemoryMB | % { $_.Sum }
          $row_rp.CpuLimit = $rp.Summary.Quickstats.CpuLimit
          $row_rp.CpuReservation = $rp.Summary.Quickstats.CpuReservation
          $row_rp.MemLimit = $rp.Summary.Quickstats.MemLimit
          $row_rp.MemReservation = $rp.Summary.Quickstats.MemReservation
          $row_rp.OverallCpuUsage = $rp.Summary.Quickstats.OverallCpuUsage
          $row_rp.OverallCpuDemand = $rp.Summary.Quickstats.OverallCpuDemand
          $row_rp.GuestMemoryUsage = $rp.Summary.Quickstats.GuestMemoryUsage
          $row_rp.HostMemoryUsage = $rp.Summary.Quickstats.HostMemoryUsage
          $row_rp.DistributedCpuEntitlement = $rp.Summary.Quickstats.DistributedCpuEntitlement
          $row_rp.DistributedMemoryEntitlement = $rp.Summary.Quickstats.DistributedMemoryEntitlement
          $row_rp.StaticCpuEntitlement = $rp.Summary.Quickstats.StaticCpuEntitlement
          $row_rp.StaticMemoryEntitlement = $rp.Summary.Quickstats.StaticMemoryEntitlement
          $row_rp.PrivateMemory = $rp.Summary.Quickstats.PrivateMemory
          $row_rp.SharedMemory = $rp.Summary.Quickstats.SharedMemory
          $row_rp.SwappedMemory = $rp.Summary.Quickstats.SwappedMemory
          $row_rp.BalloonedMemory = $rp.Summary.Quickstats.BalloonedMemory
          $row_rp.OverheadMemory = $rp.Summary.Quickstats.OverheadMemory
          $row_rp.ConsumedOverheadMemory = $rp.Summary.Quickstats.ConsumedOverheadMemory
          $row_rp.CompressedMemory = $rp.Summary.Quickstats.CompressedMemory
          $row_rp.MoRef = $rp.moref
          $row_rp.vCenter = $rp.Client.ServiceUrl.split("/")[2]
          $ResourcePool_vApp_OUTPUT += $row_rp
     }

     ######################################
     ########### vdSwitches BEGIN ##########
     Foreach ($vdSwitch in $vdSwitches)
     {
          $row_vdSw = "" | Select Name, vdSwitch, Vendor, Version, CreatedUTC, VmHosts, VmHostMembers, VLAN_Default,
                                        vdPortGroups, Ports, MaxPorts, VMs, TrafficShapingIN, InAvg, InPeak, InBurst,
                                        TrafficShapingOUT, OutAvg, OutPeak, OutBurst,
                                        DiscoveryProtocol, DiscoveryOperation, MTU, uuid, MoRef, vCenter

          $VmHosts_here = $VmHosts | ? { $_.Moref -in $vdSwitch.Config.Host.Config.host }
          $row_vdSw.Name = $vdSwitch.Name
          $row_vdSw.vdSwitch = $vdSwitch.Name
          $row_vdSw.Ports = $vdSwitch.config.Numports
          $row_vdSw.MaxPorts = $vdSwitch.config.MaxPorts
          #$row_vdSw.Datacenter = (GetvCenterResourcePath $vdSwitch).split("\\")[1]
          $row_vdSw.Version = $vdSwitch.Config.ProductInfo.Version
          $row_vdSw.Vendor = $vdSwitch.Config.ProductInfo.Vendor
          $row_vdSw.CreatedUTC = $vdSwitch.Config.CreateTime
          $row_vdSw.VmHosts = $VmHosts_here.Count
          $row_vdSw.VmHostMembers = $VmHosts_here.Name -join ", "
          $row_vdSw.vdPortGroups = $vdSwitch.Portgroup.Count
          $row_vdSw.uuid = $vdSwitch.uuid
          $row_vdSw.VMs = $vdSwitch.Summary.vm.count
          #$row_vdSw.uplinkCount = $vdSwitch.Config.Host.Config.Backing.pNicSpec.Count
          #$row_vdSw.Uplinks = $vdSwitch.Config.Host.Config.Backing.pNicSpec.pnicDevice -join ", "    ###### This line shows vmnics of every host. need to key portgroups and pnics to get vmhost associated 
          ## incorrect. does not show uplinks ##$row_vdSw.uplinks = ( $vdSwitch.Config.Host.Config.Backing.pNicSpec.PnicDevice | group ).Name -join "," 
          $row_vdSw.VLAN_Default = $vdSwitch.Config.DefaultPortConfig.Vlan.VlanId
          $row_vdSw.TrafficShapingIn = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.Enabled.Value
          $row_vdSw.InAvg = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.AverageBandwidth.Value
          $row_vdSw.InPeak = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.PeakBandwidth.Value
          $row_vdSw.InBurst = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.BurstSize.Value
          $row_vdSw.TrafficShapingOUT = $vdSwitch.Config.DefaultPortConfig.OutShapingPolicy.Enabled.Value
          $row_vdSw.OutAvg = $vdSwitch.Config.DefaultPortConfig.OutShapingPolicy.AverageBandwidth.Value
          $row_vdSw.OutPeak = $vdSwitch.Config.DefaultPortConfig.OutShapingPolicy.PeakBandwidth.Value
          $row_vdSw.OutBurst = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.BurstSize.Value
          $row_vdSw.DiscoveryProtocol = $vdSwitch.Config.LinkDiscoveryProtocolConfig.Protocol
          $row_vdSw.DiscoveryOperation = $vdSwitch.Config.LinkDiscoveryProtocolConfig.Operation
          $row_vdSw.MTU = $vdSwitch.Config.MaxMtu
          $row_vdSw.vCenter = $vdSwitch.Client.ServiceUrl.Split("/")[2]
          $row_vdSw.Moref = $vdSwitch.Moref
          
          $vdSWITCH_OUTPUT += $row_vdSw
          
     } #end vdSwitches Loop
     
     #$vdSWITCH_OUTPUT = $vdSWITCH_OUTPUT  | Group Moref | % { $_.Group | select -f 1 }
     
     
     
     ###### vdPortgroups BEGIN ######
     Foreach ($vdPortgroup in $vdPortgroups)
     {
          $row_vdPG = "" | Select vdPortgroup, vdSwitch, VmHosts, VMs, VLAN, Netflow, SecurityPolicyInherited, Promiscuous, MacChanges, ForgedTransmits,
                                        TrafficShapingIN, AverageBandwidthIN, PeakBandwidthIN, BurstSizeIN, TrafficShapingOUT, AverageBandwidthOUT,
                                        PeakBandwidthOUT, BurstSizeOUT, NicTeamingInherited, ReversePolicy, UplinkOrder, UplinkStandbyOrder,
                                        UplinkInherited, NotifySwitch, Key, Moref, vCenter
          
          $row_vdPG.VLAN = $vdPortgroup.Config.DefaultPortConfig.Vlan.VlanId
          If ($vdPortgroup.Config.DefaultPortConfig.Vlan.VlanId.Start)
          {
               $row_vdPG.VLAN = ($vdPortgroup.Config.DefaultPortConfig.Vlan.VlanId | % { [string]$_.Start + "-" + $_.End }) -join ", "
          }
          
          $vswitch_this_dvPG = $vdSwitches | ? { $_.Portgroup.Value -contains $vdPortgroup.key }
          
          $row_vdPG.Netflow = $vdPortgroup.Config.DefaultPortConfig.IpfixEnabled.Value
          $row_vdPG.vdPortgroup = $vdPortgroup.Name
          $row_vdPG.vdSwitch = $vswitch_this_dvPG.Name
          $row_vdPG.VmHosts = $vdPortgroup.Host.Count
          $row_vdPG.Vms = $vdPortgroup.VM.Count
          $row_vdPG.SecurityPolicyInherited = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.Inherited
          $row_vdPG.Promiscuous = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.AllowPromiscuous.value
          $row_vdPG.MacChanges = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.MacChanges.value
          $row_vdPG.ForgedTransmits = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.ForgedTransmits.value
          $row_vdPG.TrafficShapingIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.Enabled.Value
          $row_vdPG.AverageBandwidthIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.AverageBandwidth.Value
          $row_vdPG.PeakBandwidthIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.PeakBandwidth.Value
          $row_vdPG.BurstSizeIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.BurstSize.Value
          $row_vdPG.TrafficShapingOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.Enabled.Value
          $row_vdPG.AverageBandwidthOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.AverageBandwidth.Value
          $row_vdPG.PeakBandwidthOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.PeakBandwidth.Value
          $row_vdPG.BurstSizeOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.BurstSize.Value
          $row_vdPG.NicTeamingInherited = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.Inherited
          $row_vdPG.ReversePolicy = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.ReversePolicy.Value
          $row_vdPG.UplinkInherited = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.UplinkPortOrder.Inherited
          $row_vdPG.UplinkOrder = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.UplinkPortOrder.ActiveUplinkPort -join ", "
          $row_vdPG.UplinkStandbyOrder = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.UplinkPortOrder.StandbyUplinkPort -join ", "
          $row_vdPG.NotifySwitch = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.NotifySwitches.Value
          $row_vdPG.Key = $vdPortgroup.Key
          $row_vdPG.vCenter = $vdPortgroup.Client.ServiceUrl.split("/")[2]
          $row_vdPG.Moref = $vdPortgroup.Moref
          
          $vdPORTGROUP_OUTPUT += $row_vdPG
          
     } #END vDPORTGROUPS
     
     #$vdPORTGROUP_OUTPUT  = $vdPORTGROUP_OUTPUT | group moref | % { $_.Group | select -f 1 } # not necessary, breaks things
     
     
     
     ########### BEGIN VMViews vmInfo loops  ##########
     ForEach ($VMView in $VMViews)
     {
          $xx++
          write-progress "$xx of  $($vmviews.Count) " -activity "PHASE 1/3: Getting VM info"  -PercentComplete (($xx / $VMviews.count ) * 100)
          $VmHost = $VmHosts | ? { $_.moref -eq $VMView.Runtime.host } | ? { $_.vm -eq $VMView.Moref };
          $Cluster = $Clusters | ? { $_.Moref -eq $VmHost.Parent }
          $Folder = $Folders | ? { $_.Moref -eq $VMview.Parent }
          
          $row_vm = "" | Select VM, DnsName, PowerState, IsTemplate, MemGB, MemReserved, MemMaxReserved, "MemActive%", "MemConsumed%",
                                     MemoryReservation, SwapReservation, SwappedMemory, BalloonedMemory,
                                     Cpu, CoresPerSocket, CpuSockets, "CpuDemand%", "CpuUsage%",
                                     NumaSize, ReserveCpu, HotAddCpu, HotAddMem, Annotation, NICs,
                                     IP, IpPrimary, GuestOS, vmtools_GuestOS, Tools, ToolsStatus, syncTime,
                                     Disks, DiskRdmPhysical, DiskRdmVirtual, DiskShared, DiskGB, DiskGBUsed, DiskType, VirtualMedia, vHardware, VmHost, EsxiVersion,
                                     Snapshots, SnapshotBytes, SnapshotGB, ResourcePool, Folder, Firmware, vcFolderPath, ResourcePath,
                                     Cluster, vCenter, Datacenter, InstanceUuid, UUID, MoRef, onVSwitch, onVDswitch, HcxEligible, HcxDisqualifier, sVmotionEligible, sVmotionDisqualifier, createDate
                                     
          $VirtualEthernetCardDEVICE = $vmview.Config.Hardware.Device | ? { $_ -is [VMware.Vim.VirtualEthernetCard] }

          $row_vm.vm = $vmview.Name
          $row_vm.createDate = $vmview.config.createDate
          $row_vm.Annotation = $vmview.config.Annotation
          $row_vm.Snapshots = $vmview.LayoutEx.File | ? { $_.Type -Match "snapshot" } | Measure-Object | % { $_.Count }
          $row_vm.SnapshotBytes = $vmview.LayoutEx.File | ? { $_.Type -Match "snapshot" } | Measure-Object size -sum | % { $_.Sum }
          $row_vm.SnapshotGB = $vmview.LayoutEx.File | ? { $_.Type -Match "snapshot" } | Measure-Object size -sum | % { $_.Sum / 1gb } | % { [math]::Round($_, 2) }
          #not needed because templates won't show # $row_vm.Type = if($vmview.Config.Template){"Template"}else{"VM"}
          $row_vm.IsTemplate = [string]$vmview.Config.Template
          $row_vm.NICs = $VirtualEthernetCardDEVICE.Count
          $row_vm.PowerState = $vmview.Runtime.PowerState
          $row_vm.MemGB = $vmview.Summary.Config.MemorySizeMB / 1kb | % { [math]::Round($_, 2) }
          #$row_vm.MemReserveGB = [math]::Round(($vmview.Summary.Config.MemoryReservation / 1024), 1)
          $row_vm.MemReserved = if( $vmview.ResourceConfig.MemoryAllocation.reservation ) { "{0:p0}" -f ( $vmview.Summary.Config.MemorySizeMB / $vmview.ResourceConfig.MemoryAllocation.reservation )  }
          $row_vm.MemMaxReserved = $vmview.Config.MemoryReservationLockedToMax -eq $True | % { $_.tostring() }
          $row_vm.Firmware = $vmview.Config.Firmware
          $row_vm."MemActive%" = ($vmview.Summary.QuickStats.GuestMemoryUsage / $vmview.Summary.Config.MemorySizeMB * 100) | % { [math]::Round($_, 1) }
          $row_vm."MemConsumed%" = ($vmview.Summary.QuickStats.PrivateMemory / $vmview.Summary.Config.MemorySizeMB * 100) | % { [math]::Round($_, 1) }
          $row_vm.MemoryReservation = $vmview.Config.InitialOverhead.InitialMemoryReservation
          $row_vm.SwapReservation = $vmview.Config.InitialOverhead.InitialSwapReservation
          $row_vm.SwappedMemory = $vmview.Summary.Quickstats.SwappedMemory
          $row_vm.BalloonedMemory = $vmview.Summary.Quickstats.BalloonedMemory
          $row_vm.Cpu = $vmview.Config.Hardware.NumCPU
          $row_vm.CoresPerSocket = $vmview.Config.Hardware.NumCoresPerSocket
          $row_vm.CpuSockets = $vmview.Config.Hardware.NumCPU / $vmview.Config.Hardware.NumCoresPerSocket
          $row_vm."CpuDemand%" = [decimal]($vmview.Summary.QuickStats.OverallCpuDemand) / $vmhost.summary.hardware.CpuMhz #mhz
          $row_vm."CpuUsage%" = [decimal]($vmview.Summary.QuickStats.OverallCpuUsage) / $vmhost.summary.hardware.CpuMhz #Mhz
          
          $row_vm.ReserveCpu = $vmview.ResourceConfig.CpuAllocation.Reservation
          $row_vm.HotaddCpu = $vmview.Config.ExtraConfig | ? { $_.Key -match "vCpu.hotAdd" } | % { $_.Value -eq $True }
          $row_vm.HotaddCpu = if (($row_vm.HotaddCpu | measure).count -eq 0) { "False" }
          else { "True" }
          $row_vm.NumaSize = if ($row_vm.HotaddCpu -eq $false)
          {
               $vmview.Config.ExtraConfig | ? { $_.key -eq "numa.autosize.vcpu.maxPerVirtualNode" } | % { $_.value }
          }
          else { "None" }
          $row_vm.HotaddMem           = $vmview.Config.ExtraConfig | ? { $_.Key -match "mem.hotAdd" } | % { [bool]$_.value }
          $row_vm.HotaddMem           = $row_vm.HotaddMem -eq $True | % { $_.tostring() } #converts null to false
          $row_vm.IP                  = ($vmview.Guest.Net.IpAddress | ? { $_ -match "\." }) -join ", "
          $row_vm.DnsName             = $vmview.Guest.IpStack.DnsConfig.HostName  -join ", "
          $row_vm.GuestOS             = $vmview.Summary.Config.GuestFullName
          $row_vm.vmtools_GuestOS     = $vmview.Guest.GuestFullName
          $row_vm.InstanceUuid        = $vmview.Summary.Config.InstanceUUID
          $row_vm.Uuid                = $vmview.Summary.Config.uuid
          $row_vm.Tools               = $vmview.Config.Tools.ToolsVersion
          $row_vm.ToolsStatus         = $vmview.Guest.ToolsStatus
          $row_vm.syncTime            = [bool]$vmview.Config.Tools.syncTimeWithHost
          $row_vm.DiskRdmPhysical     = ($vmview.Config.Hardware.Device | % { $_.Backing.CompatibilityMode }) -join " " -match "physical"
          $row_vm.DiskRdmVirtual      = ($vmview.Config.Hardware.Device | % { $_.Backing.CompatibilityMode }) -join " " -match "Virtual"
          $row_vm.DiskShared          = ($vmview.Config.Hardware.Device | ? { $_.Backing.CompatibilityMode }) | ? { $_.backing.Sharing.Trim() } | Select -f 1 | % {
                                             If ($_) { "TRUE" }
                                             else { "FALSE" }
                                             }
          $row_vm.Disks = ($vmview.Config.Hardware.Device | ? { $_.backing -match "disk" } | measure).count
          $row_vm.DiskGB = (($vmview.Config.Hardware.Device | ? { $_.backing -match "disk" } | % { $_.CapacityInKB } | Measure-Object -sum).Sum / 1mb) | % { ([Math]::Round($_, 0)) }
             #Get datastore path to parse out parent disks
             $dsPath = $vmview.LayoutEx | % { $_.File } | ? { $_.name -match ".vmx$" } | % { $_.Name.split("/")[0] }

          $row_vm.DiskGBUsed = $vmview.LayoutEx | % { $_.File } | ? { $_.Type -match "diskExtent" } | ? { $_.name.Split("/")[0] -eq $dsPath } | Measure-Object -sum UniqueSize | % { $_.Sum / 1gb } | % { if ($_ -gt 1 ){ [math]::Round($_,0) }else{ $_.ToString("#.###") } }
          
          $x = $VMView.Config.Hardware.Device.Backing.ThinProvisioned 
          if($x -contains $True  ) { $x = "Thin"  }
          if($x -contains $False ) { $x = "Thick" }
          if($x -contains $true -and $x -contains $false) { $x = "Mixed" }
  
          $row_vm.DiskType = $x
          $row_vm.VirtualMedia = $vmview.Config.Hardware.Device | ? { $_.DeviceInfo.Label -match "DVD|flop" } | % { $_.Connectable } | % { $_.Connected } | ? { $_ -eq $True } | Select -f 1 | % { "TRUE" }
          $row_vm.vHardware = $vmview.Config.Version -replace "vmx-"
          $row_vm.VmHost = $VmHost.name
          $row_vm.EsxiVersion = $VmHost.Config.Product.Version
          $row_vm.Folder = $Folder.Name
          $row_vm.ResourcePool = $ResourcePools | ? { $_.moref -eq $vmview.ResourcePool } | % { $_.name }
          ### ResourcePool may error with multiple vcenters              
          #$row_vm.vcFolderPath = GetvCenterFolderPath $vmview
          #$row_vm.Datacenter = $row_vm.vcFolderPath.split("\")[1]
          #$row_vm.ResourcePath = GetvCenterResourcePath $vmview
          $row_vm.Cluster = $Cluster.Name
          $row_vm.MoRef = $vmview.Moref
          $row_vm.vCenter = $vmview.Client.ServiceUrl.Split("/")[2]
          
          ### end of vmview select statement, however some fields below . look for row_vm

          
          #append row_vm for output below
          
          #### screen output ends here. Export-Excel only from this point.


         ##### BEGIN Virtualmedia DVD CD Floppy Drive #####
         #get DVD or FLoopy with Backing Files
         $VirtualMedias = $vmview.Config.Hardware.Device | ? { $_.DeviceInfo.Label -match "DVD|flop" }  
         
         foreach ($media in $VirtualMedias )
         { 
            $row_VirtualMedia = "" | SELECT VM, Type, Connected, StartConnected, Summary, Backing, vm_Moref
            $row_VirtualMedia.vm =  $Vmview.Name
            $row_VirtualMedia.Type = $media.DeviceInfo.Label
            $row_VirtualMedia.Summary = $media.DeviceInfo.Summary
            $row_VirtualMedia.Backing = $media.Backing.Filename
            $row_VirtualMedia.Connected = !! $media.Connectable.Connected
            $row_VirtualMedia.StartConnected = !! $media.Connectable.StartConnected
            $row_VirtualMedia.vm_Moref = $vmview.Moref
            
            $DvdFloppy_OUTPUT += $row_VirtualMedia
         }
          ##### END VirtualMEDIA DVD CD Floppy Drive #####
          




          ##### BEGIN vNETWORKAdapter_OUTPUT this VMVIEW Output#####
          Foreach ( $vEth in $VirtualEthernetCardDEVICE )
          {
               $row_vEth = "" | Select vmNetworkAdapter, Type, VM, vmUuid, PortGroup, "Switch", VLAN, MacAddress, Connected, StartsConnected, Status, PowerState, vCenter 
               
               #Get $vswitch from $VmHost for this $vmview 
               $row_vEth.IP = $row_GuestNet.IpAddress
               $row_vEth.Type = $vEth.GetType().Name -replace "virtual"
               $row_vEth.Mask = $row_GuestNet.Mask
               $row_vEth.DomainName = $row_GuestNet.DomainName 
               $row_vEth.SearchDomain = $row_GuestNet.SearchDomain
               $row_vEth.vmNetworkAdapter = $vEth.DeviceInfo.Label
               $row_vEth.VM = $vmview.name
               $row_vEth.vmUuID = $vmview.Summary.Config.uuid
               $row_vEth.PortGroup = $vEth.DeviceInfo.Summary

               $vSwitch_thisLoop = $null
               $vSwitch_thisLoop = $VmHost.Config.Network.Portgroup | ? { $_.Spec.Name -in $vEth.DeviceInfo.Summary }
               $row_vEth.VLAN = $vswitch_thisLoop.Spec.VlanId

               $row_vEth.Switch = $vswitch_thisLoop.Spec.VswitchName
               $row_vm.ONvSwitch = !! $vSwitch_thisLoop ##True if present, false not present

               if(! $vSwitch_thisLoop){ #if standard portgroup not exist
                  $vdSwitch_thisLoop = $vdSwitches | ? { $_.UUID -eq $vEth.DeviceInfo.Summary.Split(":")[1].trim()  }
               }

               $row_vEth.MacAddress = $vEth.MacAddress
               $row_vEth.Connected = $vEth.Connectable.Connected
               $row_vEth.StartsConnected = $vEth.Connectable.StartConnected
               $row_vEth.Status = $vEth.Connectable.Status
               $row_vEth.PowerState = $vmview.Runtime.PowerState
               $row_vEth.vCenter = $row_vm.vCenter
               
               #lookup vdPortgroup               
               if ($vEth.DeviceInfo.Summary -match "DVSwitch:")
               {
                    $vdPG = $vdPortgroups | ? { $_.Key -in $vEth.Backing.Port.PortgroupKey }
                    $row_vEth.PortGroup = $vdPortgroups | ? { $_.Key -in $vEth.Backing.Port.PortgroupKey } | % { $_.Summary.Name }
                    $row_vEth.VLAN = $vdpg.Config.DefaultPortConfig.Vlan.VlanId
                    $row_vEth.Switch = $vdSwitches | ? { $_.Moref -eq $vdPG.Config.DistributedVirtualSwitch } | % { $_.Summary.Name }
                    if( $row_vEth.Switch ){ $row_vm.ONvdSwitch = $TRUE } 
               }
               
               $vNETWORKAdapter_OUTPUT += $row_vEth

          }# Foreach ($vEth in $VirtualEthernetCardDEVICE)

          #"verify HcxEligible"
          $HcxEligible = Switch ($True)
          {
               { ! [version]$row_vm.EsxiVersion -ge [version]"5.5" } { "EsxiVersion=$($EsxiVersion)" }
               { ! [int]$row_vm.vHardware -ge 8 }                    { "vHardware=$($row_vm.vHardware)" }
               { ! $row_vm.VirtualMedia -ne $True }                  { "VirtualMedia=$($row_vm.VirtualMedia)" }
               { ! $row_vm.DiskRdmPhysical -ne $True }               { "DiskRdmPhysical=$($row_vm.DiskRdmPhysical)" }
               { ! $row_vm.DiskShared -ne $True }                    { "DiskShared=$($row_vm.DiskShared)" }
               { ! $row_vm.ONvSwitch -ne $True }                     { "ONvSwitch=$($row_vm.ONvSwitch)" }
          }
          
          $row_vm.HcxEligible = !($HcxEligible) -eq $True | % { [string]$_ }
          $row_vm.HcxDisqualifier = $HcxEligible -join "; "
          
          $HcxEligible = Switch ($True)
            {
                   { ! [version]$row_vm.EsxiVersion -ge [version]"5.5" } { "EsxiVersion=$($EsxiVersion)" }
                   { ! [int]$row_vm.vHardware -ge 8 }                    { "vHardware=$($row_vm.vHardware)" }
                   { ! $row_vm.VirtualMedia -ne $True }                  { "VirtualMedia=$($row_vm.VirtualMedia)" }
                   { ! $row_vm.DiskRdmPhysical -ne $True }               { "DiskRdmPhysical=$($row_vm.DiskRdmPhysical)" }
                   { ! $row_vm.DiskShared -ne $True }                    { "DiskShared=$($row_vm.DiskShared)" }
                   { ! $row_vm.ONvSwitch -ne $True }                     { "ONvSwitch=$($row_vm.ONvSwitch)" }
            }
            
         $sVmotionEligible = Switch ($True)
            {
                   { ! $row_vm.DiskRdmPhysical -ne $True }               { "DiskRdmPhysical=$($row_vm.DiskRdmPhysical)" }
                   { ! $row_vm.DiskShared -ne $True }                    { "DiskShared=$($row_vm.DiskShared)" }
                   { ! $row_vm.DiskRdmPhysical -ne $True }               { "DiskRdmPhysical=$($row_vm.DiskRdmPhysical)" }
            }
          
          ### vmotion eligible
          $row_vm.sVmotionEligible = if(-Not $sVmotionEligible ){ $True }else{ $False }
          $row_vm.sVmotionDisqualifier = $sVmotionEligible -join "; "
          
          
          ########### END VMViews vmInfo loops  ##########
          
          ########### Begin Disk VMDK within $VMView ##########
          #vDISK_OUTPUT #### This may be missing paravirtual
          $Controllers = $VMView.Config.Hardware.Device | where { $_.DeviceInfo.Label -match "SCSI|ide" }
          $vDisks = $VMView.Config.Hardware.Device | ? { $_.DeviceInfo.Label -match "disk" }
          foreach ($vDisk in $vDisks)
          {
               #controller key: $Controllers | select key -Exp  DeviceInfo
               # $vdisk $vdisk.ControllerKey and $vdisk.Key
               #Get Controller for this Disk
               $Controller = $Controllers | ? { $vDisk.ControllerKey -eq $_.Key }
               $ds = $Datastores | ? { $_.Moref -eq $vDisk.Backing.Datastore }
               #Define psobject 
               $VirtualDisk = "" | Select VM, Disk, DiskMode, DiskBacking, DiskShared, BackingUuid, 
                                        ControllerType, ControllerSharedBus, Controller,
                                        SCSI_ID, Thin, Type, Split, DiskGB, DiskGbUsed, IsClone, ParentDiskFile, ParentDiskUuid, DeltaDiskFormat,
                                        IoShares, IoPriority, IoLimit, IoReservation, Datastore, DatastoreType, 
                                        DatastoreShared, VmMoref, DiskFile, PsDrive, vmUuID, vCenter
               $VirtualDisk.VM = $VMview.Name
               $VirtualDisk.vCenter = $row_vm.vCenter # $vmview.Client.ServiceUrl.Split("/")[2]
               $VirtualDisk.vmUUID = $vmview.config.Uuid
               $VirtualDisk.Controller = $Controller.DeviceInfo.Label
               $VirtualDisk.ControllerType = $Controller.DeviceInfo.Summary
               $VirtualDisk.ControllerSharedBus = $Controller.SharedBus
               $VirtualDisk.Disk = $vDisk.DeviceInfo.Label
               $VirtualDisk.Thin = (!! ( $vDisk.Backing.ThinProvisioned -eq $true)).ToString()
               $VirtualDisk.Type =  if($vdisk.Backing.EagerlyScrub){ "EagerZero" }ElseIf($vDisk.Backing.ThinProvisioned){"Thin"}ElseIf($vdisk.Backing.EagerlyScrub -ne $True -AND $vDisk.Backing.ThinProvisioned -ne $True){"LazyZero"}
               $VirtualDisk.Split = $vDisk.Backing.Split -ne 0
               $VirtualDisk.SCSI_ID = "$($Controller.BusNumber):$($vDisk.UnitNumber)"
               $VirtualDisk.DiskFile = $vDisk.Backing.FileName
               $VirtualDisk.PsDrive =  "vmstore:\$($row_vm.Datacenter)\" + ($vDisk.Backing.FileName.split(" ")[0] -replace "\[|\]") + "\" + $vDisk.Backing.FileName.split(" ")[1] -replace "\/" , "\"
               $VirtualDisk.DiskShared = $vDisk.Backing.Sharing
               $VirtualDisk.BackingUuid = $vDisk.Backing.Uuid
               $VirtualDisk.DiskGb = [math]::Round($vDisk.CapacityInBytes / 1GB, 1)
               $VirtualDisk.Datastore = $ds.Name
               $VirtualDisk.DatastoreType = $ds.Summary.Type
               $VirtualDisk.DatastoreShared = $ds.Summary.MultipleHostAccess
               $VirtualDisk.VmMoRef = $VMview.MoRef
               $VirtualDisk.IoShares = $vDisk.StorageIOAllocation.Shares.Shares
               $VirtualDisk.IoPriority = $vDisk.StorageIOAllocation.Shares.Level
               $VirtualDisk.IoLimit = $vDisk.StorageIOAllocation.Limit
               $VirtualDisk.IoReservation = $vDisk.StorageIOAllocation.Reservation
               $VirtualDisk.DiskMode = $vDisk.Backing.DiskMode
               $VirtualDisk.DiskBacking = $(
                    if ( $vDisk.backing.GetType().name -match "DiskFlat")
                    {
                         $vDisk.backing.GetType().Name -replace "Virtual|BackingInfo"
                    }
                    ElseIf ($null -ne (Get-Member -InputObject $vDisk.Backing -Name compatibilityMode))
                    {
                         ### need to verify ###
                         "Raw{0}" -f (Get-Culture).TextInfo.ToTitleCase(($vDisk.Backing.compatibilityMode -replace "mode"))
                    }
               )
               
               ### DiskGbUsed calculation begin ##
               # Filter LayoutEx Disk item that corresponds to this VirtualDisk
               $vDiskKey = $VMview.LayoutEx.Disk | ?{ $_.Key -eq $vDisk.Key } | % { $_.chain.FileKey }
               #parse datastore path to filter out parent disks
               $dsPath = $vmview.LayoutEx | % { $_.File } | ? { $_.name -match ".vmx$" } | % { $_.Name.split("/")[0] }

               $VirtualDisk.IsClone = (!! $vdisk.Backing.Parent).ToString()
               $VirtualDisk.ParentDiskFile = $vdisk.Backing.Parent.FileName 
               $VirtualDisk.ParentDiskUuid = $vdisk.Backing.Parent.Uuid
               $VirtualDisk.DeltaDiskFormat = $vdisk.Backing.DeltaDiskFormat 

               $VirtualDisk.DiskGbUsed = $vmview.LayoutEx | % { $_.File } | `
                     ? { $_.Key -in $vDiskKey } | `
                     ? { $_.Type -eq "diskExtent" } | `
                     ? { $_.name.Split("/")[0] -eq $dsPath } | `
                     Measure-Object -SUM UniqueSize | `
                     % { $_.Sum / 1gb } | `
                     % { if ($_ -gt 1 ){ [math]::Round($_,0) }else{ $_.ToString("0.###") } }
                     
               ### DiskGbUsed calculation End ##
               $vDISK_OUTPUT += $VirtualDisk
          } #End vDISKs
           
          ########### END Disk VMDK within $VMView ##########
          
          ########### BEGIN VMview Guest Network Config ########### 
          FOREACH ($GuestNet in $vmview.Guest.Net)
          {
               #some Guest.net have more than one IP
                for($i=0; $i -lt $guestnet.IpAddress.Count; $i++)
                {
                  $row_GuestNet = "" | Select VM, IpAddress, Mask, Gateway, Dns, GatewayDevice, MacAddress, Type, VLAN, Connected, Portgroup, "Switch", DomainName, SearchDomain, vmUUID, vCenter

                  $this_vNETWORKAdapter_OUTPUT = $vNETWORKAdapter_OUTPUT | ? { $_.MacAddress -eq $GuestNet.MacAddress } 

                  $row_GuestNet.VM = $row_vm.vm
                  $row_GuestNet.Portgroup = $GuestNet.Network
                  $row_GuestNet.IpAddress = $guestnet.IpAddress[$i]
                  $row_GuestNet.MacAddress = $GuestNet.MacAddress
                  $row_GuestNet.Connected = $GuestNet.Connected
                  $row_GuestNet.Mask = $GuestNet.IpConfig.IpAddress.PrefixLength[$i]
                  $row_GuestNet.DomainName = $GuestNet.DnsConfig.DomainName
                  $row_GuestNet.SearchDomain = $GuestNet.DnsConfig.SearchDomain[$i]
                  $row_GuestNet.vmUUID = $row_vm.uuid
                  $row_GuestNet.vCenter = $row_vm.vCenter
                  $row_GuestNet.VLAN = $this_vNETWORKAdapter_OUTPUT.VLAN 
                  $row_GuestNet.Type = $this_vNETWORKAdapter_OUTPUT.Type 
                  $row_GuestNet.Switch = $this_vNETWORKAdapter_OUTPUT.Switch
                  $row_GuestNet.Dns = $GuestNet.DnsConfig.IpAddress -join ", "

               #$vmview.Guest.IpStack.IpRouteConfig.IpRoute | ? { $_.network -eq $GuestNet.IpAddress }
                  $row_GuestNet.GatewayDevice = $vmview.Guest.IpStack.IpRouteConfig.IpRoute | ? { $_.network -eq $GuestNet.IpAddress[$i] } | % { $_.Gateway.Device }
                  $row_GuestNet.Gateway       = if ($row_GuestNet.GatewayDevice -eq 0 ) { $vmview.Guest.IpStack.ipRouteConfig.IpRoute | ? { $_.network -eq "0.0.0.0" } | % { $_.Gateway.Ipaddress } }
                  
                  $vmIP_OUTPUT += $row_GuestNet
                  if ($row_GuestNet.GatewayDevice -eq 0 ){ $row_vm.IpPrimary = $row_GuestNet.IpAddress }
                 } ###End for
          }
          
          ########## END VMview Guest Network Config ###########
          
          #append row_vm for output below
          $vmInfo_OUTPUT += $row_vm
    

      #{###### GetFilesOnVM ########
      $files_collection = @()

      $files  = $VMView.LayoutEx.File | Select @{N="VM" ; E = { $vmview.name } },
                                        Type,
                                        @{N="FileName"; E = { $_.Name }},
                                        Key,
                                        Size,
                                        @{N="GBProvisionedSize" ; E= { [Math]::Round( ($_.Size / 1gb ), 4) } },
                                        @{N="UsedGB"; E = {}}, #this value used for summary only
                                        @{N="MoRef"; E = { $vmview.MoRef }}
                                        

       $files = $files | Sort-Object Type
       
       $files_Summary = "" | select VM, Type, Size, GBProvisionedSize, UsedGB, Moref
       $files_Summary.VM = $vmview.Name
       $files_Summary.moref = $vmview.Moref
       $files_Summary.Type = "SUMMARY"
       $files_Summary.Size = $vmview.LayoutEx.File.size | measure -sum | % { $_.Sum / 1gb } | % { [Math]::Round($_,1) }
       $files_Summary.UsedGB =  $vmview.Storage.PerDatastoreUsage.Unshared  | measure -sum | % { [Math]::Round( ($_.sum  / 1Gb), 3) } 
       $files_Summary.GBProvisionedSize = $files | measure Size -Sum | % { $_.Sum / 1gb } | % { [Math]::Round($_,1) }

       $files_collection = $files | % { $_ } 
       $files_collection += $files_Summary | % { $_ }
       
       $FilesOnVm_OUTPUT += $files_collection

      #}###### GetFilesOnVM ########
      
      $row_vm.Portgroup = $row_vPG
    
     } # End $VMView in $VMViews

   #$vNETWORKAdapter_OUTPUT; exit # debug

    if ($VM_Export_Only)
    {
      $Path = ExportData
      start-process $Path
      exit
    
    }

     ########### BEGIN Get Snapshots ###########
     $Snapshots_OUTPUT = $vmviews | Get-Snapshotinfo
     ########### END Get Snapshots ###########

     
     ##### stop if -VM  Param specified
     if ($vm  ){
          #print to screen then quit
          #$vmInfo_OUTPUT ; #vmview output vm output
          if ( $ExportExcelDEFAULT -ne $True ){ exit }
     }     
     
     
     
     ########### Begin VmHosts, vSwitches, and standard Portgroups ##########     
     Foreach ($VmHost in $VmHosts)
     {
            $yy++
          WRITE-PROGRESS "$yy of  $($VmHosts.Count) " -activity "PHASE 2/3: Getting ESXi VMhosts info"  -PercentComplete (($yy / $VmHosts.count ) * 100)
          $Cluster = $VmHost.parent
          $vCenterServiceURL = $VmHost.Client.ServiceURL
          $ClusterName = $Clusters | ? { $_.Moref -eq $Cluster } | ? { $_.Client.ServiceURL -eq $vCenterServiceURL } | % { $_.name }
          
          $row_VmHost = "" | Select VmHost, IP, NICs, HBAs, VmotionIp, VmotionEnabled, VmotionVnic, Product, Version, LicenseVersion, Build, LastBoot, PowerState, ConnectionState,
                                          Serial, Vendor, Model, MemGB, "MemUsed%", MemUsedGB, MaxEvcMode, CPU,
                                          CPUModel, CPUMhz, CpuCores, CpuThreads, "CpuUsage%",
                                          vcFolderPath, VMs, Datastores, Cluster, MoRef, UuID, vCenter
          
          $row_VmHost.VmHost = $VmHost.Name
          $row_VmHost.MaxEvcMode = $Vmhost.Summary.MaxEVCModeKey
          $row_VmHost.Product = $vmhost.Config.Product.FullName
          $row_VmHost.IP = $VmHost.Summary.ManagementServerIp
          $row_VmHost.UuID = $vmhost.Summary.Hardware.Uuid
          $row_VmHost.NICs = $VmHost.Summary.Hardware.NumNics
          $row_VmHost.HBAs = $VmHost.Summary.Hardware.NumHbas
          $row_VmHost.Build = [int]$VmHost.Config.Product.Build
          $row_VmHost.Version = $VmHost.Config.Product.Version
          $row_VmHost.LicenseVersion = [string]$VmHost.Config.Product.LicenseProductVersion
          $row_VmHost.LastBoot = ($VmHost.Runtime.BootTime.DateTime)
          $row_VmHost.PowerState = $VmHost.Runtime.PowerState
          $row_VmHost.ConnectionState = $VmHost.Runtime.ConnectionState
          $row_VmHost.VmotionEnabled = $VmHost.Capability.StorageVMotionSupported
          $row_VmHost.VmotionVnic = ($VmHost.Config.Vmotion.NetConfig | % { $_.SelectedVnic.split("-") | select -l 1 }) -join ","
          $row_VmHost.VmotionIp = $VmHost.Config.Vmotion.IpConfig.IpAddress -join ","
          $row_VmHost.Vendor = $VmHost.Summary.Hardware.Vendor
          $row_VmHost.Model = $VmHost.Summary.Hardware.Model -replace "\s+", " "
          $row_VmHost.MemGB = $VmHost.Summary.Hardware.MemorySize / 1GB | % { [math]::Round($_, 0) }
          $row_VmHost."MemUsed%" = [decimal]($VmHost.Summary.QuickStats.OverallMemoryUsage / $VmHost.Summary.Hardware.MemorySize ) * 100000000 | % { [math]::Round($_,1) }
          $row_VmHost.MemUsedGB = [decimal]($VmHost.Summary.QuickStats.OverallMemoryUsage / 1kb) | % { [math]::Round($_) }
          $row_VmHost.CPUModel = $VmHost.Summary.Hardware.CPUModel -replace "\s+", " "
          $row_VmHost.CPUMhz = $VmHost.Summary.Hardware.CPUMhz
          $row_VmHost.CPU = $VmHost.Summary.Hardware.NumCpuPkgs
          $row_VmHost.CpuCores = $VmHost.Summary.Hardware.NumCpuCores
          $row_VmHost.CpuThreads = $VmHost.Summary.Hardware.NumCpuThreads
          $row_VmHost.Serial = $VmHost.Summary.Hardware.OtherIdentifyingInfo | where { $_.IdentifierType.Key -eq "ServiceTag" } | % { $_.IdentifierValue } | out-string | % { $_.trim() -replace "\s+", "," }
          $row_VmHost."CpuUsage%" = ($VmHost.Summary.QuickStats.OverallCpuUsage / ($VmHost.Summary.Hardware.CpuMhz * $VmHost.Summary.Hardware.NumCpuCores) * 100).ToString("#,0.##")
          $row_VmHost.Cluster = $ClusterName
          $row_VmHost.Datastores = $VmHost.Datastore.Count
          #$row_VmHost.vcFolderPath = GetvCenterFolderPath $VmHost
          #$row_VmHost.Datacenter = $row_VmHost.vcFolderPath.Split("\\")[1]
          $row_VmHost.VMs = $VmHost.VM.count
          $row_VmHost.MoRef = $VmHost.Moref
          $row_VmHost.vCenter = $VmHost.Client.ServiceUrl.Split("/")[2]
          $VmHost_OUTPUT += $row_VmHost
          
          
          #### STANDARD vSwitches BEGIN and Portgroups within VmHosts loop
          #### first lookup of vSwitches for this host. Get-view required for QueryHints for CDP -- BUt does not have VLAN
          Foreach ( $vswitch_info in $VmHost.Config.Network.Vswitch )
          {
               $row_vs = "" | Select Name, vSwitch, VmHost, MTU, Uplinks, NumPortgroups, PortGroups, Ports, PortsUsed, NicTeamingPolicy, 
                                 Promiscuous, ForgedTransmits, MacChanges, ReversePolicy, NotifySwitch, RollingOrder, 
                                 FailureCriteria, NicOrderActive, NicStandby, DiscoveryProtocol, DiscoveryOperation, Key, Cluster, vCenter

               $row_vs.Name = $vswitch_info.Name
               $row_vs.Key = $vswitch_info.Key
               $row_vs.vSwitch = $vswitch_info.Name
               $row_vs.VmHost = $VmHost.name
               #$row_vs.Datacenter = $row_VmHost.Datacenter
               $row_vs.Cluster = $ClusterName
               $row_vs.vCenter = $row_VmHost.vCenter
               $row_vs.PortGroups = $vswitch_info.Portgroup -replace "key-vim.host.PortGroup-" -join ", "
               $row_vs.numPortGroups = $vswitch_info.Portgroup.Count
               $row_vs.Ports = $vswitch_info.NumPorts
               $row_vs.PortsUsed = $vswitch_info.NumPorts - $vswitch_info.NumPortsAvailable
               $row_vs.Mtu = $vswitch_info.Mtu
               
               $row_vs.Uplinks = ($vswitch_info.Pnic | ? { $_ } | % { $_.split("-")[$_.split("-").Count - 1].trim() }) -join ","
               
               $row_vs.DiscoveryProtocol = $vswitch_info.Spec.Bridge.LinkDiscoveryProtocolConfig.Protocol
               $row_vs.DiscoveryOperation = $vswitch_info.Spec.Bridge.LinkDiscoveryProtocolConfig.Operation
               $row_vs.Promiscuous = $vswitch_info.Spec.Policy.Security.AllowPromiscuous
               $row_vs.ForgedTransmits = $vswitch_info.Spec.Policy.Security.ForgedTransmits
               $row_vs.MacChanges = $vswitch_info.Spec.Policy.Security.MacChanges
               $row_vs.NicTeamingPolicy = $vswitch_info.Spec.Policy.NicTeaming.Policy
               $row_vs.ReversePolicy = $vswitch_info.Spec.Policy.NicTeaming.ReversePolicy
               $row_vs.NotifySwitch = $vswitch_info.Spec.Policy.NicTeaming.NotifySwitches
               $row_vs.RollingOrder = $vswitch_info.Spec.Policy.NicTeaming.RollingOrder
               $row_vs.FailureCriteria = $vswitch_info.Spec.Policy.NicTeaming.FailureCriteria
               $row_vs.NicOrderActive = $vswitch_info.Spec.Policy.NicTeaming.NicOrder.ActiveNic -join ", "
               $row_vs.NicStandby = $vswitch_info.Spec.Policy.NicTeaming.NicOrder.StandbyNic -join ", "
               $vSWITCH_OUTPUT += $row_vs

               
               ####### Begin Standard Portgroups #######
               Foreach ($Portgroup in $VmHost.config.Network.Portgroup)
               {
                    #$Portgroup is only a key
                    $row_vPG = "" | Select Portgroup, vSwitch, NicOrder, VmHost, VLAN, Promiscuous, MacChanges,
                                        ForgedTransmits, TrafficShaping, NicTeaming, ReversePolicy, NicStandby,
                                        NotifySwitch, Offload, CsumOffload, TcpSegmentation, ZeroCopyXmit, Key, vCenter
                    
                    #find Portgroup object
                    $row_vPG.Portgroup = $Portgroup.Spec.Name
                    $row_vPG.vSwitch = $Portgroup.Spec.VswitchName
                    $row_vPG.VmHost = $VmHost.Name
                    $row_vPG.VLAN = $Portgroup.Spec.VlanID
                    $row_vPG.Promiscuous = $Portgroup.ComputedPolicy.Security.AllowPromiscuous
                    $row_vPg.MacChanges = $Portgroup.ComputedPolicy.Security.MacChanges
                    $row_vPg.ForgedTransmits = $Portgroup.ComputedPolicy.Security.ForgedTransmits
                    $row_vPg.TrafficShaping = $Portgroup.ComputedPolicy.ShapingPolicy.Enabled
                    $row_vPg.NicTeaming = $Portgroup.ComputedPolicy.NicTeaming.Policy
                    $row_vPg.ReversePolicy = $Portgroup.ComputedPolicy.NicTeaming.ReversePolicy
                    $row_vPg.NicOrder = $Portgroup.ComputedPolicy.NicTeaming.NicOrder.ActiveNic -join ", "
                    $row_vPg.NicStandby = $Portgroup.ComputedPolicy.NicTeaming.NicOrder.StandbyNic -join ", "
                    $row_vPg.NotifySwitch = $Portgroup.ComputedPolicy.NicTeaming.NotifySwitches
                    $row_vPG.Offload = ($Portgroup.ComputedPolicy.OffloadPolicy | gm -Type:Properties | % { $_.Name } | % { $Portgroup.ComputedPolicy.OffloadPolicy."$_" }) -join " " | % { $_ -contains $false } | % { $_ -eq $false }
                    $row_vPg.CsumOffload = $Portgroup.ComputedPolicy.OffloadPolicy.CsumOffload
                    $row_vPg.TcpSegmentation = $Portgroup.ComputedPolicy.OffloadPolicy.TcpSegmentation
                    $row_vPg.ZeroCopyXmit = $Portgroup.ComputedPolicy.OffloadPolicy.ZeroCopyXmit
                    $row_vPg.Key = $Portgroup.Key
                    $row_vPg.vCenter = $row_vmhost.vCenter # $VmHost.Client.ServiceUrl.split("/")[2]
                    
                    $vPORTGROUP_OUTPUT += $row_vPG
               } #end Foreach Portgroup
               
               #remove duplicatess
               $vPortgroup_OUTPUT = $vPortgroup_OUTPUT | Select -Unique
               
               ##end $vss.NetworkConfig standard switch loop
               
          } ### end vSwitch Loop
          #continue
          ##$vSWITCH_OUTPUT = $vSWITCH_OUTPUT | group key | % { $_.Group | select -f 1 } #this line breaks output?

          #### standard vSwitches END ####
          
          
          
          ###### BEGIN pNIC per Host (not per vSwitch) BEGN to get  CDP ######
          $NetworkSystem = Get-View $VmHost.ConfigManager.NetworkSystem #REQUIRED for Hints CDP. This function recovers v and vd switches
          Foreach ($pnic in $VmHost.Config.Network.Pnic)
          {
               $row_pnic = "" | select pNIC, VmHost, Switch, SpeedMb, FullDuplex, MacAddress, SRiovEnabled, SRiovActive, WakeOnLan, Driver, Bus, Slot, Vendor,
                                             ObservedIP_CDP, ObservedVLAN_CDP, IgmpEnabled_Cdp_PEER, Router_Cdp_PEER, TransparentBridge_Cdp_PEER, SourceRouteBridge_Cdp_PEER,
                                             NetworkSwitch_Cdp_PEER, Host_Cdp_PEER, Repeater_Cdp_PEER, Key, vCenter
               
               $pnicHARDWARE = $VmHost.Hardware.PciDevice | ? { $_.id -eq $pnic.Pci }
               $pnicSRIOV = $VmHost.Config.PciPassthruInfo | ? { $_.id -eq $pnic.Pci }
               
               $sw = $null
               $sw = $vSwitch_output | ? { $pnic.Device -in $_.Uplinks.split(",") -AND  $VmHost.Name -in $_.Vmhost }
               
               #hints retrieve CDP info
               #$ERRORACTIONPREFERENCE = "Ignore" #disable errors for disconnected VmHosts
               #if ( $NetworkSystem | gm -Name queryhint_ ) #skip queryhint if not exist {
                    $hint = $NetworkSystem.QueryNetworkHint($pnic.Device)  
               #}     
               #$ERRORACTIONPREFERENCE = "SilentlyContinue" #disable errors for disconnected VmHosts
               #match pnic from VmHost for more detail
               $row_pnic.VmHost = $VmHost.Name
               $row_pnic.pNIC = $pnic.Device
               $row_pnic.MacAddress = $pnic.mac
               $row_pnic.SpeedMb =  $pnic.Spec.LinkSpeed.SpeedMB # if ($pnic.Spec.LinkSpeed.SpeedMB) { $pnic.Spec.LinkSpeed.SpeedMB } else { "Auto" }
               $row_pnic.FullDuplex = if ($pnic.spec.LinkSpeed.Duplex -eq $true) { "TRUE" }
               $row_pnic.Switch = $sw.Name | Group-Object | % { $_.Name }
               $row_pnic.ObservedIP_CDP = if ([string]$hint.Subnet.IpSubnet -notmatch "System.Object") { $hint.Subnet.IpSubnet -join ", " }
               $row_pnic.ObservedVLAN_CDP = if ([string]$hint.Subnet.VlanID -notmatch "System.Object") { $hint.Subnet.VlanID -join ", " }
               $row_pnic.IgmpEnabled_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.IgmpEnabled
               $row_pnic.Router_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.Router
               $row_pnic.TransparentBridge_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.TransparentBridge
               $row_pnic.SourceRouteBridge_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.SourceRouteBridge
               $row_pnic.NetworkSwitch_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.NetworkSwitch
               $row_pnic.Host_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.Host
               $row_pnic.Repeater_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.Repeater
               $row_pnic.WakeOnLan = $pnic.WakeOnLanSupported
               $row_pnic.Driver = $pnic.Driver
               $row_pnic.Bus = $pnicHARDWARE.Bus
               $row_pnic.Slot = $pnicHARDWARE.Slot
               $row_pnic.Vendor = ($pnicHARDWARE.VendorName -replace "\(r\)|\(tm\)"), $pnicHARDWARE.DeviceName -Join " "
               $row_pnic.SrIovEnabled = $pnicSRIOV.SriovEnabled
               $row_pnic.SrIovActive = $pnicSRIOV.SriovActive
               $row_pnic.Key = $pnic.Key
               $row_pnic.vCenter = $row_vmhost.vCenter
               $pNIC_CDP_OUTPUT += $row_pnic
          }
        
        
          $pNIC_CDP_OUTPUT = $pNIC_CDP_OUTPUT | sort-object VmHost, pNic
          ###### END pNIC per Host 
          
          
          
          ##### vHBA Begin vHBA_OUTPUT ######
          Foreach ($hba in $vmhost.Config.StorageDevice.HostBusAdapter)
          {
               $row_hba = "" | select vmHost, Device, Type, Status, Vendor, Driver, Bus, PCI, vCenter
               
               $row_hba.Device = $hba.Device
               $row_hba.vmhost = $vmhost.name
               $row_hba.Status = $hba.Status
               $row_hba.Driver = $hba.Driver
               $row_hba.Vendor = $hba.Model
               $row_hba.Bus = [string]$hba.Bus
               $row_hba.PCI = [string]$hba.PCI
               $row_hba.Type = $hba.Key.Split(".")[2].Split("-")[0]
               $row_hba.vCenter = $row_vmhost.vCenter
               
               $vHBA_OUTPUT += $row_hba
          }
          
          
          ##### Begin VMKERNEL vmk ######
          Foreach ($vmk in $vmhost.Config.Network.Vnic)
          {
               $row_vmk = "" | select vmkernel, vmHost, EnabledServices, MacAddress, NetStack, Switch,
                                           Portgroup, MTU, NetStackInstanceKey, DCHP, IP, Mask, vCenter
               
               $EnabledServices = $vmhost.config.VirtualNicManagerInfo.NetConfig | ? { $_.SelectedVnic -match $vmk.Device }
               
               $row_vmk.vmHost = $vmhost.name
               $row_vmk.EnabledServices = $EnabledServices.NicTYPE -Join ", "
               $row_vmk.MacAddress = $vmk.Spec.Mac
               $row_vmk.vmkernel = $vmk.Device
               $row_vmk.NetStack = $vmk.Spec.NetStackInstanceKey
               $row_vmk.MTU = $vmk.Spec.MTU
               $row_vmk.NetStackInstanceKey = $vmk.Spec.NetStackInstanceKey
               $row_vmk.DCHP = $vmk.Spec.IP.DHCP -Join ", "
               $row_vmk.IP = $vmk.Spec.IP.IpAddress -Join ", "
               $row_vmk.Mask = $vmk.Spec.IP.SubnetMask -join ", "
               $row_vmk.vCenter = $row_vmhost.vCenter
               
               #Get dv or standard switch and portgroup
               if ($vmk.Spec.Portgroup)
               {
                    $row_vmk.Portgroup = $vmk.Spec.Portgroup
                    $row_vmk.Switch = $vPortgroup_OUTPUT | ? { $_.key -match $vmk.Spec.Portgroup } | % { $_.vSwitch }
                    $row_vmk.Switch = $row_vmk.Switch | group-object | % { $_.Name.Trim() }
               }
               else
               {
                    $row_vmk.Portgroup = $vdPortgroups | ? { $_.key -eq $vmk.Spec.DistributedVirtualPort.PortgroupKey } | % { $_.Name }
                    $vdportgroup_this = $vdPortgroup_OUTPUT | ? { $_.key -eq $vmk.spec.DistributedVirtualPort.PortgroupKey }
                    $row_vmk.Switch = $vdportgroup_this.vdSwitch
               }
               
               $VMKernelAdapters_OUTPUT += $row_vmk
          }
          
          
          
     } ### End $VmHosts
     

     ########### CLUSTERS begin ##########
     Foreach ($c in $Clusters )
     {
          #define psobject
          $row_Cluster = "" | Select Cluster, EvcMode, DrsEnabled, ProactiveDrs, DrsVmotion, ConcurrentVmotion, DrsMigrationThreshold, DpmBehavior, DpmEnabled,
                               Cores, Threads, vCpusAlloc, CpuRatio, SpeedMbMIN, SpeedMbMAX,
                               "CPU%", "Mem%", "N+1MEM%", "N+1CPU%", MemGB, EffectiveMemGB, VMs-On,
                               HA_enabled, HA_AdmissionControlEnabled, HA_HostMonitoring, HA_VmComponentProtecting, HA_FailoverLevel, HA_HeartbeatDatastores, HA_HeartbeatDatastore,
                               VmHosts, VmToHostRatio, Datastores, StorageCapacityGB, StorageFreeGB, "StorageUsed%",
                               vcFolderPath, MoRef, vCenter
          
          ### agregate correlate data 
          $VmHostsThisCluster = $VmHosts | ? { $_.moref -in $c.host }
          $VMsThisCluster = $VMviews | ? { $_.moref -in $VmHostsThisCluster.vm }
          $cDatastores_thisLoop = $Datastores | ? { $_.moref -in $c.Datastore }

          $row_Cluster.DrsMigrationThreshold = switch ($c.Configuration.DrsConfig.VmotionRate)
               { 1 {"1-Conservative"}
                 2 {"2-Moderate-Low"}
                 3 {"3-Moderate"}
                 4 {"4-Moderate-High"}
                 5 {"5-Aggressive"}
               }
          
          #$ErrorActionPreference = "SilentlyContinue" #disable errors due to divide by zero
          $row_Cluster.Cluster = $c.Name
          $row_Cluster.EvcMode = $c.Summary.CurrentEVCModeKey
          $row_Cluster.HA_enabled = $c.Configuration.DasConfig.Enabled
          $row_Cluster.HA_AdmissionControlEnabled = $c.Configuration.DasConfig.AdmissionControlEnabled
          $row_Cluster.HA_HostMonitoring = $c.Configuration.DasConfig.HostMonitoring
          $row_Cluster.HA_VmComponentProtecting = $c.Configuration.DasConfig.VmComponentProtecting
          $row_Cluster.HA_FailoverLevel = $c.Configuration.DasConfig.FailoverLevel
          $row_Cluster.HA_HeartbeatDatastore = ($Datastores | ? { $_.Moref -in $c.Configuration.DasConfig.HeartbeatDatastore } | sort-object Name | % { $_.Name } ) -join ", " 
          $row_Cluster.HA_HeartbeatDatastores = $row_Cluster.HA_HeartbeatDatastore.Split(",").Count
          $row_Cluster.DrsVmotion = $c.Configuration.DrsConfig.DefaultVmBehavior
          $row_Cluster.DrsEnabled = $c.Configuration.DrsConfig.Enabled -eq $True | % { $_.tostring() }
          $row_Cluster.ProactiveDrs = $c.ConfigurationEx.ProactiveDrsConfig.Enabled
          $row_Cluster.DpmBehavior = $c.ConfigurationEx.DpmConfigInfo.DefaultDpmBehavior
          $row_Cluster.DpmEnabled = $c.ConfigurationEx.DpmConfigInfo.Enabled -eq $True
           $SpeedMb = $VmHostsThisCluster | % { $_.Config.Network.Pnic | ? { $_.Device -match "vmnic" } | % { $_.linkSpeed.SpeedMB  } } | Measure-Object -Maximum -Minimum 
          $row_Cluster.SpeedMbMIN = $SpeedMb.Minimum
          $row_Cluster.SpeedMbMAX = $SpeedMb.Maximum
          $row_Cluster.ConcurrentVmotion = if( $SpeedMb.Minimum -ge 10000 ){ 8 } elseIf( $SpeedMb.Minimum -lt 10000 ) { 4 } #10gb+ supports 8 conccurent vmotion
          $row_Cluster.Cores = $c.Summary.NumCpuCores
          $row_Cluster.vCpusAlloc = $VMsThisCluster.Config.Hardware.NumCpu | Measure-Object -sum | % { $_.sum }
          $row_Cluster.CpuRatio = (($row_Cluster.vCpusAlloc + 0.001) / ($row_Cluster.Cores + 0.001)) | % { [math]::Round($_, 0) } | % { [string]$_ + ":1" }
          $row_Cluster.Threads = $c.Summary.NumCpuThreads
          $row_Cluster."CPU%" = if ($c.Summary.TotalCPU ){ [decimal](($c.Summary.EffectiveCpu / $c.Summary.TotalCPU)) * 100 | % { [math]::Round($_, 0) } }
          $row_Cluster."Mem%" = if ($c.Summary.TotalMemory) { [decimal](($c.Summary.EffectiveMemory / $c.Summary.TotalMemory)) * 100 | % { [math]::Round($_, 0) } }
          $row_Cluster.MemGB = [math]::Round($c.Summary.TotalMemory / 1GB, 0)
          $row_Cluster.EffectiveMemGB = ($c.Summary.EffectiveMemory / 1GB) | % { [math]::Round($_, 2) }
          $row_Cluster."N+1MEM%" = $c.Summary.TotalMemory * ($VmHostsThisCluster.Count - 1) / 1GB | % { [math]::Round($_, 1) }
          $row_Cluster."N+1CPU%" = $c.Summary.TotalCPU * ($VmHostsThisCluster.Count - 1) / 1GB | % { [math]::Round($_, 1) }
          $row_Cluster."VMs-On" = $VMsThisCluster.count
          $row_Cluster.VmHosts = $c.host.count
          $row_Cluster.VmToHostRatio = [string]($VMsThisCluster.Count) + ":" + ($VmHostsThisCluster.Count)
          $row_Cluster.StorageCapacityGB = ($cDatastores_thisLoop.summary.Capacity | Measure-Object -sum).sum / 1GB
          $row_Cluster.StorageFreeGB = ($cDatastores_thisLoop.summary.FreeSpace | Measure-Object -sum).sum / 1GB | % { [math]::Round($_, 0) }
          $row_Cluster."StorageUsed%" = ($row_Cluster.StorageCapacityGB - $row_Cluster.StorageFreeGB) / $row_Cluster.StorageCapacityGB | % { [math]::Round($_, 2) }
          $row_Cluster.Datastores = $cDatastores_thisLoop.Count
          $row_Cluster.vCenter = $c.Client.ServiceUrl.split("/")[2]
          #$row_Cluster.vcFolderPath = GetvCenterFolderPath $c
          #$row_Cluster.Datacenter = $row_Cluster.vcFolderPath.Split("\")[1]
          $row_Cluster.MoRef = $c.Moref
          
          $CLUSTER_OUTPUT += $row_Cluster
          #$ErrorActionPreference = "Continue" #enable errors 
                    
          ### Cluster DRS Rules
          $DrsRule_OUTPUT += Get-DrsRule -Cluster $c.Name | SELECT Cluster, Name, Enabled, Mandatory, Type, @{N="VM" ; E={ $vmids = $_.vmids ; ($vmviews | ? { $_.moref  -in $vmids } | % { $_.name } ) -join ", " }   } | ? { $_.VM }
          #$DrsVMHostRule_OUTPUT += Get-DrsVMhostRule -Cluster $c.Name | SELECT Cluster, Name, Enabled, Type, VMGroup, VMhostGroup, @{n="AffinityHostGroupName" ; E={$_.ExtensionData.AffineHostGroupName }},  @{n="AntiAffinityHostGroupName" ; E={$_.ExtensionData.AntiAffineHostGroupName }}, @{n="InCompliance" ; E={ [string]$_.ExtensionData.InCompliance  }}, @{n="Mandatory" ; E={ [string]$_.ExtensionData.Mandatory  }}
          $DrsVMHostRule_OUTPUT += Get-DrsVMhostRule -Cluster $c.Name  | SELECT Cluster, Name, Enabled, Type, VMGroup, VMhostGroup, 
                                    @{n="AffinityHostGroupName" ; E={$_.ExtensionData.AffineHostGroupName }},  
                                    @{n="AntiAffinityHostGroupName" ; E={$_.ExtensionData.AntiAffineHostGroupName }}, 
                                    @{n="InCompliance" ; E={ [string]$_.ExtensionData.InCompliance  }}, 
                                    @{n="Mandatory" ; E={ [string]$_.ExtensionData.Mandatory }}, 
                                    @{n="VMs" ; E= { $_.VMGroup.Member.Name  -join ", " } },
                                    @{n="VMIDs" ; E= { $_.VMGroup.Member.Id -join ", " } }, 
                                    @{n="VMHosts" ; E= { $_.VMhostGroup.Member.Name -join ", " } }, 
                                    @{n="VMHostIDs" ; E= { $_.VMHostGroup.Member.id -join ", " }  }  | ? { $_.VMIDs -in $VMviews.Moref }
          $DrsClusterGroup_OUTPUT += Get-DrsClusterGroup -Cluster $c.Name | SELECT Cluster, Name, GroupType, @{N="Member" ; E= { $_.Member -join ", " } } 

     }
     ########## cluster end ########## 


     ########### vCenter Licenses BEGIN #########
     $ServiceInstances = GET-VIEW ServiceInstance
     #Must invoke the object to retrieve data.
     $ServiceInstances | Out-null
     
     ForEach ($ServiceInstance in $ServiceInstances)
     {
          #Must invoke the object to retrieve data.
          #$ServiceInstance | Out-null          
          $LicenseManagers = GET-VIEW ($ServiceInstance).Content.LicenseManager
          
          Foreach ($LicenseMan in $LicenseManagers.Licenses)
          {
               $row_lic = $LicenseMan | select @{ N = "vCenter"; E = { $ServiceInstance.Client.ServiceUrl.Split("/")[2] } },
                                                       LicenseKey, EditionKey, Name, Total, Used, CostUnit
               
               if ($ScrubLicenseKey -and $LicenseMan.LicenseKey)
               {
                    $row_lic.LicenseKey = ($LicenseMan.LicenseKey.Split("-")[0 .. ($LicenseMan.LicenseKey.Split("-").count - 2)] -join "-") + "-scrubbed"
               }
               
               $vLICENSE_OUTPUT += $row_lic
          }
     }
     ########### vCenter Licenses END #########
     
     
     $ds = $null
     ########### DATASTORES $DATASTORE_OUTPUT BEGIN ##########
     Foreach ($ds in $Datastores)
     {
          $row_ds = "" | Select Datastore, StorageDeviceName, Extent, ExtentPartition, Status, Version, Type, Address, VmfsUpgradable,
                         CapacityGB, FreeGB, "Used%", Shared, VMs, VmHosts, Clusters, 
                         URL, vcFolderPath, MoRef, vCenter
                         
          $ClustersThisDatastore = $Clusters | ? { $ds.moref -in $clusters.Datastore }
          $row_ds.Datastore = $ds.Name
          $row_ds.Extent = $ds.Info.Vmfs.Extent.DiskName
          $row_ds.ExtentPartition = $ds.Info.Vmfs.Extent.Partition
          $row_ds.StorageDeviceName =  $vmhosts.Config.StorageDevice.ScsiLun | ? { $_.CanonicalName -eq $row_ds.Extent } | % { $_.DisplayName  }  | group   | % { $_.Name }
          #debug if ($ds.Info.Vmfs.Name){ exit  }
          $row_ds.Status = $ds.OverallStatus
          $row_ds.Version = $ds.Info.Vmfs.Version
          $row_ds.VmfsUpgradable = $ds.Info.Vmfs.VmfsUpgradable -eq $true | % { $_.ToString() }
          $row_ds.Type = $ds.Summary.Type
          $row_ds.Shared = $ds.Info.Vmfs.Local -eq $False
          $row_ds.CapacityGB = $ds.Summary.Capacity / 1GB
          $row_ds.FreeGB = $ds.Summary.FreeSpace / 1GB | % { [math]::round($_, 1) }
          $row_ds."Used%" = ($ds.Summary.Capacity - $ds.Summary.FreeSpace) / $ds.Summary.Capacity | % { [math]::Round($_ * 100, 1) }
          $row_ds.VMs = $ds.vm.count
          $row_ds.VmHosts = $ds.Host.Count
          $row_ds.Clusters = $ClustersThisDatastore.Name -join ", "
          $row_ds.url = $ds.Info.url
          #$row_ds.vcFolderPath = GetvCenterFolderPath $ds
          $row_ds.Address = if ($ds.Info.Nas.RemoteHost)
          { [string]$ds.Info.Nas.RemoteHost + $ds.Info.Nas.RemotePath }
          else { $ds.info.vmfs.extent.Diskname }
          $row_ds.MoRef = $ds.Moref
          $row_ds.vCenter = $ds.Client.ServiceUrl.Split("/")[2]
          $DATASTORE_OUTPUT += $row_ds
     }
     ########### DATASTORES $DATASTORE_OUTPUT BEGIN ##########
     
     
     ########### DATACENTERS Begin ############
     Foreach ($dc in $Datacenters)
     {
          $row_dc = "" | Select Datacenter, Clusters, VmHosts, VMs, Cores, Datastores,
                                     StorageCapacityGB, StorageFreeGB, 'StorageUsed%', Moref, vCenter
          
          $clusters_thisDC = $CLUSTER_OUTPUT | ? { $_.Datacenter -eq $dc.name }
          
          $row_dc.Datacenter = $dc.Name
          $row_dc.Clusters = $clusters_thisDC.Count
          $row_dc.VmHosts = $clusters_thisDC.VmHosts | Measure-Object -sum | % { $_.sum }
          $row_dc.VMs = $clusters_thisDC.'VMS-ON' | Measure-Object -sum | % { $_.sum }
          $row_dc.Cores = $clusters_thisDC.Cores | Measure-Object -sum | % { $_.sum }
          $row_dc.Datastores = $clusters_thisDC.Datastores | Measure-Object -sum | % { $_.sum }
          $row_dc.StorageCapacityGB = $clusters_thisDC.StorageCapacityGB | Measure-Object -sum | % { $_.sum }
          $row_dc.StorageFreeGB = $clusters_thisDC.StorageFreeGB | Measure-Object -sum | % { $_.sum }
          $row_dc.'StorageUsed%' = $clusters_thisDC.'StorageUsed%' | Measure-Object -Average | % { $_.Average }
          $row_dc.Moref = $dc.Moref
          $row_dc.vCenter = $dc.Client.ServiceUrl.Split("/")[2]
          
          
          $DATACENTERS_OUTPUT += $row_dc
     }
     ########### DATACENTERS END ############
     
    ########## FOLDERS BEGIN ########## 
    Foreach ($Folder in $Folders)
    {
          #write-host $folder.name -foregr yellow
          $row_folder = "" | Select Name, Type, VMs, Parent, ParentType, DiskUsedGB, MoRef #, ChildEntities, CpuUsage, MemoryUsage, 

          $row_folder.Name = $Folder.Name
          $row_folder.VMs = $vmviews | ? {  $_.Parent -in $Folder.moref  } | measure | % { $_.Count }
          $row_folder.DiskUsedGB = $vmviews | ?  { $_.Parent -in $Folder.moref } | % { $_.LayoutEx } | % { $_.File } | ? { $_.Type -match "diskExtent" } | ? { $_.name.Split("/")[0] -eq $dsPath } | Measure-Object -sum UniqueSize | % { $_.Sum / 1gb } | % { if ($_ -gt 1 ){ [math]::Round($_,0) }else{ $_.ToString("#.###") } }
          $row_folder.MoRef = $Folder.Moref -join ""
          $row_folder.Type = $Folder.Moref.Type
          #$row_folder.ChildEntities = ( $Clusters | ? { $_.MOREF -in $Folders.ChildEntity } | % { $_.Name } ).Count
          #$row_folder.CpuUsage = "tbd"
          #$row_folder.MemoryUsage = "tbd"
          
          $row_folder.ParentType = $Folder.Parent.Type

          #Get ParentType Data
          if($Folder.Parent.Type -eq "Folder")
              { $val = $Folders | ? { $_.moref -eq $Folder.Parent } | % { $_.Name } 
              }
          if($Folder.Parent.Type -eq "Datacenter")
              { $val = Datacenter { $Datacenters | ? { $_.moref -eq $Folder.Parent } | % { $_.Name } } 
              }

         $row_folder.Parent = $val

         $Folders_OUTPUT += $row_folder
    }
    ########## Folders END ##########
     
     
     ##### END Error Collection DISABLE
     $ErrorActionPreference = "Continue"
     $ErrorEnd = $Error.Count - 1
     $DebugLOG_OUTPUT = $Error[ $ErrorStart .. $ErrorEnd] | `
          SELECT  @{N="Line"; E= {$_.ScriptStackTrace.Split("`n")[0].Trim() -replace ".* Line" | % { [int]$_ }  }} , 
                  @{N="Exception" ; E={ $_.Exception | out-string | % { $_.Trim() } }   }    | `
                  GROUP Line | select @{N="Line" ; E= { $_.Name }}, Count, @{N="Error" ; E = { $_.Group[0].Exception  }}
     
     $Path = ExportData
     
     write-host $path
     if (! $NoLaunch)
     {
      Start-Process $path
      Start-Process (split-path $path -parent)
     }
     
     ###### END Dashboard and Export-EXCEL ######
     
     Write-Host  "`n `nSTOPWATCH LAPSED SECONDS: $([int]$Stopwatch.Elapsed.TotalSeconds)"
     
}  ###end of END

