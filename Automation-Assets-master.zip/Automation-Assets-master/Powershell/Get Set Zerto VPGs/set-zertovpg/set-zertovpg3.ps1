<#
 PowerShell script to create a VPG in Zerto using Zerto virtual replication RESTful API's.
 The script accepts the input VPG settings defined in a JSON file. The JSON input file
 also consists of the Zerto login credentials. A set of default vpgSettings object values
 are defined at the begining of the script. The script creates a vpgSettings object and
 then creates VPG by commiting the object.
#>

# required input parameters
Param(
  [Parameter(Position=0, mandatory=$True)][string]$InputFile
)


Function Summarize($code, $message) {
    $result = @{
        code = [int]$code
        message = $message
        errors = $script:Errors
        output = $script:Output
    }
    $data = $result | ConvertTo-Json -Depth 9 | % { [System.Text.RegularExpressions.Regex]::Unescape($_) }
    $data | Set-Content "output.json" -Force
    Write-Output $message
    Stop-Transcript
    Exit $code
}

Start-Transcript -Path "log.txt"
$Errors = @()   # Global array for error records
$Output = @{} # Global hashtable for script output

Write-Output "script execution started"

# Read the input file
Try {
	$json = Get-Content $InputFile | Out-String | ConvertFrom-Json
}
Catch {
    $Errors += @{error=$_.Exception.Message;}
    Summarize -10 "Invalid JSON input"
}

If (!$json){
    Summarize -10 "Invalid JSON input"
}

$LogLevel = $json.logging.level
If (!$LogLevel){
    Set-PSDebug -Off
}
Else {
    Set-PSDebug -Trace $LogLevel
}

If ((!$json.auth) -Or (!$json.auth.zerto)){
    $Errors += @{error="Missing authentication section in input JSON"}
    Summarize -10 "Invalid JSON input"
}

$ZertoServer = $json.auth.zerto.host
$ZertoPort = $json.auth.zerto.port
$ZertoUser = $json.auth.zerto.user
$ZertoPassword = $json.auth.zerto.password

If ((!$ZertoServer) -or (!$ZertoPort) -or (!$ZertoUser) -or (!$ZertoPassword)){
    $Errors += @{error="Missing credential details for 'Zerto'"}
    Summarize -10 "Invalid JSON input"
}

# Setting Cert Policy - required for successful auth with the Zerto API
$PSVersion = $host.version
If ($PSVersion.Major -le 5) {
Add-Type @"
   using System.Net;
   using System.Security.Cryptography.X509Certificates;
   public class TrustAllCertsPolicy : ICertificatePolicy {
       public bool CheckValidationResult(
           ServicePoint srvPoint, X509Certificate certificate,
           WebRequest request, int certificateProblem) {
           return true;
       }
   }
"@
   [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
   $PARAMS = @{}
}
Else {
   $PARAMS = @{SkipCertificateCheck=$True;}
}

# Building Zerto API string and invoking API
$BaseURL = "https://" + $ZertoServer + ":"+$ZertoPort+"/v1/"
# Authenticating with Zerto APIs
$TypeJSON = "application/JSON"

Write-Output "Connecting to Zerto at $ZertoServer"

Try {
    $url = $BaseURL+"session/add"
    $AuthInfo = ("{0}:{1}" -f $ZertoUser,$ZertoPassword)
    $AuthInfo = [System.Text.Encoding]::UTF8.GetBytes($AuthInfo)
    $AuthInfo = [System.Convert]::ToBase64String($AuthInfo)
    $Headers = @{Authorization=("Basic {0}" -f $AuthInfo)}
    $payload = '{"AuthenticationMethod": "1"}'
    $resp = Invoke-WebRequest @PARAMS -Uri $url -Headers $Headers -Method POST -Body $payload -ContentType $TypeJSON
}
Catch {
    $Errors += @{error=$_.Exception.Message}
    $err = ($Error[0] -Split '\n')[0]
    If ($err -Like "*invalid uri*" -Or $err -Like "*resolved*" -Or $err -Like "*incorrect user name or password*") {
        $code = -20
        $message = "Invalid login credentials for Zerto"
    }
    Else {
        $code = -30
        $message = "Cannot connect to Zerto at $ZertoServer"
    }

    Summarize $code $message
}
Write-Output "Connected to Zerto at $ZertoServer"

#Extracting x-zerto-session from the response, and adding it to the actual API
$xZertoSession = $resp.headers.get_item("x-zerto-session")
$SessionHeader = @{
    "x-zerto-session" = "{0}" -f $xZertoSession
    "Accept"=$TypeJSON
}

########## MAIN BODY OF SCRIPT ######################################
$SingleVPG = $False

If ($json.vpgSettings.length -le 0) {
    If ($json.vpgSetting) {
        $VPGSettings = @($json.vpgSetting)
        $SingleVPG = $True
    }
    Else {
        $Errors += @{error="VPG settings are missing";}
        Summarize -10 "Invalid data input"
    }
}
Else {
    $VPGSettings = $json.vpgSettings
}

$Record = 0
# $TimeToWaitBetweenVPGCreation = "20"

ForEach ($VPG in $VPGSettings) {
    $Record += 1
    $MissingEntry = $False

    $JournalHistoryInHours = $VPG.JournalHistoryInHours
    if (!$JournalHistoryInHours) {
        $JournalHistoryInHours = 24
    }

    $ReplicationPriority = $VPG.ReplicationPriority
    if (!$ReplicationPriority) {
        $ReplicationPriority = "Medium"
    }

    $RpoAlertInSeconds = $VPG.RpoAlertInSeconds
    if (!$RpoAlertInSeconds) {
        $RpoAlertInSeconds = 300
    }

    $TestIntervalInMinutes = $VPG.TestIntervalInMinutes
    if (!$TestIntervalInMinutes) {
        $TestIntervalInMinutes = 0
    }

    $UseWanCompression = $VPG.UseWanCompression
    If (($UseWanCompression -eq $Null) -Or ($UseWanCompression -Eq $False)) {
        $UseWanCompression = $false
    }
    Else {
        $UseWanCompression = $true
    }

    $VPGName = $VPG.VPGName
    if (!$VPGName) {
        $MissingEntry = $True
        $Errors += @{error="Missing VPGName in vpgSetting ${Record}";}
    }

    $VPGVMs = $VPG.VMs
    if (!$VPGVMs) {
        $MissingEntry = $True
        $Errors += @{error="Missing VMs in vpgSetting ${Record}";}
    }

    $RecoverySiteName = $VPG.RecoverySiteName
    If (!$RecoverySiteName) {
        $MissingEntry = $True
        $Errors += @{error="Missing RecoverySiteName in vpgSetting ${Record}";}
    }

    $ClusterName = $VPG.ClusterName
    $HostName = $VPG.HostName
    If ((!$HostName) -And (!$ClusterName)) {
        $MissingEntry = $True
        $Errors += @{error="Either ClusterName or HostName has to be specified in vpgSetting ${Record}";}
    }

    $FailoverNetwork = $VPG.FailoverNetwork
    If (!$FailoverNetwork) {
        $MissingEntry = $True
        $Errors += @{error="Missing FailoverNetwork in vpgSetting ${Record}";}
    }

    $TestNetwork = $VPG.TestNetwork
    If (!$TestNetwork) {
        $MissingEntry = $True
        $Errors += @{error="Missing TestNetwork in vpgSetting ${Record}";}
    }

    $DatastoreName = $VPG.DatastoreName
    If (!$DatastoreName) {
        $MissingEntry = $True
        $Errors += @{error="Missing DatastoreName in vpgSetting ${Record}";}
    }

    $FolderName = $VPG.Folder
    If (!$FolderName) {
        $MissingEntry = $True
        $Errors += @{error="Missing Folder in vpgSetting ${Record}";}
    }

    If ($MissingEntry) {
        If ($SingleVPG) {
            Summarize -10 "Input data is incomplete"
        }
        Continue
    }

    # Check if VPG exists
    $url = $BaseURL+"vpgs"
    $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
    $VPGID = $resp | Where-Object {$_.VpgName -eq $VPGName} | Select VpgName -ExpandProperty VpgName
    If ($VPGID) {
        $Errors += @{error="Invalid VPGName: VPG ${VPGName} exists already";}
        If ($SingleVPG) {
            Summarize -10 "Input data is invalid"
        }
        Continue
    }
 
    # Get SiteIdentifier for getting Local Identifier later in the script
    $url = $BaseURL+"localsite"
    $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
    $LocalSiteID = $resp | Select SiteIdentifier -ExpandProperty SiteIdentifier

    # Get SiteIdentifier for getting Identifiers
    $url = $BaseURL+"virtualizationsites"
    $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
    $TargetSiteID = $resp | Where-Object {$_.VirtualizationSiteName -eq $RecoverySiteName} | select SiteIdentifier -ExpandProperty SiteIdentifier
    if (!$TargetSiteID) {
        $Errors += @{error="Invalid RecoverySiteName for ${VPGName}: ${RecoverySiteName} not found";}
        If ($SingleVPG) {
            Summarize -10 "Input data is invalid"
        }
        Continue
    }

    # NOTE: We use InvalidEntry to validate as many entries as we can
    $InvalidEntry = $False

    # Get NetworkIdentifiers for API
    $url = $BaseURL+"virtualizationsites/$TargetSiteID/networks"
    $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
    $FailoverNetworkID = $resp | Where-Object {$_.VirtualizationNetworkName -eq $FailoverNetwork} | Select NetworkIdentifier -ExpandProperty NetworkIdentifier
    $TestNetworkID = $resp | Where-Object {$_.VirtualizationNetworkName -eq $TestNetwork} | Select NetworkIdentifier -ExpandProperty NetworkIdentifier
    If (!$FailoverNetworkID) {
        $InvalidEntry = $True
        $Errors += @{error="Invalid FailoverNetwork for ${VPGName}: ${FailoverNetwork} not found";}
    }

    If (!$TestNetworkID) {
        $InvalidEntry = $True
        $Errors += @{error="Invalid TestNetwork for ${VPGName}: ${TestNetwork} not found";}
    }
   
    If ($ClusterName) {
        $url = $BaseURL+"virtualizationsites/$TargetSiteID/hostclusters"
        $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
        $ClusterID = $resp | Where-Object {$_.VirtualizationClusterName -eq $ClusterName} | Select ClusterIdentifier -ExpandProperty ClusterIdentifier
        If (!$ClusterID) {
            $InvalidEntry = $True
            $Errors += @{error="Invalid ClusterName for ${VPGName}: ${ClusterName} not found";}
        }
    }
    Else {
        $url = $BaseURL+"virtualizationsites/$TargetSiteID/hosts"
        $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
        $HostID = $resp | Where-Object {$_.VirtualizationHostName -eq $HostName} | Select HostIdentifier -ExpandProperty HostIdentifier
        If (!$HostID) {
            $InvalidEntry = $True
            $Errors += @{error="Invalid HostName for ${VPGName}: ${HostName} not found";}
        }
    }

    $url = $BaseURL+"virtualizationsites/$TargetSiteID/datastores"
    $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
    $DatastoreID = $resp | Where-Object {$_.DatastoreName -eq $DatastoreName} | Select DatastoreIdentifier -ExpandProperty DatastoreIdentifier
    $JournalDatastoreID = $resp | Where-Object {$_.DatastoreName -eq $DatastoreName} | Select DatastoreIdentifier -ExpandProperty DatastoreIdentifier
    If ((!$DatastoreID) -or (!$JournalDatastoreID)) {
        $InvalidEntry = $True
        $Errors += @{error="Invalid DatastoreName for ${VPGName}: ${DatastoreName} not found";}
    }

    # Get Folders for API
    $url = $BaseURL+"virtualizationsites/$TargetSiteID/folders"
    $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
    $FolderID = $resp | Where-Object {$_.FolderName -eq $FolderName} | Select FolderIdentifier -ExpandProperty FolderIdentifier
    If (!$FolderID) {
        $InvalidEntry = $True
        $Errors += @{error="Invalid Folder for ${VPGName}: ${FolderName} not found";}
    }

    If ($ClusterID) {
        $JSONRecovery = @{
            DefaultDatastoreIdentifier = "$DatastoreID"
            DefaultFolderIdentifier = "$FolderID"
            DefaultHostClusterIdentifier = "$ClusterID"
            DefaultHostIdentifier = $null
            ResourcePoolIdentifier = $Null
        }
    }
    Else {
        $JSONRecovery = @{
            DefaultDatastoreIdentifier = "$DatastoreID"
            DefaultFolderIdentifier = "$FolderID"
            DefaultHostClusterIdentifier = $Null
            DefaultHostIdentifier = "$HostID"
            ResourcePoolIdentifier = $Null
        }
    }

    # Getting a VM identifier for each VM to be protected 
    $VMList = @()
    $VMIDList = @()

    # Running for each VM operation against the VPG name
    ForEach ($VM in $VPGVMs) {
        $VMName = $VM.VM
        $ClusterName = $VM.ClusterName
        $HostName = $VM.HostName
        $DatastoreName = $VM.DatastoreName
        $FolderName= $VM.Folder

        If (!$VMName) {
            $InvalidEntry = $True
            $Errors += @{error="VM is missing for VPG ${VPGName}";}
        }

        $url = $BaseURL+"virtualizationsites/$LocalSiteID/vms"
        $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
        $VMID = $resp | Where-Object {$_.VmName -eq $VMName} | select VmIdentifier -ExpandProperty VmIdentifier

        If (!$VMID) {
            $InvalidEntry = $True
            $Errors += @{error="Invalid VM for VPG ${VPGName}: ${VMName} not found";}
        }

        $VMIDList += [string]$VMID

        # VM.ClusterName
        If ($ClusterName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/hostclusters"
            $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $ClusterID = $resp | Where-Object {$_.VirtualizationClusterName -eq $ClusterName} | Select ClusterIdentifier -ExpandProperty ClusterIdentifier
            If (!$ClusterID) {
                $InvalidEntry = $True
                $Errors += @{error="Invalid ClusterName for VM ${VMName} in VPG ${VPGName}: ${ClusterName} not found";}
            }
        }

        # VM.HostName
        If ($HostName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/hosts"
            $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $HostID = $resp | Where-Object {$_.VirtualizationHostName -eq $HostName} | Select HostIdentifier -ExpandProperty HostIdentifier
            If (!$HostID) {
                $InvalidEntry = $True
                $Errors += @{error="Invalid HostName for VM ${VMName} in VPG ${VPGName}: ${HostName} not found";}
            }
        }

        # Get DatastoreIdentifiers for API
        If ($DatastoreName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/datastores"
            $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $DatastoreID = $resp | Where-Object {$_.DatastoreName -eq $DatastoreName} | Select DatastoreIdentifier -ExpandProperty DatastoreIdentifier
            $JournalDatastoreID = $resp | Where-Object {$_.DatastoreName -eq $DatastoreName} | Select DatastoreIdentifier -ExpandProperty DatastoreIdentifier
            If ((!$DatastoreID) -Or (!$JournalDatastoreID)) {
                $InvalidEntry = $True
                $Errors += @{error="Invalid DatastoreName for VM ${VMName} in VPG ${VPGName}: ${DatastoreName} not found";}
            }
        }

        # Get Folders for API
        If ($FolderName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/folders"
            $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $FolderID = $resp | Where-Object {$_.FolderName -eq $FolderName} | Select FolderIdentifier -ExpandProperty FolderIdentifier
            If (!$FolderID) {
                $InvalidEntry = $True
                $Errors += @{error="Invalid Folder for VM ${VMName} in VPG ${VPGName}: ${FolderName} not found";}
            }
        }

        $VMList += @{VmIdentifier = "$VMID";}
    } # end of loop ForEach ($VM in $VPGVMs)

    If ($InvalidEntry) {
        # Fail fast for single VPG
        If ($SingleVPG) {
            Summarize -10 "Input data is invalid"
        }
        Continue
    }
 
    # Building JSON Request for posting VPG settings to API
    $VPGObject = @{
        Backup = $NULL
        Basic = @{
            JournalHistoryInHours = "${JournalHistoryInHours}"
            Name = "${VPGName}"
            Priority = "${ReplicationPriority}"
            ProtectedSiteIdentifier = "${LocalSiteID}"
            RecoverySiteIdentifier = "${TargetSiteID}"
            RpoInSeconds = "${RpoAlertInSeconds}"
            ServiceProfileIdentifier = $NULL
            TestIntervalInMinutes = "${TestIntervalInMinutes}"
            UseWanCompression = $UseWanCompression
            ZorgIdentifier = $NULL
        }
        BootGroups = @{
            BootGroups = @(
                @{
                    BootDelayInSeconds = 0
                    BootGroupIdentifier = "00000000-0000-0000-0000-000000000000"
                    Name = "Default"
                }
            )
        }
        Journal = @{
            DatastoreClusterIdentifier = $Null
            DatastoreIdentifier = "${DatastoreID}"
            Limitation = @{
                HardLimitInMB = "0"
                HardLimitInPercent = $NULL
                WarningThresholdInMB = 0
                WarningThresholdInPercent = $NULL
            }
        }
        Networks = @{
            Failover = @{
                Hypervisor = @{
                    DefaultNetworkIdentifier = "${FailoverNetworkID}"
                }
            }
            FailoverTest = @{
                Hypervisor = @{
                    DefaultNetworkIdentifier = "${TestNetworkID}"
                }
            }
        }
        Recovery = $JSONRecovery
        Scripting = @{
            PostBackup = $NULL
            PostRecovery = @{
                Command = $NULL
                Parameters = $NULL
                TimeoutInSeconds = 0
            }
            PreRecovery = @{
                Command = $NULL
                Parameters = $NULL
                TimeoutInSeconds = 0
            }
        }

        Vms = $VMList
    }

    # Submit creation request
    $url = $BaseURL+"vpgSettings"
    $payload = $VPGObject | ConvertTo-Json -Depth 20
    $VPGSID = Invoke-RestMethod @PARAMS -Method Post -Uri $url -Body $payload -ContentType $TypeJSON -Headers $SessionHeader 

    # Update VM settings for a VPG
    $vm_idx = 0
    ForEach ($VM in $VPGVMs) {
        $VMID = $VMIDList[$vm_idx]
        $url = $BaseURL+"vpgSettings/${VPGSID}/vms/${VMID}"
        $VMSettings = Invoke-RestMethod @PARAMS -Method Get -Uri $url -Headers $SessionHeader -ContentType $TypeJSON

        $ClusterName = $VM.ClusterName
        $HostName = $VM.HostName
        $DatastoreName = $VM.DatastoreName
        $FolderName = $VM.Folder
        $IsThin = $VM.IsThin

        # This flag tells us at the end of the day whether an update request is needed for the VPG
        $UpdateFlag = $False

        If ($ClusterName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/hostclusters"
            $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $ClusterID = $resp | Where-Object {$_.VirtualizationClusterName -eq $ClusterName} | Select ClusterIdentifier -ExpandProperty ClusterIdentifier
            $VMSettings.Recovery.HostClusterIdentifier = "$ClusterID"
            $VMSettings.Recovery.HostIdentifier = $null
            $UpdateFlag = $True
        }

        If ($HostName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/hosts"
            $resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $HostID = $resp | Where-Object {$_.VirtualizationHostName -eq $HostName} | Select HostIdentifier -ExpandProperty HostIdentifier
            $VMSettings.Recovery.HostIdentifier = "$HostID"
            $VMSettings.Recovery.HostClusterIdentifier = $null
            $UpdateFlag = $True
        }

        If ($DatastoreName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/datastores"
            $resp  = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $DatastoreID = $resp | Where-Object {$_.DatastoreName -eq $DatastoreName} | Select DatastoreIdentifier -ExpandProperty DatastoreIdentifier
            $JournalDatastoreID = $resp | Where-Object {$_.DatastoreName -eq $DatastoreName} | Select DatastoreIdentifier -ExpandProperty DatastoreIdentifier
            $VMSettings.Recovery.DatastoreIdentifier = "$DatastoreID"
            $VMSettings.Journal.DatastoreIdentifier = "$JournalDatastoreID"

            ForEach ($Volume in $VMSettings.Volumes) {
                $Volume.Datastore.DatastoreIdentifier = "$DatastoreID"
            }
            $UpdateFlag = $True
        }

        If ($FolderName) {
            $url = $BaseURL+"virtualizationsites/$TargetSiteID/folders"
            $Resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $FolderID = $Resp | Where-Object {$_.FolderName -eq $FolderName} | Select FolderIdentifier -ExpandProperty FolderIdentifier
            $VMSettings.Recovery.FolderIdentifier = "$FolderID"
            $UpdateFlag = $True
        }

        If ($IsThin -ne $null) {
            ForEach ($Volume in $VMSettings.Volumes) {
                $Volume.Datastore.IsThin = $IsThin
            }
            $UpdateFlag = $True
        }

        # Update VM settings
        If ($UpdateFlag) {
            $url = $BaseURL+"vpgSettings/${VPGSID}/vms/${VMID}"
            $payload = $VMSettings | ConvertTo-Json -Depth 9
            Invoke-RestMethod @PARAMS -Method Put -Uri $url -Body $payload -Headers $SessionHeader -ContentType $TypeJSON
        }

        $vm_idx += 1
    } # end of VM loop

    # Update Nic settings for a VM if needed
    $vm_idx = 0
    ForEach ($VM in $VPGVMs) {
        $VMID = $VMIDList[$vm_idx]
        $url = $BaseURL+"vpgSettings/"+"$VPGSID"+"/vms/"+"$VMID"+"/nics"
        $NicSettings = Invoke-RestMethod @PARAMS -Method Get -Uri $url -Headers $SessionHeader -ContentType $TypeJSON
        $VMNics = $VM.Nics

        # Skip if VM has no special NIC setting request
        If (!$VMNics -Or ($VMNics.length -eq 0)) {
            Continue
        }

        $idx = 0
        ForEach ($Nic in $NicSettings) {
            $NetworkName = $VMNics[$idx].Failover.Network
            $TestNetworkName = $VMNics[$idx].FailoverTest.Network

            $url = $BaseURL+"virtualizationsites/$TargetSiteID/networks"
            $Resp = Invoke-RestMethod @PARAMS -Uri $url -TimeoutSec 100 -Headers $SessionHeader -ContentType $TypeJSON
            $NetworkID = $Resp | Where-Object {$_.VirtualizationNetworkName -eq $NetworkName} | Select NetworkIdentifier -ExpandProperty NetworkIdentifier
            $TestNetwork = $Resp | Where-Object {$_.VirtualizationNetworkName -eq $TestNetworkName} | Select NetworkIdentifier -ExpandProperty NetworkIdentifier
            $NicID = $Nic.NicIdentifier

            $obj = @{
                NicIdentifier = $NicID
                Failover = @{
                    Hypervisor = @{
                        NetworkIdentifier = $NetworkID
                        DnsSuffix = $Null
                        IpConfig = @{
                            Gateway = [string]$VMNics[$idx].Failover.Gateway
                            IsDhcp = $False
                            PrimaryDns = $Null
                            SecondaryDns = $Null
                            StaticIp = [string]$VMNics[$idx].Failover.StaticIp
                            SubnetMask = [string]$VMNics[$idx].Failover.SubnetMask
                        }
                        ShouldReplaceMacAddress = $False
                    }
                }
                FailoverTest = @{
                    Hypervisor = @{
                        NetworkIdentifier = $TestNetwork
                        DnsSuffix = $Null
                        IpConfig = @{
                            Gateway = $VMNics[$idx].FailoverTest.Gateway
                            IsDhcp = $False
                            PrimaryDns = $Null
                            SecondaryDns = $Null
                            StaticIp = [string]$VMNics[$idx].FailoverTest.StaticIp
                            SubnetMask = [string]$VMNics[$idx].FailoverTest.SubnetMask
                        }
                        ShouldReplaceMacAddress = $False
                    }
                }
            }

            $payload = $obj | ConvertTo-JSON -Depth 10
            $url = $BaseURL+"vpgSettings/"+"$VPGSID"+"/vms/"+"$VMID"+"/nics/"+"$NicID"
            Invoke-RestMethod @PARAMS -Method Put -Uri $url -Body $payload -Headers $SessionHeader -ContentType $TypeJSON

            $idx += 1
        }

        $vm_idx += 1
    } # end of loop for VM NIC update

    # Committing the VPG settings to be created
    Write-Output "Committing VPG creation for VPG: $VPGName"
    Try {
        $url = $BaseURL+"vpgSettings/"+"$VPGSID"+"/commit"
        Invoke-RestMethod @PARAMS -Method Post -Uri $url -ContentType $TypeJSON -Headers $SessionHeader -TimeoutSec 100
    }
    Catch {
        $Errors += @{error=$_.Exception.Message;}
        $err = ($Error[0] -Split '\n')[0]
        If ($SingleVPG) {
            Summarize -30 "Error while committing VPG creation request: ${err}"
        }
    }       

    # Waiting $TimeToWaitBetweenVPGCreation seconds to monitor progress
    # write-host "Waiting $TimeToWaitBetweenVPGCreation seconds to monitor progress"
    # sleep $TimeToWaitBetweenVPGCreation
}

########## END OF MAIN BODY #########################################

# NOTE: This is a very strict requirement
If ($Errors.count -gt 0) {
    Summarize 20 "Partial failure detected, intervention needed"
}

Summarize 0 "Successfully submitted VPG creation request"