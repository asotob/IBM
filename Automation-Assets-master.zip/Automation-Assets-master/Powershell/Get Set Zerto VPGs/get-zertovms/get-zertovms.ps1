﻿# script is to check a given list of vm object names in a vCenter and then check the esxi host it is running on for a VRA
# to confirm readiness for Zerto replication. If not found, write to file. Additional functionality will collect
# total diskspace being used, vmware tools presence and version. 

#parameters
param(
    [parameter(mandatory=$true)]
    [string]
    $vmlist,

    [parameter()]
    [string]
    $targetvcenter,

    [parameter()]
    [string]
    $user

)

# import list of vms to check
$servers = import-csv -Delimiter "`," $($vmlist)

# check to see if connection details are active in session, if not establish connection to vCenter
if (!$targetvcenterlor){
{
    write-host "input name or IP of source vCenter."
    $targetvcenter = (read-host)
    write-host ""
        }
    if (!$targetvcusername){
    write-host "input name of source vCenter Username in name@domain format."
    $targetVCUsername = (read-host)
    write-host ""
        }
    write-host ""
    write-host "input the vCenter password."
    $targetvcpasswd = (read-host -AsSecureString) 

#$targetpasswd = convertto-securestring $targetvcpasswd -asplaintext -force
    $vCcreds = new-object system.management.automation.pscredential ($targetVcusername, $targetvcpasswd)
    $targetvcenterlor = connect-viserver -server mt001xsvcprod01.federated.fds -credential $vccreds
   }

# foreach loop to check each vm in turn
foreach ($vm in $servers){

$wave = $vm.wave
# set display variable and report to screen what VM is being checked
$vmcheck = $vm.hostname | out-string
write-host ""
write-host "Checking $vmcheck for disk usage and allocation."
write-host ""

# set variables for finding esxihost used by target vm, once found filter a search for Z-VRA* object names
$vmstatus = get-vm $vmcheck -ErrorAction SilentlyContinue

# if no status, bypass this check as VM is not found
if (!$vmstatus){
write-host ""
write-host -ForegroundColor red "$vmcheck could not be found on the Lorain vCenter, may not be a vm or may 
be running on a Hyper-V host. Will continue on to next server."
continue
}


# collect disk and vmwtools information
$vmdisks = Get-HardDisk $vmstatus | select-object capacitygb, name
$vmtools = get-vmguest $vmstatus | select-object vmname, toolsversion | where-object {$_.toolsversion -like "10.*"} 

# if vmtools is up to date version, print to screen and move on
if ($vmtools){
    write-host ""
    write-host -foregroundcolor green "$vmcheck has a current version of vmtools."
}

# if vmtools check fails, print to screen and write to file
else{
    write-host ""
    write-host -ForegroundColor red "$vmcheck does not have vmTools installed, running, or 
    incompatible version. $vmcheck logged to file."
    $vmcheck | export-csv -Delimiter "`t" ".\vmtoolsissues_$wave.csv" -append -Encoding unicode -NoTypeInformation
    }

# loop through the discovered disks and create an array for reporting
foreach ($disk in $vmdisks){
    $storage = new-object psobject -property @{
        hostname = $vm.hostname
        attached_storage = $disk.name 
        sizeGB = $disk.capacitygb 
        } | select 'hostname', 'attached_storage', 'sizeGB'
        
$storage | export-csv -Delimiter "`," ".\storagecheck_$wave.csv" -NoTypeInformation -Append
    
$path = $disk.name
if ($disk.capacitygb -gt 1000000){
write-host "$path is larger than 1Tb"
}

# if storage check passes less than 1Tb, write to screen
else {
write-host ""
write-host "$path is within storage capacity"
}

}

# print to screen the VRA check
write-host ""
write-host "Checking $vmcheck for vmhost VRA."

$vmhost = Get-VMHost $vmstatus.vmhost -ErrorAction SilentlyContinue 

# if vmhost check passes, move on to check for presence of VRA appliance
if ($vmhost){
$vracheck = get-vmhost $vmhost.name |Get-VM | where {$_ -like "Z-vra*"} -ErrorAction SilentlyContinue 



# if no VRA found, print to screen and then create a $report and write to file
if (!$vracheck){
$fix = $vm.hostname
write-host -ForegroundColor red "vra not found on $vmhost for $fix"
write-host ""

# create report to export to file vm name and esxihost
$report = new-object psobject -property @{
hostname = $vm.hostname
esxihost = $vmhost.name
} | select 'hostname', 'esxihost'

$report | export-csv -Delimiter "`t" -NoTypeInformation .\zerto_vm_remediation_list_$wave.csv -Append -Encoding Unicode
continue
}



# if VRA found, write to screen and then proceed to next vm
else {
# create variable to print to screen
$good = $vm.hostname
write-host ""
write-host -foregroundcolor green "vra found on $vmhost for $good"
write-host ""
$vm.hostname | out-string
write-host ""
}
}

}

# write to screen the report path and file name after script loop completes. 
if ($report){
$path = ".\"
$output = get-childitem -Path .\zerto_vm_remediation_list_$wave.csv
write-host "A report file has been created to record the VMs that require remediation 
$output."
}
