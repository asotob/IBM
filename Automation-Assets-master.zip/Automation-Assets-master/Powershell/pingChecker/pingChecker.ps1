#Changes progress preferences to silence test-netConnection progress bar.
$OriginalProgressPreference = $Global:ProgressPreference
$Global:ProgressPreference = 'SilentlyContinue'

#Loads the content of the inventory file
$file = @(get-content -Path "C:\tmp\script windows\all servers.txt")

#start empty array to store the data of the servers checked and saved into objects.
$CheckedServers = @()


foreach ($server in $file) {
    
    $testNet = Test-netConnection -ComputerName $server.Split()[0] -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    $dnsCrossCheck = Resolve-DnsName -Name $server.Split()[0] -ErrorAction SilentlyContinue -ErrorVariable DNSError

	#check if DNS resolutions is not ok
    if ($DNSError) { 

        $dnsMatches = "False"
        $resolvedns = "False"

    } else {
        $resolvedns = "True"
		
		#check if DNS IPAddress matches the IPAddress in the inventory file
        if ( $dnsCrossCheck.IPAddress -eq $server.Split()[1] ){
            
            $dnsMatches = "True"

        } else {
            
            $dnsMatches = "False"

        }
    }   

	# Creates a new object and adds properties based on the server being checked.
    $CheckedServer = New-Object psobject -Property @{
        FQDN = $testNet.ComputerName
        DNSIPaddress = $testNet.RemoteAddress
        FileIPaddress = $server.Split()[1]
        DNSMatches = $dnsMatches
        PingSucceeded = $testNet.PingSucceeded
        ResolveDNS = $resolvedns  
    }
	
	#append checked servers into the array 
    $CheckedServers += $CheckedServer
    
}  

#Export the data stored in objects of all the servers checked into a CSV file
$CheckedServers | Select-Object -Property FQDN,DNSIPaddress,FileIPAddress,ResolveDNS,DNSMatches,PingSucceeded |Export-Csv -Path .\pingChecker.csv

#restore progress bar preferences
$Global:ProgressPreference = $OriginalProgressPreference
