---
external help file: ImportExcel-help.xml
Module Name: ImportExcel
online version: https://github.com/dfinke/ImportExcel
schema: 2.0.0
---

# Invoke-AllTests

## SYNOPSIS
{{ Fill in the Synopsis }}

## SYNTAX

```
Invoke-AllTests [[-target] <Object>] [-OnlyPassing] [-FirstOne]
```

## DESCRIPTION
{{ Fill in the Description }}

## EXAMPLES

### Example 1
```powershell
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -FirstOne
{{ Fill FirstOne Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -OnlyPassing
{{ Fill OnlyPassing Description }}

```yaml
Type: SwitchParameter
Parameter Sets: (All)
Aliases:

Required: False
Position: Named
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -target
{{ Fill target Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### None

## OUTPUTS

### System.Object
## NOTES

## RELATED LINKS
