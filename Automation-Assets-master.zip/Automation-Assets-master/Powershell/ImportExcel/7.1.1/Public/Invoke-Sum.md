---
external help file: ImportExcel-help.xml
Module Name: ImportExcel
online version: https://github.com/dfinke/ImportExcel
schema: 2.0.0
---

# Invoke-Sum

## SYNOPSIS
{{ Fill in the Synopsis }}

## SYNTAX

```
Invoke-Sum [[-Data] <Object>] [[-Dimension] <Object>] [[-Measure] <Object>]
```

## DESCRIPTION
{{ Fill in the Description }}

## EXAMPLES

### Example 1
```powershell
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -Data
{{ Fill Data Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 0
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Dimension
{{ Fill Dimension Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 1
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

### -Measure
{{ Fill Measure Description }}

```yaml
Type: Object
Parameter Sets: (All)
Aliases:

Required: False
Position: 2
Default value: None
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### None

## OUTPUTS

### System.Object
## NOTES

## RELATED LINKS
