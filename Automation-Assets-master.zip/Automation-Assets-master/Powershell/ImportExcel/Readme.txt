Windows 10, Windows 2016 and higher,
Place this directory as a subdirectory of:
C:\Program Files\WindowsPowerShell\Modules
