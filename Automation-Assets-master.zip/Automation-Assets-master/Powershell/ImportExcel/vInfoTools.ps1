<#
     .SYNOPSIS
          This powershell Script is a substitue for RVtools. Here are the highlights:
          - Retrieves VMware vCenter inventory and EXPORTS TO AN EXCEL spreadsheet on your Desktop.
          - Excel output is multi-sheet with column autowidth.
          - Excel sheets Freeze first row and column for easy viewing.
          - Prints screen with when -VM parameter is used.
          - Puts CDP (Cisco Discover Protocol) data on the PNIC tab.
          - Flags VM as candidate for HCX migration in the vmInfo worksheet, column: HcxEligible.
          - vmInfo (VM) sheet Snapshot count and Size.
          - vmInfo tab combines to one tab VM inventory with vCPU and Memory data.
     
     .DESCRIPTION
          Upon execution, this script does the following:
          - Verifies Powershell 5.0 or higher.
          - Imports Vmware Powercli Modules if required.
          - Imports non-proprietory, open source EXCEL MODULES if required.
          - Connects to vCenter using your credentials if not already connected.
          Note: Credentials use Microsoft Credential manager and passwords are not visible to this script.h
          - Retreives vCenter inventory.
          - Exports invnetory Excel.
          - Exports vmInfo (VM Inventory) to CSV if EXCEL MODULES not avalable.
          
          UPDATES:
          2021-01-13 Added installation for ImportExcel module by Zip File 
          2021-01-13 Added "MemUsed%" and "MemUsedGB" to vmHost tab
          2021-01-06 Added EvcMode field to Cluster Tab, re-ordered tabs
          2020-09-30 Added Dashboard for HcxEligible VM Count
          Added CSV Export as 1 file per Inventory Collection
          2020-10-12 added tab for ResourcePools which includes vAPP
          2020-10-14 added vCenter column to all sheets as a cross reference of vcenters objects in case connected to multiple vCenters.
          2020-10-14 added vmIP section to provide Ip to VM listing
     
     .PARAMETER VM
          Virtual Machine name
     
     .PARAMETER ExportExcel
          Enabled by default..
          True False parameter to export to excel.
          -ExportExcel:$False  #disables
     
     .PARAMETER CsvExport
          A description of the CsvExport parameter.
     
     .PARAMETER FilenamePath
          Path of a file. Exampe C:\temp\myoutput.xlsx
          Default path output is your $ENV:\User\Desktop.
     
     .PARAMETER vCenter
          vCenter FQDN name or IP address.
     
     .PARAMETER Credential
          A description of the Credential parameter.
     
     .PARAMETER Raw
          Outputs the VM data in raw format to the console. No export to file.
     
     .PARAMETER ScrubLicenseKey
          Switch to remove last part of license key
     
     .PARAMETER ImportExcelModulePath
          The path\filename to the ImportExcel module
          Use this for manual installation of supporting ImportExcel Module
          ImportExcel.zip module will automatically import if it is in the same directory as this script.
     
     .PARAMETER Help
          Displays help info.
     
     .EXAMPLE
          vmInfoTools.ps1
          -- Exports vCenter Inventory to Excel file located on your desktop.
     
     .EXAMPLE
          vmInfoTools.ps1  -ExportExcel
          -- Exports vCenter Inventory toExcel file . -ExportExcel defaults to TRUE and is the same as vmInfotools.ps1 with no parameter.
          -- the ExportExcel disables with the -VM parameter but can be over ridden by selecting th -ExportExcel parameter.
     
     .EXAMPLE
          vmInfoTools.ps1  -VM MyVM
          -- Prints vmInfo content to screen and DOES NOT create Excel file.
     
     .EXAMPLE
          vmInfoTools.ps1  -VM MyVM  -ExportExcel
          -- Prints vmInfo content to screen AND creates Excel file .
     
     .EXAMPLE
          vmInfoTools.ps1  -VM MyVM  -ExportExcel  -FileName
          -- Prints vmInfo content to screen AND creates Excel file as specified by parameter -FileName
     
     .EXAMPLE
          vmInfoTools.ps1  -FileName
          -- Prints vmInfo content to screen AND creates Excel file as specified by parameter -FileName
     
     .OUTPUTS
          Excel or CSV files.
          
     .Inputs
     No command line inputs required for export to EXCEL, but parameters are available for convenice for additional optoins.
     
     .Link
     https://www.powershellgallery.com/packages/ImportExcel/

     
     .NOTES
          Author: Mark McInturff - mark.mcinturff@ibm.com or mmcint@gmail.com
          
          HCX Verification:
          PhysicalRDM,Shared VMDK,Virtual Media,ESXi version -lt 5.0,ESXi version -lt 5.5,HW version -lt 9,Standard vSwitch,HCX vMotion,HCX Eligible
          PhysicalRDM,Shared VMDK,VirtualMedia,ESXi version -lt 5.0,ESXi version -lt 5.5,HW version -lt 9,Standard vSwitch,HCX vMotion,HCX Eligible,Environment,Have DR?,Physical?,Simple Workload
          Check for SRM Visibility
#>

param
(
     [Parameter(Mandatory = $false,
                  ValueFromPipeline = $true,
                  Position = 1,
                  HelpMessage = 'Virtual Machine Name')]
     [Alias('vmName', 'VirtualMachine', 'Name')]
     $VM,
     [SWITCH]$ExportExcel =  $True,
     [SWITCH]$CsvExport = $False,
     [STRING]$FilenamePath,
     [string]$vCenter,
     [PsCredential]$Credential,
     [SWITCH]$Raw,
     [SWITCH]$ScrubLicenseKey,
     $ImportExcelModulePath = ".\ImportExcel.zip",
     [SWITCH]$Help
)


begin
{

     ##### BEGIN Error Collection ENABLE
     $error.Clear()
     $ErrorActionPreference = "SilentlyContinue" #disable errors for null expressions
     $ErrorStart = $Error.Count - 1 
         

     Function InstallImportExcel 
     {    
          param ( $zipfile )
          
          ##### Install ImportExcel Modules ##### 
          $allPSmodule = $env:PSModulePath.Split(";") | ? { $_ -match "program files" } 
          $UserPSMODULE = $env:PSModulePath.Split(";") | ? { $_ -match "\\user" } 

          $ModulePath = $UserPSMODULE 

          if (test-path $allPSmodule)
          {
               $ModulePath = $allPSmodule
          }
          else
          {
               #Create user directory if not exist
               New-Item -Path $ModulePath -Type:Directory -ErrorAction:SilentlyContinue
          }

          $ModulePath = gi $ModulePath 

          Expand-Archive $zipfile -DestinationPath $ModulePath
          
          
     }

     if ($Help)
     {
          HELP $MyInvocation.MyCommand.Name -Detail
          exit
     }
     
     #Default No ExportCSV 
     $ExportCsvIfNoExcel = $False
     if ($CsvExport) { $ExportCsvIfNoExcel = $True }
     
     #Default as ExcelExport but not if vm name specified 
     $ExportExcelDEFAULT = $TRUE ;
     if ((! $ExportExcel )) { $ExportExcelDEFAULT = $FALSE } ;
     
     #ExportExcel if FilenamePath
     if ($FilenamePath) { $ExportExcelDEFAULT = $True }
     
     
     
     ##### Import ImportExcel Module #####
     # Get screen width for text
     $wWidth = (Get-Host).UI.RawUI.MaxWindowSize.Width - 5
     If ((gcm Export-Excel -ErrorAction:SilentlyContinue).count -lt 1 -AND (! $CsvExport) )
     {
     
          # Atempt Install of ImportModule with local zip archive file
          if (test-path $ImportExcelModulePath)
          {
               InstallImportExcel $ImportExcelModulePath
          }

          if((gcm Export-Excel -ErrorAction:SilentlyContinue).count -lt 1 )
          {
               #print freeform text
               WRITE-HOST -foreground yellow {
                    Requirements:
                    ImportExcel Module. Oneliner installation:
                    Find-Module -Name ImportExcel | Install-Module -Name ImportExcel;

                    Set-ExecutionPolicy to Bypass or Unrestricted (requires powershell Administrator mode)
                    Set-ExecutionPolicy Bypass -Force

                    VMware VMware.PowerCLI Modules
                    Find-Module VMware.PowerCLI; Install-Module VMware.PowerCLI

                    Powershell TLS Version may not match Microsoft

                    See: https://www.powershellgallery.com/packages/ImportExcel/
               } #end WRITE-HOST


               WRITE-HOST ("X" * $wWidth) "`nImporting Module: ImportExcel. Press CTRL-C to stop.`n" ("X" * $wWidth)
               $null = Set-PowerCLIConfiguration -ProxyPolicy NoProxy -InvalidCertificateAction Ignore -Confirm:$false -DefaultVIServerMode Multiple -Scope User
               $null = Set-ExecutionPolicy Bypass -Confirm:$false -Force
               Find-Module -Name ImportExcel | Install-Module -Verbose:$True
          }
          
     } #endif ImportExcel
     
     
     If ((gcm Export-Excel -ErrorAction:SilentlyContinue).count -lt 1)
     {
          #ImportExcel Module missing, export to CSV
          Write-Host ImportExcel Module not present.
          
          ## ImportExcel not installed
          $ExportCsvIfNoExcel = $True
          
          
     }
     
     ##### Import VMware Powercli Module #####     
     #Include VMware modules exist
     If ((gcm Get-VmHost -ErrorAction:SilentlyContinue).count -eq 0)
     {
          WRITE-HOST ("X" * $wWidth) "`nImporting Module : VMware.PowerCLI. Press CTRL-C to stop.`n" ("X" * $wWidth)
          Find-Module -Name VMware.PowerCLI -ErrorAction:SilentlyContinue | Install-Module -Force -Verbose
          
     }
     

     if ($vCenter){
          #$null = 
          $DefaultVIServers | ? { $_.Name -ne $vCenter } | Disconnect-ViServer -Force -Confirm:0 #-ErrorAction:Ignore
     }


     IF ( ( $DefaultVIServers.Count -gt 1 ) )
     {
          WRITE-HOST "` "  Choose which vCenter to use. "`n"
          

          #show numbered vCenter Connection List
          $i=$null; $i++ ; 
          $DefaultVIServers.Name | % { "  " + $i++ + ") " + $_  } ; 

           "  $i) NONE" 

          $choiceVc = 0
          do 
          { 
               [int]$choiceVc = (Read-Host " Type number")
          } Until ( $choiceVc.GetType().name -match "int"  -and $choiceVc -gt 0 -and $choiceVc -lt ($i + 1 ) )

          $vCenter = $DefaultVIServers[$choiceVc -1]
          
          if (! $vCenter  ){
               $null = $DefaultVIServers | Disconnect-ViServer -Force -Confirm:0 #-ErrorAction:Ignore
          }else {
               $null = $DefaultVIServers | ? { $_.name -ne $vCenter } | Disconnect-ViServer -Force -Confirm:0 #-ErrorAction:Ignore
          }
     }#end if


     if ( ! $DefaultVIServers) 
     {
          WRITE-HOST "`n Connection required. Using Get-VC";
          WRITE-HOST " If required, You'll be prompted for ""$vCenter"" credentials in a moment."
          
          if (! $vCenter){
               $vCenter = Read-Host " Type vCenter FQDN or IP address"
          }     

          if (! $Credential -OR ($Credential.GetType().name -notmatch "Credential") )
          {
               If (! $Credential) { 
               [string]$Credential = "Administrator@vsphere.local" 
               }

               [PsCredential]$Credential = Get-Credential -Message "VMware vCenter Credentials" -Username $Credential

          }

          WRITE-HOST " Connecting to $vCenter "   
          if ($vCenter -OR $Credential )
          {
               Connect-VIServer -Server $vcenter -Credential $Credential -Force  -verbose:$true | out-null
          }

     } #end if
     #END Connect to vCenter
     
     
     #vcenter connection doesn't exist
     if (! $DefaultVIServers)
     {
          WRITE-HOST -foreground:yellow "NO CONNECTION TO vCENTER."
          exit #exit script because there are no vcenters
     }
     
     #WRITE-HOST "`n vCENTER: $( $DefaultVIServers.name -Join ", ") `n";
     write-host -foreground green " vCenter:      " $DefaultVIServer
     #GLOBAL VARIABLES for File output
     $vmInfo_OUTPUT = @()
     $vNetworkAdapter_OUTPUT = @()
     $vDisk_OUTPUT = @()
     $vmHost_OUTPUT = @()
     $VMKernelAdapters_OUTPUT = @()
     $vHBA_OUTPUT = @()
     $pNIC_CDP_OUTPUT = @()
     $Cluster_OUTPUT = @()
     $ResourcePool_vApp_OUTPUT = @()
     $Datastore_OUTPUT = @()
     $vLicense_OUTPUT = @()
     $vSwitch_OUTPUT = @()
     $vPortgroup_OUTPUT = @()
     $vdSwitch_OUTPUT = @()
     $vdPortgroup_OUTPUT = @()
     $Datacenters_OUTPUT = @()
     $vmIP_OUTPUT = @()
     $DebugLOG_OUTPUT = @()
     
     $PIPELINEVM = @() #variable for vm's pipled to script
     
}

process
{
     #build array from Pipeline
     if ($_)
     {
          $PIPELINEVM += $_
          $Raw = $False
     }
     
} #end process


END
{

#Add-Type -Path ".\EPPlus.dll"
    
     ##### function to recurse path of root to VM
     Function GetvCenterFolderPath
     {
          param ($obj)
          $PATH_TO_RETURN = @()
          $PATH_TO_RETURN += $obj.Name
          switch -regex ($obj.Parent)
          {
               'ResourcePool' { $PATH_TO_RETURN += GetvCenterFolderPath ($ResourcePools | ? { $_.Moref -eq $obj.parent }) }
               'Folder'       { $PATH_TO_RETURN += GetvCenterFolderPath ($Folders | ? { $_.Moref -eq $obj.parent }) }
               'Datacenter'   { $PATH_TO_RETURN += GetvCenterFolderPath ($Datacenters | ? { $_.Moref -eq $obj.parent }) }
               'Cluster'      { $PATH_TO_RETURN += GetvCenterFolderPath ($Clusters | ? { $_.Moref -eq $obj.parent }) }
               'Host'         { $PATH_TO_RETURN += GetvCenterFolderPath ($VmHosts | ? { $_.Moref -eq $obj.parent }) }
          }
          [array]::Reverse($PATH_TO_RETURN)
          $PATH_TO_RETURN = ($PATH_TO_RETURN -join "\") ###-replace "^Datacenters\\|\\host\\|\\Resources\\" , "\"
          if (! $o.Parent)
          { 
               $PATH_TO_RETURN = $obj.Client.ServiceUrl.Split("/")[2] + "\" + $PATH_TO_RETURN
          }
          RETURN $PATH_TO_RETURN
          
     } ### End Function
     
     
     ##### function to recurse path of root to VM
     Function GetvCenterResourcePath
     {
          param ($obj)
          $PATH_TO_RETURN = @()
          $PATH_TO_RETURN += $obj.Name
          $o = $obj
          if ($obj.gettype().Name -match "VirtualMachine|Host")
          {
               $o = $ResourcePools | ? { $_.Moref -eq $obj.ResourcePool };
               $PATH_TO_RETURN += $o.Name;
          }
          switch -regex ($o.Parent)
          {
               'ResourcePool' { $PATH_TO_RETURN += GetvCenterResourcePath ($ResourcePools | ? { $_.Moref -eq $o.parent }) }
               'Folder'       { $PATH_TO_RETURN += GetvCenterResourcePath ($Folders | ? { $_.Moref -eq $o.parent }) }
               'Datacenter'   { $PATH_TO_RETURN += GetvCenterResourcePath ($Datacenters | ? { $_.Moref -eq $o.parent }) }
               'Cluster'      { $PATH_TO_RETURN += GetvCenterResourcePath ($Clusters | ? { $_.Moref -eq $o.parent }) }
               'Host'         { $PATH_TO_RETURN += GetvCenterResourcePath ($VmHosts | ? { $_.Moref -eq $o.parent }) }
          }
          [array]::Reverse($PATH_TO_RETURN)
          $PATH_TO_RETURN = ($PATH_TO_RETURN -join "\") ###-replace "^Datacenters\\|\\host\\|\\Resources\\" , "\"
          
          if (! $o.Parent)
          {
               $PATH_TO_RETURN = $obj.Client.ServiceUrl.Split("/")[2] + "\" + $PATH_TO_RETURN
          }
          
          RETURN $PATH_TO_RETURN
     } ### End Function
     
     
     #choose -VM or pipeline
     if ($PIPELINEVM.count -gt 0)
     {
          $vmList = $PIPELINEVM
     }
     
     $vmList = $VM -replace "\*", ".*" #replace * with .* for regex
     
     #convert paramater ary to filter string (regex)
     $vmlist = $vmlist -join "|"
     
     #otuput raw data onlye
     if ($Raw)
     {
          GET-VIEW -ViewType VirtualMachine -Filter @{ "Name" = $vmlist }
          Exit #after output raw data to screent
     }
     
     $Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
     
     #$viewtypes = "VirtualMachine,ComputeResource,Datacenter,Datastore,DistributedVirtualPortgroup,DistributedVirtualSwitch,Folder,HostSystem,Network,OpaqueNetwork,ResourcePool,StoragePod,VirtualApp,VmwareDistributedVirtualSwitch".Split(",") | % { $_.trim() }
     
     ###########################################
     ##### Get vCenter Inventory Data in this section
     #Get Virtual Machines from vmware.core.automation api 
     $VMViews = GET-VIEW -ViewType VirtualMachine -Filter @{ "Name" = $vmlist; "Config.Template" = "$False" } -Property Name, Layout, LayoutEx, ResourceConfig, ResourcePool, Parent, Storage, Guest, Config, Summary.Config, Summary.Guest, Summary.QuickStats, Runtime #.PowerState, Runtime.host #| ? { $_.Config.FtInfo.Role -ne 2  } | Sort-Object Name
     $Folders = GET-VIEW -ViewType Folder -Property Name, Parent
     $VmHosts = GET-VIEW -ViewType HostSystem -Property Name, Config, ConfigManager, Network, Hardware.PciDevice, Datastore, Runtime, VM, Summary, Parent, Capability | Sort-Object Name
     $Clusters = GET-VIEW -ViewType ClusterComputeResource -Property Name, Parent, Summary, ConfigurationEx, Configuration, Datastore, ResourcePool, Host
     $Datacenters = GET-VIEW -ViewType Datacenter
     
     $Datastores = GET-VIEW -ViewType Datastore #-Property Name, Parent
     $ResourcePools = GET-VIEW -ViewType ResourcePool #-Property Name, Parent
     #$vSwitchesView = @() ## don't lookup. Not context here. GET-VIEW $VmHosts.ConfigManager.NetworkSystem ### lookup once because faster than hitting in loops
     $vdSwitches = GET-VIEW -ViewType VmwareDistributedVirtualSwitch
     $vdPortgroups = GET-VIEW -ViewType DistributedVirtualPortgroup | ? { $_.Config.Uplink -ne $True } #uplinks and portgroups are same. filter out 
     ###########################################
     
     WRITE-HOST -foreground:Green " VM Count:     "$VMViews.Count
     WRITE-HOST -foreground:Green " Folders:      "$Folders.Count
     WRITE-HOST -foreground:Green " Clusters:     "$Clusters.Count
     WRITE-HOST -foreground:Green " VmHost:       "$VmHosts.Count
     WRITE-HOST -foreground:Green " vSwitches:    "$VmHosts.ConfigManager.NetworkSystem.Count
     WRITE-HOST -foreground:Green " Portgroup:    "$VmHosts.Network.Count
     WRITE-HOST -foreground:Green " Datacenters:  "$Datacenters.Count
     WRITE-HOST -foreground:Green " Datastores:   "$Datastores.Count
     WRITE-HOST -foreground:Green " ResourcePool: "$ResourcePools.Count
     WRITE-HOST -foreground:Green " vdSwitch:     "$vdSwitches.Count
     WRITE-HOST -foreground:Green " dvPortgroups: "$vdPortgroups.Count
     Write-Verbose -Message "`n STOPWATCH LAPSED SECONDS: $($Stopwatch.Elapsed.TotalSeconds)"
     
     ######################################
     ####### BEGIN Resource Pools #########
     
     Foreach ($rp in $ResourcePools)
     {
          $row_rp = "" | Select ResourcePool, ResourceType, vAppState, ResourcePath, Status, VMs, vCPUs, CpuLimit, CpuReservation, vMemMB, MemLimit, MemReservation, OverallCpuUsage, OverallCpuDemand, GuestMemoryUsage, HostMemoryUsage, DistributedCpuEntitlement, DistributedMemoryEntitlement, StaticCpuEntitlement, StaticMemoryEntitlement, PrivateMemory, SharedMemory, SwappedMemory, BalloonedMemory, OverheadMemory, ConsumedOverheadMemory, CompressedMemory, MoRef, vCenter
          
          $VMviews_this = $VMViews | ? { $Rp.vm -contains $_.MoRef }
          
          $row_rp.ResourcePool = $rp.Name
          $row_rp.ResourceType = ($rp | gm -Type:Properties | select -f 1).TypeName.split(".")[2]
          $row_rp.ResourcePath = GetvCenterResourcePath $rp
          $row_rp.vAppState = $rp.Summary.VAppState
          #$row_rp.ResourcePath = GetvCenterFolderPath $rp
          $row_rp.VMs = $rp.Vm.Count
          $row_rp.Status = $rp.OverallStatus
          $row_rp.vCPUs = $VMviews_this.Config.Hardware | measure -sum NumCPU | % { $_.Sum }
          $row_rp.vMemMB = $VMviews_this.Config.Hardware | measure -sum MemoryMB | % { $_.Sum }
          $row_rp.CpuLimit = $rp.Summary.Quickstats.CpuLimit
          $row_rp.CpuReservation = $rp.Summary.Quickstats.CpuReservation
          $row_rp.MemLimit = $rp.Summary.Quickstats.MemLimit
          $row_rp.MemReservation = $rp.Summary.Quickstats.MemReservation
          $row_rp.OverallCpuUsage = $rp.Summary.Quickstats.OverallCpuUsage
          $row_rp.OverallCpuDemand = $rp.Summary.Quickstats.OverallCpuDemand
          $row_rp.GuestMemoryUsage = $rp.Summary.Quickstats.GuestMemoryUsage
          $row_rp.HostMemoryUsage = $rp.Summary.Quickstats.HostMemoryUsage
          $row_rp.DistributedCpuEntitlement = $rp.Summary.Quickstats.DistributedCpuEntitlement
          $row_rp.DistributedMemoryEntitlement = $rp.Summary.Quickstats.DistributedMemoryEntitlement
          $row_rp.StaticCpuEntitlement = $rp.Summary.Quickstats.StaticCpuEntitlement
          $row_rp.StaticMemoryEntitlement = $rp.Summary.Quickstats.StaticMemoryEntitlement
          $row_rp.PrivateMemory = $rp.Summary.Quickstats.PrivateMemory
          $row_rp.SharedMemory = $rp.Summary.Quickstats.SharedMemory
          $row_rp.SwappedMemory = $rp.Summary.Quickstats.SwappedMemory
          $row_rp.BalloonedMemory = $rp.Summary.Quickstats.BalloonedMemory
          $row_rp.OverheadMemory = $rp.Summary.Quickstats.OverheadMemory
          $row_rp.ConsumedOverheadMemory = $rp.Summary.Quickstats.ConsumedOverheadMemory
          $row_rp.CompressedMemory = $rp.Summary.Quickstats.CompressedMemory
          $row_rp.MoRef = $rp.moref
          $row_rp.vCenter = $rp.Client.ServiceUrl.split("/")[2]
          $ResourcePool_vApp_OUTPUT += $row_rp
     }

     ######################################
     ########### vdSwitches BEGIN ##########
     Foreach ($vdSwitch in $vdSwitches)
     {
          $row_vdSw = "" | Select Name, vdSwitch, Vendor, Version, CreatedUTC, VmHosts, VmHostMembers, VLAN_Default,
                                        vdPortGroups, Ports, MaxPorts, VMs, TrafficShapingIN, InAvg, InPeak, InBurst,
                                        TrafficShapingOUT, OutAvg, OutPeak, OutBurst,
                                        DiscoveryProtocol, DiscoveryOperation, MTU, uuid, MoRef, vCenter

          $VmHosts_here = $VmHosts | ? { $_.Moref -in $vdSwitch.Config.Host.Config.host }
          $row_vdSw.Name = $vdSwitch.Name
          $row_vdSw.vdSwitch = $vdSwitch.Name
          $row_vdSw.Ports = $vdSwitch.config.Numports
          $row_vdSw.MaxPorts = $vdSwitch.config.MaxPorts
          #$row_vdSw.Datacenter = (GetvCenterResourcePath  $vdSwitch).split("\\")[1]
          $row_vdSw.Version = $vdSwitch.Config.ProductInfo.Version
          $row_vdSw.Vendor = $vdSwitch.Config.ProductInfo.Vendor
          $row_vdSw.CreatedUTC = $vdSwitch.Config.CreateTime
          $row_vdSw.VmHosts = $VmHosts_here.Count
          $row_vdSw.VmHostMembers = $VmHosts_here.Name -join ", "
          $row_vdSw.vdPortGroups = $vdSwitch.Portgroup.Count
          $row_vdSw.uuid = $vdSwitch.uuid
          $row_vdSw.VMs = $vdSwitch.Summary.vm.count
          #$row_vdSw.uplinkCount = $vdSwitch.Config.Host.Config.Backing.pNicSpec.Count
          #$row_vdSw.Uplinks = $vdSwitch.Config.Host.Config.Backing.pNicSpec.pnicDevice -join ", "    ###### This line shows vmnics of every host. need to key portgroups and pnics to get vmhost associated 
          ## incorrect. does not show uplinks ##$row_vdSw.uplinks = ( $vdSwitch.Config.Host.Config.Backing.pNicSpec.PnicDevice | group ).Name -join "," 
          $row_vdSw.VLAN_Default = $vdSwitch.Config.DefaultPortConfig.Vlan.VlanId
          $row_vdSw.TrafficShapingIn = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.Enabled.Value
          $row_vdSw.InAvg = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.AverageBandwidth.Value
          $row_vdSw.InPeak = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.PeakBandwidth.Value
          $row_vdSw.InBurst = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.BurstSize.Value
          $row_vdSw.TrafficShapingOUT = $vdSwitch.Config.DefaultPortConfig.OutShapingPolicy.Enabled.Value
          $row_vdSw.OutAvg = $vdSwitch.Config.DefaultPortConfig.OutShapingPolicy.AverageBandwidth.Value
          $row_vdSw.OutPeak = $vdSwitch.Config.DefaultPortConfig.OutShapingPolicy.PeakBandwidth.Value
          $row_vdSw.OutBurst = $vdSwitch.Config.DefaultPortConfig.InShapingPolicy.BurstSize.Value
          $row_vdSw.DiscoveryProtocol = $vdSwitch.Config.LinkDiscoveryProtocolConfig.Protocol
          $row_vdSw.DiscoveryOperation = $vdSwitch.Config.LinkDiscoveryProtocolConfig.Operation
          $row_vdSw.MTU = $vdSwitch.Config.MaxMtu
          $row_vdSw.vCenter = $vdSwitch.Client.ServiceUrl.Split("/")[2]
          $row_vdSw.Moref = $vdSwitch.Moref
          
          $vdSWITCH_OUTPUT += $row_vdSw
          
     } #end vdSwitches Loop
     
     ###### vdPortgroups BEGIN ######
     Foreach ($vdPortgroup in $vdPortgroups)
     {
          $row_vdPG = "" | Select Portgroup, vdSwitch, VmHosts, VMs, VLAN, Netflow, SecurityPolicyInherited, Promiscuous, MacChanges, ForgedTransmits,
                                        TrafficShapingIN, AverageBandwidthIN, PeakBandwidthIN, BurstSizeIN, TrafficShapingOUT, AverageBandwidthOUT,
                                        PeakBandwidthOUT, BurstSizeOUT, NicTeamingInherited, ReversePolicy, UplinkOrder, UplinkStandbyOrder,
                                        UplinkInherited, NotifySwitch, Key, Moref, vCenter
          
          $row_vdPG.VLAN = $vdPortgroup.Config.DefaultPortConfig.Vlan.VlanId
          If ($vdPortgroup.Config.DefaultPortConfig.Vlan.VlanId.Start)
          {
               $row_vdPG.VLAN = ($vdPortgroup.Config.DefaultPortConfig.Vlan.VlanId | % { [string]$_.Start + "-" + $_.End }) -join ", "
          }
          
          $vswitch_this_dvPG = $vdSwitches | ? { $_.Portgroup.Value -contains $vdPortgroup.key }
          
          $row_vdPG.Netflow = $vdPortgroup.Config.DefaultPortConfig.IpfixEnabled.Value
          $row_vdPG.Portgroup = $vdPortgroup.Name
          $row_vdPG.vdSwitch = $vswitch_this_dvPG.Name
          $row_vdPG.VmHosts = $vdPortgroup.Host.Count
          $row_vdPG.Vms = $vdPortgroup.VM.Count
          $row_vdPG.SecurityPolicyInherited = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.Inherited
          $row_vdPG.Promiscuous = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.AllowPromiscuous.value
          $row_vdPG.MacChanges = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.MacChanges.value
          $row_vdPG.ForgedTransmits = $vdPortgroup.Config.DefaultPortConfig.SecurityPolicy.ForgedTransmits.value
          $row_vdPG.TrafficShapingIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.Enabled.Value
          $row_vdPG.AverageBandwidthIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.AverageBandwidth.Value
          $row_vdPG.PeakBandwidthIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.PeakBandwidth.Value
          $row_vdPG.BurstSizeIN = $vdPortgroup.Config.DefaultPortConfig.InShapingPolicy.BurstSize.Value
          $row_vdPG.TrafficShapingOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.Enabled.Value
          $row_vdPG.AverageBandwidthOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.AverageBandwidth.Value
          $row_vdPG.PeakBandwidthOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.PeakBandwidth.Value
          $row_vdPG.BurstSizeOUT = $vdPortgroup.Config.DefaultPortConfig.OUTShapingPolicy.BurstSize.Value
          $row_vdPG.NicTeamingInherited = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.Inherited
          $row_vdPG.ReversePolicy = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.ReversePolicy.Value
          $row_vdPG.UplinkInherited = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.UplinkPortOrder.Inherited
          $row_vdPG.UplinkOrder = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.UplinkPortOrder.ActiveUplinkPort -join ", "
          $row_vdPG.UplinkStandbyOrder = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.UplinkPortOrder.StandbyUplinkPort -join ", "
          $row_vdPG.NotifySwitch = $vdPortgroup.Config.DefaultPortConfig.UplinkTeamingPolicy.NotifySwitches.Value
          $row_vdPG.Key = $vdPortgroup.Key
          $row_vdPG.vCenter = $vdPortgroup.Client.ServiceUrl.split("/")[2]
          $row_vdPG.Moref = $vdPortgroup.Moref
          
          $vdPORTGROUP_OUTPUT += $row_vdPG
          
     } #END vDPORTGROUPS
     
     
     
     
     
     ########### BEGIN VMViews vmInfo loops  ##########
     ForEach ($VMView in $VMViews)
     {
          $VmHost = $VmHosts | ? { $_.moref -eq $VMView.Runtime.host } | ? { $_.vm -eq $VMView.Moref };
          $Cluster = $Clusters | ? { $_.Moref -eq $VmHost.Parent }
          $Folder = $Folders | ? { $_.Moref -eq $VMview.Parent }
          
          $row_vm = "" | Select VM, DnsName, PowerState, MemGB, MemReserved, MemMaxReserved, "MemActive%", "MemConsumed%",
                                     MemoryReservation, SwapReservation, SwappedMemory, BalloonedMemory,
                                     Cpu, CoresPerSocket, CpuSockets, "CpuDemand%", "CpuUsage%",
                                     NumaSize, ReserveCpu, HotAddCpu, HotAddMem, Annotation, NICs,
                                     IP, GuestOS, Tools, ToolsStatus, syncTime,
                                     Disks, DiskRdmPhysical, DiskRdmVirtual, DiskShared, DiskGB, DiskGBUsed, VirtualMedia, vHardware, VmHost, EsxiVersion,
                                     Snapshots, SnapshotBytes, SnapshotGB, ResourcePool, Folder, Firmware, vcFolderPath, ResourcePath,
                                     Cluster, vCenter, InstanceUuid, UUID, MoRef, ONvSwitch, ONvdSwitch, HcxEligible, HcxDisqualifier
          
          $VirtualEthernetCardDEVICE = $vmview.Config.Hardware.Device | ? { $_ -is [VMware.Vim.VirtualEthernetCard] }
          
          $row_vm.vm = $vmview.Name
          $row_vm.Annotation = $vmview.config.Annotation
          $row_vm.Snapshots = $vmview.LayoutEx.File | ? { $_.Type -Match "snapshot" } | measure | % { $_.Count }
          $row_vm.SnapshotBytes = $vmview.LayoutEx.File | ? { $_.Type -Match "snapshot" } | measure size -sum | % { $_.Sum }
          $row_vm.SnapshotGB = $vmview.LayoutEx.File | ? { $_.Type -Match "snapshot" } | measure size -sum | % { $_.Sum / 1gb } | % { [math]::Round($_, 2) }
          #not needed because templates won't show # $row_vm.Type = if($vmview.Config.Template){"Template"}else{"VM"}
          $row_vm.NICs = $VirtualEthernetCardDEVICE.Count
          $row_vm.PowerState = $vmview.Runtime.PowerState
          $row_vm.MemGB = $vmview.Summary.Config.MemorySizeMB / 1kb | % { [math]::Round($_, 2) }
          #$row_vm.MemReserveGB = [math]::Round(($vmview.Summary.Config.MemoryReservation / 1024), 1)
          $row_vm.MemReserved = if( $vmview.ResourceConfig.MemoryAllocation.reservation ) { "{0:p0}" -f ( $vmview.Summary.Config.MemorySizeMB / $vmview.ResourceConfig.MemoryAllocation.reservation )  }
          $row_vm.MemMaxReserved = $vmview.Config.MemoryReservationLockedToMax -eq $True | % { $_.tostring() }
          $row_vm.Firmware = $vmview.Config.Firmware
          $row_vm."MemActive%" = ($vmview.Summary.QuickStats.GuestMemoryUsage / $vmview.Summary.Config.MemorySizeMB * 100) | % { [math]::Round($_, 1) }
          $row_vm."MemConsumed%" = ($vmview.Summary.QuickStats.PrivateMemory / $vmview.Summary.Config.MemorySizeMB * 100) | % { [math]::Round($_, 1) }
          $row_vm.MemoryReservation = $vmview.Config.InitialOverhead.InitialMemoryReservation
          $row_vm.SwapReservation = $vmview.Config.InitialOverhead.InitialSwapReservation
          $row_vm.SwappedMemory = $vmview.Summary.Quickstats.SwappedMemory
          $row_vm.BalloonedMemory = $vmview.Summary.Quickstats.BalloonedMemory
          $row_vm.Cpu = $vmview.Config.Hardware.NumCPU
          $row_vm.CoresPerSocket = $vmview.Config.Hardware.NumCoresPerSocket
          $row_vm.CpuSockets = $vmview.Config.Hardware.NumCPU / $vmview.Config.Hardware.NumCoresPerSocket
          $row_vm."CpuDemand%" = [decimal]($vmview.Summary.QuickStats.OverallCpuDemand) / $vmhost.summary.hardware.CpuMhz #mhz
          $row_vm."CpuUsage%" = [decimal]($vmview.Summary.QuickStats.OverallCpuUsage) / $vmhost.summary.hardware.CpuMhz #Mhz
          
          $row_vm.ReserveCpu = $vmview.ResourceConfig.CpuAllocation.Reservation
          $row_vm.HotaddCpu = $vmview.Config.ExtraConfig | ? { $_.Key -match "vCpu.hotAdd" } | % { $_.Value -eq $True }
          $row_vm.HotaddCpu = if (($row_vm.HotaddCpu | measure).count -eq 0) { "False" }
          else { "True" }
          $row_vm.NumaSize = if ($row_vm.HotaddCpu -eq $false)
          {
               $vmview.Config.ExtraConfig | ? { $_.key -eq "numa.autosize.vcpu.maxPerVirtualNode" } | % { $_.value }
          }
          else { "None" }
          $row_vm.HotaddMem           = $vmview.Config.ExtraConfig | ? { $_.Key -match "mem.hotAdd" } | % { [bool]$_.value }
          $row_vm.HotaddMem           = $row_vm.HotaddMem -eq $True | % { $_.tostring() } #converts null to false
          $row_vm.IP                  = ($vmview.Guest.Net.IpAddress | ? { $_ -match "\." }) -join ", "
          $row_vm.DnsName             = $vmview.Guest.IpStack.DnsConfig.HostName  -join ", "
          $row_vm.GuestOS             = $vmview.Summary.Config.GuestFullName
          $row_vm.InstanceUuid        = $vmview.Summary.Config.InstanceUUID
          $row_vm.Uuid                = $vmview.Summary.Config.uuid
          $row_vm.Tools               = $vmview.Config.Tools.ToolsVersion
          $row_vm.ToolsStatus         = $vmview.Guest.ToolsStatus
          $row_vm.syncTime            = [bool]$vmview.Config.Tools.syncTimeWithHost
          $row_vm.DiskRdmPhysical     = ($vmview.Config.Hardware.Device | % { $_.Backing.CompatibilityMode }) -join " " -match "physical"
          $row_vm.DiskRdmVirtual      = ($vmview.Config.Hardware.Device | % { $_.Backing.CompatibilityMode }) -join " " -match "Virtual"
          $row_vm.DiskShared          = ($vmview.Config.Hardware.Device | ? { $_.Backing.CompatibilityMode }) | ? { $_.backing.Sharing.Trim() } | Select -f 1 | % {
                                             If ($_) { "TRUE" }
                                             else { "FALSE" }
                                             }
          $row_vm.Disks = ($vmview.Config.Hardware.Device | ? { $_.backing -match "disk" } | measure).count
          $row_vm.DiskGB = (($vmview.Config.Hardware.Device | ? { $_.backing -match "disk" } | % { $_.CapacityInKB } | measure -sum).Sum / 1mb) | % { ([Math]::Round($_, 0)) }
          $row_vm.DiskGBUsed = $vmview.Storage.PerDatastoreUsage | measure uncommitted -sum | % { ($_.sum / 1GB) } | % { [math]::Round($_, 1) }
          $row_vm.VirtualMedia = $vmview.Config.Hardware.Device | ? { $_.DeviceInfo.Label -match "DVD|flop" } | % { $_.Connectable } | % { $_.Connected } | ? { $_ -eq $True } | Select -f 1 | % { "TRUE" }
          $row_vm.vHardware = $vmview.Config.Version -replace "vmx-"
          $row_vm.VmHost = $VmHost.name
          $row_vm.EsxiVersion = $VmHost.Config.Product.Version
          $row_vm.Folder = $Folder.Name
          $row_vm.ResourcePool = $ResourcePools | ? { $_.moref -eq $vmview.ResourcePool } | % { $_.name }
          ### ResourcePool may error with multiple vcenters              
          $row_vm.vcFolderPath = GetvCenterFolderPath $vmview
          $row_vm.ResourcePath = GetvCenterResourcePath $vmview
          #$row_vm.Datacenter = $row_vm.vcFolderPath.split("\")[1]
          $row_vm.Cluster = $Cluster.Name
          $row_vm.MoRef = $vmview.Moref
          $row_vm.vCenter = $vmview.Client.ServiceUrl.Split("/")[2]
          
          ### end of vmview select statement, however some fields below . look for row_vm

          
          #append row_vm for output below
          
          #### screen output ends here. Export-Excel only from this point.


          ##### BEGIN vNETWORKAdapter_OUTPUT this VMVIEW Output#####
          Foreach ($vEth in $VirtualEthernetCardDEVICE)
          {
               
               $row_vEth = "" | Select vmNetworkAdapter, Type, VM, vmUuid, PortGroup, "Switch", VLAN, MacAddress, Connected, StartsConnected, Status, vCenter 
               
               #Get $vswitch from $VmHost for this $vmview 
               $row_vEth.IP = $row_GuestNet.IpAddress
               $row_vEth.Type = $vEth.GetType().Name -replace "virtual"
               $row_vEth.Mask = $row_GuestNet.Mask
               $row_vEth.DomainName = $row_GuestNet.DomainName 
               $row_vEth.SearchDomain = $row_GuestNet.SearchDomain
               $row_vEth.vmNetworkAdapter = $vEth.DeviceInfo.Label
               $row_vEth.VM = $vmview.name
               $row_vEth.vmUuID = $vmview.Summary.Config.uuid
               $row_vEth.PortGroup = $vEth.DeviceInfo.Summary
               $row_vEth.MacAddress = $vEth.MacAddress
               $row_vEth.Connected = $vEth.Connectable.Connected
               $row_vEth.StartsConnected = $vEth.Connectable.StartConnected
               $row_vEth.Status = $vEth.Connectable.Status
               $vSwitch_thisLoop = $VmHost.Config.Network.Portgroup | ? { $_.Spec.Name -eq $vEth.DeviceInfo.Summary }
               $row_vEth.VLAN = $vswitch_thisLoop.Spec.VlanId
               $row_vEth.Switch = $vswitch_thisLoop.Spec.VswitchName
               $row_vEth.vCenter = $row_vm.vCenter
               
               $row_vm.ONvSwitch = !! $vSwitch_thisLoop ##True if present, false not present
               
               #lookup vdPorgroup
               if ($row_vEth.PortGroup -match "DVSwitch:")
               {
                    $vdPG = $vdPortgroup | ? { $_.Key -eq $vEth.Backing.Port.PortgroupKey }
                    $row_vEth.PortGroup = $vdPortgroup | ? { $_.Key -eq $vEth.Backing.Port.PortgroupKey } | % { $_.Summary.Name }
                    $row_vEth.VLAN = $vdpg.Config.DefaultPortConfig.Vlan.VlanId
                    $row_vEth.Switch = $vdSwitches | ? { $_.Moref -eq $vdPG.Config.DistributedVirtualSwitch } | % { $_.Summary.Name }
                    $row_vm.ONvdSwitch = $TRUE
               }
               
               $vNETWORKAdapter_OUTPUT += $row_vEth
               
          }
          
          #"verify HcxEligible"
          $HcxEligible = Switch ($True)
          {
               { ! [version]$row_vm.EsxiVersion -ge [version]"5.5" } { "EsxiVersion=$($EsxiVersion)" }
               { ! [int]$row_vm.vHardware -ge 8 }                    { "vHardware=$($row_vm.vHardware)" }
               { ! $row_vm.VirtualMedia -ne $True }                  { "VirtualMedia=$($row_vm.VirtualMedia)" }
               { ! $row_vm.DiskRdmPhysical -ne $True }               { "DiskRdmPhysical=$($row_vm.DiskRdmPhysical)" }
               { ! $row_vm.DiskShared -ne $True }                    { "DiskShared=$($row_vm.DiskShared)" }
               { ! $row_vm.ONvSwitch -ne $True }                     { "ONvSwitch=$($row_vm.ONvSwitch)" }
          }
          
          $row_vm.HcxEligible = !($HcxEligible) -eq $True | % { [string]$_ }
          $row_vm.HcxDisqualifier = $HcxEligible -join "; "
          
          #append row_vm for output below
          $vmInfo_OUTPUT += $row_vm
          ########### END VMViews vmInfo loops  ##########
          
          ########### Begin Disk VMDK within $VMView ##########
          #vDISK_OUTPUT #### This may be missing paravirtual
          $Controllers = $VMView.Config.Hardware.Device | where { $_.DeviceInfo.Label -match "SCSI|ide" }
          $vDisks = $VMView.Config.Hardware.Device | ? { $_.DeviceInfo.Label -match "disk" }
          foreach ($vDisk in $vDisks)
          {
               #controller key: $Controllers | select key -Exp  DeviceInfo
               # $vdisk $vdisk.ControllerKey and $vdisk.Key
               #Get Controller for this Disk
               $Controller = $Controllers | ? { $vDisk.ControllerKey -eq $_.Key }
               $ds = $Datastores | ? { $_.Moref -eq $vDisk.Backing.Datastore }
               #Define psobject 
               $VirtualDisk = "" | Select VM, Disk, DiskMode, DiskType, DiskShared, BackingUuid, 
                                        ControllerType, ControllerSharedBus, Controller,
                                        SCSI_ID, Thin, Split, DiskGB, DiskGbUsed,
                                        IoShares, IoPriority, IoLimit, IoReservation, Datastore, DatastoreType, 
                                        DatastoreShared, VmMoref, DiskFile, vmUuID, vCenter
               $VirtualDisk.VM = $VMview.Name
               $VirtualDisk.vCenter = $row_vm.vCenter # $vmview.Client.ServiceUrl.Split("/")[2]
               $VirtualDisk.vmUUID = $vmview.config.Uuid
               $VirtualDisk.Controller = $Controller.DeviceInfo.Label
               $VirtualDisk.ControllerType = $Controller.DeviceInfo.Summary
               $VirtualDisk.ControllerSharedBus = $Controller.SharedBus
               $VirtualDisk.Disk = $vDisk.DeviceInfo.Label
               $VirtualDisk.Thin = $vDisk.Backing.ThinProvisioned -eq 1 | % { $_.tostring() }
               $VirtualDisk.Split = $vDisk.Backing.Split -ne 0
               $VirtualDisk.SCSI_ID = "$($Controller.BusNumber):$($vDisk.UnitNumber)"
               $VirtualDisk.DiskFile = $vDisk.Backing.FileName
               $VirtualDisk.DiskShared = $vDisk.Backing.Sharing
               $VirtualDisk.BackingUuid = $vDisk.Backing.Uuid
               $VirtualDisk.DiskGb = [math]::Round($vDisk.CapacityInBytes / 1GB, 1)
               $VirtualDisk.Datastore = $ds.Name
               $VirtualDisk.DatastoreType = $ds.Summary.Type
               $VirtualDisk.DatastoreShared = $ds.Summary.MultipleHostAccess
               $VirtualDisk.VmMoRef = $VMview.MoRef
               $VirtualDisk.IoShares = $vDisk.StorageIOAllocation.Shares.Shares
               $VirtualDisk.IoPriority = $vDisk.StorageIOAllocation.Shares.Level
               $VirtualDisk.IoLimit = $vDisk.StorageIOAllocation.Limit
               $VirtualDisk.IoReservation = $vDisk.StorageIOAllocation.Reservation
               $VirtualDisk.DiskMode = $vDisk.Backing.DiskMode
               $VirtualDisk.DiskType = $(
                    if ($vDisk.Backing -match "DiskFlat")
                    {
                         "Flat"
                    }
                    ElseIf ($null -ne (Get-Member -InputObject $vDisk.Backing -Name compatibilityMode))
                    {
                         ### need to verify ###
                         "Raw{0}" -f (Get-Culture).TextInfo.ToTitleCase(($vDisk.Backing.compatibilityMode -replace "mode"))
                    }
               )
               ### DiskGbUsed calculation begin ##
               # Filter LayoutEx Disk item that corresponds to this VirtualDisk
               $vmviewLayoutExDisk = $VMview.LayoutEx.Disk | ?{ $_.Key -eq $vDisk.Key }
               # Filter FileKeys that correspond to the LayoutEx -> File items for this VirtualDiski
               $DiskChain = $vmviewLayoutExDisk.Chain | ?{ $_ -is [VMware.Vim.VirtualMachineFileLayoutExDiskUnit] }
               $VirtualDisk.DiskGbUsed = $DiskChain | %{ $_.FileKey } | %{ $intFileKey = $_; $VMview.LayoutEx.File | ?{ ($_.Key -eq $intFileKey) -and ($_.Type -eq "diskExtent") } } | Measure-Object -Sum Size | % { [Math]::Round($_.Sum / 1GB, 1) }
               ### DiskGbUsed calculation End ##
               $vDISK_OUTPUT += $VirtualDisk
          } #End vDISKs

          ########### END Disk VMDK within $VMView ##########
          
          ########### BEGIN VMview Guest Network Config ########### 
          Foreach ($GuestNet in $vmview.Guest.Net)
          {    
               $row_GuestNet = "" | Select VM, MacAddress, Type, IpAddress, VLAN, Connected, Mask, Portgroup, "Switch", DomainName, SearchDomain, vmUUID, vCenter
               
               $this_vNETWORKAdapter_OUTPUT = $vNETWORKAdapter_OUTPUT | ? { $_.MacAddress -eq $GuestNet.MacAddress } 

               $row_GuestNet.VM = $row_vm.vm
               $row_GuestNet.Portgroup = $GuestNet.Network
               $row_GuestNet.IpAddress = $GuestNet.IpAddress -join ", "
               $row_GuestNet.MacAddress = $GuestNet.MacAddress
               $row_GuestNet.Connected = $GuestNet.Connected
               $row_GuestNet.Mask = $GuestNet.IpConfig.IpAddress.PrefixLength -join ", "
               $row_GuestNet.DomainName = $GuestNet.DnsConfig.DomainName
               $row_GuestNet.SearchDomain = $GuestNet.DnsConfig.SearchDomain -join ", "
               $row_GuestNet.vmUUID = $row_vm.uuid
               $row_GuestNet.vCenter = $row_vm.vCenter
               $row_GuestNet.VLAN = $this_vNETWORKAdapter_OUTPUT.VLAN 
               $row_GuestNet.Type = $this_vNETWORKAdapter_OUTPUT.Type 
               $row_GuestNet.Switch = $this_vNETWORKAdapter_OUTPUT.Switch
          
               #don't output, put in vNETWORKAdapter_OUTPUT
               $vmIP_OUTPUT += $row_GuestNet
               
          }
          ########## END VMview Guest Network Config ###########
          
          
     } # End ForEach ($VMView in $VMViews)

     
     ##### stop if -VM  Param specified
     if ($vm  ){
          #print to screen then quit
          $vmInfo_OUTPUT ;
          if ( $ExportExcelDEFAULT -ne $True ) 
          {  exit }
     }     
     
     
     
     ########### Begin VmHosts, vSwitches, and standard Portgroups ##########     
     Foreach ($VmHost in $VmHosts)
     {
          $Cluster = $VmHost.parent
          $vCenterServiceURL = $VmHost.Client.ServiceURL
          $ClusterName = $Clusters | ? { $_.Moref -eq $Cluster } | ? { $_.Client.ServiceURL -eq $vCenterServiceURL } | % { $_.name }
          
          $row_VmHost = "" | Select VmHost, IP, NICs, HBAs, VmotionIp, VmotionEnabled, VmotionVnic, Product, Version, LicenseVersion, Build, LastBoot, PowerState, ConnectionState,
                                          Vendor, Serial, Model, MemGB, "MemUsed%", MemUsedGB, MaxEvcMode, CPU,
                                          CPUModel, CPUMhz, CpuCores, CpuThreads, "CpuUsage%",
                                          vcFolderPath, VMs, Datastores, Cluster, MoRef, UuID, vCenter
          
          $row_VmHost.VmHost = $VmHost.Name
          $row_VmHost.MaxEvcMode = $Vmhost.Summary.MaxEVCModeKey
          $row_VmHost.Product = $vmhost.Config.Product.FullName
          $row_VmHost.IP = $VmHost.Summary.ManagementServerIp
          $row_VmHost.UuID = $vmhost.Summary.Hardware.Uuid
          $row_VmHost.NICs = $VmHost.Summary.Hardware.NumNics
          $row_VmHost.HBAs = $VmHost.Summary.Hardware.NumHbas
          $row_VmHost.Build = [int]$VmHost.Config.Product.Build
          $row_VmHost.Version = $VmHost.Config.Product.Version
          $row_VmHost.LicenseVersion = [string]$VmHost.Config.Product.LicenseProductVersion
          $row_VmHost.LastBoot = ($VmHost.Runtime.BootTime.DateTime)
          $row_VmHost.PowerState = $VmHost.Runtime.PowerState
          $row_VmHost.ConnectionState = $VmHost.Runtime.ConnectionState
          $row_VmHost.VmotionEnabled = $VmHost.Capability.StorageVMotionSupported
          $row_VmHost.VmotionVnic = ($VmHost.Config.Vmotion.NetConfig | % { $_.SelectedVnic.split("-") | select -l 1 }) -join ","
          $row_VmHost.VmotionIp = $VmHost.Config.Vmotion.IpConfig.IpAddress -join ","
          $row_VmHost.Vendor = $VmHost.Summary.Hardware.Vendor
          $row_VmHost.Model = $VmHost.Summary.Hardware.Model -replace "\s+", " "
          $row_VmHost.MemGB = $VmHost.Summary.Hardware.MemorySize / 1GB | % { [math]::Round($_, 0) }
          $row_VmHost."MemUsed%" = [decimal]($VmHost.Summary.QuickStats.OverallMemoryUsage / $VmHost.Summary.Hardware.MemorySize ) * 100000000 | % { [math]::Round($_,1) }
          $row_VmHost.MemUsedGB = [decimal]($VmHost.Summary.QuickStats.OverallMemoryUsage / 1kb) | % { [math]::Round($_) }
          $row_VmHost.CPUModel = $VmHost.Summary.Hardware.CPUModel -replace "\s+", " "
          $row_VmHost.CPUMhz = $VmHost.Summary.Hardware.CPUMhz
          $row_VmHost.CPU = $VmHost.Summary.Hardware.NumCpuPkgs
          $row_VmHost.CpuCores = $VmHost.Summary.Hardware.NumCpuCores
          $row_VmHost.CpuThreads = $VmHost.Summary.Hardware.NumCpuThreads
          $row_VmHost.Serial = $VmHost.Summary.Hardware.OtherIdentifyingInfo | where { $_.IdentifierType.Key -eq "ServiceTag" } | % { $_.IdentifierValue } | out-string | % { $_.trim() -replace "\s+", "," }
          $row_VmHost."CpuUsage%" = ($VmHost.Summary.QuickStats.OverallCpuUsage / ($VmHost.Summary.Hardware.CpuMhz * $VmHost.Summary.Hardware.NumCpuCores) * 100).ToString("#,0.##")
          $row_VmHost.Cluster = $ClusterName
          $row_VmHost.Datastores = $VmHost.Datastore.Count
          $row_VmHost.vcFolderPath = GetvCenterFolderPath $VmHost
          #$row_VmHost.Datacenter = $row_VmHost.vcFolderPath.Split("\\")[1]
          $row_VmHost.VMs = $VmHost.VM.count
          $row_VmHost.MoRef = $VmHost.Moref
          $row_VmHost.vCenter = $VmHost.Client.ServiceUrl.Split("/")[2]
          $VmHost_OUTPUT += $row_VmHost
          
          
          #### STANDARD vSwitches BEGIN and Portgroups within VmHosts loop
          #### first lookup of vSwitches for this host. Get-view required for QueryHints for CDP -- BUt does not have VLAN
          Foreach ($vswitch_info in $VmHost.Config.Network.Vswitch)
          {
               ### Foreach vswitch in vss.NetworkConfig.vSwitch
               #for ($i=0 ; $i -lt $vss.NetworkConfig.vSwitch.Spec.Count ; $i++ )
               #{ 
               $row_vs = "" | Select Name, vSwitch, VmHost, MTU, Uplinks, NumPortgroups, PortGroups, Ports, PortsUsed,
                                          NicTeamingPolicy, Promiscuous, ForgedTransmits, MacChanges,
                                          ReversePolicy, NotifySwitch, RollingOrder, FailureCriteria, NicOrderActive, NicStandby,
                                          DiscoveryProtocol, DiscoveryOperation, Cluster, vCenter
               
               $row_vs.Name = $vswitch_info.Name
               $row_vs.vSwitch = $vswitch_info.Name
               $row_vs.VmHost = $VmHost.name
               #$row_vs.Datacenter = $row_VmHost.Datacenter
               $row_vs.Cluster = $ClusterName
               $row_vs.vCenter = $row_VmHost.vCenter
               $row_vs.PortGroups = $vswitch_info.Portgroup -replace "key-vim.host.PortGroup-" -join ", "
               $row_vs.numPortGroups = $vswitch_info.Portgroup.Count
               $row_vs.Ports = $vswitch_info.NumPorts
               $row_vs.PortsUsed = $vswitch_info.NumPorts - $vswitch_info.NumPortsAvailable
               $row_vs.Mtu = $vswitch_info.Mtu
               
               $row_vs.Uplinks = ($vswitch_info.Pnic | ? { $_ } | % { $_.split("-")[$_.split("-").Count - 1].trim() }) -join ","
               #$vswitch_info.Pnic; exit
               $row_vs.DiscoveryProtocol = $vswitch_info.Spec.Bridge.LinkDiscoveryProtocolConfig.Protocol
               $row_vs.DiscoveryOperation = $vswitch_info.Spec.Bridge.LinkDiscoveryProtocolConfig.Operation
               $row_vs.Promiscuous = $vswitch_info.Spec.Policy.Security.AllowPromiscuous
               $row_vs.ForgedTransmits = $vswitch_info.Spec.Policy.Security.ForgedTransmits
               $row_vs.MacChanges = $vswitch_info.Spec.Policy.Security.MacChanges
               $row_vs.NicTeamingPolicy = $vswitch_info.Spec.Policy.NicTeaming.Policy
               $row_vs.ReversePolicy = $vswitch_info.Spec.Policy.NicTeaming.ReversePolicy
               $row_vs.NotifySwitch = $vswitch_info.Spec.Policy.NicTeaming.NotifySwitches
               $row_vs.RollingOrder = $vswitch_info.Spec.Policy.NicTeaming.RollingOrder
               $row_vs.FailureCriteria = $vswitch_info.Spec.Policy.NicTeaming.FailureCriteria
               $row_vs.NicOrderActive = $vswitch_info.Spec.Policy.NicTeaming.NicOrder.ActiveNic -join ", "
               $row_vs.NicStandby = $vswitch_info.Spec.Policy.NicTeaming.NicOrder.StandbyNic -join ", "
               $vSWITCH_OUTPUT += $row_vs
               
               ####### Begin Standard Portgroups #######
               Foreach ($Portgroup in $VmHost.config.Network.Portgroup)
               {
                    #$Portgroup is only a key
                    $row_vPG = "" | Select Portgroup, vSwitch, NicOrder, VmHost, VLAN, Promiscuous, MacChanges,
                                                ForgedTransmits, TrafficShaping, NicTeaming, ReversePolicy, NicStandby,
                                                NotifySwitch, Offload, CsumOffload, TcpSegmentation, ZeroCopyXmit, Key, vCenter
                    
                    #find Portgroup object
                    ### $vdPG = $vdPortgroup | ? { $_.Key -eq $vEth.Backing.Port.PortgroupKey }
                    #Ex: key-vim.host.PortGroup-Management Private -- split key from name and rejoin remainder
                    $row_vPG.Portgroup = $Portgroup.Spec.Name
                    $row_vPG.vSwitch = $Portgroup.Spec.VswitchName
                    $row_vPG.VmHost = $VmHost.Name
                    $row_vPG.VLAN = $Portgroup.Spec.VlanID
                    $row_vPG.Promiscuous = $Portgroup.ComputedPolicy.Security.AllowPromiscuous
                    $row_vPg.MacChanges = $Portgroup.ComputedPolicy.Security.MacChanges
                    $row_vPg.ForgedTransmits = $Portgroup.ComputedPolicy.Security.ForgedTransmits
                    $row_vPg.TrafficShaping = $Portgroup.ComputedPolicy.ShapingPolicy.Enabled
                    $row_vPg.NicTeaming = $Portgroup.ComputedPolicy.NicTeaming.Policy
                    $row_vPg.ReversePolicy = $Portgroup.ComputedPolicy.NicTeaming.ReversePolicy
                    $row_vPg.NicOrder = $Portgroup.ComputedPolicy.NicTeaming.NicOrder.ActiveNic -join ", "
                    $row_vPg.NicStandby = $Portgroup.ComputedPolicy.NicTeaming.NicOrder.StandbyNic -join ", "
                    $row_vPg.NotifySwitch = $Portgroup.ComputedPolicy.NicTeaming.NotifySwitches
                    $row_vPG.Offload = ($Portgroup.ComputedPolicy.OffloadPolicy | gm -Type:Properties | % { $_.Name } | % { $Portgroup.ComputedPolicy.OffloadPolicy."$_" }) -join " " | % { $_ -contains $false } | % { $_ -eq $false }
                    $row_vPg.CsumOffload = $Portgroup.ComputedPolicy.OffloadPolicy.CsumOffload
                    $row_vPg.TcpSegmentation = $Portgroup.ComputedPolicy.OffloadPolicy.TcpSegmentation
                    $row_vPg.ZeroCopyXmit = $Portgroup.ComputedPolicy.OffloadPolicy.ZeroCopyXmit
                    $row_vPg.Key = $Portgroup.Key
                    $row_vPg.vCenter = $row_vmhost.vCenter # $VmHost.Client.ServiceUrl.split("/")[2]
                    
                    $vPORTGROUP_OUTPUT += $row_vPG
               } #end Foreach Portgroup
               #}#end $vss.NetworkConfig standard switch loop
          } ### end vSwitch Loop
          
          $vSWITCH_OUTPUT = $vSWITCH_OUTPUT #| Sort-Object VmHost
          #### standard vSwitches END ####
          
          
          
          ###### BEGIN pNIC per Host (not per vSwitch) BEGN to get  CDP ######
          $NetworkSystem = Get-View $VmHost.ConfigManager.NetworkSystem #REQUIRED for Hints CDP. This function recovers v and vd switches
          Foreach ($pnic in $VmHost.Config.Network.Pnic)
          {
               $row_pnic = "" | select pNIC, VmHost, Switch, SpeedMb, FullDuplex, MacAddress, SRiovEnabled, SRiovActive, WakeOnLan, Driver, Bus, Slot, Vendor,
                                             ObservedIP_CDP, ObservedVLAN_CDP, IgmpEnabled_Cdp_PEER, Router_Cdp_PEER, TransparentBridge_Cdp_PEER, SourceRouteBridge_Cdp_PEER,
                                             NetworkSwitch_Cdp_PEER, Host_Cdp_PEER, Repeater_Cdp_PEER, Key, vCenter
               
               $pnicHARDWARE = $VmHost.Hardware.PciDevice | ? { $_.id -eq $pnic.Pci }
               $pnicSRIOV = $VmHost.Config.PciPassthruInfo | ? { $_.id -eq $pnic.Pci }
               
               $sw = $null
               $sw = $vSwitch_output | ? { $_.Uplinks -match $pnic.Device } #use -match because values are not an array
               if (! $sw)
               {
                    $sw = $vdSwitch_output | ? { $_.Uplinks -match $pnic.Device } #use -match because values are not an array
               }
               
               #hints retrieve CDP info
               #$ERRORACTIONPREFERENCE = "Ignore" #disable errors for disconnected VmHosts
               #if ( $NetworkSystem | gm -Name queryhint_ ) #skip queryhint if not exist {
                    $hint = $NetworkSystem.QueryNetworkHint($pnic.Device)  
               #}     
               #$ERRORACTIONPREFERENCE = "SilentlyContinue" #disable errors for disconnected VmHosts
               #match pnic from VmHost for more detail
               $row_pnic.VmHost = $VmHost.Name
               $row_pnic.pNIC = $pnic.Device
               $row_pnic.MacAddress = $pnic.mac
               $row_pnic.SpeedMb = if ($pnic.Spec.LinkSpeed.SpeedMB) { $pnic.Spec.LinkSpeed.SpeedMB }
               else { "Auto" }
               $row_pnic.FullDuplex = if ($pnic.spec.LinkSpeed.Duplex -eq $true) { "TRUE" }
               $row_pnic.Switch = $sw.Name | Group-Object | % { $_.Name }
               $row_pnic.ObservedIP_CDP = if ([string]$hint.Subnet.IpSubnet -notmatch "System.Object") { $hint.Subnet.IpSubnet }
               $row_pnic.ObservedVLAN_CDP = if ([string]$hint.Subnet.VlanID -notmatch "System.Object") { $hint.Subnet.VlanID }
               $row_pnic.IgmpEnabled_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.IgmpEnabled
               $row_pnic.Router_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.Router
               $row_pnic.TransparentBridge_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.TransparentBridge
               $row_pnic.SourceRouteBridge_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.SourceRouteBridge
               $row_pnic.NetworkSwitch_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.NetworkSwitch
               $row_pnic.Host_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.Host
               $row_pnic.Repeater_Cdp_PEER = $hint.ConnectedSwitchPort.DeviceCapability.Repeater
               $row_pnic.WakeOnLan = $pnic.WakeOnLanSupported
               $row_pnic.Driver = $pnic.Driver
               $row_pnic.Bus = $pnicHARDWARE.Bus
               $row_pnic.Slot = $pnicHARDWARE.Slot
               $row_pnic.Vendor = ($pnicHARDWARE.VendorName -replace "\(r\)|\(tm\)"), $pnicHARDWARE.DeviceName -Join " "
               $row_pnic.SrIovEnabled = $pnicSRIOV.SriovEnabled
               $row_pnic.SrIovActive = $pnicSRIOV.SriovActive
               $row_pnic.Key = $pnic.Key
               $row_pnic.vCenter = $row_vmhost.vCenter
               $pNIC_CDP_OUTPUT += $row_pnic
          }
          
          $pNIC_CDP_OUTPUT = $pNIC_CDP_OUTPUT | sort-object VmHost, pNic
          ###### END pNIC per Host 
          
          
          
          ##### vHBA Begin vHBA_OUTPUT ######
          Foreach ($hba in $vmhost.Config.StorageDevice.HostBusAdapter)
          {
               $row_hba = "" | select vmHost, Device, Type, Status, Vendor, Driver, Bus, PCI, vCenter
               
               $row_hba.Device = $hba.Device
               $row_hba.vmhost = $vmhost.name
               $row_hba.Status = $hba.Status
               $row_hba.Driver = $hba.Driver
               $row_hba.Vendor = $hba.Model
               $row_hba.Bus = [string]$hba.Bus
               $row_hba.PCI = [string]$hba.PCI
               $row_hba.Type = $hba.Key.Split(".")[2].Split("-")[0]
               $row_hba.vCenter = $row_vmhost.vCenter
               
               $vHBA_OUTPUT += $row_hba
          }
          
          
          ##### Begin VMKERNEL vmk ######
          Foreach ($vmk in $vmhost.Config.Network.Vnic)
          {
               $row_vmk = "" | select vmkernel, vmHost, EnabledServices, MacAddress, NetStack, Switch,
                                           Portgroup, MTU, NetStackInstanceKey, DCHP, IP, Mask, vCenter
               
               $EnabledServices = $vmhost.config.VirtualNicManagerInfo.NetConfig | ? { $_.SelectedVnic -match $vmk.Device }
               
               $row_vmk.vmHost = $vmhost.name
               $row_vmk.EnabledServices = $EnabledServices.NicTYPE -Join ", "
               $row_vmk.MacAddress = $vmk.Spec.Mac
               $row_vmk.vmkernel = $vmk.Device
               $row_vmk.NetStack = $vmk.Spec.NetStackInstanceKey
               $row_vmk.MTU = $vmk.Spec.MTU
               $row_vmk.NetStackInstanceKey = $vmk.Spec.NetStackInstanceKey
               $row_vmk.DCHP = $vmk.Spec.IP.DHCP -Join ", "
               $row_vmk.IP = $vmk.Spec.IP.IpAddress -Join ", "
               $row_vmk.Mask = $vmk.Spec.IP.SubnetMask -join ", "
               $row_vmk.vCenter = $row_vmhost.vCenter
               
               #Get dv or standard switch and portgroup
               if ($vmk.Spec.Portgroup)
               {
                    $row_vmk.Portgroup = $vmk.Spec.Portgroup
                    $row_vmk.Switch = $vPortgroup_OUTPUT | ? { $_.key -match $vmk.Spec.Portgroup } | % { $_.vSwitch }
                    $row_vmk.Switch = $row_vmk.Switch | group-object | % { $_.Name.Trim() }
               }
               else
               {
                    $row_vmk.Portgroup = $vdPortgroups | ? { $_.key -eq $vmk.Spec.DistributedVirtualPort.PortgroupKey } | % { $_.Name }
                    $vdportgroup_this = $vdPortgroup_OUTPUT | ? { $_.key -eq $vmk.spec.DistributedVirtualPort.PortgroupKey }
                    $row_vmk.Switch = $vdportgroup_this.vdSwitch
               }
               
               $VMKernelAdapters_OUTPUT += $row_vmk
          }
          
          
          
     } ### End $VmHosts
     
     
     
     ########### CLUSTERS begin ##########
     Foreach ($c in ($Clusters | sort-object name))
     {
          #define psobject
          $row_Cluster = "" | Select Cluster, EvcMode, DrsEnabled, DrsVmotion, ConcurrentVmotion, DpmBehavior, DpmEnabled,
                                           Cores, Threads, vCpusAlloc, CpuRatio,
                                           "CPU%", "Mem%", "N+1MEM%", "N+1CPU%", MemGB, EffectiveMemGB, VMs-On,
                                           VmHosts, VmToHostRatio, Datastores, StorageCapacityGB, StorageFreeGB, "StorageUsed%",
                                           vcFolderPath, MoRef, vCenter
          
          ### agregate correlate data 
          $VmHostsThisCluster = $VmHosts | ? { $_.moref -in $c.host }
          $VMsThisCluster = $VMviews | ? { $_.moref -in $VmHostsThisCluster.vm }
          $cDatastores_thisLoop = $Datastores | ? { $_.moref -in $c.Datastore }
          
          #$ErrorActionPreference = "SilentlyContinue" #disable errors due to divide by zero
          $row_Cluster.Cluster = $c.Name
          $row_Cluster.EvcMode = $c.Summary.CurrentEVCModeKey
          $row_Cluster.DrsVmotion = $c.Configuration.DrsConfig.DefaultVmBehavior
          $row_Cluster.DrsEnabled = $c.Configuration.DrsConfig.Enabled -eq $True | % { $_.tostring() }
          $row_Cluster.DpmBehavior = $c.ConfigurationEx.DpmConfigInfo.DefaultDpmBehavior
          $row_Cluster.DpmEnabled = $c.ConfigurationEx.DpmConfigInfo.Enabled -eq $True
          $row_Cluster.ConcurrentVmotion = $c.ConfigurationEx.DrsConfig.VmotionRate
          $row_Cluster.Cores = $c.Summary.NumCpuCores
          $row_Cluster.vCpusAlloc = $VMsThisCluster.Config.Hardware.NumCpu | Measure -sum | % { $_.sum }
          $row_Cluster.CpuRatio = (($row_Cluster.vCpusAlloc + 0.001) / ($row_Cluster.Cores + 0.001)) | % { [math]::Round($_, 0) } | % { [string]$_ + ":1" }
          $row_Cluster.Threads = $c.Summary.NumCpuThreads
          $row_Cluster."CPU%" = if ($c.Summary.TotalCPU ){ [decimal](($c.Summary.EffectiveCpu / $c.Summary.TotalCPU)) * 100 | % { [math]::Round($_, 0) } }
          $row_Cluster."Mem%" = if ($c.Summary.TotalMemory) { [decimal](($c.Summary.EffectiveMemory / $c.Summary.TotalMemory)) * 100 | % { [math]::Round($_, 0) } }
          $row_Cluster.MemGB = [math]::Round($c.Summary.TotalMemory / 1GB, 0)
          $row_Cluster.EffectiveMemGB = ($c.Summary.EffectiveMemory / 1GB) | % { [math]::Round($_, 2) }
          $row_Cluster."N+1MEM%" = $c.Summary.TotalMemory * ($VmHostsThisCluster.Count - 1) / 1GB | % { [math]::Round($_, 1) }
          $row_Cluster."N+1CPU%" = $c.Summary.TotalCPU * ($VmHostsThisCluster.Count - 1) / 1GB | % { [math]::Round($_, 1) }
          $row_Cluster."VMs-On" = $VMsThisCluster.count
          $row_Cluster.VmHosts = $c.host.count
          $row_Cluster.VmToHostRatio = [string]($VMsThisCluster.Count) + ":" + ($VmHostsThisCluster.Count)
          $row_Cluster.StorageCapacityGB = ($cDatastores_thisLoop.summary.Capacity | measure -sum).sum / 1GB
          $row_Cluster.StorageFreeGB = ($cDatastores_thisLoop.summary.FreeSpace | measure -sum).sum / 1GB | % { [math]::Round($_, 0) }
          $row_Cluster."StorageUsed%" = ($row_Cluster.StorageCapacityGB - $row_Cluster.StorageFreeGB) / $row_Cluster.StorageCapacityGB | % { [math]::Round($_, 2) }
          $row_Cluster.Datastores = $cDatastores_thisLoop.Count
          $row_Cluster.vCenter = $c.Client.ServiceUrl.split("/")[2]
          $row_Cluster.vcFolderPath = GetvCenterFolderPath $c
          #$row_Cluster.Datacenter = $row_Cluster.vcFolderPath.Split("\")[1]
          $row_Cluster.MoRef = $c.Moref
          
          $CLUSTER_OUTPUT += $row_Cluster
          #$ErrorActionPreference = "Continue" #enable errors 
     }
     ########## cluster end ########## 
     
     
     ########### vCenter Licenses BEGIN #########
     $ServiceInstances = GET-VIEW ServiceInstance
     #Must invoke the object to retrieve data.
     $ServiceInstances | Out-null
     #$DashboardLicenses_OUTPUT = $LicenseManagers.Licenses | group Name | Select @{N="License" ; E={ $_.Name  }}, @{N="Licenses" ; E={ [string]$_.group.Used +"/"+ $_.group.Total }  }
     
     ForEach ($ServiceInstance in $ServiceInstances)
     {
          #Must invoke the object to retrieve data.
          #$ServiceInstance | Out-null          
          $LicenseManagers = GET-VIEW ($ServiceInstance).Content.LicenseManager
          
          Foreach ($LicenseMan in $LicenseManagers.Licenses)
          {
               $row_lic = $LicenseMan | select @{ N = "vCenter"; E = { $ServiceInstance.Client.ServiceUrl.Split("/")[2] } },
                                                       LicenseKey, EditionKey, Name, Total, Used, CostUnit
               
               if ($ScrubLicenseKey -and $LicenseMan.LicenseKey)
               {
                    $row_lic.LicenseKey = ($LicenseMan.LicenseKey.Split("-")[0 .. ($LicenseMan.LicenseKey.Split("-").count - 2)] -join "-") + "-scrubbed"
               }
               
               $vLICENSE_OUTPUT += $row_lic
          }
     }
     ########### vCenter Licenses END #########
     
     
     ########### DATASTORES $DATASTORE_OUTPUT BEGIN ##########
     Foreach ($ds in $Datastores)
     {
          $row_ds = "" | Select Datastore, Status, Version, Type, Address, VmfsUpgradable,
                                     CapacityGB, FreeGB, "Used%", Shared,
                                     VMs, VmHosts, Clusters, url, vcFolderPath, MoRef, vCenter
          $ClustersThisDatastore = $Clusters | ? { $ds.moref -in $clusters.Datastore }
          $row_ds.Datastore = $ds.Name
          $row_ds.Status = $ds.OverallStatus
          $row_ds.Version = $ds.Info.Vmfs.Version
          $row_ds.VmfsUpgradable = $ds.Info.Vmfs.VmfsUpgradable -eq $true | % { $_.ToString() }
          #$row_ds.SSD = $ds.Info.Vmfs.SSD
          $row_ds.Type = $ds.Summary.Type
          $row_ds.Shared = $ds.Info.Vmfs.Local -eq $False
          $row_ds.CapacityGB = $ds.Summary.Capacity / 1GB
          $row_ds.FreeGB = $ds.Summary.FreeSpace / 1GB | % { [math]::round($_, 1) }
          $row_ds."Used%" = ($ds.Summary.Capacity - $ds.Summary.FreeSpace) / $ds.Summary.Capacity | % { [math]::Round($_ * 100, 1) }
          $row_ds.VMs = $ds.vm.count
          $row_ds.VmHosts = $ds.Host.Count
          $row_ds.Clusters = $ClustersThisDatastore.Name -join ", "
          $row_ds.url = $ds.Info.url
          $row_ds.vcFolderPath = GetvCenterFolderPath $ds
          $row_ds.Address = if ($ds.Info.Nas.RemoteHost)
          { [string]$ds.Info.Nas.RemoteHost + $ds.Info.Nas.RemotePath }
          else { $ds.info.vmfs.extent.Diskname }
          $row_ds.MoRef = $ds.Moref
          $row_ds.vCenter = $ds.Client.ServiceUrl.Split("/")[2]
          $DATASTORE_OUTPUT += $row_ds
     }
     ########### DATASTORES $DATASTORE_OUTPUT BEGIN ##########
     
     
     ########### DATACENTERS Begin ############
     Foreach ($dc in $Datacenters)
     {
          $row_dc = "" | Select Datacenter, Clusters, VmHosts, VMs, Cores, Datastores,
                                     StorageCapacityGB, StorageFreeGB, 'StorageUsed%', Moref, vCenter
          
          $clusters_thisDC = $CLUSTER_OUTPUT | ? { $_.Datacenter -eq $dc.name }
          
          $row_dc.Datacenter = $dc.Name
          $row_dc.Clusters = $clusters_thisDC.Count
          $row_dc.VmHosts = $clusters_thisDC.VmHosts | measure -sum | % { $_.sum }
          $row_dc.VMs = $clusters_thisDC.'VMS-ON' | measure -sum | % { $_.sum }
          $row_dc.Cores = $clusters_thisDC.Cores | measure -sum | % { $_.sum }
          $row_dc.Datastores = $clusters_thisDC.Datastores | measure -sum | % { $_.sum }
          $row_dc.StorageCapacityGB = $clusters_thisDC.StorageCapacityGB | measure -sum | % { $_.sum }
          $row_dc.StorageFreeGB = $clusters_thisDC.StorageFreeGB | measure -sum | % { $_.sum }
          $row_dc.'StorageUsed%' = $clusters_thisDC.'StorageUsed%' | measure -Average | % { $_.Average }
          $row_dc.Moref = $dc.Moref
          $row_dc.vCenter = $dc.Client.ServiceUrl.Split("/")[2]
          
          
          $DATACENTERS_OUTPUT += $row_dc
     }
     ########### DATACENTERS END ############


     ##### END Error Collection DISABLE
     $ErrorActionPreference = "Continue"
     $ErrorEnd = $Error.Count - 1
     $DebugLOG_OUTPUT = $Error[ $ErrorStart .. $ErrorEnd] | `
          SELECT  @{N="Line"; E= {$_.ScriptStackTrace.Split("`n")[0].Trim() -replace ".* Line" | % { [int]$_ }  }} , 
                  @{N="Exception" ; E={ $_.Exception | out-string | % { $_.Trim() } }   }    | `
                  GROUP Line | select @{N="Line" ; E= { $_.Name }}, Count, @{N="Error" ; E = { $_.Group[0].Exception  }}
     
     #############################
     ###### BEGIN Dashboard ######
     #This array contains list of variables to output to Dashboard and Excel Sheets.
     $OUTPUT_Variables = "Dashboard_OUTPUT
                         vmInfo_OUTPUT
                         HcxEligible_OUTPUT
                         vDisk_OUTPUT
                         vNetworkadapter_OUTPUT
                         vmIP_OUTPUT
                         vSwitch_OUTPUT
                         vPortgroup_OUTPUT
                         vdSwitch_OUTPUT
                         vdportgroup_OUTPUT
                         ResourcePool_vApp_OUTPUT
                         Datacenters_OUTPUT
                         Cluster_OUTPUT
                         Datastore_OUTPUT
                         vmHost_OUTPUT
                         pNIC_CDP_OUTPUT
                         VMKernelAdapters_OUTPUT
                         vHba_OUTPUT
                         vLicense_OUTPUT
                         DebugLOG_OUTPUT".Split("`n").trim()
     
     #add HcxEligible count to Dashboard
     $hcxTRUE = ($vmInfo_OUTPUT | ? { $_.HcxEligible -eq $TRUE } | Measure).Count
     $row_Dashboard = "" | Select Collection, Count
     $row_Dashboard.Collection = "HcxEligible"
     $row_Dashboard.Count = [string]$hcxTRUE + " of " + $vmInfo_OUTPUT.Count
     $HcxEligible_OUTPUT = $row_Dashboard
     
     $Dashboard_OUTPUT = @()
     Foreach ($var in $OUTPUT_Variables[1 .. 99]) #skip first two OUTPUT because it is the dashboard.
     {
          $row_Dashboard = "" | Select Collection, Count
          #(gv -name $var) |ft
          
          $row_dashboard.Collection = $var -replace "_OUTPUT"
          $row_dashboard.Count = (gv -name $var).Value.Count
          $Dashboard_OUTPUT += $row_Dashboard
     }
     
     #Remove HcxEligible_OUTPUT from Excel output because it is a dashboard only item
     $OUTPUT_Variables = $OUTPUT_Variables | ? { $_ -ne "HcxEligible_OUTPUT" }
     
     ###### END DASHBOARD ######
     
     
     ###############################################
     ###### BEGIN output file to excel or CSV ######
     #assign parameter $FilenamePath if provided
     If ($FilenamePath)
     {
          $Path = $FilenamePath #user supplied path
     }
     else
     {
          #date string for generated filename for win/linux
          $d = get-date -Format yyyy-MM-dd_hh-mm-ss
          $Path = "$env:USERPROFILE\Desktop\$d - $($row_dc.vCenter) - vInventory`.xlsx"
     }
     
     
     WRITE-HOST -Foreground Green " EXPORTING TO FILE. This could take a few moments. Exporting ..."
     #Export-Excel all data
     if ($ExportCsvIfNoExcel -OR $CsvExport)
     {
          #Disable ExportExcel
          $ExportExcelDEFAULT = $False
          
          $i = 0
          $Output_Dir = "$env:USERPROFILE\Desktop\vmInfo_$d"
          New-Item -Path $Output_Dir -ItemType:Directory -Force -ErrorAction:SilentlyContinue | Out-Null
          WRITE-HOST -FOREGROUND WHITE $Output_Dir
          
          #Export only $OUTPUT_Variables 
          foreach ($OUTPUT in $OUTPUT_Variables)
          {
               $i++
               $Sheetname = ([string]$i).PadLeft(2,'0') + "-" + ((gv -Name $output).Name -replace "_OUTPUT") + ".csv"
               $Path = $Output_Dir + "\$Sheetname"
               
               (gv $OUTPUT).Value | Export-CSV  $Path -NoTypeInformation
          }
          
          start $Output_Dir
          exit
     }
     

     if ($ExportExcelDEFAULT)
     {
          Write-Verbose -Message "`n STOPWATCH LAPSED SECONDS: $($Stopwatch.Elapsed.TotalSeconds)"
          foreach ($OUTPUT in $OUTPUT_Variables)
          {
               $sheetname = (gv -Name $output).Name -replace "_OUTPUT"
               #(gv -Name $output)
               (gv $OUTPUT).Value | Export-Excel -Path $Path -WorksheetName $sheetname -AutoSize -FreezeTopRow -AutoFilter -BoldTopRow -FreezeFirstColumn -Verbose:$False
          }
     }
     else
     {
          exit
     }
     
     ###### END output  #####
     
     write-host $path
     start $path
     
     ###### END Dashboard and Export-EXCEL ######
     
     Write-Verbose -Message "`n STOPWATCH LAPSED SECONDS: $($Stopwatch.Elapsed.TotalSeconds)"
     
}  ###end of END
