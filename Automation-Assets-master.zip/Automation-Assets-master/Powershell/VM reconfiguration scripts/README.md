# VM reconfiguration scripts #
A set of script to assit with tasks like joining and disjoining machines to a domain controller, changing VM timezone, changing windows passwords, mounting a cdrom to a VM, replacing nics.
