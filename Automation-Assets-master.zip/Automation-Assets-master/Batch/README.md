# Microsoft Batch Assets #
