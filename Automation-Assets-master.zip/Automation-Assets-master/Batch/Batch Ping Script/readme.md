## Batch ping scripts ##

Batch Script to ping a set of IPs that you specify in the batch file.

Can be used for quick testing of IP connectivity for VMs after they are migration.
