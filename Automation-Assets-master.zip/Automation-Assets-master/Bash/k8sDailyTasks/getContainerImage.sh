#!/bin/bash

for i in $(kubectl get pod -n $1 | awk '{print $1}'| sed "1d")
do

  echo "--- EXECUTING ${i}---"

  kubectl describe pod/${i} -n $1 | grep "Image:"

  #sleep 1

done
