#!/bin/bash

for i in $(kubectl get pod | awk '{print $1}'| sed "1d")
do
	echo "--- EXECUTING ${i}---"

	if [ $(kubectl get pod/${i} | awk 'FNR==2 {print $2}' | sed 's/..$//') -gt 1 ]

	then

		kubectl logs --tail=100 ${i} -c $(eval sed 's/......$//' <<< ${i})

	else

		kubectl logs --tail=100 ${i}

	fi
done > allPods.log
