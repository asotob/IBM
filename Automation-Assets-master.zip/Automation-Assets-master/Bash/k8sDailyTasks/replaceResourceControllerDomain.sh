#!/bin/bash

if [ $# -ne 1 ]
then 
	echo "please provide one namespace"
else 
	for i in $(kubectl get rc -n $1 | awk '{print $1}'| sed "1d")
	do

	  echo "--- EXECUTING ${i}---"
	  
	  kubectl get -o yaml rc/${i} -n $1 | sed 's/oldDomain/newDomain/g' \
	  | kubectl replace -f -
	  
	done
fi 
