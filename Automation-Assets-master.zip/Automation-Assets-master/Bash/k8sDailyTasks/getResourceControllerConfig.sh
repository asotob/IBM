#!/bin/bash
for i in $(kubectl get rc -n $1 | awk '{print $1}'| sed "1d")
do
	
  echo "--- EXECUTING ${i}---"
	
  if [ -d "namespace-$1" ]
  then
      kubectl get -o yaml  rc/${i} -n $1 > namespace-$1/$i.yaml
  else
      mkdir namespace-$1
      kubectl get -o yaml rc/${i} -n $1 > namespace-$1/$i.yaml
  fi
done

