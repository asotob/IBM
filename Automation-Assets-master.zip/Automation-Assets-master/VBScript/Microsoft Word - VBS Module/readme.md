## Microsoft Word - VBS Module ## 

Various VBS scripts for Microsoft word that helps with document formatting.

__Note:__ You need to enable developer tab in Microsoft word so you are able to import the VBS file to the document. Also the word document need to be saved fd.or Macro enable
