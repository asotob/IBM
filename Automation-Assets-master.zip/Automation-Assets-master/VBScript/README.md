# Microsoft VBScript Assets #
